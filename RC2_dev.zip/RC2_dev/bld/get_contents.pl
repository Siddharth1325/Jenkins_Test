use strict;
use File::Copy::Recursive qw(dircopy);

my $projFolder = $ARGV[0];
chdir($projFolder) or die "Failed to perform chdir to $projFolder: $!\n";
my $version = "";

if (-e "packages.config") {
	open PKG_CFG, "<", "packages.config" or die "Failed to open packages.config: $!\n";
	while (<PKG_CFG>) {
		if ($_ =~  m/ServiceLink_Common_JS/) {
			my @params = split(/ /, $_);
			foreach my $param (@params) {
				if ($param =~ m/version=/) {
					$version = substr($param, 9, rindex($param, "\"") - 9 );					
				}
			}
		}
	}
	if ($version ne "") {
		print "Getting ServiceLink_Common_JS version=$version into workspace\n";
		if (-e "N:\\ServiceLink_Common_JS.$version" ) {
			system("cmd /c start /i /min /wait xcopy /S /C /I /Y /R /Q N:\\ServiceLink_Common_JS.$version\\content $projFolder");
		}
		else {
			die "ServiceLink_Common_JS.$version not found on NuGet repo\n";
		}
	}
}