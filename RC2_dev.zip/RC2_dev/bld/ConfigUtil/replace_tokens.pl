use strict;
use XML::Simple;
use File::Copy::Recursive qw(dircopy);
use File::Path qw(remove_tree);
use File::Find;

my $objEnvXml = new XML::Simple;
my $strTokenXML = "configTokens.xml";
my ($araEnvHashList, $araSkipSections, $araSkipLines);
my ($strPropName, $strPropValue);
if (-e $strTokenXML) {
	my $hshEnvData = $objEnvXml->XMLin($strTokenXML,KeyAttr => ['environment'], ForceArray => ['skipSection','skipLine']);
	$araEnvHashList = $hshEnvData->{environment};
}
foreach my $hshEnvData (@$araEnvHashList) {
	my $strEnvName = $hshEnvData->{name};
	print "====================\n";
	print "Building $strEnvName\n";
	print "====================\n";
	
	dircopy("../../pkg/config_temp", "../../pkg/temp");
	
	my $araCommonProps = $hshEnvData->{property};
	foreach my $hshProperty (@$araCommonProps) {
#		$configUtil::strReplacedFlg = "false";
		$strPropName = $hshProperty->{name};
		$strPropValue = $hshProperty->{value};
#		print "name=$strPropName; value=$strPropValue\n";
		
		find( \&findreplace, "../../pkg/temp");
		
		#while replacing, the find sub creates backup file (.bac) for every file 
		#modified. Delete all '.bac' files once replacement is done.
		find(
			sub {
				return unless (/\.bac$/i);
				unlink $_;
			}, "../../pkg/temp");
		
	}
	dircopy("../../pkg/temp", "../../pkg/configs/$strEnvName");
	remove_tree("../../pkg/temp")
}

rename_files();

#remove_tree("../../pkg/config_temp")

sub rename_files {
	find( \&remove_ext, "../../pkg/configs");
}

sub genConfigFile { my ($strConfigFile, $hshSkipSections, $hshSkipLines) = @_;
	open INPUT, '<', "../../pkg/config_temp/$strConfigFile" or die "Can't open for read:$!";
	open OUTPUT, '>', "../../pkg/temp/$strConfigFile" or die "Can't open for write:$!";
	
	my $strSkipSection = "false";
	my $strSkipLine = "false";
	while(<INPUT>) {
		if ($strSkipSection eq "false") {
			$strSkipLine = "false";
		}
						
		foreach my $hshSection (@$hshSkipSections) {
			my $strSectionName = $hshSection->{name};
			if ($_ =~ m/\<$strSectionName\>/) {
				$strSkipLine = "true";
				$strSkipSection = "true";
			}						
		}
		
		foreach my $hshSkipLine (@$hshSkipLines) {
			my $strSkipLineName = $hshSkipLine->{name};
			if ( $_ =~ m/$strSkipLineName/) {
				$strSkipLine = "true";
			}						
		}
						
		print OUTPUT $_ unless ( $strSkipLine eq "true" );
		
		foreach my $hshSection (@$hshSkipSections) {
			my $strSectionName = $hshSection->{name};
			if ($_ =~ m/\<\/$strSectionName\>/) {
				$strSkipLine = "false";
				$strSkipSection = "false";
			}	
		}		
	}
	
	close INPUT;
	close OUTPUT;
}

sub findreplace { my $strElemToSearch = $_;	
	if (-f $strElemToSearch) {
		local @ARGV = $strElemToSearch; 
		local $^I = '.bac'; # Invoke inplace editing and automatically creates .bac of each file being edited
		while( <> ) {
			if( s/%$strPropName%/$strPropValue/g ) {
#				$strReplacedFlg = "true"; #if property is replaced, set replace flag to make sure all tokens are used
				print;
			}		
			else {
				print;
			}
		}
	}
	return 1;
}

sub remove_ext { my $strFileName = $_;	
	if (-f $strFileName) {
#		print "strFileName=$strFileName\n";
		my $origFileName = $strFileName;
		$strFileName=~s/.env//;
		rename($origFileName, $strFileName);
#		print "strFileName=$strFileName; origFileName=$origFileName\n";
	}
	return 1;
}