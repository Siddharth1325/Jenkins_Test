﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;
using BusinessSvcImpl.SvcImpl.SpaAcc;
using BusinessSvcImpl.DataObjects.SpaAccountingService.Dto;
using BusinessSvcImpl.DataObjects.SpaAccounting.Dto;
using CommonLib.Context;
using Delegate.SpaAcc;
using Dom = DomainModel.Accounting;
using AdminClientSvc = Admin.ServiceProxy.ClientService;
using AdminInvestorSvc = Admin.ServiceProxy.InvestorService;
using AdminProductSvc = Admin.ServiceProxy.ProductService;
using InspSvc = Inspections.ServiceProxy.InspectionSvc;
using VMSvc = Vendor.ServiceProxy.VendorService;
using Admin.ServiceProxy.ReferenceService;
using ServiceLink.Billing.Configuration;
using ServiceLink.Billing.Implementation;
using ServiceLink.Billing.Definition;

namespace FieldService.Billing.ART
{
    public class ARTBillingEngine : BillingEngineBase
    {
        private const string _OVLProductCode = "1";
        private const string _OVLProductName = "OCCUPANCY VERIFICATION LETTER";
        private const string _WorkOrderStatusGroupCode = "WOSTA";
        private const string _WorkOrderBillStatusCode = "BILL";
        private const string _WorkOrderCancellationStatusCode = "CANCEL";

        public ARTBillingEngine(BillingEngineConfig bec, int workOrderId) : base(bec)
        {
            Init(PopulateContextData(workOrderId));
        }

        public override string Id
        {
            get
            {
                return "ARTBillingEngine";
            }
        }

        public override string ApplicationName
        {
            get
            {
                return "AssetShield";
            }
        }

        private ARTBillingContextData PopulateContextData(int workOrderId)
        {
            if (workOrderId <= 0) throw new ArgumentOutOfRangeException("workOrderId");

            ARTBillingContextData contextData = new ARTBillingContextData();

            GetWorkOrderData(workOrderId, contextData);
            GetClientData(workOrderId, contextData);
            GetInvestorData(workOrderId, contextData);
            GetPricingSetting(contextData);

            return contextData;
        }

        #region GetWorkOrderData
        private void GetWorkOrderData(int workOrderId, ARTBillingContextData contextData)
        {
            GetWorkOrderResponse woResp = new SpaAccountingService().GetFullWorkOrderById(new GetWorkOrderRequest() { WorkOrderId = workOrderId });
            if (woResp == null || woResp.WorkOrder == null) throw new ArgumentOutOfRangeException("workOrderId", string.Format("Work Order with Id ({0}) can't be found", workOrderId));
            contextData.WorkOrder = woResp.WorkOrder;

            if (string.IsNullOrEmpty(contextData.WorkOrder.WorkOrderStatusGroup) || string.IsNullOrEmpty(contextData.WorkOrder.WorkOrderStatusType) ||
                    string.Compare(contextData.WorkOrder.WorkOrderStatusGroup.Trim(), _WorkOrderStatusGroupCode, true) != 0 ||
                    !(string.Compare(contextData.WorkOrder.WorkOrderStatusType.Trim(), _WorkOrderBillStatusCode, true) == 0 || string.Compare(contextData.WorkOrder.WorkOrderStatusType.Trim(), _WorkOrderCancellationStatusCode, true) == 0))
            {
                throw new ArgumentOutOfRangeException("workOrderId", string.Format("Work Order (with Id {0}) is not ready for billing", workOrderId));
            }
            else if (contextData.WorkOrder.AcctProcessedDate.HasValue && contextData.WorkOrder.AcctProcessedDate.Value > DateTime.MinValue)
            {
                throw new ArgumentOutOfRangeException("workOrderId", string.Format("Work Order (with Id {0}) has been billed already", workOrderId));
            }
            else if (contextData.WorkOrder.Order == null)
            {
                throw new ArgumentOutOfRangeException("workOrderId", string.Format("Order for Work Order (with Id {0}) can't be found", workOrderId));
            }
            else if (contextData.WorkOrder.Product == null)
            {
                throw new ArgumentOutOfRangeException("workOrderId", string.Format("Product for Work Order (with Id {0}) can't be found", workOrderId));
            }
            else if (contextData.WorkOrder.Order.Loan == null)
            {
                throw new ArgumentOutOfRangeException("workOrderId", string.Format("Loan for Work Order (with Id {0}) can't be found", workOrderId));
            }
            else if (contextData.WorkOrder.WorkOrderItems == null || contextData.WorkOrder.WorkOrderItems.Count == 0)
            {
                throw new ArgumentOutOfRangeException("workOrderId", string.Format("Work Order Items for Work Order (with Id {0}) can't be found", workOrderId));
            }

            contextData.IsCancellation = string.Compare(contextData.WorkOrder.WorkOrderStatusType, _WorkOrderCancellationStatusCode, true) == 0 ||
                (contextData.WorkOrder.Order.Cancellations != null && contextData.WorkOrder.Order.Cancellations.Count > 0);
            contextData.IsOVLProduct = string.Compare(contextData.WorkOrder.Product.ProductCode, _OVLProductCode, true) == 0 || string.Compare(contextData.WorkOrder.Product.ProductName, _OVLProductName, true) == 0;

            if (string.Compare(contextData.WorkOrder.WorkOrderStatusType.Trim(), _WorkOrderCancellationStatusCode, true) != 0 && !contextData.WorkOrder.AssignedVendorId.HasValue && !contextData.IsOVLProduct)
            {
                throw new ArgumentOutOfRangeException("workOrderId", string.Format("Work Order (with Id {0}) is not assigned to any vendor", workOrderId));
            }

            InspSvc.VPRSignageResult vprSignageResult = null;
            using (InspSvc.InspServiceClient proxy = new InspSvc.InspServiceClient())
            {
                InspSvc.GetVPRSignageResultResponse response = proxy.GetVPRSignageResult(new InspSvc.GetVPRSignageResultRequest() { workOrderId = workOrderId });
                vprSignageResult = response != null ? response.SignageResult : null;
            }
            //if (vprSignageResult == null) throw new ArgumentOutOfRangeException("workOrderId", string.Format("VPR Signage Result for Work Order (with Id {0}) can't be found", workOrderId));
            contextData.VPRSignageResult = vprSignageResult;

            IsSignageFeeBilledResponse isBillResp = new SpaAccountingService().GetIsSignageFeeBilledByWorkOrder(new IsSignageFeeBilledRequest() { WorkOrderId = workOrderId });
            contextData.IsPreviouslySignedFee = isBillResp.IsSignageFeeBilled;

        }
        #endregion

        #region GetClientData
        private void GetClientData(int workOrderId, ARTBillingContextData contextData)
        {
            AdminClientSvc.SubClientProfile subClientProfile = null;
            using (AdminClientSvc.ClientServiceClient proxy = new AdminClientSvc.ClientServiceClient())
            {
                AdminClientSvc.GetSubClientResponse response = proxy.GetSubClient(new AdminClientSvc.GetSubClientRequest() { SubClientProfileId = contextData.WorkOrder.Order.Loan.SubClientProfileId.Value, MasterRequired = true, scCollection = AdminClientSvc.SubClientCollectionEnumeration.None });
                subClientProfile = response != null ? response.subClient : null;
            }
            if (subClientProfile == null) throw new ArgumentOutOfRangeException("workOrderId", string.Format("Sub Client Profile for Work Order (with Id {0}) can't be found", workOrderId));
            contextData.SubClientProfile = subClientProfile;

            AdminClientSvc.MasterClientProfile masterClientProfile = null;
            using (AdminClientSvc.ClientServiceClient proxy = new AdminClientSvc.ClientServiceClient())
            {
                AdminClientSvc.GetMasterClientResponse response = proxy.GetMasterClient(new AdminClientSvc.GetMasterClientRequest() { MasterClientProfileId = contextData.SubClientProfile.MasterClientProfileId, mcCollection = AdminClientSvc.MasterClientCollectionEnumeration.None });
                masterClientProfile = response != null ? response.Client : null;
            }
            if (masterClientProfile == null) throw new ArgumentOutOfRangeException("workOrderId", string.Format("Master Client Profile for Work Order (with Id {0}) can't be found", workOrderId));
            contextData.MasterClientProfile = masterClientProfile;

            AdminClientSvc.ClientAccounting clientAccounting = null;
            using (AdminClientSvc.ClientServiceClient proxy = new AdminClientSvc.ClientServiceClient())
            {
                AdminClientSvc.GetClientAccountingRequest request = !string.IsNullOrEmpty(ApplicationContext.Instance.UserContext.TenantHierarchyId) ?
                    new AdminClientSvc.GetClientAccountingRequest() { clientProfileId = contextData.SubClientProfile.SubClientProfileId, TenantIdentifier = ApplicationContext.Instance.UserContext.TenantHierarchyId } :
                    new AdminClientSvc.GetClientAccountingRequest() { clientProfileId = contextData.SubClientProfile.SubClientProfileId, ApplicationId = ApplicationContext.Instance.UserContext.ApplicationId };
                AdminClientSvc.GetClientAccountingResponse response = proxy.GetClientAccountingInfo(request);
                clientAccounting = response.ClientAccounting != null ? response.ClientAccounting : null;
            }
            if (clientAccounting == null) throw new ArgumentOutOfRangeException("workOrderId", string.Format("Client Accounting for Work Order (with Id {0}) can't be found", workOrderId));
            contextData.ClientAccounting = clientAccounting;

            AdminClientSvc.ClientProduct clientProduct = null;
            using (AdminClientSvc.ClientServiceClient client = new AdminClientSvc.ClientServiceClient())
            {
                AdminClientSvc.GetClientProductsResponse response = client.GetMasterClientProducts(new AdminClientSvc.GetClientProductsRequest() { ClientId = contextData.SubClientProfile.MasterClientProfileId });
                clientProduct = response != null ? response.ClientProducts.Where(item => item.ProductId.Equals(contextData.WorkOrder.Product.ProductId)).FirstOrDefault() : null;
            }
            if (clientProduct == null) throw new ArgumentOutOfRangeException("workOrderId", string.Format("Client Product for Work Order (with Id {0}) can't be found", workOrderId));
            contextData.ClientProduct = clientProduct;
        }
        #endregion

        #region GetInvestorData
        private void GetInvestorData(int workOrderId, ARTBillingContextData contextData)
        {
            AdminInvestorSvc.InvestorProfile investorProfile = null;
            using (AdminInvestorSvc.InvestorServiceClient proxy = new AdminInvestorSvc.InvestorServiceClient())
            {
                investorProfile = proxy.GetInvestorProfileByIdentifier(contextData.WorkOrder.Order.Loan.InvestorIdentifier);
            }
            if (investorProfile == null) throw new ArgumentOutOfRangeException("workOrderId", string.Format("Investor Profile for Work Order (with Id {0}) can't be found", workOrderId));
            contextData.InvestorProfile = investorProfile;            
        }
        #endregion

        #region GetPricingSetting
        private void GetPricingSetting(ARTBillingContextData contextData)
        {
            AdminClientSvc.ClientPrice clientPricing = null;
            try
            {
                using (AdminClientSvc.ClientServiceClient proxy = new AdminClientSvc.ClientServiceClient())
                {
                    if (!contextData.IsCancellation)
                    {
                        AdminClientSvc.GetPricingResponse response = proxy.GetClientPricing(new AdminClientSvc.GetPricingRequest()
                        {
                            InvestorId = contextData.InvestorProfile.InvestorProfileId,
                            ProductId = contextData.SwitchedProductId.HasValue ? contextData.SwitchedProductId.Value : contextData.WorkOrder.Product.ProductId,
                            SubClientProfileId = contextData.SubClientProfile.SubClientProfileId,
                            PropertyAddressInfo =
                                new AdminClientSvc.PropertyAddress()
                                {
                                    County = contextData.WorkOrder.Order.Loan.ValidCountyName,
                                    State = contextData.WorkOrder.Order.Loan.ValidStateCode,
                                    ZipCode = contextData.WorkOrder.Order.Loan.ValidZipCode
                                }
                        });
                        clientPricing = response != null ? response.ClientPricing : null;
                    }
                    else
                    {
                        AdminClientSvc.GetClientCancellationPricingResponse response = proxy.GetClientCancellationPricing(new AdminClientSvc.GetClientCancellationPricingRequest()
                        {
                            InvestorId = contextData.InvestorProfile.InvestorProfileId,
                            ProductId = contextData.SwitchedProductId.HasValue ? contextData.SwitchedProductId.Value : contextData.WorkOrder.Product.ProductId,
                            SubClientProfileId = contextData.SubClientProfile.SubClientProfileId,
                            TenantIdentifier = ApplicationContext.Instance.UserContext.TenantHierarchyId,
                            PropertyAddressInfo = null
                        });
                        clientPricing = response != null ? response.ClientPricing : null;
                    }
                }
            }
            catch (FaultException<AdminClientSvc.FSCustomFaultContainer> fsFault)
            {
                throw new BillingException(string.Format("Client Pricing for Sub Client (with Id {0})/Investor (with Id {1}) can't be found due to error {2}",
                    contextData.SubClientProfile.SubClientProfileId, contextData.InvestorProfile.InvestorProfileId,
                    fsFault.Detail != null ? fsFault.Detail.Reason : fsFault.Message), BillingExceptionType.DataIssue);
            }
            if (clientPricing == null) throw new BillingException(string.Format("Client Pricing for Sub Client (with Id {0})/Investor (with Id {1}) is not found",
                                                                  contextData.SubClientProfile.SubClientProfileId, contextData.InvestorProfile.InvestorProfileId), BillingExceptionType.DataIssue);
            contextData.ClientPricing = clientPricing;

            if (contextData.WorkOrder.AssignedVendorId.HasValue)
            {
                VMSvc.VendorPricing vendorPricing = null;
                try
                {
                    using (VMSvc.VMServiceClient proxy = new VMSvc.VMServiceClient())
                    {
                        VMSvc.GetVendorPricingRequest request = !string.IsNullOrEmpty(ApplicationContext.Instance.UserContext.TenantHierarchyId) ?
                            new VMSvc.GetVendorPricingRequest()
                            {
                                TenantIdentifier = ApplicationContext.Instance.UserContext.TenantHierarchyId,
                                ProductId = contextData.SwitchedProductId.HasValue ? contextData.SwitchedProductId.Value : contextData.WorkOrder.Product.ProductId,
                                Requestdate = contextData.WorkOrder.Order.RequestedDate,
                                SubClientId = contextData.SubClientProfile.SubClientProfileId,
                                VendorProfileId = contextData.WorkOrder.AssignedVendorId.Value,
                                PropertyAddressInfo = new VMSvc.PropertyAddress()
                                {
                                    CountyName = contextData.WorkOrder.Order.Loan.ValidCountyName,
                                    StateCode = contextData.WorkOrder.Order.Loan.ValidStateCode,
                                    ZipCode = contextData.WorkOrder.Order.Loan.ValidZipCode
                                }
                            } :
                            new VMSvc.GetVendorPricingRequest()
                            {
                                ApplicationId = ApplicationContext.Instance.UserContext.ApplicationId,
                                ProductId = contextData.SwitchedProductId.HasValue ? contextData.SwitchedProductId.Value : contextData.WorkOrder.Product.ProductId,
                                Requestdate = contextData.WorkOrder.Order.RequestedDate,
                                SubClientId = contextData.SubClientProfile.SubClientProfileId,
                                VendorProfileId = contextData.WorkOrder.AssignedVendorId.Value,
                                PropertyAddressInfo = new VMSvc.PropertyAddress()
                                {
                                    CountyName = contextData.WorkOrder.Order.Loan.ValidCountyName,
                                    StateCode = contextData.WorkOrder.Order.Loan.ValidStateCode,
                                    ZipCode = contextData.WorkOrder.Order.Loan.ValidZipCode
                                }
                            };
                        VMSvc.GetVendorPricingResponse response = proxy.GetVendorPricing(request);
                        vendorPricing = response != null ? response.VendorPricing : null;
                    }
                }
                catch (FaultException<VMSvc.FSCustomFaultContainer> fsFault)
                {
                    throw new BillingException(string.Format("Vendor Pricing for Assigned Vendor (with Id {0}) can not found due to error {1}",
                        contextData.WorkOrder.AssignedVendorId.Value, fsFault.Reason), BillingExceptionType.DataIssue);
                }
                if (vendorPricing == null)
                    throw new BillingException(string.Format("Vendor Pricing for Assigned Vendor (with Id {0}) is not found", contextData.WorkOrder.AssignedVendorId.Value), BillingExceptionType.DataIssue);

                contextData.VendorPricing = vendorPricing;
            }
        }
        #endregion

        public override void Init(object billableEntity)
        {
            base.Init(billableEntity);
        }

        public override void CreateBillingData()
        {
            if (this.BillingContext.Successful)
            {
                ARTBillingContextData contextData = this.BillingContext.ContextData as ARTBillingContextData;
                List<Dom.OrderHierarchy> payable = (this.BillingContext.ContextData as ARTBillingContextData).IsOVLProduct ? null : CreateAccountsPayable();
                List<Dom.OrderHierarchy> receivable = CreateAccountsReceivable();
                if ((payable != null && payable.Count > 0) && (receivable != null && receivable.Count > 0))
                {
                    new AccountingBillingDelegate().SaveAPnAR(receivable, payable);
                }
                else if (payable != null && payable.Count > 0)
                {
                    new AccountingBillingDelegate().SaveAccountsPayable(payable);
                }
                else if (receivable != null && receivable.Count > 0)
                {
                    new AccountingBillingDelegate().SaveAccountsReceiveable(receivable);
                }
            }
            else
            {
                CommonLib.Logging.LogError(BillingContext.FailureReason);
                throw new BillingException(BillingContext.FailureReason, BillingExceptionType.SystemFailure);
            }
        }

        #region Generate AP and AR
        protected virtual List<Dom.OrderHierarchy> CreateAccountsPayable()
        {
            ARTBillingContextData dataContext = this.BillingContext.ContextData as ARTBillingContextData;
            if (dataContext.WorkOrder != null && !dataContext.WorkOrder.AssignedVendorId.HasValue) return null;
            
            var payLst = new List<Dom.OrderHierarchy>();

            new AccountingBillingDelegate().GetSetOrderHierarchyByFK(dataContext.WorkOrder.OrderId.Value, null, null, null, null);

            Dom.OrderHierarchy payable = new AccountingBillingDelegate().GetSetOrderHierarchyByFK(dataContext.WorkOrder.OrderId.Value, null,
                                                        dataContext.WorkOrder.WorkOrderId, null, null);

            Dom.AccountsPayableDetail payableDetail = new Dom.AccountsPayableDetail();
            payableDetail.OrderHierarchyId = payable.OrderHierarchyId;
            payableDetail.APStatusGroup = "APSG";
            payableDetail.APStatusType = "RDY2BILL";
            payableDetail.BaseTotalCost = BillingContext.BaseCost.HasValue ? BillingContext.BaseCost.Value : 0.00m;
            payableDetail.BaseCostPerUnit = payableDetail.BaseTotalCost;
            payableDetail.FinalTotalCost = this.BillingContext.FinalCost.HasValue ? BillingContext.FinalCost.Value : CalculateCompound(BillingContext.BaseCost, BillingContext.CostAdjustments);
            payableDetail.Quantity = 1;
            payableDetail.UnitsGroup = "APUN";
            payableDetail.UnitsType = "APUN1";
            payableDetail.AcctProcessedDate = DateTime.UtcNow;

            Dom.AccountsPayableTrace firstTrace = new Dom.AccountsPayableTrace();
            firstTrace.CostSelectionReason = BillingContext.BaseCostSelectionReason;
            firstTrace.StartingCost = BillingContext.BaseCost;
            payableDetail.AccountsPayableTraces.Add(firstTrace);

            if (BillingContext.CostAdjustments != null && BillingContext.CostAdjustments.Count > 0)
            {
                decimal prevCost = BillingContext.BaseCost.HasValue ? BillingContext.BaseCost.Value : 0.00m;

                foreach (Adjustment costAdj in BillingContext.CostAdjustments)
                {
                    if (costAdj.AdjustmentGroupCode != null)
                    {
                        Dom.AccountsPayableTrace payableTrace = new Dom.AccountsPayableTrace();
                        payableTrace.StartingCost = prevCost;
                        payableTrace.CostAdjustment = decimal.Round(prevCost * costAdj.AdjustPercentage / 100.0m, 2, MidpointRounding.AwayFromZero);
                        prevCost = decimal.Round(prevCost * (1 + costAdj.AdjustPercentage / 100.0m), 2, MidpointRounding.AwayFromZero);
                        payableTrace.CostAdjustmentTypeGroup = costAdj.AdjustmentGroupCode;
                        payableTrace.CostAdjustmentType = costAdj.AdjustmentTypeCode;
                        payableTrace.CostSelectionReason = GetReferenceElementName(costAdj.AdjustmentGroupCode, costAdj.AdjustmentTypeCode);
                        payableDetail.AccountsPayableTraces.Add(payableTrace);
                    }
                }
            }

            payable.AccountsPayableDetails.Add(payableDetail);

            Dom.DisputePayableAdjustmentHistory payableAdjHist = new Dom.DisputePayableAdjustmentHistory();
            payableAdjHist.OrderHierarchyId = payable.OrderHierarchyId;
            payableAdjHist.Quantity = 1;
            payableAdjHist.AgreedUnitCost = payableDetail.FinalTotalCost;
            payableAdjHist.VendorFee = payableDetail.FinalTotalCost;
            payableAdjHist.RecordNumber = 1;
            payableAdjHist.HistoryDate = DateTime.UtcNow;
            payableAdjHist.AdjustmentHistoryRecordGroup = "ADJHIST";
            payableAdjHist.AdjustmentHistoryRecordType = "ORIG";
            payable.DisputePayableAdjustmentHistorys.Add(payableAdjHist);

            payLst.Add(payable);

            return payLst;
        }

        private decimal CalculateCompound(decimal? start, Collection<Adjustment> adjustments)
        {
            if (!start.HasValue) return 0.00m;
            if (adjustments == null || adjustments.Count == 0) return start.Value;

            decimal temp = start.Value;
            foreach (Adjustment adj in adjustments)
            {
                temp = decimal.Round(temp * (1 + adj.AdjustPercentage / 100.00m), 2, MidpointRounding.AwayFromZero);
            }
            return temp;
        }

        protected virtual List<Dom.OrderHierarchy> CreateAccountsReceivable()
        {
            ARTBillingContextData dataContext = this.BillingContext.ContextData as ARTBillingContextData;
            var recLst = new List<Dom.OrderHierarchy>();

            new AccountingBillingDelegate().GetSetOrderHierarchyByFK(dataContext.WorkOrder.OrderId.Value, null, null, null, null);

            Dom.OrderHierarchy receivable = new AccountingBillingDelegate().GetSetOrderHierarchyByFK(dataContext.WorkOrder.OrderId.Value, null,
                                                        dataContext.WorkOrder.WorkOrderId, null, null);

            Dom.AccountsReceivableDetail receivableDetail = new Dom.AccountsReceivableDetail();
            receivableDetail.OrderHierarchyId = receivable.OrderHierarchyId;
            receivableDetail.ARStatusGroup = "ARSG";
            receivableDetail.ARStatusType = "NEW";
            receivableDetail.BasePricePerUnit = BillingContext.BasePrice.HasValue ? BillingContext.BasePrice.Value : 0.00m;
            receivableDetail.BaseTotalPrice = BillingContext.BasePrice.HasValue ? BillingContext.BasePrice.Value : 0.00m;
            receivableDetail.FinalTotalPrice = BillingContext.FinalPrice.HasValue ? BillingContext.FinalPrice.Value : CalculateCompound(BillingContext.BasePrice, BillingContext.PriceAdjustments);
            receivableDetail.Quantity = 1;
            receivableDetail.UnitsGroup = "ARUN";
            receivableDetail.UnitsType = "ARUN1";
            receivableDetail.AcctProcessedDate = DateTime.UtcNow;

            Dom.AccountsReceivableTrace firstTrace = new Dom.AccountsReceivableTrace();
            firstTrace.PriceSelectionReason = BillingContext.BasePriceSelectionReason;
            firstTrace.StartingPrice = BillingContext.BasePrice;
            receivableDetail.AccountsReceivableTraces.Add(firstTrace);

            if (BillingContext.PriceAdjustments != null && BillingContext.PriceAdjustments.Count > 0)
            {
                decimal prevPrice = BillingContext.BasePrice.HasValue ? BillingContext.BasePrice.Value : 0.00m;
                foreach (Adjustment priceAdj in BillingContext.PriceAdjustments)
                {
                    if (priceAdj.AdjustmentGroupCode != null)
                    {
                        Dom.AccountsReceivableTrace receivableTrace = new Dom.AccountsReceivableTrace();
                        receivableTrace.StartingPrice = prevPrice;
                        receivableTrace.PriceAdjustment = decimal.Round(prevPrice * priceAdj.AdjustPercentage / 100.0m, 2, MidpointRounding.AwayFromZero);
                        prevPrice = decimal.Round(prevPrice * (1 + priceAdj.AdjustPercentage / 100.0m), 2, MidpointRounding.AwayFromZero);
                        receivableTrace.PriceAdjustmentTypeGroup = priceAdj.AdjustmentGroupCode;
                        receivableTrace.PriceAdjustmentType = priceAdj.AdjustmentTypeCode;
                        receivableTrace.PriceSelectionReason = GetReferenceElementName(receivableTrace.PriceAdjustmentTypeGroup, receivableTrace.PriceAdjustmentType);
                        receivableDetail.AccountsReceivableTraces.Add(receivableTrace);
                    }
                }
            }

            receivable.AccountsReceivableDetails.Add(receivableDetail);

            Dom.DisputeReceivableAdjustmentHistory receivableAdjHist = new Dom.DisputeReceivableAdjustmentHistory();
            receivableAdjHist.OrderHierarchyId = receivable.OrderHierarchyId;
            receivableAdjHist.Quantity = 1;
            receivableAdjHist.ClientPrice = receivableDetail.FinalTotalPrice;
            receivableAdjHist.AgreedClientUnitPrice = receivableDetail.FinalTotalPrice;
            receivableAdjHist.RecordNumber = 1;
            receivableAdjHist.HistoryDate = DateTime.UtcNow;
            receivableAdjHist.AdjustmentHistoryRecordGroup = "ADJHIST";
            receivableAdjHist.AdjustmentHistoryRecordType = "ORIG";
            receivable.DisputeReceivableAdjustmentHistorys.Add(receivableAdjHist);

            recLst.Add(receivable);

            return recLst;
        }
        #endregion

        #region GetReferenceElementName
        private string GetReferenceElementName(string groupCode, string elementCode)
        {
            if (string.IsNullOrEmpty(groupCode))
                throw new ArgumentNullException(groupCode);
            else if (string.IsNullOrEmpty(elementCode))
                throw new ArgumentNullException(elementCode);

            ReferenceData rdata = null;
            using (var proxy = new ReferenceDataServiceClient())
            {
                var response = proxy.GetReferenceDataElementByCode(new GetReferenceDataElementByCodeRequest() { GroupCode = groupCode, ElementCode = elementCode });
                rdata = response != null && response.ReferenceDataElement != null ? response.ReferenceDataElement : null;
            }

            return rdata != null ? rdata.ElementName : string.Empty;
        }
        #endregion

    }
}
