﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ServiceLink.Billing.Configuration;
using ServiceLink.Billing.Definition;
using ServiceLink.Billing.Implementation;

namespace FieldService.Billing.ART
{
    public class ARTBillingContext : BillingContextBase
    {
        private ARTBillingContextData _ContextData = null;
        public override object ContextData
        {
            get
            {
                return _ContextData;
            }
            set
            {
                if (value != null && value.GetType() == ContextDataType && value.GetType() == typeof(ARTBillingContextData))
                    _ContextData = value as ARTBillingContextData;
            }
        }
    }
}
