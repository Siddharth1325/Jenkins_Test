﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Admin.ServiceProxy.ClientService;
using BusinessSvcImpl.DataObjects.SpaAccounting.Dto;
using CommonLib.Context;
using Crsf.Core;
using Crsf.Core.Inrule;
using Crsf.Core.Service;
using Crsf.Core.Interface;
using ServiceLink.Billing.Preservation.RuleModel;
using ServiceLink.Billing.Definition;
using ServiceLink.Billing.Implementation;

namespace FieldService.Billing.Preservation.Step
{
    public class PreservationBillingStep : BillingStepBase
    {
        public PreservationBillingStep(IBillingContext billingContext) : base(billingContext)
        {
        }

        public override string Id
        {
            get
            {
                return "Preservation.Billing";
            }
        }

        public override void GetStepOnlyData()
        {
            base.GetStepOnlyData();
        }

        public override bool Validate()
        {
            return base.Validate();
        }
        public override void ProcessStep()
        {
            base.ProcessStep();
            PreservationBillingContextData context = this.BillingContext.ContextData as PreservationBillingContextData;
            ProductServiceDetails vDetails = context.ProductServiceDetails;

            RuleSummary ruleSummary = new PreservationBillingStepRuleService().PreservationBillingResult(vDetails);

            if (ruleSummary.AccountsPayable.AccountDetails != null)
            {
                foreach (AccountDetails details in ruleSummary.AccountsPayable.AccountDetails.Where(r => r.Quantity > 0).Distinct().ToList())
                {
                    this.BillingContext.AccountsPayableDetails.Add(new AccountsDetail()
                    {
                        OrderId = details.OrderId,
                        VendorWorkOrderId = details.VendorWorkOrderId,
                        WorkOrderId = details.WorkOrderId,
                        WorkOrderItemId = details.WorkOrderItemId,
                        WorkOrderLineItemId = details.WorkOrderLineItemId,
                        SourceOrderId = details.SourceOrderId,
                        SourceVendorWorkOrderId = details.SourceVendorWorkOrderId,
                        SourceWorkOrderId = details.SourceWorkOrderId,
                        SourceWorkOrderItemId = details.SourceWorkOrderItemId,
                        SourceWorkOrderLineItemId = details.SourceWorkOrderLineItemId,
                        BaseTotalCost = details.BaseTotalCost,
                        BaseUnitCost = details.BaseUnitCost,
                        Quantity = details.Quantity,
                        AStatusGroup = details.AStatusGroup,
                        AStatusType = details.AStatusType,
                        FeeTypeId = details.FeeTypeId == 0 ? (Nullable<int>)null : details.FeeTypeId,
                        FeeTypeName = String.IsNullOrEmpty(details.FeeTypeName) ? null : details.FeeTypeName
                    });
                }
            }

            if (ruleSummary.AccountsReceivable.AccountDetails != null)
            {
                foreach (AccountDetails details in ruleSummary.AccountsReceivable.AccountDetails.Where(r => r.Quantity > 0).Distinct().ToList())
                {
                    this.BillingContext.AccountsReceivableDetails.Add(new AccountsDetail()
                    {
                        OrderId = details.OrderId,
                        VendorWorkOrderId = details.VendorWorkOrderId,
                        WorkOrderId = details.WorkOrderId,
                        WorkOrderItemId = details.WorkOrderItemId,
                        WorkOrderLineItemId = details.WorkOrderLineItemId,
                        SourceOrderId = details.SourceOrderId,
                        SourceVendorWorkOrderId = details.SourceVendorWorkOrderId,
                        SourceWorkOrderId = details.SourceWorkOrderId,
                        SourceWorkOrderItemId = details.SourceWorkOrderItemId,
                        SourceWorkOrderLineItemId = details.SourceWorkOrderLineItemId,
                        BaseTotalCost = details.BaseTotalCost,
                        BaseUnitCost = details.BaseUnitCost,
                        Quantity = details.Quantity,
                        AStatusGroup = details.AStatusGroup,
                        AStatusType = details.AStatusType,
                        FeeTypeId = details.FeeTypeId == 0 ? (Nullable<int>)null : details.FeeTypeId,
                        FeeTypeName = String.IsNullOrEmpty(details.FeeTypeName) ? null : details.FeeTypeName
                    });
                }
            }
            this.BillingContext.Successful = ruleSummary.Successful;
        }
    }
    public class PreservationBillingStepRuleService : BusinessRuleServiceBase
    {
        [BusinessRuleMethod(Entity = "PreservationBilling", RuleGroup = "PreservationBillingRules", RuleSet = "PreservationBillingRuleSet")]
        public RuleSummary PreservationBillingResult(ProductServiceDetails vDetails)
        {
            PreservationBilling ruleEntity = new PreservationBilling();

            ruleEntity.ProductServiceDetails = new ProductServiceDetails();

            if (vDetails != null && vDetails.Count > 0)
            {
                ruleEntity.ProductServiceDetails = vDetails;
            }
            ruleEntity.AccountsPayable = new Account();
            ruleEntity.AccountsReceivable = new Account();

            RuleSummary summary = new RuleSummary();

            IBusinessRuleResponse ruleResp = base.ExecuteRule(ruleEntity);

            summary.AccountsPayable = (ruleResp.EntityState as PreservationBilling).AccountsPayable;
            summary.AccountsReceivable = (ruleResp.EntityState as PreservationBilling).AccountsReceivable;
            summary.Successful = true;

            return summary;
        }
    }
}
