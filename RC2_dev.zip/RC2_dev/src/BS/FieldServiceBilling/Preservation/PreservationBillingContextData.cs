﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using BusinessSvcImpl.DataObjects.SpaAccounting.Dto;
using ServiceLink.Billing.Preservation.RuleModel;
using PresProxy = Pres.ServiceProxy.PresSvc;

namespace FieldService.Billing.Preservation
{
    public class PreservationBillingContextData
    {
        public PreservationBillingContextData()
        {
            IsCancellation = false;
            IsEligibleForTran32 = false;
        }

        public Application TenantApplication { get; set; }

        public bool IsCancellation { get; set; }

        public bool IsEligibleForTran32 { get; set; }

        [XmlIgnore]
        public WorkOrder WorkOrder { get; set; }

        [XmlIgnore]
        public ProductServiceDetails ProductServiceDetails { get; set; }
        
        [XmlIgnore]
        public List<PresProxy.PriceCostTraceDetails> PriceCostTraceDetails { get; set; }
    }
}
