﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Admin.ServiceProxy.ClientService;
using BusinessSvcImpl.DataObjects.SpaAccounting.Dto;
using CommonLib.Context;
using Crsf.Core;
using Crsf.Core.Inrule;
using Crsf.Core.Service;
using Crsf.Core.Interface;
using RuleModel = ServiceLink.Billing.VPR.RuleModel;
using ServiceLink.Billing.Definition;
using ServiceLink.Billing.Implementation;

namespace FieldService.Billing.VPR.Step
{
    public class VPRBillingStep : BillingStepBase
    {
        public VPRBillingStep(IBillingContext billingContext) : base(billingContext)
        {
        }

        public override string Id
        {
            get
            {
                return "VPR.Billing";
            }
        }

        public override void GetStepOnlyData()
        {
            base.GetStepOnlyData();
        }

        public override bool Validate()
        {
            return base.Validate();
        }
        public override void ProcessStep()
        {
            base.ProcessStep();
            VPRBillingContextData context = this.BillingContext.ContextData as VPRBillingContextData;
            decimal priceTracker = BillingContext.PriceTracker;
            bool? isChecksCut = context.ClientAccounting.ChecksCutonBehalfClient;
            string VPRReviewerDecision = context.VPRReviewerDecision.VPRReviewType;
            string workOrderStatus = context.WorkOrder.WorkOrderStatusType;
            List<RuleModel.VPRDetails> vprDetails = null;

            if (context.PaymentDetails != null && context.PaymentDetails.Count > 0)
            {
                vprDetails = new List<RuleModel.VPRDetails>();
                context.PaymentDetails.ForEach(det => vprDetails.Add(new RuleModel.VPRDetails()
                {
                    PaymentDetailsId = det.PaymentDetailsId,
                    Amount = det.Amount,
                    IsCreditCardPayment = det.IsCreditCardPayment,
                    IsRevenue = det.IsRevenue,
                    FeeTypeId = det.FeeTypeId,
                    FeeTypeName = String.IsNullOrEmpty(det.FeeTypeName) ? null : det.FeeTypeName
                }));
            }

            RuleModel.VPRRuleSummary ruleSummary = new VPRBillingStepRuleService().VPRBillingResult(priceTracker, isChecksCut, VPRReviewerDecision,
                workOrderStatus, vprDetails);

            this.BillingContext.APTotalAmountDue = ruleSummary.AccountsPayable.TotalAmountDue;

            if (ruleSummary.AccountsPayable.AccountsDetail != null)
            {
                foreach (RuleModel.AccountsDetail details in ruleSummary.AccountsPayable.AccountsDetail)
                {
                    this.BillingContext.AccountsPayableDetails.Add(new AccountsDetail()
                    {
                        BaseTotalCost = details.BaseTotalCost,
                        AStatusGroup = details.AStatusGroup,
                        AStatusType = details.AStatusType,
                        FeeTypeId = details.FeeTypeId == 0 ? (Nullable<int>)null : details.FeeTypeId,
                        FeeTypeName = String.IsNullOrEmpty(details.FeeTypeName) ? null : details.FeeTypeName,
                        PaymentId = details.PaymentDetailsId
                    });
                }
            }

            this.BillingContext.ARTotalAmountDue = ruleSummary.AccountsReceivable.TotalAmountDue;

            if (ruleSummary.AccountsReceivable.AccountsDetail != null)
            {
                foreach (RuleModel.AccountsDetail details in ruleSummary.AccountsReceivable.AccountsDetail)
                {
                    this.BillingContext.AccountsReceivableDetails.Add(new AccountsDetail()
                    {
                        BaseTotalCost = details.BaseTotalCost,
                        AStatusGroup = details.AStatusGroup,
                        AStatusType = details.AStatusType,
                        FeeTypeId = details.FeeTypeId == 0 ? (Nullable<int>)null : details.FeeTypeId,
                        FeeTypeName = String.IsNullOrEmpty(details.FeeTypeName) ? null : details.FeeTypeName,
                        PaymentId = details.PaymentDetailsId
                    });
                }
            }
            if (ruleSummary.CostAdjustments != null)
            {
                this.BillingContext.CostAdjustments.Add(new Adjustment()
                {
                    AdjustPercentage = ruleSummary.CostAdjustments.AdjustPercentage,
                    AdjustmentGroupCode = ruleSummary.CostAdjustments.AdjustmentGroupCode,
                    AdjustmentTypeCode = ruleSummary.CostAdjustments.AdjustmentTypeCode
                });
            }
            if (ruleSummary.PriceAdjustments != null)
            {
                this.BillingContext.PriceAdjustments.Add(new Adjustment()
                {
                    AdjustPercentage = ruleSummary.PriceAdjustments.AdjustPercentage,
                    AdjustmentGroupCode = ruleSummary.PriceAdjustments.AdjustmentGroupCode,
                    AdjustmentTypeCode = ruleSummary.PriceAdjustments.AdjustmentTypeCode
                });
            }
            this.BillingContext.Successful = ruleSummary.Successful;
        }
    }
    public class VPRBillingStepRuleService : BusinessRuleServiceBase
    {
        [BusinessRuleMethod(Entity = "VPRBilling", RuleGroup = "VPRBillingRules", RuleSet = "VPRBillingRuleSet")]
        public RuleModel.VPRRuleSummary VPRBillingResult(decimal? priceTracker, bool? isChecksCut, string vPRReviewerDecision, string workOrderStatus,
            List<RuleModel.VPRDetails> vprDetails)
        {
            RuleModel.VPRBilling ruleEntity = new RuleModel.VPRBilling();
            ruleEntity.PriceTracker = priceTracker;
            ruleEntity.IsChecksCut = isChecksCut;
            ruleEntity.VPRReviewerDecision = vPRReviewerDecision;
            ruleEntity.WorkOrderStatusType = workOrderStatus;

            ruleEntity.VPRDetails = new List<RuleModel.VPRDetails>();
            if (vprDetails != null)
            {
                foreach (RuleModel.VPRDetails details in vprDetails)
                {
                    ruleEntity.VPRDetails.Add(new RuleModel.VPRDetails()
                    {
                        PaymentDetailsId = details.PaymentDetailsId,
                        Amount = details.Amount,
                        IsCreditCardPayment = details.IsCreditCardPayment,
                        IsRevenue = details.IsRevenue,
                        FeeTypeId = details.FeeTypeId == 0 ? (Nullable<int>)null : details.FeeTypeId,
                        FeeTypeName = String.IsNullOrEmpty(details.FeeTypeName) ? null : details.FeeTypeName
                    });
                }
            }

            ruleEntity.AccountsPayable = new RuleModel.Accounts();
            ruleEntity.AccountsReceivable = new RuleModel.Accounts();
            ruleEntity.CostAdjustments = new RuleModel.Adjustments();
            ruleEntity.PriceAdjustments = new RuleModel.Adjustments();

            RuleModel.VPRRuleSummary summary = new RuleModel.VPRRuleSummary();

            IBusinessRuleResponse ruleResp = base.ExecuteRule(ruleEntity);

            summary.CostAdjustments = (ruleResp.EntityState as RuleModel.VPRBilling).CostAdjustments;
            summary.PriceAdjustments = (ruleResp.EntityState as RuleModel.VPRBilling).PriceAdjustments;
            summary.AccountsPayable = (ruleResp.EntityState as RuleModel.VPRBilling).AccountsPayable;
            summary.AccountsReceivable = (ruleResp.EntityState as RuleModel.VPRBilling).AccountsReceivable;
            summary.Successful = true;

            return summary;
        }
    }
}
