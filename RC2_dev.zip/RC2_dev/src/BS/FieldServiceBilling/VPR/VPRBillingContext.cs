﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ServiceLink.Billing.Configuration;
using ServiceLink.Billing.Definition;
using ServiceLink.Billing.Implementation;

namespace FieldService.Billing.VPR
{
    public class VPRBillingContext : BillingContextBase
    {
        private VPRBillingContextData _ContextData = null;
        public override object ContextData
        {
            get
            {
                return _ContextData;
            }
            set
            {
                if (value != null && value.GetType() == ContextDataType && value.GetType() == typeof(VPRBillingContextData))
                    _ContextData = value as VPRBillingContextData;
            }
        }
    }
}
