﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Crsf.Core;
using Crsf.Core.Inrule;
using Crsf.Core.Service;
using Crsf.Core.Interface;
using ServiceLink.Billing.Definition;
using ServiceLink.Billing.Implementation;
using RuleModel = ServiceLink.Billing.Violation.RuleModel;

namespace FieldService.Billing.Violation.Step
{
    public class DefaultPriceCalculatorStep : BillingStepBase
    {
        public DefaultPriceCalculatorStep(IBillingContext billingContext) : base(billingContext)
        {
        }

        public override string Id
        {
            get
            {
                return "Violation.DefaultPriceCalculator";
            }
        }

        public override void GetStepOnlyData()
        {
            base.GetStepOnlyData();
        }

        public override bool Validate()
        {
            return base.Validate();
        }
        public override void ProcessStep()
        {
            base.ProcessStep();
            ViolationBillingContextData context = this.BillingContext.ContextData as ViolationBillingContextData;

            int? switchedProductId = context.SwitchedProductId;
            int? subClientProfileId = context.WorkOrder.Order.Loan.SubClientProfileId;
            string validCountyName = context.WorkOrder.Order.Loan.ValidCountyName;
            string validStateCode = context.WorkOrder.Order.Loan.ValidStateCode;
            string validZipCode = context.WorkOrder.Order.Loan.ValidZipCode;
            int? investorProfileId = context.InvestorProfile.InvestorProfileId;
            int? productId = context.WorkOrder.Product.ProductId;
            decimal? rushRate = context.ClientPricing.RushRate;
            decimal? initialRate = context.ClientPricing.InitialRate;
            decimal? subsequentRate = context.ClientPricing.SubsequentRate;
            decimal? standardRate = context.ClientPricing.StandardRate;
            bool? isRushOrder = context.WorkOrder.Order.IsRushOrder;
            bool? isInitial = context.WorkOrder.Order.IsInitial;

            RuleModel.ViolationRuleSummary ruleSummary = new DefaultPriceCalculatorStepRuleService().DefaultPriceCalculatorResult(
                switchedProductId, subClientProfileId, validCountyName, validStateCode, validZipCode, investorProfileId, productId, rushRate, initialRate,
                subsequentRate, standardRate, isRushOrder, isInitial);

            if (!ruleSummary.Successful)
            {
                this.BillingContext.FailureReason = ruleSummary.FailureReason;
            }
            else if (ruleSummary.IsDirty)
            {
                this.BillingContext.BasePrice = ruleSummary.BasePrice;
                this.BillingContext.BasePriceSelectionReason = ruleSummary.BasePriceSelectionReason;
                this.BillingContext.PriceTracker = ruleSummary.PriceTracker;
            }
            this.BillingContext.Successful = ruleSummary.Successful;
        }
    }
    public class DefaultPriceCalculatorStepRuleService : BusinessRuleServiceBase
    {
        [BusinessRuleMethod(Entity = "DefaultPriceCalculator", RuleGroup = "ViolationBillingRules", RuleSet = "CalculateDefaultPrice")]
        public RuleModel.ViolationRuleSummary DefaultPriceCalculatorResult(int? switchedProductId, int? subClientProfileId, 
            string validCountyName, string validStateCode, string validZipCode, int? investorProfileId, int? productId, decimal? rushRate, decimal? initialRate,
            decimal? subsequentRate, decimal? standardRate, bool? isRushOrder, bool? isInitial)
        {
            RuleModel.DefaultPriceCalculator ruleEntity = new RuleModel.DefaultPriceCalculator();
            ruleEntity.IsDirty = false;
            ruleEntity.SwitchedProductId = switchedProductId;

            ruleEntity.ClientPricing = new RuleModel.ClientPricing();
            ruleEntity.ClientPricing.RushRate = rushRate;
            ruleEntity.ClientPricing.InitialRate = initialRate;
            ruleEntity.ClientPricing.SubsequentRate = subsequentRate;
            ruleEntity.ClientPricing.StandardRate = standardRate;

            ruleEntity.Loan = new RuleModel.Loan();
            ruleEntity.Loan.SubClientProfileId = subClientProfileId;
            ruleEntity.Loan.ValidCountyName = validCountyName;
            ruleEntity.Loan.ValidStateCode = validStateCode;
            ruleEntity.Loan.ValidZipCode = validZipCode;

            ruleEntity.Product = new RuleModel.Product();
            ruleEntity.Product.ProductId = productId;

            ruleEntity.InvestorProfile = new RuleModel.InvestorProfile();
            ruleEntity.InvestorProfile.InvestorProfileId = investorProfileId;

            ruleEntity.Order = new RuleModel.Order();
            ruleEntity.Order.IsRushOrder = isRushOrder;
            ruleEntity.Order.IsInitial = isInitial;

            RuleModel.ViolationRuleSummary defaultPricCalSummary = new RuleModel.ViolationRuleSummary();

            IBusinessRuleResponse ruleResp = base.ExecuteRule(ruleEntity);

            defaultPricCalSummary.BasePrice = (ruleResp.EntityState as RuleModel.DefaultPriceCalculator).BasePrice;
            defaultPricCalSummary.PriceTracker = (ruleResp.EntityState as RuleModel.DefaultPriceCalculator).PriceTracker;
            defaultPricCalSummary.BasePriceSelectionReason = (ruleResp.EntityState as RuleModel.DefaultPriceCalculator).BasePriceSelectionReason;
            defaultPricCalSummary.FailureReason = (ruleResp.EntityState as RuleModel.DefaultPriceCalculator).FailureReason;
            defaultPricCalSummary.Successful = (ruleResp.EntityState as RuleModel.DefaultPriceCalculator).Successful;
            defaultPricCalSummary.IsDirty = (ruleResp.EntityState as RuleModel.DefaultPriceCalculator).IsDirty;

            return defaultPricCalSummary;
        }
    }
}
