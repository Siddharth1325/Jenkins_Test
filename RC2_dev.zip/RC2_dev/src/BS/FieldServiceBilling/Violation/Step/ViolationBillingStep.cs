﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Admin.ServiceProxy.ClientService;
using BusinessSvcImpl.DataObjects.SpaAccounting.Dto;
using CommonLib.Context;
using Crsf.Core;
using Crsf.Core.Inrule;
using Crsf.Core.Service;
using Crsf.Core.Interface;
using RuleModel = ServiceLink.Billing.Violation.RuleModel;
using ServiceLink.Billing.Definition;
using ServiceLink.Billing.Implementation;

namespace FieldService.Billing.Violation.Step
{
    public class ViolationBillingStep : BillingStepBase
    {
        public ViolationBillingStep(IBillingContext billingContext) : base(billingContext)
        {
        }

        public override string Id
        {
            get
            {
                return "Violation.Billing";
            }
        }

        public override void GetStepOnlyData()
        {
            base.GetStepOnlyData();
        }

        public override bool Validate()
        {
            return base.Validate();
        }
        public override void ProcessStep()
        {
            base.ProcessStep();
            ViolationBillingContextData context = this.BillingContext.ContextData as ViolationBillingContextData;
            decimal priceTracker = BillingContext.PriceTracker;
            string ResolutionStatus = string.Empty;
            string workOrderStatus = context.WorkOrder.WorkOrderStatusType;
            List<RuleModel.ViolationDetails> vDetails = null;

            if (context.PaymentDetails != null && context.PaymentDetails.Count > 0)
            {
                vDetails = new List<RuleModel.ViolationDetails>();
                ResolutionStatus = context.PaymentDetails.Where(x => x.VacancyReviewWorkOrderId == context.WorkOrder.WorkOrderId).Select(x => x.ResolutionType).Distinct().FirstOrDefault();
                context.PaymentDetails.ForEach(det => vDetails.Add(new RuleModel.ViolationDetails()
                {
                    ViolationPaymentId = det.ViolationPaymentId,
                    Amount = det.Amount,
                    IsCreditCardPayment = det.IsCreditCardPayment,
                    ChargeToClient = det.ChargeToClient,
                    FeeTypeId = det.FeeTypeId,
                    FeeTypeName = String.IsNullOrEmpty(det.FeeTypeName) ? null : det.FeeTypeName
                }));
            }

            RuleModel.ViolationRuleSummary ruleSummary = new ViolationBillingStepRuleService().ViolationBillingResult(priceTracker, ResolutionStatus,
                workOrderStatus, vDetails);

            this.BillingContext.APTotalAmountDue = ruleSummary.AccountsPayable.TotalAmountDue;

            if (ruleSummary.AccountsPayable.AccountsDetail != null)
            {
                foreach (RuleModel.AccountsDetail details in ruleSummary.AccountsPayable.AccountsDetail)
                {
                    this.BillingContext.AccountsPayableDetails.Add(new AccountsDetail()
                    {
                        BaseTotalCost = details.BaseTotalCost,
                        AStatusGroup = details.AStatusGroup,
                        AStatusType = details.AStatusType,
                        FeeTypeId = details.FeeTypeId == 0 ? (Nullable<int>)null : details.FeeTypeId,
                        FeeTypeName = String.IsNullOrEmpty(details.FeeTypeName) ? null : details.FeeTypeName,
                        PaymentId = details.ViolationPaymentId
                    });
                }
            }

            this.BillingContext.ARTotalAmountDue = ruleSummary.AccountsReceivable.TotalAmountDue;

            if (ruleSummary.AccountsReceivable.AccountsDetail != null)
            {
                foreach (RuleModel.AccountsDetail details in ruleSummary.AccountsReceivable.AccountsDetail)
                {
                    this.BillingContext.AccountsReceivableDetails.Add(new AccountsDetail()
                    {
                        BaseTotalCost = details.BaseTotalCost,
                        AStatusGroup = details.AStatusGroup,
                        AStatusType = details.AStatusType,
                        FeeTypeId = details.FeeTypeId == 0 ? (Nullable<int>)null : details.FeeTypeId,
                        FeeTypeName = String.IsNullOrEmpty(details.FeeTypeName) ? null : details.FeeTypeName,
                        PaymentId = details.ViolationPaymentId
                    });
                }
            }
            if (ruleSummary.CostAdjustments != null)
            {
                this.BillingContext.CostAdjustments.Add(new Adjustment()
                {
                    AdjustPercentage = ruleSummary.CostAdjustments.AdjustPercentage,
                    AdjustmentGroupCode = ruleSummary.CostAdjustments.AdjustmentGroupCode,
                    AdjustmentTypeCode = ruleSummary.CostAdjustments.AdjustmentTypeCode
                });
            }
            if (ruleSummary.PriceAdjustments != null)
            {
                this.BillingContext.PriceAdjustments.Add(new Adjustment()
                {
                    AdjustPercentage = ruleSummary.PriceAdjustments.AdjustPercentage,
                    AdjustmentGroupCode = ruleSummary.PriceAdjustments.AdjustmentGroupCode,
                    AdjustmentTypeCode = ruleSummary.PriceAdjustments.AdjustmentTypeCode
                });
            }
            this.BillingContext.Successful = ruleSummary.Successful;
        }
    }
    public class ViolationBillingStepRuleService : BusinessRuleServiceBase
    {
        [BusinessRuleMethod(Entity = "ViolationBilling", RuleGroup = "ViolationBillingRules", RuleSet = "ViolationBillingRuleSet")]
        public RuleModel.ViolationRuleSummary ViolationBillingResult(decimal? priceTracker, string vResolutionStatus, string workOrderStatus,
            List<RuleModel.ViolationDetails> vDetails)
        {
            RuleModel.ViolationBilling ruleEntity = new RuleModel.ViolationBilling();
            ruleEntity.PriceTracker = priceTracker;
            ruleEntity.ResolutionStatus = vResolutionStatus;
            ruleEntity.WorkOrderStatusType = workOrderStatus;

            ruleEntity.ViolationDetails = new List<RuleModel.ViolationDetails>();
            if (vDetails != null)
            {
                foreach (RuleModel.ViolationDetails details in vDetails)
                {
                    ruleEntity.ViolationDetails.Add(new RuleModel.ViolationDetails()
                    {
                        ViolationPaymentId = details.ViolationPaymentId,
                        Amount = details.Amount,
                        IsCreditCardPayment = details.IsCreditCardPayment,
                        ChargeToClient = details.ChargeToClient,
                        FeeTypeId = details.FeeTypeId == 0 ? (Nullable<int>)null : details.FeeTypeId,
                        FeeTypeName = String.IsNullOrEmpty(details.FeeTypeName) ? null : details.FeeTypeName
                    });
                }
            }

            ruleEntity.AccountsPayable = new RuleModel.Accounts();
            ruleEntity.AccountsReceivable = new RuleModel.Accounts();
            ruleEntity.CostAdjustments = new RuleModel.Adjustments();
            ruleEntity.PriceAdjustments = new RuleModel.Adjustments();

            RuleModel.ViolationRuleSummary summary = new RuleModel.ViolationRuleSummary();

            IBusinessRuleResponse ruleResp = base.ExecuteRule(ruleEntity);

            summary.CostAdjustments = (ruleResp.EntityState as RuleModel.ViolationBilling).CostAdjustments;
            summary.PriceAdjustments = (ruleResp.EntityState as RuleModel.ViolationBilling).PriceAdjustments;
            summary.AccountsPayable = (ruleResp.EntityState as RuleModel.ViolationBilling).AccountsPayable;
            summary.AccountsReceivable = (ruleResp.EntityState as RuleModel.ViolationBilling).AccountsReceivable;
            summary.Successful = true;

            return summary;
        }
    }
}
