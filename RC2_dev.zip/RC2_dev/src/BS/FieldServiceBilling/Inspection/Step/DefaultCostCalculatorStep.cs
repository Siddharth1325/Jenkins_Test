﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Crsf.Core;
using Crsf.Core.Inrule;
using Crsf.Core.Service;
using Crsf.Core.Interface;
using ServiceLink.Billing.Definition;
using ServiceLink.Billing.Implementation;
using InspectionRuleMode = ServiceLink.Billing.Inspection.RuleModel;

namespace FieldService.Billing.Inspection.Step
{
    public class DefaultCostCalculatorStep : BillingStepBase
    {
        public DefaultCostCalculatorStep(IBillingContext billingContext)
            : base(billingContext)
        {
        }

        public override string Id
        {
            get
            {
                return "Inspection.DefaultCostCalculator";
            }
        }

        public override void GetStepOnlyData()
        {
            
        }

        public override bool Validate()
        {
            return base.Validate();
        }
        public override void ProcessStep()
        {
            base.ProcessStep();
            InspectionBillingContextData context = this.BillingContext.ContextData as InspectionBillingContextData;

            int? switchedProductId = context.SwitchedProductId;
            string validCountyName = context.WorkOrder.Order.Loan.ValidCountyName;
            string validStateCode = context.WorkOrder.Order.Loan.ValidStateCode;
            string validZipCode = context.WorkOrder.Order.Loan.ValidZipCode;
            int? subClientProfileId = context.WorkOrder.Order.Loan.SubClientProfileId;
            int? productId = context.WorkOrder.Product.ProductId;
            decimal? rushRate = context.VendorPricing != null ? context.VendorPricing.RushRate : null;
            decimal? standardRate = context.VendorPricing != null ? context.VendorPricing.StandardRate : null;
            bool? isRushOrder = context.WorkOrder.Order.IsRushOrder;
            int? assignedVendorId = context.WorkOrder.AssignedVendorId;

            InspectionRuleMode.InspectionRuleSummary ruleSummary = new DefaultCostCalculatorStepRuleService().DefaultCostCalculatorResult(
                switchedProductId, validCountyName, validStateCode, validZipCode, subClientProfileId, productId, rushRate, standardRate, isRushOrder, 
                assignedVendorId);

            if (!ruleSummary.Successful)
            {
                this.BillingContext.FailureReason = ruleSummary.FailureReason;
            }
            if (ruleSummary.IsDirty)
            {
                this.BillingContext.BaseCost = ruleSummary.BaseCost;
                this.BillingContext.BaseCostSelectionReason = ruleSummary.BaseCostSelectionReason;
                this.BillingContext.CostTracker = ruleSummary.CostTracker;
            }

            this.BillingContext.Successful = ruleSummary.Successful;
        }
    }
    public class DefaultCostCalculatorStepRuleService : BusinessRuleServiceBase
    {
        [BusinessRuleMethod(Entity = "DefaultCostCalculator", RuleGroup = "FieldServiceInspectionBillingRules", RuleSet = "CalculateDefaultCost")]
        public InspectionRuleMode.InspectionRuleSummary DefaultCostCalculatorResult(int? switchedProductId, string validCountyName, string validStateCode, 
            string validZipCode, int? subClientProfileId, int? productId, decimal? rushRate, decimal? standardRate, bool? isRushOrder, int? assignedVendorId)
        {
            InspectionRuleMode.DefaultCostCalculator ruleEntity = new InspectionRuleMode.DefaultCostCalculator();
            ruleEntity.SwitchedProductId = switchedProductId;

            ruleEntity.VendorPricing = new InspectionRuleMode.VendorPricing();
            ruleEntity.VendorPricing.RushRate = rushRate;
            ruleEntity.VendorPricing.StandardRate = standardRate;

            ruleEntity.Loan = new InspectionRuleMode.Loan();
            ruleEntity.Loan.ValidCountyName = validCountyName;
            ruleEntity.Loan.ValidStateCode = validStateCode;
            ruleEntity.Loan.ValidZipCode = validZipCode;

            ruleEntity.Product = new InspectionRuleMode.Product();
            ruleEntity.Product.ProductId = productId;

            ruleEntity.SubClientProfile = new InspectionRuleMode.SubClientProfile();
            ruleEntity.SubClientProfile.SubClientProfileId = subClientProfileId;

            ruleEntity.Order = new InspectionRuleMode.Order();
            ruleEntity.Order.IsRushOrder = isRushOrder;

            ruleEntity.WorkOrder = new InspectionRuleMode.WorkOrder();
            ruleEntity.WorkOrder.AssignedVendorId = assignedVendorId;

            InspectionRuleMode.InspectionRuleSummary defaultCostCalSummary = new InspectionRuleMode.InspectionRuleSummary();

            IBusinessRuleResponse ruleResp = base.ExecuteRule(ruleEntity);

            defaultCostCalSummary.BaseCost = (ruleResp.EntityState as InspectionRuleMode.DefaultCostCalculator).BaseCost;
            defaultCostCalSummary.CostTracker = (ruleResp.EntityState as InspectionRuleMode.DefaultCostCalculator).CostTracker;
            defaultCostCalSummary.BaseCostSelectionReason = (ruleResp.EntityState as InspectionRuleMode.DefaultCostCalculator).BaseCostSelectionReason;
            defaultCostCalSummary.FailureReason = (ruleResp.EntityState as InspectionRuleMode.DefaultCostCalculator).FailureReason;
            defaultCostCalSummary.Successful = (ruleResp.EntityState as InspectionRuleMode.DefaultCostCalculator).Successful;
            defaultCostCalSummary.IsDirty = (ruleResp.EntityState as InspectionRuleMode.DefaultCostCalculator).IsDirty;

            return defaultCostCalSummary;
        }
    }
}
