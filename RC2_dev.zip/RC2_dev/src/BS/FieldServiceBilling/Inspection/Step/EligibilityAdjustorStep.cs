﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Crsf.Core;
using Crsf.Core.Inrule;
using Crsf.Core.Service;
using Crsf.Core.Interface;
using ServiceLink.Billing.Definition;
using ServiceLink.Billing.Implementation;
using InspectionRuleMode = ServiceLink.Billing.Inspection.RuleModel;

namespace FieldService.Billing.Inspection.Step
{
    public class EligibilityAdjustorStep : BillingStepBase
    {
        public EligibilityAdjustorStep(IBillingContext billingContext) : base(billingContext)
        {
        }

        public override string Id
        {
            get
            {
                return "Inspection.EligibilityAdjustor";
            }
        }

        public override void GetStepOnlyData()
        {
            base.GetStepOnlyData();
        }

        public override bool Validate()
        {
            return base.Validate();
        }
        public override void ProcessStep()
        {
            base.ProcessStep();
            InspectionBillingContextData context = this.BillingContext.ContextData as InspectionBillingContextData;

            bool isDoNotPayVendor = context.WorkOrder.Order.IsDoNotPayVendor;
            bool isDoNotBillClient = context.WorkOrder.Order.IsDoNotBillClient;
            decimal? baseCost = this.BillingContext.BaseCost;
            decimal? basePrice = this.BillingContext.BasePrice;

            InspectionRuleMode.InspectionRuleSummary ruleSummary = new EligibilityAdjustorStepRuleService().EligibilityAdjustorResult(
                isDoNotPayVendor, isDoNotBillClient, baseCost, basePrice);

            if (ruleSummary.IsDirty)
            {
                this.BillingContext.BaseCost = ruleSummary.BaseCost;
                this.BillingContext.BaseCostSelectionReason = ruleSummary.BaseCostSelectionReason;
                this.BillingContext.CostTracker = ruleSummary.CostTracker;
                this.BillingContext.FinalCost = ruleSummary.FinalCost;
            }
            else if (ruleSummary.IsDirtyCost)
            {
                this.BillingContext.CostAdjustments.Add(new Adjustment()
                {
                    AdjustPercentage = ruleSummary.CostAdjustments.AdjustPercentage,
                    AdjustmentGroupCode = ruleSummary.CostAdjustments.AdjustmentGroupCode,
                    AdjustmentTypeCode = ruleSummary.CostAdjustments.AdjustmentTypeCode
                });
                this.BillingContext.CostTracker = ruleSummary.CostTracker;
                this.BillingContext.FinalCost = ruleSummary.FinalCost;
            }

            if (ruleSummary.IsDirty1)
            {
                this.BillingContext.BasePrice = ruleSummary.BasePrice;
                this.BillingContext.BasePriceSelectionReason = ruleSummary.BasePriceSelectionReason;
                this.BillingContext.PriceTracker = ruleSummary.PriceTracker;
                this.BillingContext.FinalPrice = ruleSummary.FinalPrice;
                context.IsEligibleForTran32 = ruleSummary.IsEligibleForTran32;
            }
            else if (ruleSummary.IsDirtyPrice)
            {
                this.BillingContext.PriceAdjustments.Add(new Adjustment()
                {
                    AdjustPercentage = ruleSummary.PriceAdjustments.AdjustPercentage,
                    AdjustmentGroupCode = ruleSummary.PriceAdjustments.AdjustmentGroupCode,
                    AdjustmentTypeCode = ruleSummary.PriceAdjustments.AdjustmentTypeCode
                });
                this.BillingContext.PriceTracker = ruleSummary.PriceTracker;
                this.BillingContext.FinalPrice = ruleSummary.FinalPrice;
                context.IsEligibleForTran32 = ruleSummary.IsEligibleForTran32;
            }
            this.BillingContext.Successful = ruleSummary.Successful;

        }
    }

    public class EligibilityAdjustorStepRuleService : BusinessRuleServiceBase
    {
        [BusinessRuleMethod(Entity = "EligibilityAdjustor", RuleGroup = "FieldServiceInspectionBillingRules", RuleSet = "CalculateEL")]
        public InspectionRuleMode.InspectionRuleSummary EligibilityAdjustorResult(bool isDoNotPayVendor, bool isDoNotBillClient, decimal? baseCost, 
            decimal? basePrice)
        {
            InspectionRuleMode.EligibilityAdjustor ruleEntity = new InspectionRuleMode.EligibilityAdjustor();
            ruleEntity.Order = new InspectionRuleMode.Order();
            ruleEntity.Order.IsDoNotPayVendor = isDoNotPayVendor;
            ruleEntity.Order.IsDoNotBillClient = isDoNotBillClient;
            ruleEntity.BaseCost = baseCost;
            ruleEntity.BasePrice = basePrice;

            ruleEntity.CostAdjustments = new InspectionRuleMode.CostAdjustments();
            ruleEntity.PriceAdjustments = new InspectionRuleMode.PriceAdjustments();

            InspectionRuleMode.InspectionRuleSummary eligibilityAdjSummary = new InspectionRuleMode.InspectionRuleSummary();

            IBusinessRuleResponse ruleResp = base.ExecuteRule(ruleEntity);

            eligibilityAdjSummary.CostAdjustments = (ruleResp.EntityState as InspectionRuleMode.EligibilityAdjustor).CostAdjustments;
            eligibilityAdjSummary.PriceAdjustments = (ruleResp.EntityState as InspectionRuleMode.EligibilityAdjustor).PriceAdjustments;
            eligibilityAdjSummary.CostTracker = (ruleResp.EntityState as InspectionRuleMode.EligibilityAdjustor).CostTracker;
            eligibilityAdjSummary.FinalCost = (ruleResp.EntityState as InspectionRuleMode.EligibilityAdjustor).FinalCost;
            eligibilityAdjSummary.PriceTracker = (ruleResp.EntityState as InspectionRuleMode.EligibilityAdjustor).PriceTracker;
            eligibilityAdjSummary.FinalPrice = (ruleResp.EntityState as InspectionRuleMode.EligibilityAdjustor).FinalPrice;
            eligibilityAdjSummary.IsEligibleForTran32 = (ruleResp.EntityState as InspectionRuleMode.EligibilityAdjustor).IsEligibleForTran32;
            eligibilityAdjSummary.BaseCost = (ruleResp.EntityState as InspectionRuleMode.EligibilityAdjustor).BaseCost;
            eligibilityAdjSummary.BaseCostSelectionReason = (ruleResp.EntityState as InspectionRuleMode.EligibilityAdjustor).BaseCostSelectionReason;
            eligibilityAdjSummary.BasePrice = (ruleResp.EntityState as InspectionRuleMode.EligibilityAdjustor).BasePrice;
            eligibilityAdjSummary.BasePriceSelectionReason = (ruleResp.EntityState as InspectionRuleMode.EligibilityAdjustor).BasePriceSelectionReason;
            eligibilityAdjSummary.Calculated = (ruleResp.EntityState as InspectionRuleMode.EligibilityAdjustor).Calculated;
            eligibilityAdjSummary.Successful = (ruleResp.EntityState as InspectionRuleMode.EligibilityAdjustor).Successful;
            eligibilityAdjSummary.IsDirtyCost = (ruleResp.EntityState as InspectionRuleMode.EligibilityAdjustor).IsDirtyCost;
            eligibilityAdjSummary.IsDirtyPrice = (ruleResp.EntityState as InspectionRuleMode.EligibilityAdjustor).IsDirtyPrice;
            eligibilityAdjSummary.IsDirty = (ruleResp.EntityState as InspectionRuleMode.EligibilityAdjustor).IsDirty;
            eligibilityAdjSummary.IsDirty1 = (ruleResp.EntityState as InspectionRuleMode.EligibilityAdjustor).IsDirty1;

            return eligibilityAdjSummary;
        }
    }
}
