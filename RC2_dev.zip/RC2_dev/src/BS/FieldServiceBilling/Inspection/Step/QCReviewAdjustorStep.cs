﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Crsf.Core;
using Crsf.Core.Inrule;
using Crsf.Core.Service;
using Crsf.Core.Interface;
using ServiceLink.Billing.Definition;
using ServiceLink.Billing.Implementation;
using InspectionRuleMode = ServiceLink.Billing.Inspection.RuleModel;

namespace FieldService.Billing.Inspection.Step
{
    public class QCReviewAdjustorStep : BillingStepBase
    {
        public QCReviewAdjustorStep(IBillingContext billingContext) : base(billingContext)
        {
        }

        public override string Id
        {
            get
            {
                return "Inspection.QCReviewAdjustor";
            }
        }

        public override void GetStepOnlyData()
        {
            base.GetStepOnlyData();
        }

        public override bool Validate()
        {
            return base.Validate();
        }
        public override void ProcessStep()
        {
            base.ProcessStep();
            InspectionBillingContextData context = this.BillingContext.ContextData as InspectionBillingContextData;
            
            string payVendorGroup = context.WorkOrder.PayVendorGroup;
            string payVendorType = context.WorkOrder.PayVendorType;
            bool? isBillClient = context.WorkOrder.IsBillClient;

            InspectionRuleMode.InspectionRuleSummary ruleSummary = new QCReviewAdjustorStepRuleService().QCReviewAdjustorResult(
                payVendorGroup, payVendorType, isBillClient);

            if (ruleSummary.IsDirty)
            {
                this.BillingContext.CostTracker = ruleSummary.CostTracker;
            }
            else if (ruleSummary.IsDirty1)
            {
                this.BillingContext.CostTracker = ruleSummary.CostTracker;
                this.BillingContext.FinalCost = ruleSummary.FinalCost;
            }

            if (ruleSummary.IsDirtyCost)
            {
                this.BillingContext.CostAdjustments.Add(new Adjustment()
                {
                    AdjustPercentage = ruleSummary.CostAdjustments.AdjustPercentage,
                    AdjustmentGroupCode = ruleSummary.CostAdjustments.AdjustmentGroupCode,
                    AdjustmentTypeCode = ruleSummary.CostAdjustments.AdjustmentTypeCode
                });
            }

            if (ruleSummary.IsDirtyPrice)
            {
                this.BillingContext.PriceTracker = ruleSummary.PriceTracker;
                this.BillingContext.FinalPrice = ruleSummary.FinalPrice;
                this.BillingContext.PriceAdjustments.Add(new Adjustment()
                {
                    AdjustPercentage = ruleSummary.PriceAdjustments.AdjustPercentage,
                    AdjustmentGroupCode = ruleSummary.PriceAdjustments.AdjustmentGroupCode,
                    AdjustmentTypeCode = ruleSummary.PriceAdjustments.AdjustmentTypeCode
                });
                context.IsEligibleForTran32 = ruleSummary.IsEligibleForTran32;
            }
            this.BillingContext.Successful = ruleSummary.Successful;
        }
    }

    public class QCReviewAdjustorStepRuleService : BusinessRuleServiceBase
    {
        [BusinessRuleMethod(Entity = "QCReviewAdjustor", RuleGroup = "FieldServiceInspectionBillingRules", RuleSet = "CalculateQC")]
        public InspectionRuleMode.InspectionRuleSummary QCReviewAdjustorResult(string payVendorGroup, string payVendorType, bool? isBillClient)
        {
            InspectionRuleMode.QCReviewAdjustor ruleEntity = new InspectionRuleMode.QCReviewAdjustor();
            ruleEntity.WorkOrder = new InspectionRuleMode.WorkOrder();
            ruleEntity.WorkOrder.PayVendorGroup = payVendorGroup;
            ruleEntity.WorkOrder.PayVendorType = payVendorType;
            ruleEntity.WorkOrder.IsBillClient = isBillClient;

            ruleEntity.CostAdjustments = new InspectionRuleMode.CostAdjustments();
            ruleEntity.PriceAdjustments = new InspectionRuleMode.PriceAdjustments();

            InspectionRuleMode.InspectionRuleSummary qcReviewAdjSummary = new InspectionRuleMode.InspectionRuleSummary();

            IBusinessRuleResponse ruleResp = base.ExecuteRule(ruleEntity);

            qcReviewAdjSummary.CostAdjustments = (ruleResp.EntityState as InspectionRuleMode.QCReviewAdjustor).CostAdjustments;
            qcReviewAdjSummary.PriceAdjustments = (ruleResp.EntityState as InspectionRuleMode.QCReviewAdjustor).PriceAdjustments;
            qcReviewAdjSummary.CostTracker = (ruleResp.EntityState as InspectionRuleMode.QCReviewAdjustor).CostTracker;
            qcReviewAdjSummary.FinalCost = (ruleResp.EntityState as InspectionRuleMode.QCReviewAdjustor).FinalCost;
            qcReviewAdjSummary.PriceTracker = (ruleResp.EntityState as InspectionRuleMode.QCReviewAdjustor).PriceTracker;
            qcReviewAdjSummary.FinalPrice = (ruleResp.EntityState as InspectionRuleMode.QCReviewAdjustor).FinalPrice;
            qcReviewAdjSummary.IsEligibleForTran32 = (ruleResp.EntityState as InspectionRuleMode.QCReviewAdjustor).IsEligibleForTran32;
            qcReviewAdjSummary.Calculated = (ruleResp.EntityState as InspectionRuleMode.QCReviewAdjustor).Calculated;
            qcReviewAdjSummary.Successful = (ruleResp.EntityState as InspectionRuleMode.QCReviewAdjustor).Successful;
            qcReviewAdjSummary.IsDirtyCost = (ruleResp.EntityState as InspectionRuleMode.QCReviewAdjustor).IsDirtyCost;
            qcReviewAdjSummary.IsDirtyPrice = (ruleResp.EntityState as InspectionRuleMode.QCReviewAdjustor).IsDirtyPrice;
            qcReviewAdjSummary.IsDirty = (ruleResp.EntityState as InspectionRuleMode.QCReviewAdjustor).IsDirty;
            qcReviewAdjSummary.IsDirty1 = (ruleResp.EntityState as InspectionRuleMode.QCReviewAdjustor).IsDirty1;

            return qcReviewAdjSummary;
        }
    }
}
