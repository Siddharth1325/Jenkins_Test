﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Crsf.Core;
using Crsf.Core.Inrule;
using Crsf.Core.Service;
using Crsf.Core.Interface;
using ServiceLink.Billing.Definition;
using ServiceLink.Billing.Implementation;
using Admin.ServiceProxy.ClientService;

namespace FieldService.Billing.Inspection.Step
{
    public class Tran32AdjustorStep : BillingStepBase
    {
        private List<Tran32Configuration> _Tran32Configs = null;
        private const string _WorkOrderCancellationStatusCode = "CANCEL";

        public Tran32AdjustorStep(IBillingContext billingContext)
            : base(billingContext)
        {
        }

        public override string Id
        {
            get
            {
                return "Inspection.Tran32Adjustor";
            }
        }

        public override void GetStepOnlyData()
        {
            InspectionBillingContextData contextData = this.BillingContext.ContextData as InspectionBillingContextData;
            if (contextData.IsEligibleForTran32)
            {
                using (ClientServiceClient proxy = new ClientServiceClient())
                {
                    GetTran32ConfigurationBySubClientResponse response = proxy.GetTran32ConfigurationBySubClientProfileId(contextData.SubClientProfile.SubClientProfileId);
                    _Tran32Configs = (response != null) ? response.Tran32Configurations : null;
                }
            }
        }

        public override void ProcessStep()
        {            
            InspectionBillingContextData contextData = this.BillingContext.ContextData as InspectionBillingContextData;
            if (!contextData.IsEligibleForTran32) return;

            if (contextData.WorkOrder != null && string.Compare(contextData.WorkOrder.WorkOrderStatusType, _WorkOrderCancellationStatusCode, true) == 0)
                contextData.IsEligibleForTran32 = false;
            else if (contextData.InspectionResult != null && (!contextData.InspectionResult.IsWorkPerformed ||
                (contextData.InspectionResult.InspRsltWorkNotPerformeds != null && contextData.InspectionResult.InspRsltWorkNotPerformeds.Count > 0)))
                contextData.IsEligibleForTran32 = false;

            if (contextData.IsEligibleForTran32)
            {
                if (_Tran32Configs != null && _Tran32Configs.Count > 0)
                {
                    contextData.IsEligibleForTran32 = _Tran32Configs.SelectMany(t => t.Tran32DepartmentInclusions)
                        .Count(i => string.Compare(i.DepartmentCode, contextData.WorkOrder.Order.DepartmentCode, true) == 0) > 0;

                    if (contextData.IsEligibleForTran32)
                    {
                        contextData.IsEligibleForTran32 = !(_Tran32Configs.SelectMany(t => t.Tran32Exclusions)
                            .Count(e => string.Compare(e.DepartmentCode, contextData.WorkOrder.Order.DepartmentCode, true) == 0 &&
                                       ((!string.IsNullOrWhiteSpace(contextData.WorkOrder.Order.MBACodeType) && string.Compare(e.MBACodeType, contextData.WorkOrder.Order.MBACodeType, true) == 0)
                                         || (string.IsNullOrWhiteSpace(contextData.WorkOrder.Order.MBACodeType) && string.Compare(e.MBACodeType, "NA", true) == 0))) > 0);
                    }

                    if (contextData.IsEligibleForTran32)
                    {
                        contextData.IsEligibleForTran32 = !(_Tran32Configs.SelectMany(t => t.Tran32Exclusions)
                            .Count(e => string.Compare(e.StateCode, contextData.WorkOrder.Order.Loan.ValidStateCode, true) == 0 && (string.IsNullOrWhiteSpace(e.DepartmentCode)
                                     || (!string.IsNullOrWhiteSpace(e.DepartmentCode) && string.Compare(e.DepartmentCode, contextData.WorkOrder.Order.DepartmentCode, true) == 0))) > 0);
                    }

                    if (contextData.IsEligibleForTran32)
                    {
                        contextData.IsEligibleForTran32 = !(_Tran32Configs.SelectMany(t => t.Tran32Exclusions)
                            .Count(e => string.Compare(e.ZipCode, contextData.WorkOrder.Order.Loan.ValidZipCode, true) == 0 && (string.IsNullOrWhiteSpace(e.DepartmentCode)
                                     || (!string.IsNullOrWhiteSpace(e.DepartmentCode) && string.Compare(e.DepartmentCode, contextData.WorkOrder.Order.DepartmentCode, true) == 0))) > 0);
                    }
                }
                else
                    contextData.IsEligibleForTran32 = false;
            }
        }
    }
}
