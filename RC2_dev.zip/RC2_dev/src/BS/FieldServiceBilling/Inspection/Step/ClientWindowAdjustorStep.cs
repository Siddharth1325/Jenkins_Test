﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Crsf.Core;
using Crsf.Core.Inrule;
using Crsf.Core.Service;
using Crsf.Core.Interface;
using ServiceLink.Billing.Definition;
using ServiceLink.Billing.Implementation;
using InspectionRuleMode = ServiceLink.Billing.Inspection.RuleModel;

namespace FieldService.Billing.Inspection.Step
{
    public class ClientWindowAdjustorStep : BillingStepBase
    {
        public ClientWindowAdjustorStep(IBillingContext billingContext) : base(billingContext)
        {
        }

        public override string Id
        {
            get
            {
                return "Inspection.ClientWindowAdjustor";
            }
        }

        public override void GetStepOnlyData()
        {
            base.GetStepOnlyData();
        }

        public override bool Validate()
        {
            return base.Validate();
        }

        public override void ProcessStep()
        {
            base.ProcessStep();
            InspectionBillingContextData context = this.BillingContext.ContextData as InspectionBillingContextData;
            
            DateTime? winStartDate = context.WorkOrder.WindowStartDate;
            DateTime? winEndDate = context.WorkOrder.WindowEndDate;

            DateTime subDate = DateTime.MinValue;
            if (context.InspectionResult != null)
            {
                subDate = context.InspectionResult.InspectionDate.HasValue ? context.InspectionResult.InspectionDate.Value : context.InspectionResult.SubmissionDate;
            }
            bool isBillOutOfCompliance = context.ClientAccounting.IsBillOutOfCompliance;
            bool isPayOutOfCompliance = context.ClientAccounting.IsPayOutOfCompliance;

            InspectionRuleMode.InspectionRuleSummary ruleSummary = new ClientWindowAdjustorStepRuleService().ClientWindowAdjustorResult(
                winStartDate, winEndDate, subDate, isBillOutOfCompliance, isPayOutOfCompliance);

            if (ruleSummary.IsDirtyCost)
            {
                this.BillingContext.CostTracker = ruleSummary.CostTracker;
                this.BillingContext.FinalCost = ruleSummary.FinalCost;
                this.BillingContext.CostAdjustments.Add(new Adjustment()
                {
                    AdjustPercentage = ruleSummary.CostAdjustments.AdjustPercentage,
                    AdjustmentGroupCode = ruleSummary.CostAdjustments.AdjustmentGroupCode,
                    AdjustmentTypeCode = ruleSummary.CostAdjustments.AdjustmentTypeCode
                });
            }
            if (ruleSummary.IsDirtyPrice)
            {
                this.BillingContext.PriceTracker = ruleSummary.PriceTracker;
                this.BillingContext.FinalPrice = ruleSummary.FinalPrice;
                this.BillingContext.PriceAdjustments.Add(new Adjustment()
                {
                    AdjustPercentage = ruleSummary.PriceAdjustments.AdjustPercentage,
                    AdjustmentGroupCode = ruleSummary.PriceAdjustments.AdjustmentGroupCode,
                    AdjustmentTypeCode = ruleSummary.PriceAdjustments.AdjustmentTypeCode
                });
            }
            this.BillingContext.Successful = ruleSummary.Successful;

        }
    }

    public class ClientWindowAdjustorStepRuleService : BusinessRuleServiceBase
    {
        [BusinessRuleMethod(Entity = "ClientWindowAdjustor", RuleGroup = "FieldServiceInspectionBillingRules", RuleSet = "CalculateCWA")]
        public InspectionRuleMode.InspectionRuleSummary ClientWindowAdjustorResult(DateTime? winStartDate, DateTime? winEndDate, DateTime subDate, 
            bool isBillOutOfCompliance, bool isPayOutOfCompliance)
        {
            InspectionRuleMode.ClientWindowAdjustor ruleEntity = new InspectionRuleMode.ClientWindowAdjustor();
            ruleEntity.WorkOrder = new InspectionRuleMode.WorkOrder();
            ruleEntity.WorkOrder.WindowStartDate = winStartDate;
            ruleEntity.WorkOrder.WindowEndDate = winEndDate;

            ruleEntity.InspectionResult = new InspectionRuleMode.InspectionResult();
            ruleEntity.InspectionResult.SubmissionDate = subDate;

            ruleEntity.ClientAccounting = new InspectionRuleMode.ClientAccounting();
            ruleEntity.ClientAccounting.IsBillOutOfCompliance = isBillOutOfCompliance;
            ruleEntity.ClientAccounting.IsPayOutOfCompliance = isPayOutOfCompliance;

            bool isOutOfCompliance = winEndDate.HasValue ? subDate.Date > winEndDate.Value.Date : false;
            ruleEntity.isOutOfCompliance = isOutOfCompliance;

            ruleEntity.CostAdjustments = new InspectionRuleMode.CostAdjustments();
            ruleEntity.PriceAdjustments = new InspectionRuleMode.PriceAdjustments();

            InspectionRuleMode.InspectionRuleSummary clientWinAdjSummary = new InspectionRuleMode.InspectionRuleSummary();

            IBusinessRuleResponse ruleResp = base.ExecuteRule(ruleEntity);

            clientWinAdjSummary.CostAdjustments = (ruleResp.EntityState as InspectionRuleMode.ClientWindowAdjustor).CostAdjustments;
            clientWinAdjSummary.PriceAdjustments = (ruleResp.EntityState as InspectionRuleMode.ClientWindowAdjustor).PriceAdjustments;
            clientWinAdjSummary.CostTracker = (ruleResp.EntityState as InspectionRuleMode.ClientWindowAdjustor).CostTracker;
            clientWinAdjSummary.FinalCost = (ruleResp.EntityState as InspectionRuleMode.ClientWindowAdjustor).FinalCost;
            clientWinAdjSummary.PriceTracker = (ruleResp.EntityState as InspectionRuleMode.ClientWindowAdjustor).PriceTracker;
            clientWinAdjSummary.FinalPrice = (ruleResp.EntityState as InspectionRuleMode.ClientWindowAdjustor).FinalPrice;
            clientWinAdjSummary.Calculated = (ruleResp.EntityState as InspectionRuleMode.ClientWindowAdjustor).Calculated;
            clientWinAdjSummary.Successful = (ruleResp.EntityState as InspectionRuleMode.ClientWindowAdjustor).Successful;
            clientWinAdjSummary.IsDirtyCost = (ruleResp.EntityState as InspectionRuleMode.ClientWindowAdjustor).IsDirtyCost;
            clientWinAdjSummary.IsDirtyPrice = (ruleResp.EntityState as InspectionRuleMode.ClientWindowAdjustor).IsDirtyPrice;

            return clientWinAdjSummary;
        }
    }
}
