﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Crsf.Core;
using Crsf.Core.Inrule;
using Crsf.Core.Service;
using Crsf.Core.Interface;
using ServiceLink.Billing.Definition;
using ServiceLink.Billing.Implementation;
using InspectionRuleMode = ServiceLink.Billing.Inspection.RuleModel;
using Inspections.ServiceProxy.InspectionSvc;

namespace FieldService.Billing.Inspection.Step
{
    public class WorkNotPerformedAdjustorStep : BillingStepBase
    {
        public WorkNotPerformedAdjustorStep(IBillingContext billingContext) : base(billingContext)
        {
        }

        public override string Id
        {
            get
            {
                return "Inspection.WorkNotPerformedAdjustor";
            }
        }

        public override void GetStepOnlyData()
        {
            base.GetStepOnlyData();
        }

        public override bool Validate()
        {
            return base.Validate();
        }
        public override void ProcessStep()
        {
            base.ProcessStep();
            InspectionBillingContextData context = this.BillingContext.ContextData as InspectionBillingContextData;

            decimal? basePrice = this.BillingContext.BasePrice;
            decimal priceTracker = this.BillingContext.PriceTracker;
            bool? isBillForAccessDenied = context.ClientAccounting.IsBillForAccessDenied;
            decimal? accessDeniedAmount = context.ClientAccounting.AccessDeniedAmount;
            bool? isBillForBadAddress = context.ClientAccounting.IsBillForBadAddress;
            decimal? badAddressAmount = context.ClientAccounting.BadAddressAmount;
            bool? isBillWorkNotPerformed = context.ClientAccounting.IsBillWorkNotPerformed;
            decimal? workNotPerformedAmount  = context.ClientAccounting.WorkNotPerformedAmount;
            
            InspectionRuleMode.InspectionRuleSummary ruleSummary = null;

            if (context.InspectionResult != null && context.InspectionResult.InspRsltWorkNotPerformeds != null)
            {
                ruleSummary = new WorkNotPerformedAdjustorRuleService().WorkNotPerformedAdjustorResult(
                    basePrice, priceTracker, isBillForAccessDenied, accessDeniedAmount, isBillForBadAddress, badAddressAmount, isBillWorkNotPerformed,
                    workNotPerformedAmount, context.InspectionResult.InspRsltWorkNotPerformeds);
            }
            else
            {
                ruleSummary = new WorkNotPerformedAdjustorRuleService().WorkNotPerformedAdjustorResult(
                    basePrice, priceTracker, isBillForAccessDenied, accessDeniedAmount, isBillForBadAddress, badAddressAmount, isBillWorkNotPerformed,
                    workNotPerformedAmount, null);

            }

            if (ruleSummary.IsDirtyCost)
            {
                this.BillingContext.CostTracker = ruleSummary.CostTracker;
                this.BillingContext.CostAdjustments.Add(new Adjustment()
                {
                    AdjustPercentage = ruleSummary.CostAdjustments.AdjustPercentage,
                    AdjustmentGroupCode = ruleSummary.CostAdjustments.AdjustmentGroupCode,
                    AdjustmentTypeCode = ruleSummary.CostAdjustments.AdjustmentTypeCode
                });
            }
            
            if(ruleSummary.IsDirty)
            {
                this.BillingContext.BasePrice = ruleSummary.BasePrice;
                this.BillingContext.BasePriceSelectionReason = ruleSummary.BasePriceSelectionReason;
                this.BillingContext.PriceTracker = ruleSummary.PriceTracker;
                this.BillingContext.FinalPrice = ruleSummary.FinalPrice;
            }
            else if (ruleSummary.IsDirtyPrice)
            {
                this.BillingContext.PriceAdjustments.Add(new Adjustment()
                {
                    AdjustPercentage = ruleSummary.PriceAdjustments.AdjustPercentage,
                    AdjustmentGroupCode = ruleSummary.PriceAdjustments.AdjustmentGroupCode,
                    AdjustmentTypeCode = ruleSummary.PriceAdjustments.AdjustmentTypeCode
                });
                this.BillingContext.PriceTracker = ruleSummary.PriceTracker;
                this.BillingContext.FinalPrice = ruleSummary.FinalPrice;
            }

            context.IsEligibleForTran32 = ruleSummary.IsEligibleForTran32;
            this.BillingContext.Successful = ruleSummary.Successful;
        }
    }
    public class WorkNotPerformedAdjustorRuleService : BusinessRuleServiceBase
    {
        [BusinessRuleMethod(Entity = "WorkNotPerformedAdjustor", RuleGroup = "FieldServiceInspectionBillingRules", RuleSet = "CalculateWorkNotPerformed")]
        public InspectionRuleMode.InspectionRuleSummary WorkNotPerformedAdjustorResult(decimal? basePrice, decimal priceTracker, bool? isBillForAccessDenied, 
            decimal? accessDeniedAmount, bool? isBillForBadAddress, decimal? badAddressAmount, bool? isBillWorkNotPerformed, decimal? workNotPerformedAmount,
            List<InspRsltWorkNotPerformed> inspRsltWorkNotPerformed)
        {
            InspectionRuleMode.WorkNotPerformedAdjustor ruleEntity = new InspectionRuleMode.WorkNotPerformedAdjustor();
            ruleEntity.BasePrice = basePrice;
            ruleEntity.PriceTracker = priceTracker;

            ruleEntity.WorkOrder = new InspectionRuleMode.WorkOrder();

            ruleEntity.InspectionResult = new InspectionRuleMode.InspectionResult();
            ruleEntity.InspectionResult.InspRsltWorkNotPerformed = new List<InspectionRuleMode.InspRsltWorkNotPerformed>();
            if (inspRsltWorkNotPerformed != null)
            {
                foreach (InspRsltWorkNotPerformed inspRsltWorkNotPerformeds in inspRsltWorkNotPerformed)
                {
                    ruleEntity.InspectionResult.InspRsltWorkNotPerformed.Add(new InspectionRuleMode.InspRsltWorkNotPerformed()
                    {
                        AccessDeniedGroup = inspRsltWorkNotPerformeds.AccessDeniedGroup,
                        BadAddrGroupCode = inspRsltWorkNotPerformeds.BadAddrGroupCode,
                        WorkNotPerformedReasonGroup = inspRsltWorkNotPerformeds.WorkNotPerformedReasonGroup
                    });
                }
            }

            ruleEntity.ClientAccounting = new InspectionRuleMode.ClientAccounting();
            ruleEntity.ClientAccounting.IsBillForAccessDenied = isBillForAccessDenied;
            ruleEntity.ClientAccounting.AccessDeniedAmount = accessDeniedAmount;
            ruleEntity.ClientAccounting.IsBillForBadAddress = isBillForBadAddress;
            ruleEntity.ClientAccounting.BadAddressAmount = badAddressAmount;
            ruleEntity.ClientAccounting.IsBillWorkNotPerformed = isBillWorkNotPerformed;
            ruleEntity.ClientAccounting.WorkNotPerformedAmount = workNotPerformedAmount;

            ruleEntity.CostAdjustments = new InspectionRuleMode.CostAdjustments();
            ruleEntity.PriceAdjustments = new InspectionRuleMode.PriceAdjustments();

            InspectionRuleMode.InspectionRuleSummary workNotPerformedAdjSummary = new InspectionRuleMode.InspectionRuleSummary();

            IBusinessRuleResponse ruleResp = base.ExecuteRule(ruleEntity);

            workNotPerformedAdjSummary.CostAdjustments = (ruleResp.EntityState as InspectionRuleMode.WorkNotPerformedAdjustor).CostAdjustments;
            workNotPerformedAdjSummary.PriceAdjustments = (ruleResp.EntityState as InspectionRuleMode.WorkNotPerformedAdjustor).PriceAdjustments;
            workNotPerformedAdjSummary.CostTracker = (ruleResp.EntityState as InspectionRuleMode.WorkNotPerformedAdjustor).CostTracker;
            workNotPerformedAdjSummary.BasePrice = (ruleResp.EntityState as InspectionRuleMode.WorkNotPerformedAdjustor).BasePrice;
            workNotPerformedAdjSummary.PriceTracker = (ruleResp.EntityState as InspectionRuleMode.WorkNotPerformedAdjustor).PriceTracker;
            workNotPerformedAdjSummary.FinalPrice = (ruleResp.EntityState as InspectionRuleMode.WorkNotPerformedAdjustor).FinalPrice;
            workNotPerformedAdjSummary.BasePriceSelectionReason = (ruleResp.EntityState as InspectionRuleMode.WorkNotPerformedAdjustor).BasePriceSelectionReason;
            workNotPerformedAdjSummary.Successful = (ruleResp.EntityState as InspectionRuleMode.WorkNotPerformedAdjustor).Successful;
            workNotPerformedAdjSummary.IsEligibleForTran32 = (ruleResp.EntityState as InspectionRuleMode.WorkNotPerformedAdjustor).IsEligibleForTran32;
            workNotPerformedAdjSummary.IsDirty = (ruleResp.EntityState as InspectionRuleMode.WorkNotPerformedAdjustor).IsDirty;
            workNotPerformedAdjSummary.IsDirtyCost = (ruleResp.EntityState as InspectionRuleMode.WorkNotPerformedAdjustor).IsDirtyCost;
            workNotPerformedAdjSummary.IsDirtyPrice = (ruleResp.EntityState as InspectionRuleMode.WorkNotPerformedAdjustor).IsDirtyPrice;

            return workNotPerformedAdjSummary;
        }
    }
}
