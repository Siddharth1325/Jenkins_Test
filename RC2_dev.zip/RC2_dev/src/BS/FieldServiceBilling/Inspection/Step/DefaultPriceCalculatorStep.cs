﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Crsf.Core;
using Crsf.Core.Inrule;
using Crsf.Core.Service;
using Crsf.Core.Interface;
using ServiceLink.Billing.Definition;
using ServiceLink.Billing.Implementation;
using InspectionRuleMode = ServiceLink.Billing.Inspection.RuleModel;

namespace FieldService.Billing.Inspection.Step
{
    public class DefaultPriceCalculatorStep : BillingStepBase
    {
        public DefaultPriceCalculatorStep(IBillingContext billingContext) : base(billingContext)
        {
        }

        public override string Id
        {
            get
            {
                return "Inspection.DefaultPriceCalculator";
            }
        }

        public override void GetStepOnlyData()
        {
            base.GetStepOnlyData();
        }

        public override bool Validate()
        {
            return base.Validate();
        }
        public override void ProcessStep()
        {
            base.ProcessStep();
            InspectionBillingContextData context = this.BillingContext.ContextData as InspectionBillingContextData;

            int? switchedProductId = context.SwitchedProductId;
            int? subClientProfileId = context.WorkOrder.Order.Loan.SubClientProfileId;
            string validCountyName = context.WorkOrder.Order.Loan.ValidCountyName;
            string validStateCode = context.WorkOrder.Order.Loan.ValidStateCode;
            string validZipCode = context.WorkOrder.Order.Loan.ValidZipCode;
            int? investorProfileId = context.InvestorProfile.InvestorProfileId;
            int? productId = context.WorkOrder.Product.ProductId;
            decimal? rushRate = context.ClientPricing.RushRate;
            decimal? initialRate = context.ClientPricing.InitialRate;
            decimal? subsequentRate = context.ClientPricing.SubsequentRate;
            decimal? standardRate = context.ClientPricing.StandardRate;
            bool? isRushOrder = context.WorkOrder.Order.IsRushOrder;
            bool? isInitial = context.WorkOrder.Order.IsInitial;

            InspectionRuleMode.InspectionRuleSummary ruleSummary = new DefaultPriceCalculatorStepRuleService().DefaultPriceCalculatorResult(
                switchedProductId, subClientProfileId, validCountyName, validStateCode, validZipCode, investorProfileId, productId, rushRate, initialRate,
                subsequentRate, standardRate, isRushOrder, isInitial);

            if (!ruleSummary.Successful)
            {
                this.BillingContext.FailureReason = ruleSummary.FailureReason;
            }
            else if (ruleSummary.IsDirty)
            {
                this.BillingContext.BasePrice = ruleSummary.BasePrice;
                this.BillingContext.BasePriceSelectionReason = ruleSummary.BasePriceSelectionReason;
                this.BillingContext.PriceTracker = ruleSummary.PriceTracker;
            }
            this.BillingContext.Successful = ruleSummary.Successful;
        }
    }
    public class DefaultPriceCalculatorStepRuleService : BusinessRuleServiceBase
    {
        [BusinessRuleMethod(Entity = "DefaultPriceCalculator", RuleGroup = "FieldServiceInspectionBillingRules", RuleSet = "CalculateDefaultPrice")]
        public InspectionRuleMode.InspectionRuleSummary DefaultPriceCalculatorResult(int? switchedProductId, int? subClientProfileId, 
            string validCountyName, string validStateCode, string validZipCode, int? investorProfileId, int? productId, decimal? rushRate, decimal? initialRate,
            decimal? subsequentRate, decimal? standardRate, bool? isRushOrder, bool? isInitial)
        {
            InspectionRuleMode.DefaultPriceCalculator ruleEntity = new InspectionRuleMode.DefaultPriceCalculator();
            ruleEntity.IsDirty = false;
            ruleEntity.SwitchedProductId = switchedProductId;

            ruleEntity.ClientPricing = new InspectionRuleMode.ClientPricing();
            ruleEntity.ClientPricing.RushRate = rushRate;
            ruleEntity.ClientPricing.InitialRate = initialRate;
            ruleEntity.ClientPricing.SubsequentRate = subsequentRate;
            ruleEntity.ClientPricing.StandardRate = standardRate;

            ruleEntity.Loan = new InspectionRuleMode.Loan();
            ruleEntity.Loan.SubClientProfileId = subClientProfileId;
            ruleEntity.Loan.ValidCountyName = validCountyName;
            ruleEntity.Loan.ValidStateCode = validStateCode;
            ruleEntity.Loan.ValidZipCode = validZipCode;

            ruleEntity.Product = new InspectionRuleMode.Product();
            ruleEntity.Product.ProductId = productId;

            ruleEntity.InvestorProfile = new InspectionRuleMode.InvestorProfile();
            ruleEntity.InvestorProfile.InvestorProfileId = investorProfileId;

            ruleEntity.Order = new InspectionRuleMode.Order();
            ruleEntity.Order.IsRushOrder = isRushOrder;
            ruleEntity.Order.IsInitial = isInitial;

            InspectionRuleMode.InspectionRuleSummary defaultPricCalSummary = new InspectionRuleMode.InspectionRuleSummary();

            IBusinessRuleResponse ruleResp = base.ExecuteRule(ruleEntity);

            defaultPricCalSummary.BasePrice = (ruleResp.EntityState as InspectionRuleMode.DefaultPriceCalculator).BasePrice;
            defaultPricCalSummary.PriceTracker = (ruleResp.EntityState as InspectionRuleMode.DefaultPriceCalculator).PriceTracker;
            defaultPricCalSummary.BasePriceSelectionReason = (ruleResp.EntityState as InspectionRuleMode.DefaultPriceCalculator).BasePriceSelectionReason;
            defaultPricCalSummary.FailureReason = (ruleResp.EntityState as InspectionRuleMode.DefaultPriceCalculator).FailureReason;
            defaultPricCalSummary.Successful = (ruleResp.EntityState as InspectionRuleMode.DefaultPriceCalculator).Successful;
            defaultPricCalSummary.IsDirty = (ruleResp.EntityState as InspectionRuleMode.DefaultPriceCalculator).IsDirty;

            return defaultPricCalSummary;
        }
    }
}
