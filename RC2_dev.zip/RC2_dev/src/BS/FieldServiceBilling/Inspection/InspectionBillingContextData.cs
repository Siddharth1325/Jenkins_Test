﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using BusinessSvcImpl.DataObjects.SpaAccounting.Dto;
using InspSvc = Inspections.ServiceProxy.InspectionSvc;
using AdminClientSvc = Admin.ServiceProxy.ClientService;
using AdminInvestorSvc = Admin.ServiceProxy.InvestorService;
using VMSvc = Vendor.ServiceProxy.VendorService;

namespace FieldService.Billing.Inspection
{
    public class InspectionBillingContextData
    {
        public InspectionBillingContextData()
        {
            IsOVLProduct = false;
            IsCancellation = false;
            IsEligibleForTran32 = true;
            IsQCOverride = false;
        }

        public Application TenantApplication { get; set; }

        public bool IsOVLProduct { get; set; }

        public bool IsCancellation { get; set; }

        public int? SwitchedProductId { get; set; }

        public bool IsEligibleForTran32 { get; set; }

        public bool IsQCOverride { get; set; }

        [XmlIgnore]
        public WorkOrder WorkOrder { get; set; }     

        [XmlIgnore]
        public InspSvc.InspectionResult InspectionResult { get; set; }

        [XmlIgnore]
        public AdminClientSvc.MasterClientProfile MasterClientProfile { get; set; }

        [XmlIgnore]
        public AdminClientSvc.SubClientProfile SubClientProfile { get; set; }

        [XmlIgnore]
        public AdminInvestorSvc.InvestorProfile InvestorProfile { get; set; }

        [XmlIgnore]
        public AdminClientSvc.ClientAccounting ClientAccounting { get; set; }

        [XmlIgnore]
        public AdminClientSvc.ClientPrice ClientPricing { get; set; }

        [XmlIgnore]
        public VMSvc.VendorPricing VendorPricing { get; set; }
    }
}
