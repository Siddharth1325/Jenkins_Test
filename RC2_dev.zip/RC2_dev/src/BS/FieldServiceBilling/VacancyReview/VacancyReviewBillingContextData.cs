﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using BusinessSvcImpl.DataObjects.SpaAccounting.Dto;
using AdminClientSvc = Admin.ServiceProxy.ClientService;
using AdminInvestorSvc = Admin.ServiceProxy.InvestorService;

namespace FieldService.Billing.VacancyReview
{
    public class VacancyReviewBillingContextData
    {
        public VacancyReviewBillingContextData()
        {
            IsCancellation = false;
        }

        public Application TenantApplication { get; set; }

        public bool IsCancellation { get; set; }

        public int? SwitchedProductId { get; set; }

        [XmlIgnore]
        public WorkOrder WorkOrder { get; set; }     

        [XmlIgnore]
        public AdminClientSvc.MasterClientProfile MasterClientProfile { get; set; }

        [XmlIgnore]
        public AdminClientSvc.SubClientProfile SubClientProfile { get; set; }

        [XmlIgnore]
        public AdminInvestorSvc.InvestorProfile InvestorProfile { get; set; }

        [XmlIgnore]
        public AdminClientSvc.ClientAccounting ClientAccounting { get; set; }

        [XmlIgnore]
        public AdminClientSvc.ClientPrice ClientPricing { get; set; }

        [XmlIgnore]
        public AdminClientSvc.ClientProduct ClientProduct { get; set; }
    }
}
