﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FS.AccountingBilling.Inspection;

namespace FS.AccountingBilling.Common.WorkOrder
{
    public class WorkOrderProcessorFactory
    {
        private WorkOrderProcessorFactory()
        {
        }
        private static WorkOrderProcessorFactory _Instance = new WorkOrderProcessorFactory();
        public static WorkOrderProcessorFactory Instance { get { return _Instance; } }
        public WorkOrderProcessorBase GetWorkOrderBillingProcessor(string applicationCode, int workOrderId)
        {
            if (string.IsNullOrEmpty(applicationCode)) throw new ArgumentNullException("applicationCode");
            else if (workOrderId <= 0) throw new ArgumentOutOfRangeException("workOrderId");

            switch(applicationCode.Trim().ToUpper())
            {
                default:
                    return new WorkOrderProcessor(applicationCode, workOrderId);
            }
        }
    }
}
