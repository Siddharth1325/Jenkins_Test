﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using  FS.AccountingBilling.Common;

namespace FS.AccountingBilling.Common.WorkOrder
{
    public abstract class WorkOrderBillingAdjustorBase : ICalculator
    {
        WorkOrderBillingContext _BillingContext = null;
        public WorkOrderBillingAdjustorBase(WorkOrderBillingContext billingContext)
        {
            if (billingContext == null) throw new ArgumentNullException("billingContext");
            else _BillingContext = billingContext;
        }

        public string Name
        {
            get { return this.GetType().Name; }
        }

        public IAccountingBillingContext BillingContext
        {
            get { return _BillingContext; }
        }

        public virtual void Calculate()
        {
            throw new NotImplementedException();
        }

        public virtual bool EndAfter()
        {
            throw new NotImplementedException();
        }
    }
}
