﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FS.AccountingBilling.Common.WorkOrder
{
    internal class WorkOrderBillingController
    {
        List<ICalculator> _BillingSequence = new List<ICalculator>();

        internal WorkOrderBillingController()
        {
        }

        internal void AddBillingSequence(ICalculator billingCalculator)
        {
            if (billingCalculator == null)
                throw new ArgumentNullException("billingCalculator");
            else
                _BillingSequence.Add(billingCalculator);
        }

        internal void StartSequence()
        {
            foreach(ICalculator calc in _BillingSequence)
            {
                calc.Calculate();
                if (!calc.BillingContext.Successful)
                    break;
                else if (calc.EndAfter()) break;
            }
        }
    }
}
