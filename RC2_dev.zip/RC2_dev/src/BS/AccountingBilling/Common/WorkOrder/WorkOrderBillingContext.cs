﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FS.AccountingBilling.Common;
using DomainModel.Accounting;
using InspRM = Inspections.ServiceProxy.InspectionSvc;
using AdminClientRM = Admin.ServiceProxy.ClientService;
using AdminProdRM = Admin.ServiceProxy.ProductService;
using AdminInvestorRM = Admin.ServiceProxy.InvestorService;
using VMRM = Vendor.ServiceProxy.VendorService;

namespace FS.AccountingBilling.Common.WorkOrder
{
    public class WorkOrderBillingContext : IAccountingBillingContext
    {
        public WorkOrderBillingContext()
        {
            IsOVLProduct = false;
            IsEligibleForTran32 = true;
        }

        private List<Adjustment> _CostAdjustments = new List<Adjustment>();
        private List<Adjustment> _PriceAdjustments = new List<Adjustment>();

        public string ApplicationCode { get; set; }
        public decimal? BaseCost { get; set; }
        public decimal? BasePrice { get; set; }
        public string BaseCostSelectionReason { get; set; }
        public string BasePriceSelectionReason { get; set; }
        public decimal? FinalCost { get; set; }
        public decimal? FinalPrice { get; set; }
        public List<Adjustment> CostAdjustments { get { return _CostAdjustments; } }
        public List<Adjustment> PriceAdjustments { get { return _PriceAdjustments; } }
        public bool Successful { get; set; }
        public string FailureReason { get; set; }
        
        public InspRM.Loan Loan { get; set; }
        public InspRM.Order Order { get; set; }
        public InspRM.WorkOrder WorkOrder { set; get; }
        public AdminClientRM.MasterClientProfile MasterClientProfile { get; set; }
        public AdminClientRM.SubClientProfile SubClientProfile { get; set; }
        public AdminInvestorRM.InvestorProfile Investor { get; set; }
        public InspRM.Product Product { get; set; }
        public int? SwitchedProductId { get; set; }
        public bool IsOVLProduct { get; set; }
        public InspRM.WorkOrderItem[] WorkOrderItems { get; set; }
        public InspRM.InspectionResult InspectionResult { get; set; }
        public AdminClientRM.ClientAccounting ClientAccounting { get; set; }
        public AdminClientRM.ClientPrice ClientPricing { get; set; }        
        public bool IsEligibleForTran32 { get; set; }
        public VMRM.VendorPricing VendorPricing { get; set; }
        public decimal PriceTracker { get; set; }
        public decimal CostTracker { get; set; }
    }
}
