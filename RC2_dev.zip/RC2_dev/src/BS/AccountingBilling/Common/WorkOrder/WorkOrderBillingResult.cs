﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DomainModel.Accounting;

namespace FS.AccountingBilling.Common.WorkOrder
{
    public class WorkOrderBillingResult
    {
        public AccountsReceivable AccountsReceivable { get; set; }
        public AccountsPayable AccountsPayable { get; set; }
        
    }
}
