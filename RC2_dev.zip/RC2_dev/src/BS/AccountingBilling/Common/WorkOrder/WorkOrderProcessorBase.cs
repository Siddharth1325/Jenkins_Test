﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FS.AccountingBilling.Inspection;
using DomainModel.Accounting;
using Delegate.SpaAcc;
using Reference.ServiceProxy.ReferenceService;

namespace FS.AccountingBilling.Common.WorkOrder
{
    public abstract class WorkOrderProcessorBase
    {
        protected int _WorkOrderId = 0;
        private WorkOrderBillingContext _BillingContext = new WorkOrderBillingContext();
        private WorkOrderBillingController _Controller = new WorkOrderBillingController();

        public WorkOrderProcessorBase(string applicationCode, int workOrderId)
        {
            if (string.IsNullOrEmpty(applicationCode))
                throw new ArgumentNullException("applicationCode");
            else if (workOrderId <= 0)
                throw new ArgumentOutOfRangeException("workOrderId");
            else
            {
                _BillingContext.ApplicationCode = applicationCode;
                _WorkOrderId = workOrderId;
            }
        }

        #region BillingContext
        public WorkOrderBillingContext BillingContext  
        { 
            get { return _BillingContext; } 
        }
        #endregion

        #region FindWorkOrder
        //Force child calss to implement
        public virtual void FindWorkOrder()
        {
            throw new NotImplementedException();
        }
        #endregion

        #region ValidateWorkOrder
        
        public const string Validation_WorkOrder_NotExist = "WorkOrder {0} doesn't exist, or its parent Order doesn't exist";
        public const string Validation_WorkOrderItem_NotExist = "WorkOrderItem for WorkOrder {0} doesn't exist";
        public const string Validation_WorkOrder_NotAssigned = "WorkOrder {0} doesn't have an assigned vendor";
        public const string Validation_WorkOrder_NotReadyForBilling = "WorkOrder {0} is not ready for billing";
        public const string Validation_WorkOrderItem_NotReadyForBilling = "WorkOrder {0} children WorkOrderItems are not ready for billing";
        public const string Validation_WorkOrder_AlreadyProcessedForBilling = "WorkOrder {0} has been processed on {1}";
        public const string Validation_LoanClient_Missing = "Order {0} doesn't have loan or client information";

        public virtual bool ValidateWorkOrder(out string validationMsg)
        {
            bool isValid = true;
            StringBuilder sb = new StringBuilder();

            if(_BillingContext.WorkOrder == null || _BillingContext.Order == null)
            {
                isValid = false;
                sb.Append(string.Format(Validation_WorkOrder_NotExist, _WorkOrderId)).Append("\n");
            }
            else
            {
                if (string.IsNullOrEmpty(_BillingContext.WorkOrder.WorkOrderStatusGroup) || string.IsNullOrEmpty(_BillingContext.WorkOrder.WorkOrderStatusType) ||
                        string.Compare(_BillingContext.WorkOrder.WorkOrderStatusGroup.Trim(), "WOSTA", true) != 0 ||
                        !(string.Compare(_BillingContext.WorkOrder.WorkOrderStatusType.Trim(), "BILL", true) == 0 || string.Compare(_BillingContext.WorkOrder.WorkOrderStatusType.Trim(), "CANCEL", true) == 0))
                {
                    isValid = false;
                    sb.Append(string.Format(Validation_WorkOrder_NotReadyForBilling, _WorkOrderId)).Append("\n");
                }
                if (_BillingContext.WorkOrder.AcctProcessedDate.HasValue && _BillingContext.WorkOrder.AcctProcessedDate.Value > DateTime.MinValue)
                {
                    isValid = false;
                    sb.Append(string.Format(Validation_WorkOrder_AlreadyProcessedForBilling, _WorkOrderId, _BillingContext.WorkOrder.AcctProcessedDate.Value)).Append("\n");
                }
                if (string.Compare(_BillingContext.WorkOrder.WorkOrderStatusType.Trim(), "CANCEL", true) != 0 && !_BillingContext.WorkOrder.AssignedVendorId.HasValue && !_BillingContext.IsOVLProduct )
                {
                    isValid = false;
                    sb.Append(string.Format(Validation_WorkOrder_NotAssigned, _WorkOrderId)).Append("\n");
                }
                if (string.Compare(_BillingContext.WorkOrder.WorkOrderStatusType.Trim(), "BILL", true) == 0)
                {
                    foreach (var wi in _BillingContext.WorkOrderItems)
                    {
                        if (string.IsNullOrEmpty(wi.WorkOrderItemStatusType) || string.Compare(wi.WorkOrderItemStatusType, "COMP", true) != 0)
                        {
                            isValid = false;
                            sb.Append(string.Format(Validation_WorkOrderItem_NotReadyForBilling, _WorkOrderId)).Append("\n");
                            break;
                        }
                    }
                }
                else if (_BillingContext.WorkOrderItems == null || _BillingContext.WorkOrderItems.Count() == 0)
                {
                    isValid = false;
                    sb.Append(string.Format(Validation_WorkOrderItem_NotExist, _WorkOrderId)).Append("\n");
                }
            }

            if(_BillingContext.Loan == null || !_BillingContext.Loan.SubClientProfileId.HasValue)
            {
                isValid = false;
                sb.Append(string.Format(Validation_LoanClient_Missing, _BillingContext.Order.OrderId)).Append("\n");
            }

            validationMsg = sb.ToString();

            return isValid;
        }
        #endregion

        #region Init
        //Force child class to implement
        protected virtual void Init()
        {
            throw new NotImplementedException();
        }
        #endregion

        #region AddCalculator
        protected void AddCalculator(ICalculator calc)
        {
            this._Controller.AddBillingSequence(calc);
        }
        #endregion

        #region GenerateAPAndAR
        public virtual WorkOrderBillingResult GenerateAPAndAR()
        {
            FindWorkOrder();
            string validationMsg = string.Empty;
            if (!ValidateWorkOrder(out validationMsg))
                throw new ArgumentException(validationMsg);

            WorkOrderBillingResult result = new WorkOrderBillingResult();
            Init();
            _Controller.StartSequence();
            if (_BillingContext.Successful)
            {
                AccountsPayable payable = _BillingContext.IsOVLProduct ? null : CreateAccountsPayable();
                AccountsReceivable receivable = CreateAccountsReceivable();
                if (payable != null && receivable != null)
                    new AccountingBillingDelegate().SaveAPnAR(receivable, payable, _BillingContext.WorkOrder.WorkOrderId);
                else if (payable != null)
                    new AccountingBillingDelegate().SaveAccountsPayable(payable, _BillingContext.WorkOrder.WorkOrderId);
                else if(receivable != null)
                    new AccountingBillingDelegate().SaveAccountsReceiveable(receivable, _BillingContext.WorkOrder.WorkOrderId);

                result.AccountsPayable = payable;
                result.AccountsReceivable = receivable;
            }
            else
            {
                CommonLib.Logging.LogError(_BillingContext.FailureReason);
                throw new Exception(_BillingContext.FailureReason);
            }
            return result;
        }

        protected virtual AccountsPayable CreateAccountsPayable()
        {
            if (_BillingContext.WorkOrder != null && !_BillingContext.WorkOrder.AssignedVendorId.HasValue) return null;

            AccountsPayable payable = new AccountsPayable();
            payable.GLTransTypeGroup = "GLTRN";
            payable.GLTransType = "APTRANS";                        
            payable.TotalAmountDue = _BillingContext.FinalCost.HasValue ? _BillingContext.FinalCost.Value : CalculateCompound(_BillingContext.BaseCost, _BillingContext.CostAdjustments);
            payable.SubtotalDue = payable.TotalAmountDue;
            payable.TaxesDue = 0.00m;
            payable.WorkOrderId = _BillingContext.WorkOrder.WorkOrderId;

            AccountsPayableDetail payableDetail = new AccountsPayableDetail();
            payableDetail.APStatusGroup = "APSG";
            payableDetail.APStatusType = "RDY2BILL";
            payableDetail.BaseTotalCost = _BillingContext.BaseCost.HasValue ? _BillingContext.BaseCost.Value : 0.00m;
            payableDetail.BaseCostPerUnit = payableDetail.BaseTotalCost;
            payableDetail.FinalTotalCost = payable.TotalAmountDue;
            payableDetail.Quantity = 1;
            payableDetail.UnitsGroup = "APUN";
            payableDetail.UnitsType = "APUN1";
            payableDetail.WorkOrderItemId = _BillingContext.WorkOrderItems[0].WorkOrderItemId;

            AccountsPayableTrace firstTrace = new AccountsPayableTrace();
            firstTrace.CostSelectionReason = _BillingContext.BaseCostSelectionReason;
            firstTrace.StartingCost = _BillingContext.BaseCost;
            payableDetail.AccountsPayableTraces.Add(firstTrace);

            if(_BillingContext.CostAdjustments != null && _BillingContext.CostAdjustments.Count > 0)
            {
                decimal prevCost = _BillingContext.BaseCost.HasValue ? _BillingContext.BaseCost.Value : 0.00m;

                foreach (Adjustment costAdj in _BillingContext.CostAdjustments)
                {
                    AccountsPayableTrace payableTrace = new AccountsPayableTrace();
                    payableTrace.StartingCost = prevCost;
                    payableTrace.CostAdjustment = decimal.Round(prevCost * costAdj.AdjustPercentage / 100.0m, 2, MidpointRounding.AwayFromZero);
                    prevCost = decimal.Round(prevCost * (1 + costAdj.AdjustPercentage / 100.0m), 2, MidpointRounding.AwayFromZero);
                    payableTrace.CostAdjustmentTypeGroup = costAdj.AdjustmentGroupCode;
                    payableTrace.CostAdjustmentType = costAdj.AdjustmentTypeCode;
                    payableTrace.CostSelectionReason = GetReferenceElementName(costAdj.AdjustmentGroupCode, costAdj.AdjustmentTypeCode);
                    payableDetail.AccountsPayableTraces.Add(payableTrace);
                }
            }

            payable.AccountsPayableDetails.Add(payableDetail);

            return payable;  
        }

        private decimal CalculateCompound(decimal? start, List<Adjustment> adjustments)
        {
            if (!start.HasValue) return 0.00m;
            if (adjustments == null || adjustments.Count == 0) return start.Value;

            decimal temp = start.Value;
            foreach(Adjustment adj in adjustments)
            {
                temp = decimal.Round(temp * (1 + adj.AdjustPercentage / 100.00m), 2, MidpointRounding.AwayFromZero);
            }
            return temp;
        }

        protected virtual AccountsReceivable CreateAccountsReceivable()
        {
            AccountsReceivable receivable = new AccountsReceivable();
            receivable.GLTransTypeGroup = "GLTRN";
            receivable.GLTransType = "ARTRANS";
            receivable.IsEligibleForTran32 = _BillingContext.IsEligibleForTran32; 
            receivable.TotalAmountDue = _BillingContext.FinalPrice.HasValue ? _BillingContext.FinalPrice.Value : CalculateCompound(_BillingContext.BasePrice, _BillingContext.PriceAdjustments);
            receivable.SubtotalDue = receivable.TotalAmountDue;
            receivable.TaxesDue = 0.00m;
            receivable.Tran32ProcessedDate = null;
            receivable.WorkOrderId = _BillingContext.WorkOrder.WorkOrderId;

            AccountsReceivableDetail receivableDetail = new AccountsReceivableDetail();
            receivableDetail.ARStatusGroup = "ARSG";
            receivableDetail.ARStatusType = "NEW";
            receivableDetail.BasePricePerUnit = _BillingContext.BasePrice.HasValue ? _BillingContext.BasePrice.Value : 0.00m;
            receivableDetail.BaseTotalPrice = _BillingContext.BasePrice.HasValue ? _BillingContext.BasePrice.Value : 0.00m;
            receivableDetail.FinalTotalPrice = receivable.TotalAmountDue;
            receivableDetail.Quantity = 1;
            receivableDetail.UnitsGroup = "ARUN";
            receivableDetail.UnitsType = "ARUN1";
            receivableDetail.WorkOrderItemId = _BillingContext.WorkOrderItems[0].WorkOrderItemId;

            AccountsReceivableTrace firstTrace = new AccountsReceivableTrace();
            firstTrace.PriceSelectionReason = _BillingContext.BasePriceSelectionReason;
            firstTrace.StartingPrice = _BillingContext.BasePrice;
            receivableDetail.AccountsReceivableTraces.Add(firstTrace);

            if (_BillingContext.PriceAdjustments != null && _BillingContext.PriceAdjustments.Count > 0)
            {
                decimal prevPrice = _BillingContext.BasePrice.HasValue ? _BillingContext.BasePrice.Value : 0.00m;
                foreach (Adjustment priceAdj in _BillingContext.PriceAdjustments)
                {
                    AccountsReceivableTrace receivableTrace = new AccountsReceivableTrace();
                    receivableTrace.StartingPrice = prevPrice;
                    receivableTrace.PriceAdjustment = decimal.Round(prevPrice * priceAdj.AdjustPercentage / 100.0m, 2, MidpointRounding.AwayFromZero);
                    prevPrice = decimal.Round(prevPrice * (1 + priceAdj.AdjustPercentage / 100.0m), 2, MidpointRounding.AwayFromZero);
                    receivableTrace.PriceAdjustmentTypeGroup = priceAdj.AdjustmentGroupCode;
                    receivableTrace.PriceAdjustmentType = priceAdj.AdjustmentTypeCode;
                    receivableTrace.PriceSelectionReason = GetReferenceElementName(receivableTrace.PriceAdjustmentTypeGroup, receivableTrace.PriceAdjustmentType);
                    receivableDetail.AccountsReceivableTraces.Add(receivableTrace);
                }
            }

            receivable.AccountsReceivableDetails.Add(receivableDetail);

            return receivable;
        }                
        #endregion

        #region GetReferenceElementName
        private string GetReferenceElementName(string groupCode, string elementCode)
        {
            if (string.IsNullOrEmpty(groupCode))
                throw new ArgumentNullException(groupCode);
            else if (string.IsNullOrEmpty(elementCode))
                throw new ArgumentNullException(elementCode);

            ReferenceData rdata = null;
            using(var proxy = new ReferenceDataServiceClient())
            {
                var response = proxy.GetReferenceDataElementByCode(new GetReferenceDataElementByCodeRequest() { GroupCode = groupCode, ElementCode = elementCode });
                rdata = response != null && response.ReferenceDataElement != null ? response.ReferenceDataElement : null;
            }

            return rdata != null ? rdata.ElementName : string.Empty;
        }
        #endregion
    }
}
