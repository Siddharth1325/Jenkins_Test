﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FS.AccountingBilling.Common
{
    public interface IAccountingBillingContext
    {
        string ApplicationCode { get; set; }
        decimal? BaseCost { get; set; }
        decimal? BasePrice { get; set; }
        string BaseCostSelectionReason { get; set; }
        string BasePriceSelectionReason { get; set; }
        decimal? FinalCost { get; set; }
        decimal? FinalPrice { get; set; }
        List<Adjustment> CostAdjustments { get; }
        List<Adjustment> PriceAdjustments { get; }
        bool Successful { get; set; }
        string FailureReason { get; set; }
    }
}
