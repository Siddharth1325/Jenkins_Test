﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FS.AccountingBilling.Common
{
    public interface ICalculator
    {
        string Name { get; }

        IAccountingBillingContext BillingContext { get; }

        /// <summary>
        /// Add Adjusment records into IAccountingBillingContext
        /// </summary>
        void Calculate();

        bool EndAfter();
    }

    public class Adjustment
    {
        /// <summary>
        /// Adjust Cost
        /// </summary>
        /// <returns>Percentage of cost change, e.g., -1 (-100%) means set the cost to zero, -0.5 (-50%) means reduce the cost by half</returns>
        public decimal AdjustPercentage { get; set; }
        public string AdjustmentGroupCode { get; set; }
        public string AdjustmentTypeCode { get; set; }
    }
}
