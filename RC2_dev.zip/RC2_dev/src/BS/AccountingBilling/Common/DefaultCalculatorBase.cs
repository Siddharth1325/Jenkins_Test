﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FS.AccountingBilling.Common
{
    public abstract class DefaultCalculatorBase : ICalculator
    {
        IAccountingBillingContext _BillingContext = null;
        public DefaultCalculatorBase(IAccountingBillingContext billingContext)
        {
            if (billingContext == null) throw new ArgumentNullException("billingContext");
            else _BillingContext = billingContext;
        }

        public virtual string Name
        {
            get { return this.GetType().Name; }
        }

        public IAccountingBillingContext BillingContext
        {
            get { return _BillingContext; }
        }

        //Force child class to implement
        public virtual void Calculate()
        {
            throw new NotImplementedException();
        }

        public bool EndAfter()
        {
            return false; 
        }
    }
}
