﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Delegate.SpaAcc;
using FS.AccountingBilling.Common;
using FS.AccountingBilling.Common.WorkOrder;
using Inspections.ServiceProxy.InspectionSvc;

namespace FS.AccountingBilling.Inspection.Adjustor
{
    public class CancellationAdjustor : WorkOrderBillingAdjustorBase
    {
        private bool _Calculated = false;
        public CancellationAdjustor(WorkOrderBillingContext billingContext)
            : base(billingContext) { }

        public override void Calculate()
        {
            WorkOrderBillingContext context = this.BillingContext as WorkOrderBillingContext;
            
            if (string.Compare(context.WorkOrder.WorkOrderStatusType, "CANCEL", true) == 0)
            {
                if (!context.WorkOrder.AssignedVendorId.HasValue || context.InspectionResult == null || !context.InspectionResult.IsWorkPerformed)
                {
                    context.CostAdjustments.Add(new Adjustment() { AdjustmentGroupCode = "APADJ", AdjustmentTypeCode = "CANCL", AdjustPercentage = -100.00m });
                    context.CostTracker = 0.00m;
                    context.FinalCost = 0.0m;

                    if (string.Compare(context.WorkOrder.CancellationReasonType, "BADADDR", true) == 0)
                    {
                        if (context.ClientAccounting != null && context.ClientAccounting.IsBillForPrevBadAddress && context.ClientAccounting.PrevBadAddressAmount.HasValue)
                        {
                            decimal percentage = context.PriceTracker == 0.00m ? 0.00m : (context.ClientAccounting.PrevBadAddressAmount.Value - context.PriceTracker) / context.PriceTracker * 100.00m;
                            context.PriceAdjustments.Add(new Adjustment() { AdjustmentGroupCode = "ARADJ", AdjustmentTypeCode = "CANCL", AdjustPercentage = decimal.Round(percentage, 2, MidpointRounding.AwayFromZero) });
                            context.PriceTracker = context.ClientAccounting.PrevBadAddressAmount.Value;
                            context.FinalPrice = context.ClientAccounting.PrevBadAddressAmount.Value;
                        }
                        else if (context.ClientAccounting != null && !context.ClientAccounting.IsBillForPrevBadAddress)
                        {
                            context.PriceAdjustments.Add(new Adjustment() { AdjustmentGroupCode = "ARADJ", AdjustmentTypeCode = "CANCL", AdjustPercentage = -100.00m });
                            context.PriceTracker = 0.0m;
                            context.FinalPrice = 0.0m;
                            context.IsEligibleForTran32 = false;
                        }
                    }
                    else if (string.Compare(context.WorkOrder.CancellationReasonType, "INSFADDR", true) == 0)
                    {
                        if (context.ClientAccounting != null && context.ClientAccounting.IsBillForInsufficientAddress && context.ClientAccounting.InsufficientAddressAmount.HasValue)
                        {
                            decimal percentage = context.PriceTracker == 0.00m ? 0.00m : (context.ClientAccounting.InsufficientAddressAmount.Value - context.PriceTracker) / context.PriceTracker * 100.00m;
                            context.PriceAdjustments.Add(new Adjustment() { AdjustmentGroupCode = "ARADJ", AdjustmentTypeCode = "CANCL", AdjustPercentage = decimal.Round(percentage, 2, MidpointRounding.AwayFromZero) });
                            context.PriceTracker = context.ClientAccounting.InsufficientAddressAmount.Value;
                            context.FinalPrice = context.ClientAccounting.InsufficientAddressAmount.Value;
                        }
                        else if (context.ClientAccounting != null && !context.ClientAccounting.IsBillForInsufficientAddress)
                        {
                            context.PriceAdjustments.Add(new Adjustment() { AdjustmentGroupCode = "ARADJ", AdjustmentTypeCode = "CANCL", AdjustPercentage = -100.00m });
                            context.PriceTracker = 0.0m;
                            context.FinalPrice = 0.0m;
                            context.IsEligibleForTran32 = false;
                        }
                    }
                    else if (context.ClientAccounting != null && context.ClientAccounting.IsBillCancellations && context.ClientAccounting.CancellationAmount.HasValue)
                    {
                        decimal percentage = context.PriceTracker == 0.00m ? 0.00m : (context.ClientAccounting.CancellationAmount.Value - context.PriceTracker) / context.PriceTracker * 100.00m;
                        context.PriceAdjustments.Add(new Adjustment() { AdjustmentGroupCode = "ARADJ", AdjustmentTypeCode = "CANCL", AdjustPercentage = decimal.Round(percentage, 2, MidpointRounding.AwayFromZero) });
                        context.PriceTracker = context.ClientAccounting.CancellationAmount.Value;
                        context.FinalPrice = context.ClientAccounting.CancellationAmount.Value;
                    }
                    else
                    {
                        context.PriceAdjustments.Add(new Adjustment() { AdjustmentGroupCode = "ARADJ", AdjustmentTypeCode = "CANCL", AdjustPercentage = -100.00m });
                        context.PriceTracker = 0.0m;
                        context.FinalPrice = 0.0m;
                        context.IsEligibleForTran32 = false;
                    }
                }
            }
            
            DateTime? workOrderCancellationDate = new Nullable<DateTime>();
            bool cancelledWithin24Hrs = false;
            if (context.WorkOrder.Order.Cancellations != null && context.WorkOrder.Order.Cancellations.Count > 0)
            {
                Cancellation workOrderCancellation = context.WorkOrder.Order.Cancellations.Where(c => c.CancelledWorkOrderId.HasValue && c.CancelledWorkOrderId.Value == context.WorkOrder.WorkOrderId).OrderByDescending(c => c.CancellationDate).FirstOrDefault();
                Cancellation orderCancellation = context.WorkOrder.Order.Cancellations.Where(c => c.CancelledOrderId.HasValue && c.CancelledOrderId.Value == context.Order.OrderId).OrderByDescending(c => c.CancellationDate).FirstOrDefault();
                Cancellation loanCancellation = context.WorkOrder.Order.Cancellations.Where(c => c.CancelledLoanId.HasValue && c.CancelledLoanId.Value == context.Loan.LoanId).OrderByDescending(c => c.CancellationDate).FirstOrDefault();
                
                if (workOrderCancellation != null && workOrderCancellation.CancellationDate > DateTime.MinValue && context.WorkOrder.RequestedDate > DateTime.MinValue
                    && (workOrderCancellation.CancellationDate - context.WorkOrder.RequestedDate).Days <= 1)
                    cancelledWithin24Hrs = true;
                else if (orderCancellation != null && orderCancellation.CancellationDate > DateTime.MinValue && context.Order.RequestedDate > DateTime.MinValue
                    && (orderCancellation.CancellationDate - context.Order.RequestedDate).Days <= 1)
                    cancelledWithin24Hrs = true;
                else if (loanCancellation != null && loanCancellation.CancellationDate > DateTime.MinValue && context.Loan.CreatedDate > DateTime.MinValue
                    && (loanCancellation.CancellationDate - context.Loan.CreatedDate).Days <= 1)
                    cancelledWithin24Hrs = true;
            }
            else if((workOrderCancellationDate = new AccountingBillingDelegate().GetWorkOrderCancellationDate(context.WorkOrder.WorkOrderId)).HasValue)
            {
                if(workOrderCancellationDate.Value > DateTime.MinValue && context.WorkOrder.RequestedDate > DateTime.MinValue
                    && (workOrderCancellationDate.Value - context.WorkOrder.RequestedDate).Days <= 1)
                    cancelledWithin24Hrs = true;
            }

            if (cancelledWithin24Hrs)
            {
                context.PriceAdjustments.Add(new Adjustment() { AdjustmentGroupCode = "ARADJ", AdjustmentTypeCode = "24HRCNCL", AdjustPercentage = -100.00m });
                context.PriceTracker = 0.0m;
                context.FinalPrice = 0.0m;
                context.IsEligibleForTran32 = false;
            }
            
            _Calculated = true;
            context.Successful = true;
        }

        public override bool EndAfter()
        {
            if (!_Calculated) throw new Exception("CancellationAdjustor has not finished calculation");
            else
            {
                return this.BillingContext.FinalPrice.HasValue && this.BillingContext.FinalPrice == 0.00m
                    && this.BillingContext.FinalCost.HasValue && this.BillingContext.FinalCost.Value == 0.00m;
            }
        }
    }
}
