﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FS.AccountingBilling.Common;
using FS.AccountingBilling.Common.WorkOrder;

namespace FS.AccountingBilling.Inspection.Adjustor
{
    public class ClientWindowAdjustor : WorkOrderBillingAdjustorBase
    {
        private bool _Calculated = false;
        public ClientWindowAdjustor(WorkOrderBillingContext billingContext)
            : base(billingContext) {}

        public override void Calculate()
        {
            WorkOrderBillingContext context = this.BillingContext as WorkOrderBillingContext;
            if(context.InspectionResult != null && context.WorkOrder.WindowEndDate.HasValue && context.WorkOrder.WindowStartDate.HasValue && context.WorkOrder.WindowEndDate > context.WorkOrder.WindowStartDate 
                && context.ClientAccounting != null && !(context.ClientAccounting.IsPayOutOfCompliance && context.ClientAccounting.IsBillOutOfCompliance))
            {
                bool isOutOfCompliance = false;

                if ( context.InspectionResult.InspectionDate.HasValue)
                {
                    isOutOfCompliance = context.InspectionResult.InspectionDate.Value.Date > context.WorkOrder.WindowEndDate.Value.Date;
                }
                else
                {
                    if (context.InspectionResult.SubmissionDate > DateTime.MinValue)
                    {
                        isOutOfCompliance = context.InspectionResult.SubmissionDate.Date > context.WorkOrder.WindowEndDate.Value.Date;
                    }
                }
                 
                if(isOutOfCompliance && !context.ClientAccounting.IsBillOutOfCompliance)
                {
                    context.PriceTracker = 0.00m;
                    context.FinalPrice = 0.00m;
                    context.PriceAdjustments.Add(new Adjustment() { AdjustPercentage = -100.0m, AdjustmentGroupCode = "ARADJ", AdjustmentTypeCode = "CLWD" });                    
                }
                if(isOutOfCompliance && !context.ClientAccounting.IsPayOutOfCompliance)
                {
                    context.CostTracker = 0.00m;
                    context.FinalCost = 0.00m;
                    context.CostAdjustments.Add(new Adjustment() { AdjustPercentage = -100.0m, AdjustmentGroupCode = "APADJ", AdjustmentTypeCode = "CLWD" });
                }
            }            

            _Calculated = true;
            context.Successful = true;
        }

        public override bool EndAfter()
        {
            if (!_Calculated) throw new Exception("ClientWindowAdjustor has not finished calculation");
            else
            {
                return this.BillingContext.FinalPrice.HasValue && this.BillingContext.FinalPrice == 0.00m
                    && this.BillingContext.FinalCost.HasValue && this.BillingContext.FinalCost.Value == 0.00m;
            }
        }
    }
}
