﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FS.AccountingBilling.Common;
using FS.AccountingBilling.Common.WorkOrder;
using InspRM = Inspections.ServiceProxy.InspectionSvc;

namespace FS.AccountingBilling.Inspection.Adjustor
{
    public class WorkNotPerformedAdjustor  : WorkOrderBillingAdjustorBase
    {
        private bool _Calculated = false;
        public WorkNotPerformedAdjustor(WorkOrderBillingContext billingContext)
            : base(billingContext)
        {
        }

        public const string WNP_AccessDenied_Amount_Billed = "Client accounting setting allows billing for WNP - Access Denied";
        public const string WNP_BadAddress_Amount_Billed = "Client accounting setting allows billing for WNP - Bad Address";
        public const string WNP_Other_Amount_Billed = "Client accounting setting allows billing for WNP - Other";
        public const string WNP_Other_Cost_Zero = "Zero Cost on WNP - Other";

        public override void Calculate()
        {
            WorkOrderBillingContext context = this.BillingContext as WorkOrderBillingContext;
            if (context != null && context.WorkOrder != null && context.InspectionResult != null && context.InspectionResult.InspRsltWorkNotPerformeds != null 
                                                                                                 && context.InspectionResult.InspRsltWorkNotPerformeds.Count > 0)
            {
                context.IsEligibleForTran32 = false;
                if(context.ClientAccounting != null)
                {
                    if(context.InspectionResult.InspRsltWorkNotPerformeds.Where( p => string.Compare(p.AccessDeniedGroup, "WNPAD", true) == 0).Count() > 0)
                    {
                        if (context.ClientAccounting.IsBillForAccessDenied && context.ClientAccounting.AccessDeniedAmount.HasValue)
                        {
                            if(!context.BasePrice.HasValue)
                            {
                                context.BasePrice = context.ClientAccounting.AccessDeniedAmount.Value;
                                context.BasePriceSelectionReason = WNP_AccessDenied_Amount_Billed;
                            }
                            else
                            {
                                decimal percentage = context.PriceTracker == 0.00m ? 0.00m : (context.ClientAccounting.AccessDeniedAmount.Value - context.PriceTracker) / context.PriceTracker * 100.00m;
                                context.PriceAdjustments.Add(new Adjustment() { AdjustmentGroupCode = "ARADJ", AdjustmentTypeCode = "WNPAD", AdjustPercentage = decimal.Round(percentage, 2, MidpointRounding.AwayFromZero) });                        
                            }
                            context.PriceTracker = context.ClientAccounting.AccessDeniedAmount.Value;
                            context.FinalPrice = context.ClientAccounting.AccessDeniedAmount.Value;
                        }

                        context.CostAdjustments.Add(new Adjustment() { AdjustmentGroupCode = "APADJ", AdjustmentTypeCode = "WNPAD", AdjustPercentage = -50.00m });
                        context.CostTracker = decimal.Round(context.CostTracker * 0.50m, 2, MidpointRounding.AwayFromZero);
                    }
                    else if (context.InspectionResult.InspRsltWorkNotPerformeds.Where(p => string.Compare(p.BadAddrGroupCode, "WBAOR", true) == 0 || string.Compare(p.BadAddrGroupCode, "WBARE", true) == 0).Count() > 0)
                    {
                        if (context.ClientAccounting.IsBillForBadAddress && context.ClientAccounting.BadAddressAmount.HasValue)
                        {
                            if (!context.BasePrice.HasValue)
                            {
                                context.BasePrice = context.ClientAccounting.BadAddressAmount.Value;
                                context.BasePriceSelectionReason = WNP_BadAddress_Amount_Billed;
                            }
                            else
                            {
                                decimal percentage = context.PriceTracker == 0.00m ? 0.00m : (context.ClientAccounting.BadAddressAmount.Value - context.PriceTracker) / context.PriceTracker * 100.00m;
                                context.PriceAdjustments.Add(new Adjustment() { AdjustmentGroupCode = "ARADJ", AdjustmentTypeCode = "WNPBA", AdjustPercentage = decimal.Round(percentage, 2, MidpointRounding.AwayFromZero) });                            
                            }
                            context.PriceTracker = context.ClientAccounting.BadAddressAmount.Value;
                            context.FinalPrice = context.ClientAccounting.BadAddressAmount.Value;
                        }
                    }
                    else if (context.InspectionResult.InspRsltWorkNotPerformeds.Where(p => string.Compare(p.WorkNotPerformedReasonGroup, "WNPR1", true) == 0 && string.Compare(p.WorkNotPerformedReasonType, "WNPR13", true) == 0).Count() > 0)
                    {
                        if (context.ClientAccounting.IsBillWorkNotPerformed && context.ClientAccounting.WorkNotPerformedAmount.HasValue)
                        {
                            if (!context.BasePrice.HasValue)
                            {
                                context.BasePrice = context.ClientAccounting.WorkNotPerformedAmount.Value;
                                context.BasePriceSelectionReason = WNP_Other_Amount_Billed;
                            }
                            else
                            {
                                decimal percentage = context.PriceTracker == 0.00m ? 0.00m : (context.ClientAccounting.WorkNotPerformedAmount.Value - context.PriceTracker) / context.PriceTracker * 100.00m;
                                context.PriceAdjustments.Add(new Adjustment() { AdjustmentGroupCode = "ARADJ", AdjustmentTypeCode = "WNPOT", AdjustPercentage = decimal.Round(percentage, 2, MidpointRounding.AwayFromZero) });
                            }
                            context.PriceTracker = context.ClientAccounting.WorkNotPerformedAmount.Value;
                            context.FinalPrice = context.ClientAccounting.WorkNotPerformedAmount.Value;
                        }

                        /*
                        if (!context.BaseCost.HasValue)
                        {
                            context.BaseCost = 0.0m;
                            context.BaseCostSelectionReason = WNP_Other_Cost_Zero;
                        }
                        else
                        {
                            context.CostAdjustments.Add(new Adjustment() { AdjustmentGroupCode = "APADJ", AdjustmentTypeCode = "WNPOT", AdjustPercentage = -100.00m });
                        }
                        context.CostTracker = 0.00m;
                        context.FinalCost = 0.0m;
                        */
                    }
                }
            }

            _Calculated = true;
            context.Successful = true;
        }

        public override bool EndAfter()
        {
            if (!_Calculated) throw new Exception("WorkNotPerformedAdjustor has not finished calculation");
            else
            {
                return this.BillingContext.FinalPrice.HasValue && this.BillingContext.FinalPrice == 0.00m
                    && this.BillingContext.FinalCost.HasValue && this.BillingContext.FinalCost.Value == 0.00m;
            }
        }
            
    }
}
