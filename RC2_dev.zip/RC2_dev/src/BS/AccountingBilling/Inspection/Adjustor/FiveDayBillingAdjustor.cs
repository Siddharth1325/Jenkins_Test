﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FS.AccountingBilling.Common;
using FS.AccountingBilling.Common.WorkOrder;
using Inspections.ServiceProxy.InspectionSvc;

namespace FS.AccountingBilling.Inspection.Adjustor
{
    public class FiveDayBillingAdjustor : WorkOrderBillingAdjustorBase
    {
        private bool _Calculated = false;
        public FiveDayBillingAdjustor(WorkOrderBillingContext billingContext)
            : base(billingContext)
        {
        }

        public override void Calculate()
        {
            /*
            ProductCode	ProductName
            12	        EXTERIOR INSPECTION
            15	        SALE DATE INSPECTION
            16	        INSURANCE LOSS INSPECTION
            23	        FNMA 30
            34	        CONTACT INSPECTION
            40	        REO INSPECTION
            5	        BANKRUPTCY INSPECTION
            66	        MULTIPLE CONTACT INSPECTION
            68	        6-8PM OCCUPANCY
            73	        INTERIOR/EXTERIOR INSPECTION
            79	        CONTACT WITH DOORCARD INSPECTION
            81	        DISASTER INSPECTION
            88	        TREE HOUSE INSPECTIONS
            98	        OCCUPANCY VERIFICATION LETTER
            99	        NO CONTACT INSPECTION
            */

            WorkOrderBillingContext context = this.BillingContext as WorkOrderBillingContext;
            if(!context.WorkOrder.AcctProcessedDate.HasValue && !context.Order.IsRushOrder && !context.Order.IsFrequent && string.Compare(context.Investor.InvestorName, "FANNIE MAE", true) != 0)
            {
                string[] excludedProductCodes = new string[] {"73", "23", "15", "16", "68"};
                if (context.Product != null && !excludedProductCodes.Contains(context.Product.ProductCode) && context.InspectionResult != null && context.InspectionResult.SubmissionDate > DateTime.MinValue)
                {
                    List<WorkOrder> workOrders = new InspectionBillingDelegate().GetWorkOrdersFor5Days(context.SubClientProfile.SubClientProfileId, context.Loan.LoanId,
                        context.InspectionResult.SubmissionDate.AddDays(-5.00d).Date, context.InspectionResult.SubmissionDate.AddDays(5.00d).Date);
                    if(workOrders == null || workOrders.Count == 0 || workOrders.Where(p=>p.WorkOrderId == context.WorkOrder.WorkOrderId).Count() != 1)
                    {
                        this.BillingContext.Successful = false;
                        this.BillingContext.FailureReason = "5 Days Billing failed - can't determine if other orders within 5 days";
                    }
                    else if (workOrders.Where(p => p.WorkOrderId != context.WorkOrder.WorkOrderId).Count() > 0)
                    {
                        if(workOrders.Where(p => p.WorkOrderId != context.WorkOrder.WorkOrderId && p.AcctProcessedDate.HasValue).Count() > 0)
                        {                            
                            if (context.MasterClientProfile.ClientName.ToUpper().IndexOf("WELLS") >= 0)
                            {
                                context.CostTracker = 0.00m;
                                context.FinalCost = 0.00m;
                                context.CostAdjustments.Add(new Adjustment() { AdjustPercentage = -100.0m, AdjustmentGroupCode = "APADJ", AdjustmentTypeCode = "WELSD" });
                            }
                            else
                            {
                                if (workOrders.Where(p => p.AssignedVendorId != context.WorkOrder.AssignedVendorId).Count() == 0)
                                {
                                    context.CostTracker = 0.00m;
                                    context.FinalCost = 0.00m;
                                    context.CostAdjustments.Add(new Adjustment() { AdjustPercentage = -100.0m, AdjustmentGroupCode = "APADJ", AdjustmentTypeCode = "FIVED" });
                                    context.PriceTracker = 0.00m;
                                    context.FinalPrice = 0.00m;
                                    context.PriceAdjustments.Add(new Adjustment() { AdjustPercentage = -100.0m, AdjustmentGroupCode = "ARADJ", AdjustmentTypeCode = "FIVED" });
                                }
                                else if (workOrders.Where(p => p.AssignedVendorId != context.WorkOrder.AssignedVendorId).Count() > 0)
                                {
                                    context.PriceTracker = 0.00m;
                                    context.FinalPrice = 0.00m;
                                    context.PriceAdjustments.Add(new Adjustment() { AdjustPercentage = -100.0m, AdjustmentGroupCode = "ARADJ", AdjustmentTypeCode = "FIVED" });
                                }
                            }
                            
                        }
                    }
                }
            }
            
            _Calculated = true;
            context.Successful = true;
        }

        public override bool EndAfter()
        {
            if (!_Calculated) throw new Exception("FiveDayBillingAdjustor has not finished calculation");

            return this.BillingContext.FinalPrice.HasValue && this.BillingContext.FinalPrice == 0.00m
                && this.BillingContext.FinalCost.HasValue && this.BillingContext.FinalCost.Value == 0.00m;        
        }
    }
}
