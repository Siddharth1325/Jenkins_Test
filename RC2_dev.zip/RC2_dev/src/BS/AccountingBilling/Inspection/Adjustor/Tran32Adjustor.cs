﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AdminClientRM = Admin.ServiceProxy.ClientService;
using FS.AccountingBilling.Common;
using FS.AccountingBilling.Common.WorkOrder;

namespace FS.AccountingBilling.Inspection.Adjustor
{
    public class Tran32Adjustor : WorkOrderBillingAdjustorBase
    {
        private bool _Calculated = false;
        public Tran32Adjustor(WorkOrderBillingContext billingContext)
            : base(billingContext) { }

        public override void Calculate()
        {
            WorkOrderBillingContext context = this.BillingContext as WorkOrderBillingContext;

            //If the flag is set to false by other adjustors, exit
            if (!context.IsEligibleForTran32)
            {
                _Calculated = true;
                context.Successful = true;
                return;
            }            

            if (context.WorkOrder != null && string.Compare(context.WorkOrder.WorkOrderStatusType, "CANCEL", true) == 0)
                context.IsEligibleForTran32 = false;
            else if(context.InspectionResult != null && (!context.InspectionResult.IsWorkPerformed || 
                (context.InspectionResult.InspRsltWorkNotPerformeds != null && context.InspectionResult.InspRsltWorkNotPerformeds.Count > 0)))
                context.IsEligibleForTran32 = false;
            
            if (context.IsEligibleForTran32)
            {
                List<AdminClientRM.Tran32Configuration> tran32Configs = null;
                using (var proxy = new AdminClientRM.ClientServiceClient())
                {
                    var response = proxy.GetTran32ConfigurationBySubClientProfileId(context.SubClientProfile.SubClientProfileId);
                    tran32Configs = (response != null) ? response.Tran32Configurations : null;
                }
                                
                if(tran32Configs != null && tran32Configs.Count > 0)
                {
                    context.IsEligibleForTran32 = tran32Configs.SelectMany(t => t.Tran32DepartmentInclusions)
                        .Count(i => string.Compare(i.DepartmentCode, context.Order.DepartmentCode, true) == 0) > 0;
                    
                    if(context.IsEligibleForTran32)
                    {
                        context.IsEligibleForTran32 = ! (tran32Configs.SelectMany(t => t.Tran32Exclusions)
                            .Count(e => string.Compare(e.DepartmentCode, context.Order.DepartmentCode, true) == 0 && 
                                       ((!string.IsNullOrWhiteSpace(context.Order.MbaCodeType) && string.Compare(e.MBACodeType, context.Order.MbaCodeType, true) == 0)
                                         || (string.IsNullOrWhiteSpace(context.Order.MbaCodeType) && string.Compare(e.MBACodeType, "NA", true) == 0))) > 0) ;                    
                    }

                    if(context.IsEligibleForTran32)
                    {
                        context.IsEligibleForTran32 = ! (tran32Configs.SelectMany(t => t.Tran32Exclusions)
                            .Count(e => string.Compare(e.StateCode, context.Loan.ValidStateCode, true) == 0 && (string.IsNullOrWhiteSpace(e.DepartmentCode)
                                     || (!string.IsNullOrWhiteSpace(e.DepartmentCode) && string.Compare(e.DepartmentCode, context.Order.DepartmentCode, true) == 0))) > 0);
                    }

                    if (context.IsEligibleForTran32)
                    {
                        context.IsEligibleForTran32 = !(tran32Configs.SelectMany(t => t.Tran32Exclusions)
                            .Count(e => string.Compare(e.ZipCode, context.Loan.ValidZipCode, true) == 0 && (string.IsNullOrWhiteSpace(e.DepartmentCode)
                                     || (!string.IsNullOrWhiteSpace(e.DepartmentCode) && string.Compare(e.DepartmentCode, context.Order.DepartmentCode, true) == 0))) > 0);
                    }
                }
                else
                    context.IsEligibleForTran32 = false;
            }

            _Calculated = true;
            context.Successful = true;
        }

        public override bool EndAfter()
        {
            if (!_Calculated) throw new Exception("Tran32Adjustor has not finished calculation");
            else
            {
                return false;
            }
        }
    }
}
