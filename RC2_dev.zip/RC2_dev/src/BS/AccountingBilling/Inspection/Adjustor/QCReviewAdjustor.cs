﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FS.AccountingBilling.Common;
using FS.AccountingBilling.Common.WorkOrder;

namespace FS.AccountingBilling.Inspection.Adjustor
{
    public class QCReviewAdjustor : WorkOrderBillingAdjustorBase
    {
        private bool _Calculated = false;
        public QCReviewAdjustor(WorkOrderBillingContext billingContext)
            : base(billingContext)
        {

        }

        public override void Calculate()
        {
            WorkOrderBillingContext context = this.BillingContext as WorkOrderBillingContext;
            if(!string.IsNullOrEmpty(context.WorkOrder.PayVendorGroup) && string.Compare(context.WorkOrder.PayVendorGroup, "QCPVN", true) == 0 
                && !string.IsNullOrEmpty(context.WorkOrder.PayVendorType))
            {
                switch(context.WorkOrder.PayVendorType.Trim().ToUpper())
                {
                    case "ZERO":
                        context.CostAdjustments.Add(new Adjustment() { AdjustmentGroupCode = "APADJ", AdjustmentTypeCode = "QCNPV", AdjustPercentage = -100.00m });
                        context.CostTracker = 0.00m;
                        context.FinalCost = 0.00m;
                        break;
                    case "ONE":
                        context.CostAdjustments.Add(new Adjustment() { AdjustmentGroupCode = "APADJ", AdjustmentTypeCode = "QCPVO", AdjustPercentage = 0.00m });                                                
                        break;
                    case "TWO":
                        context.CostAdjustments.Add(new Adjustment() { AdjustmentGroupCode = "APADJ", AdjustmentTypeCode = "QCPVT", AdjustPercentage = 100.00m });
                        context.CostTracker *= 2.00m;
                        break;
                    case "THREE":
                        context.CostAdjustments.Add(new Adjustment() { AdjustmentGroupCode = "APADJ", AdjustmentTypeCode = "QCPV3", AdjustPercentage = 200.00m });
                        context.CostTracker *= 3.00m;
                        break;
                    /*
                    case "FOUR":
                        context.CostAdjustments.Add(new Adjustment() { AdjustmentGroupCode = "APADJ", AdjustmentTypeCode = "QCPV4", AdjustPercentage = 300.00m });
                        context.CostTracker *= 4.00m;
                        break;
                    case "FIVE":
                        context.CostAdjustments.Add(new Adjustment() { AdjustmentGroupCode = "APADJ", AdjustmentTypeCode = "QCPV5", AdjustPercentage = 400.00m });
                        context.CostTracker *= 5.00m;
                        break;
                    case "SIX":
                        context.CostAdjustments.Add(new Adjustment() { AdjustmentGroupCode = "APADJ", AdjustmentTypeCode = "QCPV6", AdjustPercentage = 500.00m });
                        context.CostTracker *= 6.00m;                        
                        break;
                    case "SEVEN":
                        context.CostAdjustments.Add(new Adjustment() { AdjustmentGroupCode = "APADJ", AdjustmentTypeCode = "QCPV7", AdjustPercentage = 600.00m });
                        context.CostTracker *= 7.00m;    
                        break;
                    case "EIGHT":
                        context.CostAdjustments.Add(new Adjustment() { AdjustmentGroupCode = "APADJ", AdjustmentTypeCode = "QCPV8", AdjustPercentage = 700.00m });
                        context.CostTracker *= 8.00m;
                        break;
                    case "NINE":
                        context.CostAdjustments.Add(new Adjustment() { AdjustmentGroupCode = "APADJ", AdjustmentTypeCode = "QCPV9", AdjustPercentage = 800.00m });
                        context.CostTracker *= 9.00m;
                        break;
                    case "TEN":
                        context.CostAdjustments.Add(new Adjustment() { AdjustmentGroupCode = "APADJ", AdjustmentTypeCode = "QCPV10", AdjustPercentage = 900.00m });
                        context.CostTracker *= 10.00m;
                        break;
                    */
                }
            }

            if(context.WorkOrder.IsBillClient.HasValue && !context.WorkOrder.IsBillClient.Value)
            {
                context.PriceAdjustments.Add(new Adjustment() { AdjustmentGroupCode = "ARADJ", AdjustmentTypeCode = "QCNBC", AdjustPercentage = -100.00m });
                context.PriceTracker = 0.00m;
                context.FinalPrice = 0.00m;
                context.IsEligibleForTran32 = false;
            }

            _Calculated = true;
            context.Successful = true;
        }

        public override bool EndAfter()
        {

            if (!_Calculated) throw new Exception("QCReviewAdjustor has not finished calculation");

            return this.BillingContext.FinalPrice.HasValue && this.BillingContext.FinalPrice == 0.00m
                && this.BillingContext.FinalCost.HasValue && this.BillingContext.FinalCost.Value == 0.00m;
            
        }
    }
}
