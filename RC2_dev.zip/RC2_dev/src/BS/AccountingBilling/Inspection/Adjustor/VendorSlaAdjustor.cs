﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FS.AccountingBilling.Common;
using FS.AccountingBilling.Common.WorkOrder;
using Inspections.ServiceProxy.InspectionSvc;

namespace FS.AccountingBilling.Inspection.Adjustor
{
    public class VendorSlaAdjustor : WorkOrderBillingAdjustorBase
    {
        private bool _Calculated = false;

        public VendorSlaAdjustor(WorkOrderBillingContext billingContext)
            : base(billingContext)
        {
        }

        public override void Calculate()
        {
            WorkOrderBillingContext context = this.BillingContext as WorkOrderBillingContext;
            if(context.InspectionResult == null || !context.WorkOrder.AssignedVendorId.HasValue)
            {
                _Calculated = true;
                context.Successful = true;
                return;
            }

            int subClientProfileId = context.SubClientProfile.SubClientProfileId;
            bool isWindowOrder = context.WorkOrder.WindowStartDate.HasValue && context.WorkOrder.WindowEndDate.HasValue 
                              && context.WorkOrder.WindowEndDate.Value > context.WorkOrder.WindowStartDate.Value;

            //TODO Verify with Kavya-Bug 14020
            //if (!isWindowOrder && context.WorkOrder.DueFromVendorDate.HasValue && context.InspectionResult.SubmissionDate.Date > context.WorkOrder.DueFromVendorDate.Value.Date)
            if (context.WorkOrder.DueFromVendorDate.HasValue && context.InspectionResult.SubmissionDate.Date > context.WorkOrder.DueFromVendorDate.Value.Date)         
            {
                context.CostAdjustments.Add(new Adjustment() { AdjustmentGroupCode = "APADJ", AdjustmentTypeCode = "SLANP", AdjustPercentage = -100.00m });
                context.CostTracker = 0.00m;
                context.FinalCost = 0.00m;
            }

            //TODO Verify with Kavya-Bug 14020
            //else if (isWindowOrder && context.InspectionResult.SubmissionDate > DateTime.MinValue && context.WorkOrder.WindowEndDate.HasValue
            //         && context.WorkOrder.WindowEndDate.Value > DateTime.MinValue && context.InspectionResult.SubmissionDate.Date > context.WorkOrder.WindowEndDate.Value.Date)
            //{
            //    int numberOfBusinessDays = GetNumberOfBusinessDays(subClientProfileId, context.WorkOrder.WindowEndDate.Value.Date, context.InspectionResult.SubmissionDate.Date);
            //    if (numberOfBusinessDays >= 2)
            //    {
            //        context.CostAdjustments.Add(new Adjustment() { AdjustmentGroupCode = "APADJ", AdjustmentTypeCode = "SLANP", AdjustPercentage = -100.00m });
            //        context.CostTracker = 0.00m;
            //        context.FinalCost = 0.00m;
            //    }
            //}

            if(context.ClientAccounting != null)
            {
                DateTime orderDate = PickOrderDateForSla(context.Order, context.WorkOrder).Date;
                if (orderDate > DateTime.MinValue)
                {
                    if (context.ClientAccounting.InspectionPerformedThreshold.HasValue 
                        && context.InspectionResult.SubmissionDate > DateTime.MinValue && context.InspectionResult.SubmissionDate.Date > orderDate)
                    {
                        int numberOfBusinessDays = GetNumberOfBusinessDays(subClientProfileId, orderDate, context.InspectionResult.SubmissionDate.Date);
                        if (numberOfBusinessDays > context.ClientAccounting.InspectionPerformedThreshold.Value)
                        {
                            context.PriceAdjustments.Add(new Adjustment() { AdjustmentGroupCode = "ARADJ", AdjustmentTypeCode = "SLANB", AdjustPercentage = -100.00m });
                            context.PriceTracker = 0.00m;
                            context.FinalPrice = 0.00m;
                        }
                    }
                    if (context.ClientAccounting.InspectionTransmitThreshold.HasValue && context.WorkOrder.TransmittedDate.HasValue
                             && context.WorkOrder.TransmittedDate.Value > DateTime.MinValue && context.WorkOrder.TransmittedDate.Value.Date > orderDate)
                    {
                        int numberOfBusinessDays = GetNumberOfBusinessDays(subClientProfileId, orderDate, context.WorkOrder.TransmittedDate.Value.Date);
                        if (numberOfBusinessDays > context.ClientAccounting.InspectionTransmitThreshold.Value)
                        {
                            context.PriceAdjustments.Add(new Adjustment() { AdjustmentGroupCode = "ARADJ", AdjustmentTypeCode = "SLANB", AdjustPercentage = -100.00m });
                            context.PriceTracker = 0.00m;
                            context.FinalPrice = 0.00m;
                        }
                    }
                    if (context.ClientAccounting.InspectionReturnedThreshold.HasValue && context.WorkOrder.CompletedDate.HasValue
                             && context.WorkOrder.CompletedDate.Value > DateTime.MinValue && context.WorkOrder.CompletedDate.Value.Date > orderDate)
                    {
                        int numberOfBusinessDays = GetNumberOfBusinessDays(subClientProfileId, orderDate, context.WorkOrder.CompletedDate.Value.Date);
                        if (numberOfBusinessDays > context.ClientAccounting.InspectionReturnedThreshold.Value)
                        {
                            context.PriceAdjustments.Add(new Adjustment() { AdjustmentGroupCode = "ARADJ", AdjustmentTypeCode = "SLANB", AdjustPercentage = -100.00m });
                            context.PriceTracker = 0.00m;
                            context.FinalPrice = 0.00m;
                        }
                    }
                }
            }

            _Calculated = true;
            context.Successful = true;
        }

        private DateTime PickOrderDateForSla(Order order, WorkOrder workOrder)
        {
            if (order == null || workOrder == null) return DateTime.MinValue;
            if (workOrder.RequestedDate > DateTime.MinValue) return workOrder.RequestedDate;
            if (order.RequestedDate != DateTime.MinValue && order.ReceivedDate != DateTime.MinValue) return order.ReceivedDate > order.RequestedDate ? order.ReceivedDate : order.RequestedDate;
            else if (order.ReceivedDate != DateTime.MinValue) return order.ReceivedDate;
            else if (order.RequestedDate != DateTime.MinValue) return order.RequestedDate;
            else return DateTime.MinValue;
        }

        private int GetNumberOfBusinessDays(int subClientProfileId, DateTime startDate, DateTime endDate)
        {
            var businessDaysCheckResults = new InspectionBillingDelegate().GetClientBusinessDaysByDateRange(subClientProfileId, startDate, endDate);
            return businessDaysCheckResults != null && businessDaysCheckResults.Length > 0 ? businessDaysCheckResults.Count(rs => rs.IsBusinessDay) : (endDate - startDate).Days;
        }

        public override bool EndAfter()
        {
            if (!_Calculated) throw new Exception("VendorSlaAdjustor has not finished calculation");

            return this.BillingContext.FinalPrice.HasValue && this.BillingContext.FinalPrice == 0.00m
                && this.BillingContext.FinalCost.HasValue && this.BillingContext.FinalCost.Value == 0.00m;            
        }
    }
}
