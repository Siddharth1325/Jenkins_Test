﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FS.AccountingBilling.Common;
using FS.AccountingBilling.Common.WorkOrder;

namespace FS.AccountingBilling.Inspection.Adjustor
{
    public class EligibilityAdjustor : WorkOrderBillingAdjustorBase
    {
        private bool _Calculated = false;
        //private bool _TerminateAfter = false;
        public EligibilityAdjustor(WorkOrderBillingContext billingContext)
            : base(billingContext) { }

        public override void Calculate()
        {
            WorkOrderBillingContext context = this.BillingContext as WorkOrderBillingContext;
            if(context.Order.IsDoNotPayVendor)
            {
                if(!context.BaseCost.HasValue)
                {
                    context.BaseCost = 0.0m;
                    context.BaseCostSelectionReason = "Billing Eligibility Rule - Order is set to Do Not Pay Vendor";
                }
                else
                {
                    context.CostAdjustments.Add(new Adjustment() { AdjustmentGroupCode = "APADJ", AdjustmentTypeCode = "ELINP", AdjustPercentage = -100.00m });                        
                }
                context.FinalCost = 0.0m;
                context.CostTracker = 0.00m;

            }
            if(context.Order.IsDoNotBillClient)
            {
                if(!context.BasePrice.HasValue)
                {
                    context.BasePrice = 0.0m;                    
                    context.BasePriceSelectionReason = "Billing Eligibility Rule - Order is set to Do Not Bill Client";                    
                }
                else
                {
                    context.PriceAdjustments.Add(new Adjustment() { AdjustmentGroupCode = "ARADJ", AdjustmentTypeCode = "ELINB", AdjustPercentage = -100.00m });  
                }
                context.PriceTracker = 0.00m;
                context.FinalPrice = 0.0m;
                context.IsEligibleForTran32 = false;
            }

            _Calculated = true;
            context.Successful = true;
        }

        public override bool EndAfter()
        {                       
            if (!_Calculated) throw new Exception("EligibilityAdjustor has not finished calculation");
            else
            {
                return this.BillingContext.FinalPrice.HasValue && this.BillingContext.FinalPrice == 0.00m
                    && this.BillingContext.FinalCost.HasValue && this.BillingContext.FinalCost.Value == 0.00m;
            }            
        }
    }
}
