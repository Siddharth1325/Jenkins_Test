﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FS.AccountingBilling.Common;
using FS.AccountingBilling.Common.WorkOrder;
using Vendor.ServiceProxy.VendorService;
using User.ServiceProxy.UserRepository;

namespace FS.AccountingBilling.Inspection
{
    public class DefaultCostCalculator : DefaultCalculatorBase
    {
        public DefaultCostCalculator(WorkOrderBillingContext billingContext)
            : base(billingContext)
        {
        }

        public override void Calculate()
        {
            WorkOrderBillingContext context = this.BillingContext as WorkOrderBillingContext;
            if(context.WorkOrder != null && !context.WorkOrder.AssignedVendorId.HasValue)
            {
                context.Successful = true;
                return;
            }

            User.ServiceProxy.UserRepository.Application application = null;
            using(var proxy = new UserRepoServiceClient())
            {
                application = proxy.GetApplicationByApplicationCode(context.ApplicationCode);
            }

            using(var proxy = new VMServiceClient())
            {
                var response =  proxy.GetVendorPricing(new GetVendorPricingRequest() { 
                    ApplicationId = application != null ? application.ApplicationId : 0,
                    ProductId = context.SwitchedProductId.HasValue ? context.SwitchedProductId.Value : context.Product.ProductId, 
                    Requestdate = context.Order.RequestedDate, 
                    SubClientId = context.SubClientProfile.SubClientProfileId,
                    VendorProfileId = context.WorkOrder.AssignedVendorId.Value,
                    PropertyAddressInfo = new PropertyAddress() { CountyName = context.Loan.ValidCountyName, StateCode = context.Loan.ValidStateCode, ZipCode = context.Loan.ValidZipCode}
                });

                if (response == null || response.VendorPricing == null)
                {
                    context.Successful = false;
                    context.FailureReason = "Missing vendor pricing setting for vendor id " + context.WorkOrder.AssignedVendorId.Value.ToString();
                }
                else
                {
                    context.VendorPricing = response.VendorPricing;
                    SetBaseCost();
                }
            }
        }

        private void SetBaseCost()
        {
            WorkOrderBillingContext context = this.BillingContext as WorkOrderBillingContext;

            if (context.VendorPricing.RushRate.HasValue && context.Order.IsRushOrder)
            {
                context.BaseCost = context.VendorPricing.RushRate.Value;
                context.BaseCostSelectionReason = "Vendor rush rate is selected";
                context.CostTracker = context.BaseCost.Value;
                context.Successful = true;
            }
            else if (context.VendorPricing.StandardRate.HasValue)
            {
                context.BaseCost = context.VendorPricing.StandardRate;
                context.BaseCostSelectionReason = "Vendor standard rate is selected";
                context.CostTracker = context.BaseCost.Value;
                context.Successful = true;
            }
            else
            {
                context.Successful = false;
                context.FailureReason = "Missing vendor pricing setting for vendor id " + context.WorkOrder.AssignedVendorId.Value.ToString();
            }
        }
    }
}
