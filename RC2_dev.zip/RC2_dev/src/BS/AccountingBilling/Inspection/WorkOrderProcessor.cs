﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CommonLib;
using DomainModel.Accounting;
using FS.AccountingBilling.Common;
using FS.AccountingBilling.Common.WorkOrder;
using FS.AccountingBilling.Inspection.Adjustor;
using InspRM = Inspections.ServiceProxy.InspectionSvc;

namespace FS.AccountingBilling.Inspection
{
    public class WorkOrderProcessor : WorkOrderProcessorBase
    {
        private const string _OVLProductCode = "1";
        private const string _IntExtProductCode = "73";
        private const string _OVLProductName = "OCCUPANCY VERIFICATION LETTER";
        private const string _IntExtProductName = "INTERIOR/EXTERIOR INSPECTION";

        private const string Validation_InspectionWorkOrder_MoreThanOneWorkOrderItem = "WorkOrder {0} has multiple WorkOrderItems";
        private const string Validation_InspectionResult_Missing = "WorkOrder {0} does not have Inspection Result record";
        private const string Validation_SubClientProfile_Missing = "WorkOrder {0} does not have SubClientProfile record";
        private const string Validation_MasterClientProfile_Missing = "WorkOrder {0} does not have MasterClientProfile record";
        private const string Validation_Product_Missing = "WorkOrder {0} does not have Product record";

        private InspectionBillingDelegate _Delegate = new InspectionBillingDelegate();

        public WorkOrderProcessor(string applicationCode, int workOrderId) 
            : base(applicationCode, workOrderId)
        {
        }

        public override void FindWorkOrder()
        {
            InspRM.WorkOrder workOrder = _Delegate.GetWorkOrder(_WorkOrderId);
            if (workOrder == null || workOrder.Order == null || workOrder.Order.Loan == null || workOrder.Product == null)
            {
                string errorMsg = string.Format("The requested work order (id={0}) doesn't exist, or associated order, loan, or product doesn't exist", _WorkOrderId);
                ArgumentNullException ex = new ArgumentNullException("workOrderId", errorMsg);
                Logging.LogError(ex);
                throw ex;
            }

            BillingContext.WorkOrder = workOrder;
            BillingContext.Order = workOrder.Order;
            BillingContext.Product = workOrder.Product;
            BillingContext.IsOVLProduct = string.Compare(this.BillingContext.Product.ProductCode, _OVLProductCode, true) == 0 || string.Compare(this.BillingContext.Product.ProductName, _OVLProductName, true) == 0;
            BillingContext.Loan = workOrder.Order.Loan;
            BillingContext.WorkOrderItems = workOrder.WorkOrderItems != null ? workOrder.WorkOrderItems.ToArray() : null;
            BillingContext.InspectionResult = _Delegate.GetInspectionResult(_WorkOrderId);
            BillingContext.ClientAccounting = workOrder.Order.Loan.SubClientProfileId.HasValue ? _Delegate.GetClientAccounting(workOrder.Order.Loan.SubClientProfileId.Value) : null;
            BillingContext.SubClientProfile = workOrder.Order.Loan.SubClientProfileId.HasValue ? _Delegate.GetSubClientProfile(workOrder.Order.Loan.SubClientProfileId.Value) : null;
            BillingContext.MasterClientProfile = BillingContext.SubClientProfile != null ? _Delegate.GetMasterClientProfile(BillingContext.SubClientProfile.MasterClientProfileId) : null;

            HandleInteriorExteriorSwitch(); 
        }

        private void HandleInteriorExteriorSwitch()
        {
            //If a workorder with Interior/Exterior product is placed and only exterior work has been performed, but the interior wasn't,
            //then Billing Service should identify it and only bill or pay per the Exterior inspection product price
            if(BillingContext.InspectionResult != null && BillingContext.InspectionResult.IsWorkPerformed &&
                (string.Compare(BillingContext.Product.ProductCode, _IntExtProductCode, true) == 0 || string.Compare(BillingContext.Product.ProductName, _IntExtProductName, true) == 0))
            {
                BillingContext.SwitchedProductId = _Delegate.SwitchProduct(_WorkOrderId, _IntExtProductCode);
            }
        }

        public override bool ValidateWorkOrder(out string validationMsg)
        {
            bool isValid = true;
            string parentMsg = string.Empty;
            isValid = base.ValidateWorkOrder(out parentMsg);
            validationMsg = isValid ? string.Empty : parentMsg;

            if (this.BillingContext.SubClientProfile == null)
            {
                isValid = false;
                validationMsg += string.Format(Validation_SubClientProfile_Missing, this.BillingContext.WorkOrder.WorkOrderId);
            }
            if (this.BillingContext.MasterClientProfile == null)
            {
                isValid = false;
                validationMsg += string.Format(Validation_MasterClientProfile_Missing, this.BillingContext.WorkOrder.WorkOrderId);
            }
            if (this.BillingContext.Product == null)
            {
                isValid = false;
                validationMsg += string.Format(Validation_Product_Missing, this.BillingContext.WorkOrder.WorkOrderId);
            }

            /*
            if(this.BillingContext.WorkOrderItems != null && this.BillingContext.WorkOrderItems.Count() > 1)
            {
                isValid = false;
                validationMsg += string.Format(Validation_InspectionWorkOrder_MoreThanOneWorkOrderItem, this.BillingContext.WorkOrder.WorkOrderId);
            }
            */

            if (this.BillingContext.WorkOrder != null && string.Compare(this.BillingContext.WorkOrder.WorkOrderStatusType.Trim(), "BILL", true) == 0 && !this.BillingContext.IsOVLProduct)
            {
                if (this.BillingContext.InspectionResult == null)
                {
                    isValid = false;
                    validationMsg += string.Format(Validation_InspectionResult_Missing, this.BillingContext.WorkOrder.WorkOrderId);
                }
            }

            return isValid;
        }

        protected  override void Init()
        {
            //The sequence of AddCalculator matters as it will be the same sequence 
            //which the controller will follow to execute each calculator

            bool isCancellation = string.Compare(this.BillingContext.WorkOrder.WorkOrderStatusType, "CANCEL", true) == 0 || 
                (this.BillingContext.WorkOrder.Order.Cancellations != null && this.BillingContext.WorkOrder.Order.Cancellations.Count > 0);
            if (!this.BillingContext.IsOVLProduct)  base.AddCalculator(new DefaultCostCalculator(this.BillingContext));
            base.AddCalculator(new DefaultPriceCalculator(this.BillingContext));
            if (!this.BillingContext.IsOVLProduct)
            {
                base.AddCalculator(new WorkNotPerformedAdjustor(this.BillingContext));
                base.AddCalculator(new FiveDayBillingAdjustor(this.BillingContext));
                base.AddCalculator(new EligibilityAdjustor(this.BillingContext));
                base.AddCalculator(new QCReviewAdjustor(this.BillingContext));                                
                base.AddCalculator(new ClientWindowAdjustor(this.BillingContext));
                base.AddCalculator(new VendorSlaAdjustor(this.BillingContext));                
            }
            base.AddCalculator(new Tran32Adjustor(this.BillingContext));
            if (isCancellation) base.AddCalculator(new CancellationAdjustor(this.BillingContext));            
        }
    }
}
