﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FS.AccountingBilling.Common;
using FS.AccountingBilling.Common.WorkOrder;
using AdminClientRM = Admin.ServiceProxy.ClientService;
using AdminInvestorRM = Admin.ServiceProxy.InvestorService;

namespace FS.AccountingBilling.Inspection
{
    public class DefaultPriceCalculator : DefaultCalculatorBase
    {
        public DefaultPriceCalculator(WorkOrderBillingContext billingContext)
            : base(billingContext)
        {

        }

        public override void Calculate()
        {
            WorkOrderBillingContext context = this.BillingContext as WorkOrderBillingContext;

            AdminInvestorRM.InvestorProfile investor = null;
            if (!string.IsNullOrEmpty(context.Loan.InvestorIdentifier))
            {
                using (var proxy = new AdminInvestorRM.InvestorServiceClient())
                {
                    investor = proxy.GetInvestorProfileByIdentifier(context.Loan.InvestorIdentifier);
                    context.Investor = investor;
                }
            }

            using (var proxy = new AdminClientRM.ClientServiceClient())
            {
                var response = proxy.GetClientPricing(new AdminClientRM.GetPricingRequest()
                {
                    InvestorId = investor != null ? investor.InvestorProfileId : 0,
                    ProductId = context.SwitchedProductId.HasValue ? context.SwitchedProductId.Value : context.Product.ProductId,
                    SubClientProfileId = context.Loan.SubClientProfileId.HasValue ? context.Loan.SubClientProfileId.Value : 0,
                    PropertyAddressInfo = new AdminClientRM.PropertyAddress() { County = context.Loan.ValidCountyName, State = context.Loan.ValidStateCode, ZipCode = context.Loan.ValidZipCode }
                });

                if (response == null || response.ClientPricing == null)
                {
                    context.Successful = false;                    
                    //context.FailureReason = string.Format("Missing client pricing setting for subclientprofile id {0}, product id {1}, investor id {2} and property at {3}, {4}, {5}",
                    //    context.Loan.SubClientProfileId.Value.ToString(), context.SwitchedProductId.HasValue ? context.SwitchedProductId.Value.ToString() : context.Product.ProductId.ToString(), 
                    //    investor != null ? investor.InvestorProfileId : 0, context.Loan.ValidCountyName, context.Loan.ValidStateCode, context.Loan.ValidZipCode);
                    context.FailureReason = string.Format("Missing client pricing setting for client {0}, product {1}, investor {2} and property at {3}, {4}, {5}",
                        context.MasterClientProfile != null ? context.MasterClientProfile.ClientName : "", context.Product.ProductName, investor != null ? investor.InvestorName : "", context.Loan.ValidCountyName, context.Loan.ValidStateCode, context.Loan.ValidZipCode);
                }
                else
                {
                    context.ClientPricing = response.ClientPricing;
                    SetBasePrice();
                }
            }
        }

        private void SetBasePrice()
        {
            WorkOrderBillingContext context = this.BillingContext as WorkOrderBillingContext;

            if(context.ClientPricing.RushRate.HasValue && context.Order.IsRushOrder)
            {
                context.BasePrice = context.ClientPricing.RushRate.Value;
                context.PriceTracker = context.ClientPricing.RushRate.Value;
                context.BasePriceSelectionReason = "Rush order price is selected";
                context.Successful = true;
            }
            else if(context.ClientPricing.InitialRate.HasValue && context.Order.IsInitial)
            {
                context.BasePrice = context.ClientPricing.InitialRate.Value;
                context.PriceTracker = context.ClientPricing.InitialRate.Value;
                context.BasePriceSelectionReason = "Initial order price is selected";
                context.Successful = true;
            }
            else if(context.ClientPricing.SubsequentRate.HasValue && !context.Order.IsInitial)
            {
                context.BasePrice = context.ClientPricing.SubsequentRate.Value;
                context.PriceTracker = context.ClientPricing.SubsequentRate.Value;
                context.BasePriceSelectionReason = "Subsequent order price is selected";
                context.Successful = true;
            }                
            else if(context.ClientPricing.StandardRate.HasValue)
            {
                context.BasePrice = context.ClientPricing.StandardRate.Value;
                context.PriceTracker = context.ClientPricing.StandardRate.Value;
                context.BasePriceSelectionReason = "Standard order price is selected";
                context.Successful = true;
            }
            else
            {
                context.Successful = false;
                //context.FailureReason = string.Format("Missing client pricing setting for subclientprofile id {0}, product id {1}, investor id {2} and property at {3}, {4}, {5}",
                //    context.Loan.SubClientProfileId.Value.ToString(), context.SwitchedProductId.HasValue ? context.SwitchedProductId.Value.ToString() : context.Product.ProductId.ToString(), 
                //    context.Investor != null ? context.Investor.InvestorProfileId : 0, context.Loan.ValidCountyName, context.Loan.ValidStateCode, context.Loan.ValidZipCode);

                context.FailureReason = string.Format("Missing client pricing setting for client {0}, product {1}, investor {2} and property at {3}, {4}, {5}",
                        context.MasterClientProfile != null ? context.MasterClientProfile.ClientName : "", context.Product.ProductName, context.Investor != null ? context.Investor.InvestorName : "", context.Loan.ValidCountyName, context.Loan.ValidStateCode, context.Loan.ValidZipCode);
            }                           
        }
    }
}
