﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CommonLib;
using DomainModel.Accounting;
using InspRM = Inspections.ServiceProxy.InspectionSvc;
using AdminClientRM = Admin.ServiceProxy.ClientService;
using AdminInvestorRM = Admin.ServiceProxy.InvestorService;
using AdminProdRM = Admin.ServiceProxy.ProductService;
using VMRM = Vendor.ServiceProxy.VendorService;

namespace FS.AccountingBilling.Inspection
{
    public class InspectionBillingDelegate 
    {
        public InspRM.WorkOrder GetWorkOrder(int workOrderId)
        {
            using (var proxy = new InspRM.InspServiceClient())
            {
                return proxy.GetWorkOrderForBilling(workOrderId);
            }
        }

        public InspRM.InspectionResult GetInspectionResult(int workOrderId)
        {
            using (var proxy = new InspRM.InspServiceClient())
            {
                return proxy.GetInspRsltForBillingByWorkOrderId(workOrderId);
            }
        }

        public int? SwitchProduct(int workOrderId, string productCode)
        {
            int? switchToProductId = new Nullable<int>();
            
            InspRM.SwitchProductForBillingResponse response = null;
            using (var proxy = new InspRM.InspServiceClient())
            {
                response = proxy.SwitchProductForBillingByWorkOrderId(workOrderId, productCode);                
            }
            if (response != null && response.NeedSwitch && !string.IsNullOrWhiteSpace(response.SwitchProductCode))
            {
                using(var proxy = new AdminProdRM.ProductServiceClient())
                {
                    var product = proxy.GetProductByProductCode(response.SwitchProductCode);
                    if (product != null)
                    {
                        switchToProductId = product.ProductId;
                        Logging.LogInfo(string.Format("The actual product code used for billing has been changed from {0} to {1}", productCode, product.ProductCode));
                    }
                }
            }
            
            return switchToProductId;
        }

        public AdminClientRM.ClientAccounting GetClientAccounting(int subClientProfileId)
        {
            using(var proxy = new AdminClientRM.ClientServiceClient())
            {
                var response = proxy.GetClientAccountingInfo(new AdminClientRM.GetClientAccountingRequest() { clientProfileId = subClientProfileId });
                return response.ClientAccounting != null ? response.ClientAccounting : null;
                
            }
        }

        /*
        public AdminInvestorRM.InvestorProfile GetInvestorProfile(string investorIdentifier)
        {
            using(var proxy = new AdminInvestorRM.InvestorServiceClient())
            {
                return proxy.GetInvestorProfileByIdentifier(investorIdentifier);
            }
        }
        
        public AdminProdRM.Product GetProduct(int productId)
        {
            using(var proxy = new AdminProdRM.ProductServiceClient())
            {
                var response = proxy.GetProduct(new AdminProdRM.GetProductRequest() { ProductId = productId, ProductCollection = AdminProdRM.ProductProductCollectionEnumeration.None });
                return response != null ? response.Product : null;
            }
        }
        */

        public AdminClientRM.SubClientProfile GetSubClientProfile(int subClientProfileId)
        {
            using (var proxy = new AdminClientRM.ClientServiceClient())
            {
                var response = proxy.GetSubClient(new AdminClientRM.GetSubClientRequest() { SubClientProfileId = subClientProfileId, MasterRequired = true, scCollection = AdminClientRM.SubClientCollectionEnumeration.None });
                return response != null ? response.subClient : null;
            }
        }

        public AdminClientRM.MasterClientProfile GetMasterClientProfile(int masterClientProfileId)
        {
            using(var proxy = new AdminClientRM.ClientServiceClient())
            {
                var response = proxy.GetMasterClient(new AdminClientRM.GetMasterClientRequest() { MasterClientProfileId = masterClientProfileId, mcCollection = AdminClientRM.MasterClientCollectionEnumeration.None });
                return response != null ? response.Client : null;
            }
        }

        public List<InspRM.WorkOrder> GetWorkOrdersFor5Days(int subClientProfileId, int loanId, DateTime inspSubmissionAfter, DateTime inspSubmissionBefore)
        {
            using(var proxy = new InspRM.InspServiceClient())
            {
                return proxy.GetWorkOrdersByClientLoanInspectionDateRange(subClientProfileId, loanId, inspSubmissionAfter, inspSubmissionBefore);
            }
        }

        /*
        public AdminClientRM.Tran32Configuration GetTrans32Configuration(int subClientProfileId, string departmentType)
        {
            using(var proxy = new AdminClientRM.ClientServiceClient())
            {
                var response = proxy.GetTran32ConfigurationsBySubClientDepartment(subClientProfileId, departmentType);
                return response != null ? response.tran32Configuration : null;
            }
        }
        */

        public AdminClientRM.ClientBusinessDayCheckResult[] GetClientBusinessDaysByDateRange(int subClientProfileId, DateTime startDate, DateTime endDate)
        {
            using(var proxy = new AdminClientRM.ClientServiceClient())
            {
                var response = proxy.GetClientBusinessDaysByDateRange(new AdminClientRM.GetClientBusinessDaysByDateRangeRequest() { SubClientProfiledId = subClientProfileId, StartDate = startDate, StartDateIncluded = true, EndDate = endDate, EndDateIncluded = true});
                return response != null && response.ClientBusinessDayCheckResults != null ? response.ClientBusinessDayCheckResults.ToArray() : null;
            }
        }
    }
}
