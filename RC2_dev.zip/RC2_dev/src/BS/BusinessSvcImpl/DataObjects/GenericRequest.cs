﻿using System.Runtime.Serialization;

namespace BusinessSvcImpl.DataObjects
{
  [DataContract(Name = "RequestOfType{0}", Namespace = "http://www.bkfs.com/FS/DataContract/Insp/1.00")]
  public class GenericRequest<T>
  {
    [DataMember]
    public T Data { get; set; }
  }
}
