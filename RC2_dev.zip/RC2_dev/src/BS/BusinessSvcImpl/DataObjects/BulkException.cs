﻿using CommonLib.DataObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using CommonLib.ModelAttrib;

namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{
    [DataContract(Namespace = "http://www.bkfs.com/FS/DataContract/Accounting/1.00")]
    [Serializable]
    [AutoGenMap]
    [KnownTypeAttribute(typeof(BaseDto))]
    public partial class BulkException : BaseDto
    {       
        [DataMember]
        [AutoGenMapProp(IsAutoMap = true, IsAutoMapId = true)]
        public int BulkExceptionId { get; set; }

        [DataMember]
        public string ExceptionCategoryGrpCde { get; set; }
        [DataMember]
        public string ExceptionCategoryEleCde { get; set; }

        [DataMember]
        public string BulkID { get; set; }

        [DataMember]
        public string FileName { get; set; }
        [DataMember]
        public string FileTypeGrpCde { get; set; }
        [DataMember]
        public string FileTypeEleCde { get; set; }
        [DataMember]
        public DateTime? FileDate { get; set; }
        [DataMember]
        public int? FileCount { get; set; }

        [DataMember]
        public string ClientID { get; set; }

        [DataMember]
        public string Status { get; set; }

        [DataMember]
        public string LineNumber { get; set; }

        [DataMember]
        public string ErrorDescription { get; set; }
    }
}
