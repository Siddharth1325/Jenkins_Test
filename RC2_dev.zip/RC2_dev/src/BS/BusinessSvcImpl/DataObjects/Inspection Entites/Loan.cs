using CommonLib.DataObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using CommonLib.ModelAttrib;

namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{
    [DataContract(Namespace = "http://www.bkfs.com/FS/DataContract/Accounting/1.00")]
    [Serializable]
    [AutoGenMap]
    [KnownTypeAttribute(typeof(BaseDto))]
    public partial class Loan : BaseDto
    {
        public Loan()
        {
            Orders = new List<Order>();
        }

        [DataMember]
        [AutoGenMapProp(IsAutoMap = true, IsAutoMapId = true)]
        public int LoanId { get; set; }

        [DataMember]
        public int ApplicationId { get; set; }

        [DataMember]
        public int SourceLoanId { get; set; }

        [DataMember]
        public int? SubClientProfileId { get; set; }

        [DataMember]
        public string LoanNumber { get; set; }

        [DataMember]
        public int? AssetId { get; set; }

        [DataMember]
        public string LoanTypeGroup { get; set; }

        [DataMember]
        public string LoanType { get; set; }

        [DataMember]
        public string LoanStatusGroup { get; set; }

        [DataMember]
        public string LoanStatus { get; set; }

        [DataMember]
        public string InvestorIdentifier { get; set; }

        [DataMember]
        public string InvestorName { get; set; }

        [DataMember]
        public string InvestorCode { get; set; }

        [DataMember]
        public string BorrowerFirstName { get; set; }

        [DataMember]
        public string BorrowerMiddleInitial { get; set; }

        [DataMember]
        public string BorrowerLastName { get; set; }

        [DataMember]
        public string PropAddress1 { get; set; }


        [DataMember]
        public string PropAddress2 { get; set; }


        [DataMember]
        public string PropCityName { get; set; }


        [DataMember]
        public string PropStateCode { get; set; }

        [DataMember]
        public string PropZipCode { get; set; }

        [DataMember]
        public string PropZipPlusFour { get; set; }

        [DataMember]
        public string PropCountyName { get; set; }

        [DataMember]
        public string MailAddress1 { get; set; }

        [DataMember]
        public string MailAddress2 { get; set; }


        [DataMember]
        public string MailCityName { get; set; }

        [DataMember]
        public string MailStateCode { get; set; }

        [DataMember]
        public string MailZipCode { get; set; }

        [DataMember]
        public string MailZipPlusFour { get; set; }

        [DataMember]
        public string ValidAddress1 { get; set; }

        [DataMember]
        public string ValidAddress2 { get; set; }

        [DataMember]
        public string ValidCityName { get; set; }


        [DataMember]
        public string ValidStateCode { get; set; }

        [DataMember]
        public string ValidZipCode { get; set; }


        [DataMember]
        public string ValidZipPlusFour { get; set; }

        [DataMember]
        public string ValidCountyName { get; set; }

        [DataMember]
        public string ValidLatitude { get; set; }

        [DataMember]
        public string ValidLongitude { get; set; }

        [DataMember]
        public string PrimaryPhone { get; set; }

        [DataMember]
        public string PrimaryPhoneTypeGroup { get; set; }

        [DataMember]
        public string PrimaryPhoneType { get; set; }

        [DataMember]
        public string AlternatePhone { get; set; }

        [DataMember]
        public string AlternatePhoneTypeGroup { get; set; }

        [DataMember]
        public string AlternatePhoneType { get; set; }


        [DateTimeBoth]
        [DataMember]
        public DateTime? WinterizationDate { get; set; }


        [DateTimeBoth]
        [DataMember]
        public DateTime? LastGrassCutDate { get; set; }


        [DateTimeBoth]
        [DataMember]
        public DateTime? FirstTimeVacantDate { get; set; }


        [DateTimeBoth]
        [DataMember]
        public DateTime? FirstTimePartialVacantDate { get; set; }


        [DateTimeBoth]
        [DataMember]
        public DateTime? LastVacantDate { get; set; }


        [DateTimeBoth]
        [DataMember]
        public DateTime? LastPartialVacantDate { get; set; }


        [DateTimeBoth]
        [DataMember]
        public DateTime? LastOccupancyDate { get; set; }

        [DataMember]
        public string OccupancyStatusGroup { get; set; }

        [DataMember]
        public string OccupancyStatusType { get; set; }


        [DateTimeBoth]
        [DataMember]
        public DateTime? InitialSecureDate { get; set; }


        [DateTimeBoth]
        [DataMember]
        public DateTime? RedemptionConfirmDate { get; set; }


        [DateTimeBoth]
        [DataMember]
        public DateTime? ExtensionApprovedDate { get; set; }


        [DateTimeBoth]
        [DataMember]
        public DateTime? CodeViolationDate { get; set; }

        [DataMember]
        public bool IsCeaseAndDesist { get; set; }


        [DateTimeBoth]
        [DataMember]
        public DateTime? CeaseAndDesistDate { get; set; }

        [DataMember]
        public string CeaseAndDesistReason { get; set; }

        [DataMember]
        public string InspFreqTypeGroup { get; set; }

        [DataMember]
        public string InspectionFreqType { get; set; }

        [DataMember]
        public string EligibleOccupancyGroup { get; set; }

        [DataMember]
        public string EligibleOccupancyType { get; set; }

        [DataMember]
        public bool IsNonStandardFrequent { get; set; }

        [DataMember]
        public string NonStandardFreqReason { get; set; }

        [DataMember]
        public string DoorKeyCode { get; set; }

        [DataMember]
        public string LockBoxCode { get; set; }

        [DateTimeBoth]
        [DataMember]
        public DateTime? MortgageDueDate { get; set; }

        [DataMember]
        public decimal? OutstandingBalance { get; set; }

        [DataMember]
        public string GuarantorCaseNumber { get; set; }

        [DataMember]
        public string BillMortgagor { get; set; }

        [DataMember]
        public string LowType { get; set; }

        [DataMember]
        public bool? IsAssetLoan { get; set; }

        [DataMember]
        public bool? IsBadAddress { get; set; }

        [DataMember]
        public string DepartmentTypeGroup { get; set; }

        [DataMember]
        public string DepartmentType { get; set; }

        [DataMember]
        public int CreatedById { get; set; }


        [DateTimeBoth]
        [DataMember]
        public DateTime CreatedDate { get; set; }

        [DataMember]
        public int? LastUpdatedById { get; set; }


        [DateTimeBoth]
        [DataMember]
        public DateTime? LastUpdatedDate { get; set; }

        [DataMember]
        public string DBCreatedBy { get; set; }


        [DateTimeBoth]
        [DataMember]
        public DateTime? DBCreatedDate { get; set; }

        [DataMember]
        public string DBLastUpdatedBy { get; set; }


        [DateTimeBoth]
        [DataMember]
        public DateTime? DBLastUpdatedDate { get; set; }

        [DataMember]
        public string Version { get; set; }

        [DataMember]
        public virtual Asset Asset { get; set; }

        [DataMember]
        public virtual List<Order> Orders { get; set; }
    }
}
