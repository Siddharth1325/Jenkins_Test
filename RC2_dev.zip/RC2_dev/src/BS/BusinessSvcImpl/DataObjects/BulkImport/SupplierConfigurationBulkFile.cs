﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using CommonLib.DataObjects;
using CommonLib.ModelAttrib;

namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{

    [DataContract(Namespace = "http://www.bkfs.com/FS/DataContract/Accounting/1.00")]
    [Serializable]
    [AutoGenMap]

    public partial class SupplierConfigurationBulkFile : BaseDto
    {
        [DataMember]
        [AutoGenMapProp(IsAutoMap = true, IsAutoMapId = true)]
        public int SupplierConfigurationBulkFileId { get; set; }
        [DataMember]
        public string ConfigurationType { get; set; }
        [DataMember]
        public string FileName { get; set; }
        [DataMember]
        public int DocumentId { get; set; }
        [DataMember]
        public string Status { get; set; }
        [DataMember]
        public int? TotalRecordCount { get; set; }
        [DataMember]
        public int? SuccessRecordCount { get; set; }
        [DataMember]
        public int? FailedRecordCount { get; set; }
        [DataMember]
        public string FailureMessage { get; set; }
        [DataMember]
        public int? MasterClientProfileId { get; set; }
        [DataMember]
        public int? SubClientProfileId { get; set; }
        public int? ClientNumber { get; set; }
        [DataMember]
        public string ClientName { get; set; }

        [DataMember]
        public int CreatedById { get; set; }
        [DateTimeBoth]
        [DataMember]
        public DateTime CreatedDate { get; set; }

        public int? LastUpdatedById { get; set; }
        [DateTimeBoth]
        [DataMember]
        public DateTime? LastUpdatedDate { get; set; }

        [DataMember]
        public string Version { get; set; }

        [DataMember]
        public string BulkId { get; set; }

        [DataMember]
        public int AppUserID { get; set; }
        [DataMember]
        public string UploadedBy { get; set; }
    }

}
