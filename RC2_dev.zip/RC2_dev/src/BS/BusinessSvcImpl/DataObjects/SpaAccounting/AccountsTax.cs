﻿using CommonLib.DataObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using CommonLib.ModelAttrib;

namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{
    [DataContract(Namespace = "http://www.bkfs.com/FS/DataContract/Accounting/1.00")]
    [Serializable]
    [AutoGenMap]
    [KnownTypeAttribute(typeof(BaseDto))]
    [KnownTypeAttribute(typeof(AccountsTax))]
    public partial class AccountsTax : BaseDto
    {
        [DataMember]
        [AutoGenMapProp(IsAutoMap = true, IsAutoMapId = true)]
        public int AccountsTaxId { get; set; }

        [DataMember]
        public int? AccountsReceivableAdjustmentId { get; set; }
        [DataMember]
        public int? AccountsReceivableDetailId { get; set; }
        [DataMember]
        public int? ApplicationId { get; set; }

        [DataMember]
        public decimal? TaxAmount { get; set; }

        [DataMember]
        public decimal? TaxRate { get; set; }

        [DataMember]
        public string TransmissionStatus { get; set; }

        [DataMember]
        public string TransmissionStatusGroup { get; set; }

        [DataMember]
        public string ErrorMsg { get; set; }

        [DateTimeBoth]
        [DataMember]
        public DateTime? ErrorDate { get; set; }

        [DataMember]
        public int CreatedById { get; set; }

        [DateTimeBoth]
        [DataMember]
        public DateTime CreatedDate { get; set; }

        [DateTimeBoth]
        [DataMember]
        public int? LastUpdatedById { get; set; }

        [DataMember]
        public DateTime? LastUpdatedDate { get; set; }

        [DataMember]
        public string Version { get; set; }
        [DataMember]
        public virtual AccountsReceivableDetail AccountsReceivableDetail { get; set; }
    }
}
