﻿using CommonLib.DataObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using CommonLib.ModelAttrib;

namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{
    [DataContract(Namespace = "http://www.bkfs.com/FS/DataContract/Accounting/1.00")]
    [Serializable]
    [AutoGenMap]
    [KnownTypeAttribute(typeof(BaseDto))]
    [KnownTypeAttribute(typeof(AccountingWorkOrderAPInvoice))]
    [KnownTypeAttribute(typeof(AccountingWorkOrderARInvoice))]
    public partial class AccountingWorkOrder : BaseDto
    {
        [DataMember]
        [AutoGenMapProp(IsAutoMap = true, IsAutoMapId = true)]
        public int WorkOrderId { get; set; }

        [DataMember]
        public AccountingWorkOrderAPInvoice AccountingWorkOrderAPInvoice { get; set; }

        [DataMember]
        public virtual AccountingWorkOrderARInvoice AccountingWorkOrderARInvoice { get; set; }
    }
}
