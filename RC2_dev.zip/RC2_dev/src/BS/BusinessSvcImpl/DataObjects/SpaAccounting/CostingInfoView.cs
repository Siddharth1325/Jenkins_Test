﻿using CommonLib.DataObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using CommonLib.ModelAttrib;

namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{
    [DataContract(Namespace = "http://www.bkfs.com/FS/DataContract/Accounting/1.00")]
    [Serializable]
    [AutoGenMap]
    [KnownTypeAttribute(typeof(BaseDto))]
    [KnownTypeAttribute(typeof(CostingInfoView))]
    public partial class CostingInfoView : BaseDto
    {
        [DataMember]
        public decimal Amount { get; set; }

        [DataMember]
        public string AdjustmentType { get; set; }


        [DataMember]
        public decimal TotalAmountDue { get; set; }

        [DataMember]
        public string InvoiceNumber { get; set; }
        [DataMember]
        public int? VendorId { get; set; }

        [DataMember]
        public string VendorName { get; set; }

        [DataMember]
        public int WorkOrderId { get; set; }

        //[DataMember]
        //public string MunicipalityZipCode { get; set; }

        //[DataMember]
        //public string Municipality { get; set; }

        [DataMember]
        public bool isVPR { get; set; }
    }
}
