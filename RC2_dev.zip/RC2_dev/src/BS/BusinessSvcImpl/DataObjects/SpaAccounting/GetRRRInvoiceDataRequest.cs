﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using CommonLib.DataObjects;

namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{
    [DataContract]
    public class GetRRRInvoiceDataRequest : BaseRequestDto
    {
        [DataMember]
        public int InvoiceExportId { get; set; }
    }

    [DataContract]
    public class GetRRRInvoiceDecisionDetailsDataRequest : BaseRequestDto
    {
        [DataMember]
        public int RRRInvoiceJSONHeaderId { get; set; }
    }

    [DataContract]
    public class GetRRRInvoiceDecisionDetailsDataResponse : BaseResponseDto
    {
        [DataMember]
        public RRRInvoiceDecisionDetail RRRInvoiceDecisionDetailsView { get; set; }
    }

    public class RRRInvoiceDecisionItemTrackingRequest : BaseRequestDto
    {
        [DataMember]
        public RRRInvoiceDecisionItemTracking RRRInvoiceDecisionItemTracking { get; set; }
    }
}
