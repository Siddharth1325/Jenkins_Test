﻿using CommonLib.DataObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using CommonLib.ModelAttrib;

namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{
    [DataContract(Namespace = "http://www.bkfs.com/FS/DataContract/Accounting/1.00")]
    [Serializable]
    public class OrderSummaryDTO : BaseDto
    {
        [DataMember]
        public int OrderNumber { get; set; }

        [DataMember]
        public string InvoiceNumber { get; set; }

        [DataMember]
        public int WorkOrderNumber { get; set; }

        [DataMember]
        public string ProductCode { get; set; }
       
        [DataMember]
        public string BusinessLine { get; set; }
       
        [DataMember]
        public string OrderDate { get; set; }
        
        [DataMember]
        public string CompletedDate { get; set; }
      
        [DataMember]
        public string ClientNumber { get; set; }
       
        [DataMember]
        public string ClientName { get; set; }
       
        [DataMember]
        public string Status { get; set; }
        [DataMember]
        public string Address { get; set; }
        
        [DataMember]
        public string County { get; set; }
        
        [DataMember]
        public string City { get; set; }

        [DataMember]
        public string State { get; set; }

        [DataMember]
        public string ZipCode { get; set; }
        
        [DataMember]
        public string BorrowerName { get; set; }

        [DataMember]
        public string BorrowerLoanNumber { get; set; }

        [DataMember]
        public string BorrowerLoanType { get; set; }

        [DataMember]
        public string BorrowerLoanAmount { get; set; }

        [DataMember]
        public string BorrowerWorkPhone { get; set; }

        [DataMember]
        public string BorrowerAddress { get; set; }

        [DataMember]
        public string BorrowerCounty { get; set; }

        [DataMember]
        public string BorrowerCity { get; set; }

        [DataMember]
        public string BorrowerState { get; set; }

        [DataMember]
        public string BorrowerZIPCode { get; set; }

        [DataMember]
        public string InvoiceDate { get; set; }

        [DataMember]
        public string InvoiceType { get; set; }

        [DataMember]
        public string BillingFrequency { get; set; }

        [DataMember]
        public string InvoiceAmount { get; set; }

        [DataMember]
        public string TotalDebits { get; set; }

        [DataMember]
        public string TotalCredits { get; set; }

        [DataMember]
        public string Balance { get; set; }

        [DataMember]
        public string VendorNumber { get; set; }

        [DataMember]
        public string VendorName { get; set; }

        [DataMember]
        public string VendorInvoiceNumber { get; set; }

        [DataMember]
        public string VendorFee { get; set; }

        [DataMember]
        public string VendorTotalDebits { get; set; }

        [DataMember]
        public string VendorTotalCredits { get; set; }

        [DataMember]
        public string VendorBalance { get; set; }
    }
}
