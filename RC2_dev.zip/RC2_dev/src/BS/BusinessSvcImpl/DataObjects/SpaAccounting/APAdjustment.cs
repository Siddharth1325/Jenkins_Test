﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{
    public class APAdjustment
    {
        public string WorkOrderNumber { get; set; }       
        public string OrderNumber { get; set; }
        public string InvoiceNumber { get; set; }       
        public string VendorNumber { get; set; }
        public string InspectorUniqueID { get; set; }       
        public string AdjustmentType { get; set; }
        public string AdjustmentDate { get; set; }
        public string AdjustmentCode { get; set; }
        public string ReserveType { get; set; }
        public string Amount { get; set; }
        public string Operation { get; set; }
        public string Function { get; set; }
        public string NaturalAccount { get; set; }
        public string Comments { get; set; }

        public string AdjInvoiceNumber { get; set; }

        public string SupplierComments { get; set; }

        public string ProductCategory { get; set; }

    }
}
