﻿using System;
using System.Runtime.Serialization;
using CommonLib.DataObjects;
using CommonLib.ModelAttrib;

namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{
    public class RRRInvoiceJSONDetail : BaseDto
    {
        [DataMember]
        public int RRRInvoiceJSONDetailId { get; set; }
        [DataMember]
        public int? RRRInvoiceJSONHeaderId { get; set; }
        [DataMember]
        public int ApplicationId { get; set; }
        [DataMember]
        public int? AccountsReceivableDetailId { get; set; }
        [DataMember]
        public int? AccountingExportDetailId { get; set; }
        [DataMember]
        public string Category { get; set; }
        [DataMember]
        public string Description { get; set; }
        [DataMember]
        public int? BillingCode { get; set; }
        [DataMember]
        public int? Quantity { get; set; }
        [DataMember]
        public decimal? ItemPrice { get; set; }
        [DataMember]
        public decimal? ItemSubtotal { get; set; }
        [DataMember]
        public decimal? ItemTax { get; set; }
        [DataMember]
        public decimal? ItemTotal { get; set; }
        [DataMember]
        public string RecordStatusGroup { get; set; }
        [DataMember]
        public string RecordStatusType { get; set; }
        [DataMember]
        public decimal? ItemApprovedAmount { get; set; }
        [DataMember]
        public string ItemDecisionComments { get; set; }
        [DataMember]
        public string ItemDecisionStatus { get; set; }
        [DataMember]
        public int CreatedById { get; set; }

        [DateTimeBoth]
        [DataMember]
        public DateTime CreatedDate { get; set; }

        [DataMember]
        public int? LastUpdatedById { get; set; }

        [DateTimeBoth]
        [DataMember]
        public DateTime? LastUpdatedDate { get; set; }

        [DataMember]
        public string Version { get; set; }
    }
}
