﻿using CommonLib.DataObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using CommonLib.ModelAttrib;

namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{
    [DataContract(Namespace = "http://www.bkfs.com/FS/DataContract/Accounting/1.00")]
    [Serializable]
    [KnownTypeAttribute(typeof(BaseDto))]
    [KnownTypeAttribute(typeof(VertexErrorLog))]
    public partial class VertexErrorLog : BaseDto
    {
        [DataMember]
        public int workOrderId { get; set; }
        [DataMember]
        public int? clientNumber { get; set; }
        [DataMember]
        public string ProductName { get; set; }
        [DataMember]
        public string Address { get; set; }
        [DataMember]
        public string City { get; set; }
        [DataMember]
        public string State { get; set; }
        [DataMember]
        public string Zip { get; set; }
        [DataMember]
        public string Zip4 { get; set; }
        [DataMember]
        public DateTime? ErrorDate { get; set; }
        [DataMember]
        public string ErrorMessage { get; set; }
        [DataMember]
        public decimal EligibleAmount { get; set; }
    }
}
