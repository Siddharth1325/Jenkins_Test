﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{
    public class APInvoice
    {
        public string WorkOrderNumber { get; set; }
        public string InspectorUniqueId { get; set; }
        public string InvoiceAmount { get; set; }
        public string AssignedDate { get; set; }
        public string CompletedDate { get; set; }
        public string ProductCode { get; set; }
        public string PriceAdjReason { get; set; }
        public string Occupancy { get; set; }
        public string PropertyAddress { get; set; }
        public string QCSupplierComment { get; set; }

    }
}
