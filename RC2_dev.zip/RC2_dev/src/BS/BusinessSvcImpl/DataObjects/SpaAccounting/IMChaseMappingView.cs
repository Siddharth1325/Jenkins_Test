using System;
using System.Collections.Generic;
using System.Linq;
using CommonLib.DataObjects;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using CommonLib.ModelAttrib;

namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{
    [DataContract(Namespace = "http://www.bkfs.com/FS/DataContract/Accounting/1.00")]
    [Serializable]
    [AutoGenMap]
    [KnownTypeAttribute(typeof(BaseDto))]
    public partial class IMChaseMappingView : BaseDto
    {
        [DataMember]
        public int IMChaseMappingId { get; set; }

        [DataMember]
        public int ApplicationId { get; set; }

        [DataMember]
        public int ClientNumber { get; set; }

        [DataMember]
        public string ClientLSCI { get; set; }
        [DataMember]
        public string RequestorCode { get; set; }

        [DataMember]
        public string MBACodeType { get; set; }

        [DataMember]
        public string IMInvoiceType { get; set; }

        [DataMember]
        public string IMOrderType { get; set; }

        [DataMember]
        public string IMLineItem { get; set; }
        [DataMember]
        public string LOBType { get; set; }
        [DataMember]
        public bool? IsTax { get; set; }
       
        [DataMember]
        public bool? IsRush { get; set; }

        [DataMember]
        public string ServiceName { get; set; }
        [DataMember]
        public int? ServiceId { get; set; }
        [DataMember]
        public int? LineItemId { get; set; }
        [DataMember]
        public string ServiceItem { get; set; }

        [DataMember]
        public string FeeTypeName { get; set; }

        [DataMember]
        public string Product { get; set; }
        [DataMember]
        public int? ProductId { get; set; }
        [DataMember]
        public string ProductCode { get; set; }
    }
}
