﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CommonLib.DataObjects;
using System.Runtime.Serialization;

namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{
    [DataContract]
    [Serializable]
   public class GetRRRInvoiceDataResponse : BaseResponseDto
    {
        [DataMember]
        public List<RrrInvoiceData> InvoiceDataList { get; set; }


    }

    [DataContract]
    public class RrrInvoiceData
    {
        [DataMember]
        public int RRRInvoiceJSONHeaderId { get; set; }

        [DataMember]
        public Guid RecordID { get; set; }

        [DataMember]
        public string LoanNumber { get; set; }

        [DataMember]
        public int ClientOrderNumber { get; set; }

        [DataMember]
        public int VendorOrderNumber { get; set; }

        [DataMember]
        public string LoanType { get; set; }

        [DataMember]
        public string PackageName { get; set; }

        [DataMember]
        public string BillTo { get; set; }

        [DataMember]
        public string OrderBy { get; set; }

        [DataMember]
        public decimal? HUDCostToDate { get; set; }

        [DataMember]
        public string TransmissionAction { get; set; }

        [DataMember]
        public Guid TransmissionID { get; set; }

        [DataMember]
        public string PartnerID { get; set; }

        [DataMember]
        public string PartnerSystemID { get; set; }

        [DataMember]
        public RRRInvoiceHeader RRRInvoiceHeader { get; set; }
    }

    public class RRRInvoiceHeader
    {

        [DataMember]
        public int RRRInvoiceJSONHeaderId { get; set; }

        [DataMember]
        public DateTime? OrderOpenDate { get; set; }

        [DataMember]
        public DateTime? CompletionDate { get; set; }

        [DataMember]
        public DateTime? InvoiceDate { get; set; }

        [DataMember]
        public string InvoiceNumber { get; set; }

        [DataMember]
        public decimal? InvoiceSubtotal { get; set; }

        [DataMember]
        public decimal? InvoiceTax { get; set; }

        [DataMember]
        public decimal? InvoiceTotal { get; set; }

        [DataMember]
        public List<RRRInvoiceDetail> RRRInvoiceDetails { get; set; }
    }

    public class RRRInvoiceDetail
    {
        [DataMember]
        public int RRRInvoiceJSONDetailId { get; set; }

        [DataMember]
        public string Category { get; set; }

        [DataMember]
        public string Description { get; set; }

        [DataMember]
        public int? BillingCode { get; set; }

        [DataMember]
        public int? Quantity { get; set; }

        [DataMember]
        public decimal? ItemPrice { get; set; }

        [DataMember]
        public decimal? ItemSubtotal { get; set; }

        [DataMember]
        public decimal? ItemTax { get; set; }

        [DataMember]
        public decimal? ItemTotal { get; set; }
    }

    [DataContract]
    public class RRRInvoiceDecisionDetail
    {
        [DataMember]
        public int RRRInvoiceJSONHeaderId { get; set; }
        [DataMember]
        public int ClientOrderNumber { get; set; }
        [DataMember]
        public string InvoiceNumber { get; set; }
        [DataMember]
        public DateTime? InvoiceDate { get; set; }
        [DataMember]
        public DateTime? SentToClientDate { get; set; }
        [DataMember]
        public DateTime? InvoiceDecisionDate { get; set; }
        [DataMember]
        public string LoanNumber { get; set; }
        [DataMember]
        public string LoanType { get; set; }
        [DataMember]
        public string PackageName { get; set; }
        [DataMember]
        public string InvoiceDecision { get; set; }
        [DataMember]
        public string InvoiceDecisionComments { get; set; }
        [DataMember]
        public decimal? InvoiceSubtotal { get; set; }
        [DataMember]
        public decimal? InvoiceTax { get; set; }
        [DataMember]
        public decimal? InvoiceTotal { get; set; }
        [DataMember]
        public decimal? InvoiceApprovedAmount { get; set; }

        [DataMember]
        public string InternalDecision { get; set; }

        [DataMember]
        public List<RRRInvoiceDecisionItemDetail> RRRInvoiceDecisionItemDetails { get; set; }
    }

    public class RRRInvoiceDecisionItemDetail
    {
        [DataMember]
        public int RRRInvoiceJSONDetailId { get; set; }
        [DataMember]
        public string SLFSLineItem { get; set; }
        [DataMember]
        public string ItemDescription { get; set; }
        [DataMember]
        public DateTime? PerformedDate { get; set; }
        [DataMember]
        public string SLFSDecision { get; set; }
        [DataMember]
        public string ItemDecision { get; set; }
        [DataMember]
        public int? Quantity { get; set; }
        [DataMember]
        public decimal? ItemPrice { get; set; }
        [DataMember]
        public decimal? ItemSubtotal { get; set; }
        [DataMember]
        public decimal? ItemTax { get; set; }
        [DataMember]
        public decimal? ItemTotal { get; set; }
        [DataMember]
        public decimal? ItemApprovedAmt { get; set; }
        [DataMember]
        public string ItemDecisionComments { get; set; }
        [DataMember]
        public List<RRRInvoiceDecisionItemTracking> RRRInvoiceDecisionItemTrackings { get; set; }
    }

    public class RRRInvoiceDecisionItemTracking
    {
        [DataMember]
        public int RRRDecisionInvoiceItemTrackingId { get; set; }
        [DataMember]
        public int? RRRInvoiceJSONDetailId { get; set; }
        [DataMember]
        public int? DecisionInvoiceNo { get; set; }
        [DataMember]
        public string SLFSDecision { get; set; }
        [DataMember]
        public int? NewQuantity { get; set; }
        [DataMember]
        public decimal? NewItemPrice { get; set; }
        [DataMember]
        public decimal? NewItemSubtotal { get; set; }
        [DataMember]
        public decimal? NewItemTax { get; set; }
        [DataMember]
        public decimal? NewItemTotal { get; set; }
        [DataMember]
        public string SLFSResponseToClient { get; set; }
        [DataMember]
        public string EnteredBy { get; set; }
        [DataMember]
        public DateTime EnteredDate { get; set; }

        [DataMember]
        public string ItemDecision { get; set; }
    }

}
