using CommonLib.DataObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using CommonLib.ModelAttrib;
using AutoMapper;

namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{
    [DataContract(Namespace = "http://www.bkfs.com/FS/DataContract/Accounting/1.00")]
    [Serializable]
    [AutoGenMap]
    [KnownTypeAttribute(typeof(BaseDto))]
    public partial class AccountingGLCode : BaseDto
    {
        [DataMember]
        [AutoGenMapProp(IsAutoMap = true, IsAutoMapId = true)]
        public int AccountingGLCodeId { get; set; }

        [DataMember]
        public int ApplicationId { get; set; }


        [DataMember]
        [GroupCode("ProductCategoryGroup", GroupCodeEnum.LOB)]
        public string ProductCategory { get; set; }


        [DataMember]
        [GroupCode("GLTransTypeGroup", GroupCodeEnum.GLTRN)]
        public string GLTransType { get; set; }

        [DataMember]
        [GroupCode("ReserveTypeGroup", GroupCodeEnum.RESRV)]
        public string ReserveType { get; set; }

        [DataMember]
        public string GLCompany { get; set; }

        [DataMember]
        public string Operation { get; set; }

        public string Function { get; set; }

        [DataMember]
        [AutoGenMapProp(IsAutoMap = false)]
        public string Functions
        {
            get { return Function; }
            set
            {
                Function = value;
            }
        }

        [DataMember]
        public string NaturalAccount { get; set; }

        [DataMember]
        public string Intercompany { get; set; }

        [DataMember]
        public string FRU1 { get; set; }

        [DataMember]
        public string FRU2 { get; set; }
        [DataMember]
        public int? ServiceId { get; set; }
        [DataMember]
        public int? ProductId { get; set; }
        [DataMember]
        public int? FeeTypeId { get; set; }

        [DataMember]
        public int? MasterClientProfileId { get; set; }

        [DataMember]
        public int? LineItemId { get; set; }

        [DataMember]
        public bool IsActive { get; set; }

        [DataMember]
        public string LocationCode { get; set; }

        [DataMember]
        [AutoGenMapProp(IsAutoMap = false)]
        public string Active { get; set; }

        [DataMember]
        public int CreatedById { get; set; }

        [DateTimeBoth]
        [DataMember]
        public DateTime CreatedDate { get; set; }

        [DataMember]
        public int? LastUpdatedById { get; set; }

        [DateTimeBoth]
        [DataMember]
        public DateTime? LastUpdatedDate { get; set; }

        [DataMember]
        public string Version { get; set; }
        [DataMember]
        public virtual Service Service { get; set; }
        [DataMember]
        public virtual FeeType FeeType { get; set; }
        [DataMember]
        public virtual Product Product { get; set; }
        [DataMember]
        public virtual MasterClientProfile MasterClientProfile { get; set; }
        [DataMember]
        public virtual LineItem LineItem { get; set; }

        [IgnoreMap]
        [DataMember]
        public List<int?> ProductCodes { get; set; }

        [IgnoreMap]
        [DataMember]
        public int ClientNumber { get; set; }


    }
}
