﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{
    public class ARInvoice
    {
        public string InvoiceNumber { get; set; }
        public string InvoiceDate { get; set; }
        public string TotalInvoiceAmount { get; set; }
        public string ClientNumber { get; set; }
        public string Department { get; set; }
        public string LineOfBusiness { get; set; }
        public string BillingFrequency { get; set; }
        public string InvoiceType { get; set; }
        public string OrderNumber { get; set; }
        public string WorkOrderNumber { get; set; }
        public string LoanNumber { get; set; }
        public string ClientPrice { get; set; }
        public string TaxAmount { get; set; }
        public string InvoiceAmount { get; set; }
        public string OrderedDate { get; set; }
        public string CompletedDate { get; set; }
        public string ProductCode { get; set; }
        public string LoanType { get; set; }
        public string Occupancy { get; set; }
        public string MBACode { get; set; }
        public string MortgagorName { get; set; }
        public string ProductCategory { get; set; }

    }
}
