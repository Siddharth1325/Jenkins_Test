using System;
using System.Collections.Generic;
using System.Linq;
using CommonLib.DataObjects;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using CommonLib.ModelAttrib;

namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{
    [DataContract(Namespace = "http://www.bkfs.com/FS/DataContract/Accounting/1.00")]
    [Serializable]
    [AutoGenMap]
    [KnownTypeAttribute(typeof(BaseDto))]
    public partial class ARInvoiceDetailView : BaseDto
    {
        [DataMember]
        public string InvoiceNumber { get; set; }

        [DataMember]
        public int ApplicationId { get; set; }

        [DataMember]
        public int? WorkOrderId { get; set; }

        [DataMember]
        public string LoanNumber { get; set; }

        [DataMember]
        public decimal? InvoiceAmount { get; set; }

        [DataMember]
        public DateTime OrderDate { get; set; }

        [DataMember]
        public DateTime? CompletedDate { get; set; }

        [DataMember]
        public string ProductCode { get; set; }

        [DataMember]
        public string LoanType { get; set; }

        [DataMember]
        public string Occupancy { get; set; }

        [DataMember]
        public string MBACode { get; set; }

        [DataMember]
        public string MortgagorName { get; set; }
        [DataMember]
        public decimal ClientPrice { get; set; }

        [DataMember]
        public decimal? TaxAmount { get; set; }

        [DataMember]
        public int? AccountsReceivableAdjustmentId { get; set; }

        [DataMember]
        public string ProductCategory { get; set; }

        [DataMember]
        public int OrderId { get; set; }


    }
}
