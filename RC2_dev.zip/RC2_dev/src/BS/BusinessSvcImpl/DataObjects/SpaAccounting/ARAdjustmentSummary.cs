﻿using CommonLib.DataObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using CommonLib.ModelAttrib;

namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{
    [DataContract(Namespace = "http://www.bkfs.com/FS/DataContract/Accounting/1.00")]
    [Serializable]
    public class ARAdjustmentSummary : BaseDto
    {
        [DataMember]
        public int OrderNumber { get; set; }

        [DataMember]
        public string InvoiceNumber { get; set; }

        [DataMember]
        public int WorkOrderNumber { get; set; }
       
        [DataMember]
        public string TotalDebits { get; set; }

        [DataMember]
        public string TotalCredits { get; set; }

        [DataMember]
        public ARAdjustmentDetail[] AdjustmentDetail { get; set; }
    }
}
