﻿using CommonLib.DataObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using CommonLib.ModelAttrib;


namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{
    [DataContract(Namespace = "http://www.bkfs.com/FS/DataContract/VPR/1.00")]
    [Serializable]
       [KnownTypeAttribute(typeof(BaseDto))]

    public partial class MunicipalityPayee : BaseDto
    {
        [DataMember]
        [AutoGenMapProp(IsAutoMap = true, IsAutoMapId = true)]
        public int MunicipalityPayeeId { get; set; }

        [DataMember]
        public int MunicipalityId { get; set; }

        [DataMember]
        public int MunicipalityReference { get; set; }

        [DataMember]
        public int CheckNo { get; set; }

        //[DataMember]
        //public string FeeTypeGroup { get; set; }

        //[DataMember]
        //public string FeeType { get; set; }

        [DataMember]
        public string PayeeName { get; set; }

        [DataMember]
        public int CreatedById { get; set; }

        [DateTimeBoth]
        [DataMember]
        public DateTime CreatedDate { get; set; }

        [DataMember]
        public int? LastUpdatedById { get; set; }

        [DateTimeBoth]
        [DataMember]
        public DateTime? LastUpdatedDate { get; set; }

        [DataMember]
        public string Version { get; set; }

        [DataMember]
        public virtual Municipality Municipality { get; set; }
    }
}
