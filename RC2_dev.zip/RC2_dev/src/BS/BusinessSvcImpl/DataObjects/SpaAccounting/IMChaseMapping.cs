using System;
using System.Collections.Generic;
using System.Linq;
using CommonLib.DataObjects;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using CommonLib.ModelAttrib;

namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{
    [DataContract(Namespace = "http://www.bkfs.com/FS/DataContract/Accounting/1.00")]
    [Serializable]
    [AutoGenMap]
    [KnownTypeAttribute(typeof(BaseDto))]
    public partial class IMChaseMapping : BaseDto
    {
        [DataMember]
        [AutoGenMapProp(IsAutoMap = true, IsAutoMapId = true)]
        public int IMChaseMappingId { get; set; }

        [DataMember]
        public int ApplicationId { get; set; }

        [DataMember]
        public int MasterClientProfileId { get; set; }

        [DataMember]
        public int SubClientProfileId { get; set; }

        [DataMember]
        public string RequestorCode { get; set; }

        [DataMember]
        [GroupCode("MBACodeGroup", GroupCodeEnum.MBACD)]
        public string MBACodeType { get; set; }

        [DataMember]
        public string IMInvoiceType { get; set; }

        [DataMember]
        [GroupCode("IMOrderTypeGroup", GroupCodeEnum.IMORT)]
        public string IMOrderType { get; set; }

        [DataMember]
        public string IMLineItem { get; set; }

       [DataMember]
        public string LOBTypeGroup { get; set; }

        [DataMember]
        public string LOBType { get; set; }
        [DataMember]
        public bool? IsTax { get; set; }
        [DataMember]
        public bool? IsRush { get; set; }
        [DataMember]
        public int? ProductId { get; set; }
        [DataMember]
        public int? ServiceId { get; set; }
        [DataMember]
        public int? LineItemId { get; set; }
        [DataMember]
        public int? FeeTypeId { get; set; }


        [DataMember]
        public int CreatedById { get; set; }

        [DateTimeBoth]
        [DataMember]
        public DateTime CreatedDate { get; set; }

        [DataMember]
        public int? LastUpdatedById { get; set; }

        [DateTimeBoth]
        [DataMember]
        public DateTime? LastUpdatedDate { get; set; }

        [DataMember]
        public string Version { get; set; }

         [DataMember]
        public virtual FeeType FeeType { get; set; }
         [DataMember]
         public virtual Service Service { get; set; }
    }
}
