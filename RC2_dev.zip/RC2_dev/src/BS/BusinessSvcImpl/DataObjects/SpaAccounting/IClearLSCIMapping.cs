using System;
using System.Collections.Generic;
using System.Linq;
using CommonLib.DataObjects;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using CommonLib.ModelAttrib;

namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{
    [DataContract(Namespace = "http://www.bkfs.com/FS/DataContract/Accounting/1.00")]
    [Serializable]
    [AutoGenMap]
    [KnownTypeAttribute(typeof(BaseDto))]
    public partial class IClearLSCIMapping : BaseDto
    {
        [DataMember]
        [AutoGenMapProp(IsAutoMap = true, IsAutoMapId = true)]
        public int IClearLSCIMappingId { get; set; }

        [DataMember]
        public int ApplicationId { get; set; }

        [DataMember]
        public int MasterClientProfileId { get; set; }

        [DataMember]
        public int SubClientProfileId { get; set; }

        [DataMember]
        public string IClearClientCode { get; set; }
        [DataMember]
        public string LOBTypeGroup { get; set; }

        [DataMember]
        public string LOBType { get; set; }
        [DataMember]
        public int? LineItemId { get; set; }

        [DataMember]
        public int CreatedById { get; set; }

        [DateTimeBoth]
        [DataMember]
        public DateTime CreatedDate { get; set; }

        [DataMember]
        public int? LastUpdatedById { get; set; }

        [DateTimeBoth]
        [DataMember]
        public DateTime? LastUpdatedDate { get; set; }

        [DataMember]
        public string Version { get; set; }
    }
}
