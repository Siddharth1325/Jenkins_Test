﻿using CommonLib.DataObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using CommonLib.ModelAttrib;

namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{
    [DataContract(Namespace = "http://www.bkfs.com/FS/DataContract/Accounting/1.00")]
    [Serializable]
    [AutoGenMap]
    [KnownTypeAttribute(typeof(BaseDto))]
    [KnownTypeAttribute(typeof(AccountsPayableDetail))]
    [KnownTypeAttribute(typeof(AccountingAPInvoicePayable))]
    public partial class AccountsPayable : BaseDto
    {
        public AccountsPayable()
        {
            AccountingAPInvoicePayables = new HashSet<AccountingAPInvoicePayable>();
            AccountsPayableDetails = new HashSet<AccountsPayableDetail>();
        }

        [DataMember]
        [AutoGenMapProp(IsAutoMap = true, IsAutoMapId = true)]
        public int AccountsPayableId { get; set; }

        [DataMember]
        public int ApplicationId { get; set; }

        [DataMember]
        public int? SourceAccountsPayableId { get; set; }

        [DataMember]
        public int? WorkOrderId { get; set; }

        [DataMember]
        public string GLTransTypeGroup { get; set; }

        [DataMember]
        public string GLTransType { get; set; }

        [DataMember]
        public decimal? SubtotalDue { get; set; }

        [DataMember]
        public decimal? TaxesDue { get; set; }

        [DataMember]
        public decimal TotalAmountDue { get; set; }

        [DataMember]
        public int CreatedById { get; set; }

        [DateTimeBoth]
        [DataMember]
        public DateTime CreatedDate { get; set; }

        [DataMember]
        public int? LastUpdatedById { get; set; }

        [DateTimeBoth]
        [DataMember]
        public DateTime? LastUpdatedDate { get; set; }

        [DataMember]
        public string Version { get; set; }

        [DataMember]
        public virtual WorkOrder WorkOrders { get; set; }

        [DataMember]
        public virtual ICollection<AccountingAPInvoicePayable> AccountingAPInvoicePayables { get; set; }

        [DataMember]
        public virtual ICollection<AccountsPayableDetail> AccountsPayableDetails { get; set; }
    }
}
