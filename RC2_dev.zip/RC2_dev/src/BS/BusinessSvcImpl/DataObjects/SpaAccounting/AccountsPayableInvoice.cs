using CommonLib.DataObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using CommonLib.ModelAttrib;

namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{
    [DataContract(Namespace = "http://www.bkfs.com/FS/DataContract/Accounting/1.00")]
    [Serializable]
    [AutoGenMap]
    [KnownTypeAttribute(typeof(BaseDto))]
    [KnownTypeAttribute(typeof(AccountingWorkOrderAPInvoice))]
    [KnownTypeAttribute(typeof(AccountsPayableAdjustment))]
    [KnownTypeAttribute(typeof(AccountsPayableRemittance))]
    public partial class AccountsPayableInvoice : BaseDto
    {
        public AccountsPayableInvoice()
        {
            // AccountingWorkOrderAPInvoices = new HashSet<AccountingWorkOrderAPInvoice>();
            AccountsPayableAdjustments = new HashSet<AccountsPayableAdjustment>();
            AccountsPayableRemittances = new HashSet<AccountsPayableRemittance>();
        }
        [DataMember]
        [AutoGenMapProp(IsAutoMap = true, IsAutoMapId = true)]
        public int AccountsPayableInvoiceId { get; set; }

        [DataMember]
        public int ApplicationId { get; set; }

        [DataMember]
        public int? VendorProfileId { get; set; }
        [DataMember]
        public int? VPRMunicipalityId { get; set; }

        [DataMember]
        public string InvoiceNumber { get; set; }

        [DataMember]
        public DateTime InvoiceDate { get; set; }

        [DataMember]
        public decimal InvoiceAmount { get; set; }

        [DataMember]
        public int CreatedById { get; set; }

        [DateTimeBoth]
        [DataMember]
        public DateTime CreatedDate { get; set; }

        [DataMember]
        public int? LastUpdatedById { get; set; }

        [DateTimeBoth]
        [DataMember]
        public DateTime? LastUpdatedDate { get; set; }

        [DataMember]
        public string Version { get; set; }

        //[DataMember]
        //public virtual Municipality Municipality { get; set; }
        //[DataMember]
        //public virtual ICollection<AccountingWorkOrderAPInvoice> AccountingWorkOrderAPInvoices { get; set; }

        [DataMember]
        public virtual ICollection<AccountsPayableAdjustment> AccountsPayableAdjustments { get; set; }

        [DataMember]
        public virtual ICollection<AccountsPayableRemittance> AccountsPayableRemittances { get; set; }
    }
}
