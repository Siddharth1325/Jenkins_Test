﻿using System;
using System.Collections.Generic;
using System.Linq;
using CommonLib.DataObjects;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using CommonLib.ModelAttrib;

namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{
    [DataContract(Namespace = "http://www.bkfs.com/FS/DataContract/Accounting/1.00")]
    [Serializable]
    public class AdjustmentCodeSearchInput : BaseDto
    {
        [DataMember]
        public string AdjustmentCategoryType { get; set; }

        [DataMember]
        public string AdjustmentType { get; set; }

        [DataMember]
        public string AdjustmentCode { get; set; }

        [DataMember]
        public string IsActive { get; set; }


    }
}
