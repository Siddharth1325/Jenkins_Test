﻿using CommonLib.DataObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using CommonLib.ModelAttrib;

namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{
    [DataContract(Namespace = "http://www.bkfs.com/FS/DataContract/Accounting/1.00")]
    [Serializable]
    public class ARAdjustmentDetail : BaseDto
    {    

        [DataMember]
        public string AdjustmentType { get; set; }

        [DataMember]
        public string AdjustmentDate { get; set; }

        [DataMember]
        public string AdjustmentCode { get; set; }

        [DataMember]
        public string ReserveType { get; set; }

        [DataMember]
        public string Amount { get; set; }

        [DataMember]
        public string Operation { get; set; }

        [DataMember]
        public string Function { get; set; }

        [DataMember]
        public string NaturalAccount { get; set; }

        [DataMember]
        public string Comments { get; set; }
       
    }
}
