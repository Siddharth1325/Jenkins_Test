using System;
using System.Collections.Generic;
using System.Linq;
using CommonLib.DataObjects;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using CommonLib.ModelAttrib;

namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{
    [DataContract(Namespace = "http://www.bkfs.com/FS/DataContract/Accounting/1.00")]
    [Serializable]
    [AutoGenMap]
    [KnownTypeAttribute(typeof(BaseDto))]
    public partial class APInvoiceDetailView : BaseDto
    {
        [DataMember]
        public Guid APInvoiceDetailViewId { get; set; }

        [DataMember]
        public string InvoiceNumber { get; set; }

        [DataMember]
        public int ApplicationId { get; set; }

        [DataMember]
        public int? VendorProfileId { get; set; }

        [DataMember]
        public int? WorkOrderId { get; set; }

        [DataMember]
        public string InspectorUniqueId { get; set; }

        [DataMember]
        public decimal? InvoiceAmount { get; set; }

        [DataMember]
        public DateTime? AssignedDate { get; set; }

        [DataMember]
        public DateTime? CompletedDate { get; set; }

        [DataMember]
        public string ProductCode { get; set; }

        [DataMember]
        public string Occupancy { get; set; }

        [DataMember]
        public string PropertyAddress { get; set; }

        [DataMember]
        public string PriceAdjReason { get; set; }

       
        [DataMember]
        public string ProductName { get; set; }

        [DataMember]
        public int? AccountsPayableAdjustmentId { get; set; }

        [DataMember]
        public int? SourceVendorWorkOrderId { get; set; }
        [DataMember]
        public string QCSupplierComment { get; set; }
    }
}
