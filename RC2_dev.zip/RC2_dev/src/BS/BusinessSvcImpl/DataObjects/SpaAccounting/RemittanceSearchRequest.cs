﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CommonLib.DataObjects;
using System.Runtime.Serialization;

namespace DomainModel.Common.Dto
{
    [DataContract(Namespace = "http://www.bkfs.com/FS/DataContract/Vendor/1.00")]
    [Serializable]
    public class RemittanceSearchRequest : BaseDto
    {
        [DataMember]
        public int? VendorProfileId { get; set; }
        [DataMember]
        public string VendorName { get; set; }
        [DataMember]
        public string Loan { get; set; }
        [DataMember]
        public string Check { get; set; }
        [DataMember]
        public string PresWorkOrderId { get; set; }
        [DataMember]
        public string InspWorkOrderId { get; set; }
        [DataMember]
        public DateTime? ChkDateFrom { get; set; }
        [DataMember]
        public DateTime? ChkDateTo { get; set; }
        [DataMember]
        public DateTime? InvoiceDateFrom { get; set; }
        [DataMember]
        public DateTime? InvoiceDateTo { get; set; }
        [DataMember]
        public DateTime? SubmissionFromDate { get; set; }
        [DataMember]
        public DateTime? SubmissionToDate { get; set; }
        [DataMember]
        public string Lobs { get; set; }
        [DataMember]
        public int? ApplicationId { get; set; }
        [DataMember]
        public bool IsVendorNumber { get; set; }
        [DataMember]
        public string ViewType { get; set; }
        [DataMember]
        public string InvoiceNumber { get; set; }
        [DataMember]
        public string OracleId { get; set; }

    }
}
