using CommonLib.DataObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using CommonLib.ModelAttrib;

namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{
    [DataContract(Namespace = "http://www.bkfs.com/FS/DataContract/Accounting/1.00")]
    [Serializable]
    [AutoGenMap]
    [KnownTypeAttribute(typeof(BaseDto))]
    public partial class AccountsPayableAdjustment : BaseDto
    {
        [DataMember]
        [AutoGenMapProp(IsAutoMap = true, IsAutoMapId = true)]
        public int AccountsPayableAdjustmentId { get; set; }

        [DataMember]
        public int ApplicationId { get; set; }

        [DataMember]
        public int? AccountsPayableInvoiceId { get; set; }

        [DataMember]
        public int? DisputePayableAdjustmentHistoryId { get; set; }

        [DataMember]
        public int? AccountsPayableDetailId { get; set; } 

        [DataMember]
        public int? WorkOrderId { get; set; }

        [DataMember]
        public string AdjustmentType { get; set; }

        [DataMember]
        public string AdjustmentCode { get; set; }

        [DateTimeBoth]
        [DataMember]
        public DateTime AdjustmentDate { get; set; }

        [DataMember]
        public decimal Amount { get; set; }

        [DataMember]
        public string GLTransTypeGroup { get; set; }

        [DataMember]
        public string GLTransType { get; set; }

        [DataMember]
        public string Operation { get; set; }

        [DataMember]
        public string Function { get; set; }

        [DataMember]
        public string NaturalAccount { get; set; }

        [DataMember]
        public string Comments { get; set; }

        [DataMember]
        public string SupplierComment { get; set; }

        public int CreatedById { get; set; }

        [DateTimeBoth]
        [DataMember]
        public DateTime CreatedDate { get; set; }

        [DataMember]
        public int? LastUpdatedById { get; set; }

        [DateTimeBoth]
        [DataMember]
        public DateTime? LastUpdatedDate { get; set; }

        [DataMember]
        public string Version { get; set; }
    }
}
