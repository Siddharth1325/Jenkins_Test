﻿using CommonLib.DataObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using CommonLib.ModelAttrib;

namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{
    [DataContract(Namespace = "http://www.bkfs.com/FS/DataContract/Accounting/1.00")]
    [Serializable]
    [AutoGenMap]
    [KnownTypeAttribute(typeof(BaseDto))]
    [KnownTypeAttribute(typeof(AccountsPayableTrace))]
    public partial class AccountsPayableDetail : BaseDto
    {
        public AccountsPayableDetail()
        {
            AccountsPayableTraces = new HashSet<AccountsPayableTrace>();
            AccountingAPInvoicePayables = new HashSet<AccountingAPInvoicePayable>();
        }

        [DataMember]
        [AutoGenMapProp(IsAutoMap = true, IsAutoMapId = true)]
        public int AccountsPayableDetailId { get; set; }

        [DataMember]
        public int ApplicationId { get; set; }

        [DataMember]
        public int? SourceAccountsPayableDetailId { get; set; }

        [DataMember]
        public int? OrderHierarchyId { get; set; }

        [DataMember]
        public int? AccountsPayableId { get; set; }

        [DataMember]
        public int? WorkOrderItemId { get; set; }

        [DataMember]
        public int? Quantity { get; set; }

        [DataMember]
        public string UnitsGroup { get; set; }

        [DataMember]
        public string UnitsType { get; set; }

        [DataMember]
        public decimal? BaseCostPerUnit { get; set; }

        [DataMember]
        public decimal BaseTotalCost { get; set; }

        [DataMember]
        public decimal? FinalTotalCost { get; set; }

        [DataMember]
        public int? FeeTypeId { get; set; }

        [DataMember]
        public string APStatusGroup { get; set; }

        [DataMember]
        public string APStatusType { get; set; }

        [DataMember]
        public int CreatedById { get; set; }

        [DateTimeBoth]
        [DataMember]
        public DateTime CreatedDate { get; set; }

        [DataMember]
        public int? LastUpdatedById { get; set; }

        [DateTimeBoth]
        [DataMember]
        public DateTime? LastUpdatedDate { get; set; }

        [DataMember]
        public string Version { get; set; }

        [DataMember]
        public string QCSupplierComment { get; set; }

        [DataMember]
        public virtual ICollection<AccountsPayableTrace> AccountsPayableTraces { get; set; }

        [DataMember]
        public virtual OrderHierarchy OrderHierarchy { get; set; }

        [DataMember]
        public virtual FeeType FeeType { get; set; }

        

        [DataMember]
        public virtual ICollection<AccountingAPInvoicePayable> AccountingAPInvoicePayables { get; set; }
    }
}
