﻿using CommonLib.DataObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using CommonLib.ModelAttrib;



namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{
       [DataContract(Namespace = "http://www.bkfs.com/FS/DataContract/Accounting/1.00")]
    [Serializable]
   
    [KnownTypeAttribute(typeof(BaseDto))]
    

    public partial class Municipality : BaseDto
    {
        public Municipality()
        {
        //    //this.AccountsPayableInvoices = new HashSet<AccountsPayableInvoice>();
       // MunicipalityPayee = new HashSet<MunicipalityPayee>();
        //    //this.ClientProductFees = new HashSet<ClientProductFee>();
        //    //this.ProductFees = new HashSet<ProductFee>();
        }

        [DataMember]
        [AutoGenMapProp(IsAutoMap = true, IsAutoMapId = true)]
        public int MunicipalityId { get; set; }

        [DataMember]
        public string StateCode { get; set; }

        [DataMember]
        public string CountyName { get; set; }

        [DataMember]
        public string MunicipalityName { get; set; }

        //[DataMember]
        //public string ARTNotes { get; set; }

        //[DataMember]
        //public string VerifyLocationNotes { get; set; }

        //public int LinksUrlPathId { get; set; }

        [DataMember]
        public int? CreatedById { get; set; }

        [DateTimeBoth]
        [DataMember]
        public DateTime CreatedDate { get; set; }

        [DataMember]
        public int? LastUpdatedById { get; set; }

        [DateTimeBoth]
        [DataMember]
        public DateTime? LastUpdatedDate { get; set; }

        [DataMember]
        public string Version { get; set; }

        //[DataMember]
        //public virtual ICollection<MunicipalityPayee> MunicipalityPayee { get; set; }
      
    }
}
