﻿using CommonLib.DataObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using CommonLib.ModelAttrib;

namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{
    [DataContract(Namespace = "http://www.bkfs.com/FS/DataContract/Accounting/1.00")]
    [Serializable]
    [AutoGenMap]
    [KnownTypeAttribute(typeof(BaseDto))]
    [KnownTypeAttribute(typeof(Service))]
   public partial class Service : BaseDto
    {
        [DataMember]
        [AutoGenMapProp(IsAutoMap = true, IsAutoMapId = true)]
        public int ServiceId { get; set; }
        [DataMember]
        public int ApplicationId { get; set; }
        [DataMember]
        public string ServiceCode { get; set; }
        [DataMember]
        public string ServiceName { get; set; }
        [DataMember]
        public string ServiceDesc { get; set; }

        [DataMember]
        public string Instructions { get; set; }

        [DataMember]
        public string ProductCategoryGroup { get; set; }
        [DataMember]
        public string ProductCategory { get; set; }
        [DataMember]
        public string ServiceCategoryGroup { get; set; }

        [DataMember]
        public string ServiceCategoryType { get; set; }

        [DataMember]
        public decimal? DefaultPrice { get; set; }
        [DataMember]
        public bool IsActive { get; set; }

        [DataMember]
        public DateTime? ActiveChangedDate { get; set; }
        [DataMember]
        public int? ActiveChangedById { get; set; }
        [DataMember]
        public int CreatedById { get; set; }

        [DataMember]
        public DateTime CreatedDate { get; set; }
        [DataMember]
        public int? LastUpdatedById { get; set; }

        [DataMember]
        public DateTime? LastUpdatedDate { get; set; }

        [DataMember]
        public string Version { get; set; }
		
    }
}
