﻿using CommonLib.DataObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using CommonLib.ModelAttrib;

namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{
    [DataContract(Namespace = "http://www.bkfs.com/FS/DataContract/Accounting/1.00")]
    [Serializable]    
    public partial class AdjustmentCodeSearchResult : BaseDto
    {
        [DataMember]
        public int AccountingAdjustmentCodeId { get; set; }

        [DataMember]
        public string AdjustmentCategoryType { get; set; }

        [DataMember]
        public string AdjustmentType { get; set; }

        [DataMember]
        public string AdjustmentCode { get; set; }

        [DataMember]
        public string Description { get; set; }

        [DataMember]
        public string IsActive { get; set; }

        [DataMember]
        public string LastUpdatedDate { get; set; }

    }
}
