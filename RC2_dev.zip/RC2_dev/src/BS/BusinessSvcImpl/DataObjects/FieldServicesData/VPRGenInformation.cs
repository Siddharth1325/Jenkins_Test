﻿using CommonLib.DataObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using CommonLib.ModelAttrib;

namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{
    [DataContract(Namespace = "http://www.bkfs.com/FS/DataContract/Accounting/1.00")]
    [Serializable]
    [AutoGenMap]
    [KnownTypeAttribute(typeof(BaseDto))]
    [KnownTypeAttribute(typeof(VPRGenInformation))]
    public partial class VPRGenInformation : BaseDto
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public VPRGenInformation()
        {
            PaymentDetails = new HashSet<PaymentDetail>();
        }
        [DataMember]

        public int VPRGenInformationId { get; set; }
        [DataMember]
        public int? WorkOrderId { get; set; }

        [DataMember]
        public int? OrdinanceProfileId { get; set; }

        //[DataMember]
        //public string Municipality { get; set; }

        //[DataMember]
        //public string MunicipalityZipCode { get; set; }

        [DataMember]
        public DateTime? InitialRegistrationDue { get; set; }
        [DataMember]
        public bool? OnlineRegistration { get; set; }

        [DataMember]
        public string OccupancyStatusGroup { get; set; }

        [DataMember]
        public string OccupancyStatusType { get; set; }


         [DataMember]
        public bool? IscreditCardPayment { get; set; }

         [DataMember]
        public string ConfirmationNo { get; set; }

       [DataMember]
        public string MunicipalityAddress1 { get; set; }

        [DataMember]
        public string MunicipalityAddress2 { get; set; }

        [DataMember]
        public string MunicipalityCity { get; set; }

         [DataMember]
        public string MunicipalityState { get; set; }

        [DataMember]
        [DateTimeBoth]
        public DateTime? ChargeOffDate { get; set; }

        [DataMember]
        public int CreatedById { get; set; }

        [DataMember]
        [DateTimeBoth]
        public DateTime CreatedDate { get; set; }
        [DataMember]
        public int? LastUpdatedById { get; set; }

        [DataMember]
        [DateTimeBoth]
        public DateTime? LastUpdatedDate { get; set; }

        [DataMember]

        public string Version { get; set; }

        [DataMember]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<PaymentDetail> PaymentDetails { get; set; }
    }
}
