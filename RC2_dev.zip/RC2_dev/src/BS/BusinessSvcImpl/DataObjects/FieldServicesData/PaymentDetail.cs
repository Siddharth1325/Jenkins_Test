﻿using CommonLib.DataObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using CommonLib.ModelAttrib;

namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{
    [DataContract(Namespace = "http://www.bkfs.com/FS/DataContract/Accounting/1.00")]
    [Serializable]
    [AutoGenMap]
    [KnownTypeAttribute(typeof(BaseDto))]
    [KnownTypeAttribute(typeof(PaymentDetail))]
    public partial class PaymentDetail : BaseDto
    {
        [DataMember]
        [AutoGenMapProp(IsAutoMap = true, IsAutoMapId = true)]
        public int PaymentDetailsId { get; set; }
        [DataMember]
        public int VPRGenInformationId { get; set; }
[DataMember]
        public int? WorkOrderId { get; set; }

        [DataMember]
        public string Payee { get; set; }

        [DataMember]
        public decimal? Amount { get; set; }

       [DataMember]
        public string MunicipalityReferenceNo { get; set; }
        [DataMember]
        public bool? IsCreditCardPayment { get; set; }

        [DataMember]
        public string ConfirmationNo { get; set; }

        [DataMember]
        public DateTime? PaymentDate { get; set; }

       [DataMember]
        public string PaymentType { get; set; }
[DataMember]
        public int CreatedById { get; set; }

       [DataMember]
        public DateTime CreatedDate { get; set; }
        [DataMember]
        public int? LastUpdatedById { get; set; }

        [DataMember]
        public DateTime? LastUpdatedDate { get; set; }

       [DataMember]
        public string Version { get; set; }

       [DataMember]
        public string FeeTypeName { get; set; }
        [DataMember]
        public virtual VPRGenInformation VPRGenInformation { get; set; }
    }
}
