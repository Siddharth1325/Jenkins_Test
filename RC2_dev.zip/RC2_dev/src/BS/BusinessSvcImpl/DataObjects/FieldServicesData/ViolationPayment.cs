﻿using CommonLib.DataObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using CommonLib.ModelAttrib;

namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{
    [DataContract(Namespace = "http://www.bkfs.com/FS/DataContract/Accounting/1.00")]
    [Serializable]
    [AutoGenMap]
    [KnownTypeAttribute(typeof(BaseDto))]

    public partial class ViolationPayment : BaseDto
    {
        [DataMember]
        public int ViolationPaymentId { get; set; }
        [DataMember]
        public int? OrderId { get; set; }
        [DataMember]
        public string Payee { get; set; }
        [DataMember]
        public bool ChargeToClient { get; set; }

        [DataMember]
        public string ViolationPaymentGroup { get; set; }
        [DataMember]
        public string ViolationPaymentType { get; set; }
        [DataMember]
        public string FeeTypeGroup { get; set; }
        [DataMember]
        public string FeeType { get; set; }
        [DataMember]
        public int? WorkOrderId { get; set; }
        [DataMember]
        public int? FeeTypeId { get; set; }
        [DataMember]
        public bool IsCreditCardPayment { get; set; }
        [DataMember]
        public decimal FeeAmount { get; set; }
        [DataMember]
        public DateTime? DateApproved { get; set; }
        [DataMember]
        public string ApprovedBy { get; set; }

        [DataMember]
        public DateTime? CheckDate { get; set; }

        [DataMember]
        public DateTime? CCPaymentDate { get; set; }

        [DataMember]
        public string CheckNumber { get; set; }

        [DataMember]
        public string ConfirmationNumber { get; set; }

        [DataMember]
        public string Memo { get; set; }
        [DataMember]
        public int CreatedById { get; set; }
        [DataMember]
        public DateTime CreatedDate { get; set; }
        [DataMember]
        public int? LastUpdatedById { get; set; }
        [DataMember]
        public DateTime? LastUpdatedDate { get; set; }
        [DataMember]
        public string Version { get; set; }
        [DataMember]
        public virtual Order Order { get; set; }

    }
}
