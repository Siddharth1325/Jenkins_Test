﻿using CommonLib.DataObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using CommonLib.ModelAttrib;

namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{
    [DataContract(Namespace = "http://www.bkfs.com/FS/DataContract/Accounting/1.00")]
    [Serializable]
    [AutoGenMap]
    [KnownTypeAttribute(typeof(BaseDto))]

    public partial class OrdinanceProfile : BaseDto
    {       

        [DataMember]
        [AutoGenMapProp(IsAutoMap = true, IsAutoMapId = true)]
        public int OrdinanceProfileId { get; set; }

        //[DataMember]
        //public string Municipality { get; set; }

        //[DataMember]
        //public string MunicipalityZipCode { get; set; }

        [DataMember]
        [GroupCode("OrdinanceStatusGroup", GroupCodeEnum.ODT)]
        public string OrdinanceStatus { get; set; }


        [DataMember]
        [IgnoreDataMember]
        public string OrdinanceStatusGridText { get; set; }

        [DataMember]
        public DateTime? EffectiveDate { get; set; }

        [DataMember]
        public string CommonName { get; set; }

        [DataMember]
        public bool? IsActive { get; set; }
      

        [DataMember]
        [GroupCode("RenewalBasisGroup", GroupCodeEnum.RENBASIS)]
        public string RenewalBasis { get; set; }

        [DataMember]
        public string RenewalDueText { get; set; }
      

        //[DataMember]
        //[GroupCode("RegistrationTypeGroup", GroupCodeEnum.REGTYP)]
        //public string RegistrationType { get; set; }
      

        [DataMember]
        [GroupCode("GoverningEntityGroup", GroupCodeEnum.GOVENT)]
        public string GoverningEntity { get; set; }

        [DataMember]
        public string Citation { get; set; }

        [DataMember]
        public string FormsLink { get; set; }

        [DataMember]
        ///[GroupCode("DeRegistrationGroup", GroupCodeEnum.ORDDRPS)]
        public string DeRegistration { get; set; }

        [DataMember]
        //[GroupCode("BondRequiredGroup", GroupCodeEnum.ORDDRPS)]
        public string BondRequired { get; set; }

        [DataMember]
        public string OrdinanceLink { get; set; }

        [DataMember]
        public decimal? BondAmount { get; set; }

        [DataMember]
       // [GroupCode("BondEnforceGroup", GroupCodeEnum.ORDDRPS)]
        public string BondEnforce { get; set; }

        [DataMember]
       // [GroupCode("PostPropertySignGroup", GroupCodeEnum.ORDDRPS)]
        public string PostPropertySign { get; set; }
     
        //[DataMember]
        ////[GroupCode("SignateTypeGroup", GroupCodeEnum.SIGTYPE)]
        //public string SignateType { get; set; }

        [DataMember]
       // [GroupCode("InsuranceRequiredGroup", GroupCodeEnum.ORDDRPS)]
        public string InsuranceRequired { get; set; }

        [DataMember]
       // [GroupCode("InsuranceEnforceGroup", GroupCodeEnum.ORDDRPS)]
        public string InsuranceEnforce { get; set; }

        [DataMember]
        public string MinimumInsuranceText { get; set; }

        [DataMember]
        public string PropertyLookupLink { get; set; }

        [DataMember]
        public string PropertyLookupPhone { get; set; }

        [DataMember]
        //[GroupCode("ApprovedToSignFormsGroup", GroupCodeEnum.ORDDRPS)]
        public string ApprovedToSignForms { get; set; }

        [DataMember]
        //[GroupCode("ApprovedToSignNotaryGroup", GroupCodeEnum.ORDDRPS)]
        public string ApprovedToSignNotary { get; set; }

        [DataMember]
       /// [GroupCode("ApprovedToSignAttestationGroup", GroupCodeEnum.ORDDRPS)]
        public string ApprovedToSignAttestation { get; set; }

        [DataMember]
        public string AttentionTo { get; set; }

        [DataMember]
        public string Address1 { get; set; }

        [DataMember]
        public string Address2 { get; set; }

        [DataMember]
        public string CityName { get; set; }

        [DataMember]
        public string CountyName { get; set; }

        [DataMember]
        public string StateCode { get; set; }

        [DataMember]
        public string ZipCode { get; set; }

        [DataMember]
        ///[GroupCode("SubmitPropertyManagerGroup", GroupCodeEnum.ORDDRPS)]
        public string SubmitPropertyManager { get; set; }

        [DataMember]
       // [GroupCode("LocalPropertyManagerGroup", GroupCodeEnum.ORDDRPS)]
        public string LocalPropertyManager { get; set; }

        [DataMember]
        public string ExplainLocal { get; set; }

        [DataMember]
        //[GroupCode("PropertyManagerEnforceGroup", GroupCodeEnum.ORDDRPS)]
        public string PropertyManagerEnforce { get; set; }

        [DataMember]
       // [GroupCode("PropertyManagerToSendDocGroup", GroupCodeEnum.ORDDRPS)]
        public string PropertyManagerToSendDoc { get; set; }


        [DataMember]
        public string MailingCityName { get; set; }

        [DataMember]
        public string MailingState { get; set; }

        [DataMember]
        public string MailingZipCode { get; set; }

        [DataMember]
        public int CreatedById { get; set; }

        [DataMember]
        [DateTimeBoth]
        public DateTime CreatedDate { get; set; }

        [DataMember]
        public int? LastUpdatedById { get; set; }

        [DataMember]
        [DateTimeBoth]
        public DateTime? LastUpdatedDate { get; set; }

        [DataMember]
        public string Version { get; set; }
      
    }
}
