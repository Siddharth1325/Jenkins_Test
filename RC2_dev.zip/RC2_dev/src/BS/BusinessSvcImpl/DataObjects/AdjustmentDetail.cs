﻿using CommonLib.DataObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using CommonLib.ModelAttrib;

namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{
    [Serializable]
    [DataContract(Namespace = "http://www.bkfs.com/FS/DataContract/Vendor/1.00")]
    public class AdjustmentDetailRequest : BaseRequestDto
    {
        [DataMember]
        public int? OrderId { get; set; }
        [DataMember]
        public int? LoanID { get; set; }
        [DataMember]
        public string UpdateGridType { get; set; }
        [DataMember]
        public int? PageSize { get; set; }
        [DataMember]
        public int? SkipCount { get; set; }
    }

    public class AdjustmentDetailResponse : BaseResponseDto
    {

        [DataMember]
        public bool IsMiscProduct { get; set; }

        [DataMember]
        public List<ClientFeeAdjustmentDetail> clientAdjustMentResponseList { get; set; }
        [DataMember]
        public List<VendorFeeAdjustmentDetail> vendorFeeAdjustmentResponseList { get; set; }
        [DataMember]
        public List<ProductServiceAdjustmentResponse> productServiceAdjustmentResponseList { get; set; }

        [DataMember]
        public List<MiscAdjustmentDetail> MiscAdjustmentDetailList { get; set; }

        [DataMember]
        public OrderTotal OrderTotals { get; set; }
    }


    [Serializable]
    [DataContract(Namespace = "http://www.bkfs.com/FS/DataContract/Vendor/1.00")]
    public class PrdSrvMainDataRequest : BaseRequestDto
    {
        [DataMember]
        public int? HistoryPayableId { get; set; }
        [DataMember]
        public int? HistoryreceivableId { get; set; }
        [DataMember]
        public int? OrderhierachyID { get; set; }
        [DataMember]
        public string FeeType { get; set; }
        [DataMember]
        public int? PageSize { get; set; }
        [DataMember]
        public int? SkipCount { get; set; }
    }

    public class PrdSrvMainDataResponse : BaseResponseDto
    {
        [DataMember]
        public List<FlatFeeAdjustmentDetail> FlatFeeAdjustmentResponseList { get; set; }
        [DataMember]
        public List<DiscountAdjustmentDetail> DiscountAdjustmentResponseList { get; set; }
        [DataMember]
        public List<LineItemAdjustmentDetail> LineItemAdjustmentResponseList { get; set; }

        [DataMember]
        public OrderTotal OrderTotals { get; set; }
    }

    public enum BillAdjustmentDetailType
    {
        Order,
        VendorWorkOrder,
        FlatFee,
        Discount,
        LineItem,
        MiscProduct,
        Penalty
    }

    [Serializable]
    [DataContract(Namespace = "http://www.bkfs.com/FS/DataContract/Vendor/1.00")]
    public class FeeAdjustmentDetailRequest : BaseRequestDto
    {
        [DataMember]
        public int ARAdjustmentHistoryId { get; set; }

        [DataMember]
        public int OrderHierarchyId { get; set; }

        [DataMember]
        public BillAdjustmentDetailType DetailType { get; set; }

        [DataMember]
        public string Type { get; set; }

        [DataMember]
        public string AchievementName { get; set; }

        [DataMember]
        public int?  feeTypeId { get; set; }

        [DataMember]
        public int? FeeTypeRefId { get; set; }
    }
    [Serializable]
    [DataContract(Namespace = "http://www.bkfs.com/FS/DataContract/Vendor/1.00")]
    public class SaveDisputeEntitiesRequest : BaseRequestDto
    {
        [DataMember]
        public DisputePayableAdjustmentHistory DisputePayableAdjustmentHistory { get; set; }
        [DataMember]
        public DisputeReceivableAdjustmentHistory DisputeReceivableAdjustmentHistory { get; set; }
    }

    [Serializable]
    [DataContract(Namespace = "http://www.bkfs.com/FS/DataContract/Vendor/1.00")]
    public class FeeAdjustmentDetailResponse : BaseResponseDto
    {
        [DataMember]
        public List<ClientFeeAdjustmentDetail> ClientFeeAdjustmentDetailList { get; set; }
        [DataMember]
        public List<VendorFeeAdjustmentDetail> VendorFeeAdjustmentDetailList { get; set; }
        [DataMember]
        public List<FlatFeeAdjustmentDetail> FlatFeeAdjustmentDetailList { get; set; }
        [DataMember]
        public List<DiscountAdjustmentDetail> DiscountAdjustmentDetailList { get; set; }
        [DataMember]
        public List<LineItemAdjustmentDetail> LineItemAdjustmentDetailList { get; set; }

        [DataMember]
        public List<MiscAdjustmentDetail> MiscAdjustmentDetailList { get; set; }

        [DataMember]
        public List<PenaltyAdjustmentDetail> PenaltyAdjustmentDetailList { get; set; }
       
    }

    [DataContract]
    public partial class MiscAdjustmentDetail : BaseDto
    {
        [DataMember]
        public int OrderId { get; set; }
        
        [DataMember]
        public int WorkOrderId { get; set; }

        [DataMember]
        public int Id { get; set; }

        [DataMember]
        public string IdType { get; set; }

        [DataMember]
        public string FeeType { get; set; }

        [DataMember]
        public decimal? Cost { get; set; }

        [DataMember]
        public decimal? CostAdjustment { get; set; }

        [DataMember]
        public string RecType { get; set; }

        [DataMember]
        public DateTime? InvoicedDate { get; set; }

        [DataMember]
        public string InvoiceNumber { get; set; }

        [DataMember]
        public decimal? Tax { get; set; }

        [DataMember]
        public string Product { get; set; }
        
        [DataMember]
        public int RecordNumber { get; set; }

        [DataMember]
        public int OrderHierarchyId { get; set; }

        [DataMember]
        public string Comments { get; set; }

        [DataMember]
        public int? FeeTypeId { get; set; }

        [DataMember]
        public DateTime? AdjustmentDate { get; set; }

        [DataMember]
        public int? FeeTypeRefId { get; set; }

        [DataMember]
        public int? VendorId { get; set; }

        [DataMember]
        public string ProductCode { get; set; }

        [DataMember]
        public string Version { get; set; }
    }

    [DataContract]
    public class PenaltyDataResponse
    {

        public PenaltyDataResponse()
        {
            PenaltyAdjustmentDetailList = new List<PenaltyAdjustmentDetail>();
            PenaltyVwoDetailsList = new List<PenaltyVendorWorkOrderDetailDto>();
        }

        [DataMember]
        public List<PenaltyAdjustmentDetail> PenaltyAdjustmentDetailList { get; set; }

        [DataMember]
        public List<PenaltyVendorWorkOrderDetailDto> PenaltyVwoDetailsList { get; set; }
       
        [DataMember]
        public bool IsScoreCardVisible { get; set; }

    }

    [DataContract]
    public class PenaltyVendorWorkOrderDetailDto
    {
        [DataMember]
        public int VendorWorkOrderId { get; set; }

        [DataMember]
        public int VendorId { get; set; }
    }

    [DataContract]
    public partial class PenaltyAdjustmentDetail : BaseDto
    {
        [DataMember]
        public int DisputePenaltyAdjustmentHistoryId { get; set; }
        [DataMember]
        public int? VendorWorkOrderId { get; set; }
        [DataMember]
        public int AssignedVendorId { get; set; }
        [DataMember]
        public int? WorkOrderId { get; set; }
        [DataMember]
        public int? OrderId { get; set; }
        [DataMember]
        public string ProductName { get; set; }
        [DataMember]
        public string ServiceName { get; set; }
        [DataMember]
        public string GoalName { get; set; }
        [DataMember]
        public string AchievementName { get; set; }
        [DataMember]
        public decimal? PenaltyAmount { get; set; }
        [DataMember]
        public decimal? PenaltyAdjustmentAmount { get; set; }
        [DataMember]
        public string InvoiceNumber { get; set; }
        [DataMember]
        public DateTime? InvoiceDate { get; set; }
        [DataMember]
        public string Comments { get; set; }
        [DataMember]
        public string SupplierComment { get; set; }
        [DataMember]
        public string RecType { get; set; }
        [DataMember]
        // public int rnk { get; set; }
        public DateTime? AdjustmentDate { get; set; }
        [DataMember]
        public int RecordNumber { get; set; }
        [DataMember]
        public int OrderHierarchyId { get; set; }

        [DataMember]
        public string Version { get; set; }

        [DataMember]
        public int? ApplicationId { get; set; }


        [DataMember]
        public int? FeeTypeId { get; set; }

        [DataMember]
        public bool IsAPAdjusted { get; set; }
    }

    [DataContract]
    public partial class AdjustmentScoreCard : BaseDto
    {

        [DataMember]
        public int? WorkOrderId { get; set; }

        [DataMember]
        public int? WorkOrderItemId { get; set; }

        [DataMember]
        public string GoalName { get; set; }

        [DataMember]
        public string AchievementName { get; set; }

        [DataMember]
        public decimal? AdjustmentAmount { get; set; }

    }

    [Serializable]
    [DataContract(Namespace = "http://www.bkfs.com/FS/DataContract/Vendor/1.00")]
    [AutoGenMap]
    public partial class ClientFeeAdjustmentDetail : BaseDto
    {
        [DataMember]
        [AutoGenMapProp(IsAutoMap = true, IsAutoMapId = true)]
        public int? AdjustmentDetailHistoryId { get; set; }
        [DataMember]
        public bool? IsAdjusted { get; set; }
        [DataMember]
        public string RecType { get; set; }
        [DataMember]
        public int? OrderId { get; set; }
        [DataMember]
        public string ARInvoiceNumber { get; set; }
        [DataMember]
        public decimal? ClientTripFee { get; set; }
        [DataMember]
        public decimal? ClientTripFeeAdj { get; set; }
        [DataMember]
        public decimal? RushFee { get; set; }
        [DataMember]
        public decimal? RushFeeAdj { get; set; }
        [DataMember]
        public decimal? ClientTripFeeTaxAmount { get; set; }
        [DataMember]
        public decimal? RushFeeTaxAmount { get; set; }
        [DataMember]
        public DateTime? InvoicedDate { get; set; }
        [DataMember]
        public DateTime? AdjustmentDate { get; set; }
        [DataMember]
        public string Comments { get; set; }

        public string SupplierComment { get; set; }


        [DataMember]
        public int? OrderHierarchyId { get; set; }
        [DataMember]
        public int RecordNumber { get; set; }

        [DataMember]
        public bool IsArInvoiced { get; set; }

        [DataMember]
        public string Version { get; set; }
      
    }

    [Serializable]
    [DataContract(Namespace = "http://www.bkfs.com/FS/DataContract/Vendor/1.00")]
    [AutoGenMap]
    public partial class VendorFeeAdjustmentDetail : BaseDto
    {
        [DataMember]
        public bool? IsAdjusted { get; set; }
        [DataMember]
        [AutoGenMapProp(IsAutoMap = true, IsAutoMapId = true)]
        public int? AdjustmentDetailHistoryId { get; set; }
        [DataMember]
        public int? OrderHierarchyId { get; set; }
        [DataMember]
        public int? VendorWorkOrderId { get; set; }
        [DataMember]
        public int? VendorId { get; set; }
        [DataMember]
        public decimal? OneTimeFee { get; set; }
        [DataMember]
        public decimal? OneTimeFeeAdjAmount { get; set; }
        [DataMember]
        public decimal? TripFee { get; set; }
        [DataMember]
        public decimal? TripFeeAdjAmount { get; set; }
        [DataMember]
        public decimal? MinServiceFee { get; set; }
        [DataMember]
        public decimal? MinServiceFeeAdjAmount { get; set; }
        [DataMember]
        public DateTime? InvoicedDate { get; set; }
        [DataMember]
        public DateTime? AdjustmentDate { get; set; }
        [DataMember]
        public string Comments { get; set; }
        [DataMember]
        public string RecType { get; set; }
        [DataMember]
        public int RecordNumber { get; set; }

        [DataMember]
        public string InvoiceNumber { get; set; }

        [DataMember]
        public bool IsApInvoiced { get; set; }

        [DataMember]
        public string Version { get; set; }

        [DataMember]
        public decimal? VwoPenalty { get; set; }

    }

    [Serializable]
    [DataContract(Namespace = "http://www.bkfs.com/FS/DataContract/Vendor/1.00")]
    [AutoGenMap]
    public partial class FlatFeeAdjustmentDetail : BaseDto
    {
        [DataMember]
        [AutoGenMapProp(IsAutoMap = true, IsAutoMapId = true)]
        public int? AdjustmentDetailHistoryId { get; set; }
        [DataMember]
        public int? OrderHierarchyId { get; set; }
        [DataMember]
        public decimal? FlatFeeAmount { get; set; }
        [DataMember]
        public decimal? FlatFeeAdjAmount { get; set; }
        [DataMember]
        public DateTime? AdjustmentDate { get; set; }
        [DataMember]
        public string Comments { get; set; }
        [DataMember]
        public string RecType { get; set; }
        [DataMember]
        public int? RecordNumber { get; set; }

        [DataMember]
        public decimal? ClientPrice { get; set; }

        [DataMember]
        public decimal? ClientPriceAdjstdAmt { get; set; }

        [DataMember]
        public DateTime? ArInvoiceDate { get; set; }

        [DataMember]
        public string ArInvoiceNumber { get; set; }

        [DataMember]
        public int? ArRecordNumber { get; set; }

        [DataMember]
        public int? DisputeReceivableAdjustmentHistoryId { get; set; }

        [DataMember]
        public DateTime? InvoicedDate { get; set; }

        [DataMember]
        public string ApInvoiceNumber { get; set; }


        [DataMember]
        public bool IsApInvoiced { get; set; }

        [DataMember]
        public bool IsArInvoiced { get; set; }

        [DataMember]
        public int? VendorId { get; set; }

        [DataMember]
        public bool IsAPAdjusted { get; set; }

        [DataMember]
        public bool IsARAdjusted { get; set; }

        [DataMember]
        public string ApVersion { get; set; }


        [DataMember]
        public string ArVersion { get; set; }

    }

    [Serializable]
    [DataContract(Namespace = "http://www.bkfs.com/FS/DataContract/Vendor/1.00")]
    [AutoGenMap]
    public partial class DiscountAdjustmentDetail : BaseDto
    {
        [DataMember]
        [AutoGenMapProp(IsAutoMap = true, IsAutoMapId = true)]
        public int? AdjustmentDetailHistoryId { get; set; }
        [DataMember]
        public int? OrderHierarchyId { get; set; }
        [DataMember]
        public decimal? DiscountPercent { get; set; }
        [DataMember]
        public decimal? DiscountPercentAdjsted { get; set; }
        [DataMember]
        public DateTime? AdjustmentDate { get; set; }
        [DataMember]
        public string Comments { get; set; }
        [DataMember]
        public string SupplierComment { get; set; }
      
        [DataMember]
        public string RecType { get; set; }
        [DataMember]
        public int? RecordNumber { get; set; }

        [DataMember]
        public string ApInvoiceNumber { get; set; }

        [DataMember]
        public DateTime? InvoicedDate { get; set; }

        [DataMember]
        public bool IsApInvoiced { get; set; }

        [DataMember]
        public int? VendorId { get; set; }

        [DataMember]
        public string ApVersion { get; set; }
        
    }

 

    [Serializable]
    [DataContract(Namespace = "http://www.bkfs.com/FS/DataContract/Vendor/1.00")]
    [AutoGenMap]
    public partial class LineItemAdjustmentDetail : BaseDto
    {
        [DataMember]
        [AutoGenMapProp(IsAutoMap = true, IsAutoMapId = true)]
        public int? AdjustmentDetailHistoryId { get; set; }

        [DataMember]
        public int? ARAdjustmentDetailHistoryId { get; set; }

        [DataMember]
        public int? OrderHierarchyId { get; set; }

        [DataMember]
        public string LineItemDescription { get; set; }

        [DataMember]
        public int? Quantity { get; set; }

        [DataMember]
        public string UnitOfMeasure { get; set; }

        [DataMember]
        public decimal? VendorUnitCost { get; set; }

        [DataMember]
        public decimal? VendorFee { get; set; }

        [DataMember]
        public decimal? VendorFeeAfterDiscount { get; set; }

        [DataMember]
        public decimal? ClientUnitPrice { get; set; }

        [DataMember]
        public decimal? ClientPrice { get; set; }

        [DataMember]
        public decimal? TaxAmount { get; set; }

        [DataMember]
        public DateTime? InvoicedDate { get; set; }

        [DataMember]
        public string Comments { get; set; }

        [DataMember]
        public string SupplierComment { get; set; }

        [DataMember]
        public string RecType { get; set; }

        [DataMember]
        public string ArRecType { get; set; }

        [DataMember]
        public int? WorkOrderLineItemId { get; set; }

        [DataMember]
        public int? APRecordNumber { get; set; }

        [DataMember]
        public int? ARRecordNumber { get; set; }

        [DataMember]
        public int RecordNumber { get; set; }

        [DataMember]
        public string ApRecType { get; set; }

        [DataMember]
        public decimal? VendorFeeAdjAmt { get; set; }

        [DataMember]
        public decimal? ClientPriceAdjAmt { get; set; }

        [DataMember]
        public DateTime? AdjustmentDate { get; set; }

        [DataMember]
        public string ArInvoiceNumber { get; set; }

        [DataMember]
        public string ApInvoiceNumber { get; set; }

        [DataMember]
         public DateTime? ApInvoicedDate { get; set; }

        [DataMember]
        public bool IsApInvoiced { get; set; }

        [DataMember]
        public bool IsArInvoiced { get; set; }

        [DataMember]
        public int? VendorId { get; set; }

        [DataMember]
        public int? PerformedQuantity { get; set; }

        [DataMember]
        public bool IsAPAdjusted { get; set; }

        [DataMember]
        public bool IsARAdjusted { get; set; }

        [DataMember]
        public string ApVersion { get; set; }

        [DataMember]
        public string ArVersion { get; set; }

    }

    [Serializable]
    [DataContract(Namespace = "http://www.bkfs.com/FS/DataContract/Vendor/1.00")]
    public class ClientFeeAdjustmentResponse
    {
        [DataMember]
        public bool? IsAdjusted { get; set; }
        [DataMember]
        public int? OrderNumber { get; set; }
        [DataMember]
        public string ARInvoiceNumber { get; set; }
        [DataMember]
        public decimal? ClientTripFee { get; set; }
        [DataMember]
        public decimal? ClientTripFeeAdj { get; set; }
        [DataMember]
        public decimal? TaxAmountForClientTripFee { get; set; }
        [DataMember]
        public decimal? RushFee { get; set; }
        [DataMember]
        public decimal? TaxAmountForRushFee { get; set; }
        [DataMember]
        public DateTime? InvoiceDate { get; set; }
        [DataMember]
        public DateTime? AdjustmentDate { get; set; }
        [DataMember]
        public string Comments { get; set; }
    }

    [Serializable]
    [DataContract(Namespace = "http://www.bkfs.com/FS/DataContract/Vendor/1.00")]
    public class VendorFeeAdjustmentResponse
    {
        [DataMember]
        public bool? IsAdjusted { get; set; }
        [DataMember]
        public int? VendorWorkOrderNumber { get; set; }
        [DataMember]
        public int? VendorId { get; set; }
        [DataMember]
        public decimal? OneTimeFee { get; set; }
        [DataMember]
        public decimal? OneTimeFeeAdj { get; set; }
        [DataMember]
        public decimal? TripFeeAfterDisc { get; set; }
        [DataMember]
        public decimal? TripFeeAdj { get; set; }
        [DataMember]
        public decimal? MinServiceFeeAfterDisc { get; set; }
        [DataMember]
        public decimal? MinServiceFeeAdj { get; set; }
        [DataMember]
        public DateTime? InvoiceDate { get; set; }
        [DataMember]
        public DateTime? AdjustmentDate { get; set; }
        [DataMember]
        public string Comments { get; set; }
    }

    [Serializable]
    [DataContract(Namespace = "http://www.bkfs.com/FS/DataContract/Vendor/1.00")]
    public class ProductServiceAdjustmentResponse
    {
        [DataMember]
        public int? OrderId { get; set; }
        [DataMember]
        public int? WorkOrderId { get; set; }
        [DataMember]
        public int? VendorWorkOrderId { get; set; }
        [DataMember]
        public int? WorkOrderItemId { get; set; }
        [DataMember]
        public string Product { get; set; }
        [DataMember]
        public string Service { get; set; }
        [DataMember]
        public string Cost { get; set; }
        [DataMember]
        public string Discount { get; set; }
        [DataMember]
        public decimal? DiscountAmt { get; set; }
        [DataMember]
        public decimal? CostAfterDiscount { get; set; }
        [DataMember]
        public string ClientBilling { get; set; }
        [DataMember]
        public decimal? ClientPrice { get; set; }
        [DataMember]
        public bool? IsARAdjusted { get; set; }
        [DataMember]
        public bool? IsAPAdjusted { get; set; }
        [DataMember]
        public string ArInvoiceNumber { get; set; }
        [DataMember]
        public decimal? TaxAmount { get; set; }
        [DataMember]
        public DateTime? invoicedDate { get; set; }
        [DataMember]
        public int? OrderHierarchyId { get; set; }
        [DataMember]
        public int? AdjustmentHistoryPayableId { get; set; }
        [DataMember]
        public int? AdjustmentHistoryReceivableId { get; set; }
        [DataMember]
        public string RecType { get; set; }

        [DataMember]
        public string ProductCode { get; set; }

        [DataMember]
        public string ApInvoiceNumber { get; set; }

        [DataMember]
        public DateTime? ApInvoiceDate { get; set; }

        [DataMember]
        public bool IsApInvoiced { get; set; }

        [DataMember]
        public bool IsArInvoiced { get; set; }

        [DataMember]
        public int? VendorId { get; set; }

        [DataMember]
        public bool? IsServiceLevelBilling { get; set; }

        [DataMember]
        public decimal? PenaltyIncentive { get; set; }

        [DataMember]
        public decimal? CostAfterPI { get; set; }
    }

    [Serializable]
    [DataContract(Namespace = "http://www.bkfs.com/FS/DataContract/Vendor/1.00")]
    public class CronologicalAdjustmentListResponse : BaseResponseDto
    {
        [DataMember]
        public string AdjustedCategory { get; set; }
        [DataMember]
        public decimal? StartingAmount { get; set; }
        [DataMember]
        public decimal? AdjustmentAmount { get; set; }
        [DataMember]
        public decimal? EndingAmount { get; set; }

        [DataMember]
        public decimal? EndingTax { get; set; }
        [DataMember]
        public string AdjustmentInvoiceNumber { get; set; }
        [DataMember]
        public int? OderNumber { get; set; }
        [DataMember]
        public int? VendorWorkOrderNumber { get; set; }
        [DataMember]
        public int? VendorId { get; set; }
        [DataMember]
        public string Product { get; set; }
        [DataMember]
        public string Service { get; set; }
        [DataMember]
        public string ServiceItem { get; set; }
        [DataMember]
        public string Feetype { get; set; }
        [DataMember]
        public string AdjustedBy { get; set; }
        [DataMember]
        public DateTime? AdjustmentDate { get; set; }
        [DataMember]
        public DateTime? SentToOracleDate { get; set; }

        [DataMember]
        public string RecordNumber { get; set; }
    }

    [DataContract]
    public class OrderTotal
    {
        [DataMember]
        public decimal? VendorFee { get; set; }

        [DataMember]
        public decimal? VendorFinalFee { get; set; }

        [DataMember]
        public decimal? ClientPrice { get; set; }

        [DataMember]
        public decimal? Penalties { get; set; }
    }
}
