﻿using CommonLib.DataObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using CommonLib.ModelAttrib;

namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{
    [DataContract(Namespace = "http://www.bkfs.com/FS/DataContract/Accounting/1.00")]
    [Serializable]
    [AutoGenMap]
    [KnownTypeAttribute(typeof(BaseDto))]
    public partial class Product : BaseDto
    {
        public Product()
        {
            ProductServices = new HashSet<ProductService>();
        }
        [DataMember]
        [AutoGenMapProp(IsAutoMap = true, IsAutoMapId = true)]
        public int ProductId { get; set; }

        [DataMember]
        public int ApplicationId { get; set; }

        [DataMember]
        public string ProductCode { get; set; }

        [DataMember]
        public string ProductName { get; set; }

        [DataMember]
        public string ProductDesc { get; set; }

        [DataMember]
        public string Instructions { get; set; }

        [DataMember]
        public string ProductCategoryGroup { get; set; }

        [DataMember]
        public string ProductCategory { get; set; }

        [DataMember]
        public bool IsBundle { get; set; }

        [DataMember]
        public bool IsInternal { get; set; }

        [DataMember]
        public bool IsSeasonal { get; set; }

        [DataMember]
        public bool IsRecurring { get; set; }

        [DataMember]
        public bool IsAutoAssign { get; set; }

        [DataMember]
        public bool IsActive { get; set; }

        [DataMember]
        public bool IsFeeBased { get; set; }

        [DateTimeBoth]
        [DataMember]
        public DateTime? ActiveChangedDate { get; set; }

        [DataMember]
        public int? ActiveChangedById { get; set; }

        [DataMember]
        public bool IsAssignable { get; set; }

        [DataMember]
        public int CreatedById { get; set; }

        [DateTimeBoth]
        [DataMember]
        public DateTime CreatedDate { get; set; }

        [DataMember]
        public int? LastUpdatedById { get; set; }

        [DateTimeBoth]
        [DataMember]
        public DateTime? LastUpdatedDate { get; set; }

        [DataMember]
        public string Version { get; set; }

        [DataMember]
        public virtual ICollection<ProductService> ProductServices { get; set; }
    }
}
