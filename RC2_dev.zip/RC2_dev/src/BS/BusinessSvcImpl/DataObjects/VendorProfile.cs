﻿using CommonLib.DataObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using CommonLib.ModelAttrib;

namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{
    [DataContract(Namespace = "http://www.bkfs.com/FS/DataContract/Accounting/1.00")]
    [Serializable]
    [AutoGenMap]
    [KnownTypeAttribute(typeof(BaseDto))]
   public partial class VendorProfile : BaseRequestDto
    {
        public VendorProfile()
        {
            WorkOrders = new HashSet<WorkOrder>();
        }
        [DataMember]
        [AutoGenMapProp(IsAutoMap = true, IsAutoMapId = true)]
        public int VendorProfileId { get; set; }
        [DataMember]
        public int ApplicationId { get; set; }

        [DataMember]
        public string VendorName { get; set; }

        [DataMember]
        public string AddressLine1 { get; set; }

        [DataMember]
        public string AddressLine2 { get; set; }

        [DataMember]
        public string CityName { get; set; }

        [DataMember]
        public string StateCode { get; set; }

        [DataMember]
        public string ZipCode { get; set; }

        [DataMember]
        public string CountyName { get; set; }

        [DataMember]
        public string Phone { get; set; }

        [DataMember]
        public string PhoneExtension { get; set; }

        [DataMember]
        public string Fax { get; set; }

        [DataMember]
        public string Website { get; set; }

        [DataMember]
        public string BusinessHours { get; set; }

        [DataMember]
        public string VendorTypeGroup { get; set; }

        [DataMember]
        public string VendorType { get; set; }

        [DataMember]
        public string VendorStatusGroup { get; set; }

        [DataMember]
        public string VendorStatusType { get; set; }

        [DataMember]
        public string OnHoldReasonGroup { get; set; }

        [DataMember]
        public string OnHoldReasonType { get; set; }

        [DataMember]
        public string TerminationReason { get; set; }

        [DataMember]
        public string CredentialingId { get; set; }

        [DataMember]
        public string CredentialingStatusGroup { get; set; }

        [DataMember]
        public string CredentialingStatusType { get; set; }

        [DataMember]
        public string ComplianceGroup { get; set; }

        [DataMember]
        public string ComplianceType { get; set; }

        [DataMember]
        public string PrimaryContactFirst { get; set; }

        [DataMember]
        public string PrimaryContactLast { get; set; }

        [DataMember]
        public string PrimaryContactEmail { get; set; }

        [DataMember]
        public string ContactTypeGroup { get; set; }

        [DataMember]
        public string ContactType { get; set; }
        [DataMember]
        public bool IsOwnerCitizen { get; set; }
        [DataMember]
        public bool IsVMOFormOnFile { get; set; }

        [DataMember]
        public string CloudServiceProvider { get; set; }

        [DataMember]
        public string AlsoKnownAs { get; set; }
        [DataMember]
        public int? OfficeFTE { get; set; }
        [DataMember]
        public int? FieldFTE { get; set; }
        [DataMember]
        public int? FieldSubs { get; set; }

        [DataMember]
        public DateTime? OnLeaveStartDate { get; set; }

        [DataMember]
        public DateTime? OnLeaveEndDate { get; set; }

        [DataMember]
        public string OnLeaveReasonGroup { get; set; }

        [DataMember]
        public string OnLeaveReason { get; set; }
        [DataMember]
        public decimal? OverallScore { get; set; }
        [DataMember]
        public bool IsAutoAssign { get; set; }
        [DataMember]
        public bool IsAutoAccept { get; set; }
        [DataMember]
        public int CreatedById { get; set; }

        [DataMember]
        public DateTime CreatedDate { get; set; }
        [DataMember]
        public int? LastUpdatedById { get; set; }

        [DataMember]
        public DateTime? LastUpdatedDate { get; set; }

        [DataMember]
        public string Version { get; set; }
        [DataMember]

        public virtual ICollection<WorkOrder> WorkOrders { get; set; }
    }
}
