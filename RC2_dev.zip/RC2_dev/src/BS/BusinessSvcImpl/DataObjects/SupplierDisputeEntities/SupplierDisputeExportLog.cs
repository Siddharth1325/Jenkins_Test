﻿using System;
using System.Collections.Generic;
using System.Linq;
using CommonLib.DataObjects;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using CommonLib.ModelAttrib;
using BusinessSvcImpl.DataObjects.SpaAccounting.Dto;

namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{
    [DataContract(Namespace = "http://www.bkfs.com/FS/DataContract/Accounting/1.00")]
    [Serializable]
    [AutoGenMap]
    [KnownTypeAttribute(typeof(BaseDto))]
    public partial class SupplierDisputeExportLog : BaseDto
    {
        [AutoGenMapProp(IsAutoMap = true, IsAutoMapId = true)]
        [DataMember]
        public string FieldScapeWO { get; set; }
        [DataMember]
        public string AssetShieldInspectionWO { get; set; }
        [DataMember]
        public string AssetShieldPreservationVendorWO { get; set; }
        [DataMember]
        public string DisputedAmount { get; set; }
        [DataMember]
        public string DisputeReason { get; set; }
        [DataMember]
        public string DisputeComments { get; set; }
        [DataMember]
        public string Result { get; set; }
        [DataMember]
        public string Message { get; set; }
    }
}
