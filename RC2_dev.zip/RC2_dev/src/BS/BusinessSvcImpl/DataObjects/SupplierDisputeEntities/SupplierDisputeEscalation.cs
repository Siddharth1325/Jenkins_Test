﻿namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{
    using CommonLib.DataObjects;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using System.Text;
    using CommonLib.ModelAttrib;

    [DataContract(Namespace = "http://www.bkfs.com/FS/DataContract/Accounting/1.00")]
    [Serializable]
    [AutoGenMap]
    [KnownTypeAttribute(typeof(BaseDto))]
    public partial class SupplierDisputeEscalation : BaseDto
    {
        [DataMember]
        [AutoGenMapProp(IsAutoMap = true, IsAutoMapId = true)]
        public int SupplierDisputeEscalationId { get; set; }
        [DataMember]
        public int SupplierDisputeId { get; set; }
        [DataMember]
        public string EscalationDisputeStatusGroup { get; set; }
        [DataMember]
        public string EscalationDisputeStatusType { get; set; }
        [DataMember]
        public int? AssignedToUserId { get; set; }
        [DataMember]
        public DateTime? EscalationAssignDate { get; set; }
        [DataMember]
        public DateTime? EscalationCompleteDate { get; set; }
        [DataMember]
        public string EscalationResolutionStatusGroup { get; set; }
        [DataMember]
        public string EscalationResolutionStatusType { get; set; }
        [DataMember]
        public string EscalationComments { get; set; }
        [DataMember]
        public string SLFSEscalationComments { get; set; }
        [DataMember]
        public bool EscalatedByVendor { get; set; }

        [DataMember]
        public DateTime? EscalationDueDate { get; set; }
        

        [DataMember]
        public int CreatedById { get; set; }
        [DataMember]
        public DateTime CreatedDate { get; set; }
        [DataMember]
        public int? LastUpdatedById { get; set; }

        [DataMember]
        public DateTime? LastUpdatedDate { get; set; }

        [DataMember]
        public string Version { get; set; }
        [MapIgnoreProp]
        [DataMember]
        public virtual bool Modified { get; set; }
    }
}
