namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{
    using CommonLib.DataObjects;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using System.Text;
    using CommonLib.ModelAttrib;

    [DataContract(Namespace = "http://www.bkfs.com/FS/DataContract/Accounting/1.00")]
    [Serializable]
    [AutoGenMap]
    [KnownTypeAttribute(typeof(BaseDto))]
    public partial class SupplierDisputeDocument : BaseDto
    {
        [DataMember]
        [AutoGenMapProp(IsAutoMap = true, IsAutoMapId = true)]
        public int SupplierDisputeDocumentId { get; set; }
        [DataMember]
        public int DocumentId { get; set; }
        [DataMember]
        public int SupplierDisputeId { get; set; }
        [DataMember]
        public string AdditionalDocumentGroup { get; set; }
        [DataMember]
        public string AdditionalDocumentType { get; set; }

         [DataMember]
        public bool VisibleToVendor { get; set; }

        [DataMember]
        public int CreatedById { get; set; }
        [DataMember]
        public DateTime CreatedDate { get; set; }
        [DataMember]
        public int? LastUpdatedById { get; set; }
        [DataMember]
        public DateTime? LastUpdatedDate { get; set; }
       
        [DataMember]
        public string DocumentName { get; set; }


        [DataMember]
        public string LastUpdatedByName { get; set; }
        
        [DataMember]
        public string AdditionalDocType { get; set; }

        [DataMember]
        public string AdditionalDocTypeName { get; set; }
        public string Version { get; set; }
    }
}
