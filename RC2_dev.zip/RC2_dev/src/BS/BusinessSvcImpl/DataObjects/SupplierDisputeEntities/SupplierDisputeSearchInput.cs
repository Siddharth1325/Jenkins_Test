﻿using System;
using System.Collections.Generic;
using System.Linq;
using CommonLib.DataObjects;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using CommonLib.ModelAttrib;
using BusinessSvcImpl.DataObjects.SpaAccounting.Dto;

namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{
    [DataContract(Namespace = "http://www.bkfs.com/FS/DataContract/Accounting/1.00")]
    [Serializable]
    [AutoGenMap]
    [KnownTypeAttribute(typeof(BaseDto))]
    public partial class SupplierDisputeSearchInput : BaseDto
    {
        [DataMember]
        public int? VendorId { get; set; }
        [DataMember]
        public int? AssignUserId { get; set; }
        [DataMember]
        public int? BulkId { get; set; }
        [DataMember]
        public List<string> State { get; set; }
        [DataMember]
        public int? FieldScapeWorkOrderId { get; set; }
        [DataMember]
        public int? VendorWorkOrderId { get; set; }
        [DataMember]
        public int? InspWorkOrderId { get; set; }
        [DataMember]
        public List<string> DisputeStatusType { get; set; }
        [DataMember]
        public DateTime? DisputeSubmittedFromDate { get; set; }
        [DataMember]
        public DateTime? DisputeSubmittedToDate { get; set; }
        [DataMember]
        public DateTime? DisputeDueDateFrom { get; set; }
        [DataMember]
        public DateTime? DisputeDueDateTo { get; set; }
        [DataMember]
        public List<string> EscalationResolution { get; set; }
        [DataMember]
        public DateTime? EscalationResolutionFromDate { get; set; }
        [DataMember]
        public DateTime? EscalationResolutionToDate { get; set; }
    }
}
