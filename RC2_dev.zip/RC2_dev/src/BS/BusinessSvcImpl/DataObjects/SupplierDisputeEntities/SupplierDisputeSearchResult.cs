﻿using System;
using System.Collections.Generic;
using System.Linq;
using CommonLib.DataObjects;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using CommonLib.ModelAttrib;
using BusinessSvcImpl.DataObjects.SpaAccounting.Dto;




namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{
    [DataContract(Namespace = "http://www.bkfs.com/FS/DataContract/Accounting/1.00")]
    [Serializable]
    [AutoGenMap]
    [KnownTypeAttribute(typeof(BaseDto))]
    public partial class SupplierDisputeSearchResult : BaseDto
    {
        [AutoGenMapProp(IsAutoMap = true, IsAutoMapId = true)]
        [DataMember]
        public int SupplierDisputeId { get; set; }
        [DataMember]
        public int BulkId { get; set; }
        [DataMember]
        public int VendorId { get; set; }
        [DataMember]
        public int? FieldScapeWorkOrderId { get; set; }
        [DataMember]
        public int? InspWorkOrderId { get; set; }
        [DataMember]
        public int? VendorWorkOrderId { get; set; }
        [DataMember]
        public DateTime? DisputeDate { get; set; }
        [DataMember]
        public DateTime? DisputeDueDate { get; set; }
        [DataMember]
        public string DisputeStatus { get; set; }
        [DataMember]
        public string DisputeStatusType { get; set; }
        [DataMember]
        public string EscalationResolutionStatusType { get; set; }
        [DataMember]
        public string EscalationResolutionStatus { get; set; }
        [DataMember]
        public DateTime? EscalationDueDate { get; set; }
        [DataMember]
        public decimal? AdditionalAmtApproved { get; set; }
        [DataMember]
        public string DisputeReason { get; set; }
        [DataMember]
        public string VendorDisputeComments { get; set; }
        [DataMember]
        public string DisputeResolutionType { get; set; }
        [DataMember]
        public string DisputeResolution { get; set; }
        [DataMember]
        public DateTime? DisputeCompletedDate { get; set; }
        [DataMember]
        public string SLFSResponseToVendor { get; set; }
        [DataMember]
        public DateTime? EscalationCompleteDate { get; set; }
        [DataMember]
        public string EscalationComments { get; set; }
        [DataMember]
        public DateTime? EscalationDate { get; set; }
        [DataMember]
        public string SLFSResponseToEscalation { get; set; }

        [DataMember]
        public bool EscalatedByVendor { get; set; }

        [DataMember]
        public string VendorName { get; set; }
        [DataMember]
        public string PropertyAddress
        {
            get;
            set;
        }
        [DataMember]
        public string PropertyAddress1 { get; set; }
        [DataMember]
        public string PropertyAddress2 { get; set; }
        [DataMember]
        public string PropertyCity { get; set; }
        [DataMember]
        public string PropertyState { get; set; }
        [DataMember]
        public string PropertyZip { get; set; }
        [DataMember]
        public string ProductName { get; set; }
        [DataMember]
        public string ClientNumber { get; set; }
        [DataMember]
        public decimal? DisputeAmount { get; set; }
        [DataMember]
        public string Decision { get; set; }
        [DataMember]
        public string Resolution { get; set; }
        [DataMember]
        public string EscalationDecision { get; set; }
        [DataMember]
        public string SLFSEscalationComments { get; set; }
        
    }
}
