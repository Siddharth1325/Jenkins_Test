﻿namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{
    using CommonLib.DataObjects;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using System.Text;
    using CommonLib.ModelAttrib;

    [DataContract(Namespace = "http://www.bkfs.com/FS/DataContract/Accounting/1.00")]
    [Serializable]
    [AutoGenMap]
    [KnownTypeAttribute(typeof(BaseDto))]
    public partial class SupplierDispute : BaseDto
    {
        [DataMember]
        [AutoGenMapProp(IsAutoMap = true, IsAutoMapId = true)]
        public int SupplierDisputeId { get; set; }
        [DataMember]

        public int? FieldScapeWorkOrderId { get; set; }
        [DataMember]

        public int? VendorWorkOrderId { get; set; }
        [DataMember]

        public int? InspWorkOrderId { get; set; }
        [DataMember]

        public int BulkId { get; set; }
        [DataMember]

        public string VendorDisputeComments { get; set; }
        [DataMember]

        public string SLFSResponseToVendor { get; set; }
        [DataMember]

        public string VendorEscalationComments { get; set; }
        [DataMember]

        public string SLFSResponseToEscalation { get; set; }
        [DataMember]

        public string DisputeStatusGroup { get; set; }
        [DataMember]

        public string DisputeStatusType { get; set; }
        [DataMember]

        public string DisputeResolutionGroup { get; set; }
        [DataMember]

        public string DisputeResolutionType { get; set; }
        [DataMember]

        public DateTime? DisputeCompleteDate { get; set; }
        [DataMember]

        public string ResponsibleDepartmentGroup { get; set; }

        [DataMember]

        public string ResponsibleDepartmentType { get; set; }
        [DataMember]

        public string DisputeGroup { get; set; }

        [DataMember]

        public string DisputeType { get; set; }
        [DataMember]

        public int? DisputeErrorCausedById { get; set; }

        [DataMember]

        public decimal? CreditVendorAmount { get; set; }
        [DataMember]

        public decimal? DebitVendorAmount { get; set; }
        [DataMember]

        public decimal? DisputeAmount { get; set; }
        [DataMember]

        public string RebillNumber { get; set; }
        [DataMember]

        public decimal? HardLossAmount { get; set; }
        [DataMember]

        public string DisputeErrorGroup { get; set; }

        [DataMember]

        public string DisputeErrorType { get; set; }
        [DataMember]

        public int? ApprovedById { get; set; }
        [DataMember]
        public int? DisputecompletedById { get; set; }
        [DataMember]
        public int? VendorId { get; set; }
        [DataMember]

        public int CreatedById { get; set; }
        [DataMember]

        public DateTime CreatedDate { get; set; }
        [DataMember]

        public int? LastUpdatedById { get; set; }
        [DataMember]

        public DateTime? LastUpdatedDate { get; set; }
        [DataMember]

        public string Version { get; set; }

        [DataMember]
        public int? AssignUserId { get; set; }

        [DataMember]
        public string DisputeReasonType { get; set; }

        [DataMember]
        public string DisputeReasonGroup { get; set; }
        
        [DataMember]
        public string DisputeCompleteBy { get; set; }

        [DataMember]
        public bool EscalatedByVendor { get; set; }

    }
}
