namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{
    using CommonLib.DataObjects;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using System.Text;
    using CommonLib.ModelAttrib;

    [DataContract(Namespace = "http://www.bkfs.com/FS/DataContract/Accounting/1.00")]
    [Serializable]
    [AutoGenMap]
    [KnownTypeAttribute(typeof(BaseDto))]
    public partial class SupplierDisputeFollowup : BaseDto
    {
        [DataMember]
        [AutoGenMapProp(IsAutoMap = true, IsAutoMapId = true)]
        public int SupplierDisputeFollowupId { get; set; }
        [DataMember]
        public int SupplierDisputeId { get; set; }
        [DataMember]
        public string FollowupStatusGroup { get; set; }
        [DataMember]
        public string FollowupStatusType { get; set; }
        [DataMember]
        public int? AssignedToUserId { get; set; }
        [DataMember]
        public DateTime? FollowupAssignDate { get; set; }
        [DataMember]
        public DateTime? FollowupCompleteDate { get; set; }
        [DataMember]
        public string FollowupResolutionStatusGroup { get; set; }
        [DataMember]
        public string FollowupResolutionStatusType { get; set; }
        [DataMember]
        public int CreatedById { get; set; }
        [DataMember]
        public DateTime CreatedDate { get; set; }
        [DataMember]
        public int? LastUpdatedById { get; set; }
        [DataMember]
        public DateTime? LastUpdatedDate { get; set; }
        [DataMember]
        public string Version { get; set; }
        [MapIgnoreProp]
        [DataMember]
        public virtual bool Modified { get; set; }


        [MapIgnoreProp]
        [DataMember]
        public string AssignedToName { get; set; }

        [MapIgnoreProp]
        [DataMember]
        public string FollowUpResearchTypeName { get; set; }

        [MapIgnoreProp]
        [DataMember]
        public string FollowUpStatusElementName { get; set; }
    }
}
