﻿using BusinessSvcImpl.DataObjects.SpaAccounting.Dto;
using CommonLib.DataObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace BusinessSvcImpl.DataObjects.SpaAccountingService.Dto
{

    [DataContract(Namespace = "http://www.bkfs.com/FS/DataContract/Accounting/1.00")]
    [Serializable]

    public class GetInvoiceDecisionSearchRequest : BaseRequestDto
    {
        [DataMember]
        public InvoiceDecisionSearchInput SearchInput { get; set; }

        [DataMember]
        public int? SkipCount { get; set; }

        [DataMember]
        public int? PageSize { get; set; }

        [DataMember]
        public int? PageNumber { get; set; }


    }
    public class GetInvoiceDecisionSearchResponse : BaseResponseDto
    {
        [DataMember]
        public List<InvoiceDecisionSearchResult> SearchResults { get; set; }

        [DataMember]
        public int? TotalCount { get; set; }
    }

    public class UpdateRRRHeaderInternalStatusResponse : BaseResponseDto
    {
        [DataMember]
        public bool IsInternalStatusSaved { get; set; }
    }

    public class UpdateRRRHeaderInternalStatusRequest : BaseRequestDto
    {
        [DataMember]
        public int RRRInvoiceHeaderJsonId { get; set; }
        [DataMember]
        public string InternalStatus { get; set; }
    }
}
