﻿using BusinessSvcImpl.DataObjects.SpaAccounting.Dto;
using CommonLib.DataObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace BusinessSvcImpl.DataObjects.SpaAccountingService.Dto
{

    [DataContract(Namespace = "http://www.bkfs.com/FS/DataContract/Accounting/1.00")]
    [Serializable]

    public class GetDisputeSearchRequest : BaseRequestDto
    {
        [DataMember]
        public DisputeSearchInput SearchInput { get; set; }

        [DataMember]
        public int? SkipCount { get; set; }

        [DataMember]
        public int? PageSize { get; set; }

        [DataMember]
        public int? PageNumber { get; set; }


    }
    public class GetDisputeSearchResponse : BaseResponseDto
    {
        [DataMember]
        public List<DisputeSearchResult> SearchResults { get; set; }
       
        [DataMember]
        public int? TotalCount { get; set; }
    }


    public class GetAccountingDisputeResponse : BaseResponseDto
    {
        [DataMember]
        public AccountingDispute AccountingDispute { get; set; }
    }


    public class SaveAccountingDisputeResponse : BaseResponseDto
    {
        [DataMember]
        public AccountingDispute AccountingDispute { get; set; }
    }

    public class SaveAccountingDisputeRequest : BaseRequestDto
    {
        [DataMember]
        public AccountingDispute AccountingDispute { get; set; }
    }


    public class SaveDisputeFollowupResponse : BaseResponseDto
    {
        [DataMember]
        public List<DisputeFollowup> DisputeFollowup { get; set; }
    }

    public class GetDisputeFollowupResponse : BaseResponseDto
    {
        [DataMember]
        public List<DisputeFollowup> DisputeFollowups { get; set; }
    }


    public class SaveDisputeFollowupRequest : BaseRequestDto
    {
        [DataMember]
        public List<DisputeFollowup> DisputeFollowup { get; set; }
    }



    public class SaveVendorDisputeCommentsResponse : BaseResponseDto
    {
        [DataMember]
        public List<VendorDisputeComment> VendorDisputeComments { get; set; }
    }


    public class SaveVendorDisputeCommentsRequest : BaseRequestDto
    {
        [DataMember]
        public List<VendorDisputeComment> VendorDisputeComments { get; set; }

        [DataMember]
        public List<VendorDisputeComment> DeleteVendorComments { get; set; }

    }


    public class GetVendorDisputeCommentsResponse : BaseResponseDto
    {
        [DataMember]
        public List<VendorDisputeComment> VendorDisputeComments { get; set; }
    }

    public class SaveDisputeDocumentResponse : BaseResponseDto
    {
        [DataMember]
        public List<DisputeDocument> DisputeDocument { get; set; }
    }

    public class SaveDisputeDocumentRequest : BaseRequestDto
    {
        [DataMember]
        public DisputeDocument DisputeDocument { get; set; }
    }

    public class GetDisputeDocumentResponse : BaseResponseDto
    {
        [DataMember]
        public List<DisputeDocument> DisputeDocuments { get; set; }
    }

    [DataContract(Namespace = "http://www.bkfs.com/FS/DataContract/Accounting/1.00")]
    [Serializable]
    public class GetSupplierDisputeExportLogRequest : BaseRequestDto
    {
        [DataMember]
        public SupplierDisputeExportLogInput SearchInput { get; set; }

        [DataMember]
        public int? SkipCount { get; set; }

        [DataMember]
        public int? PageSize { get; set; }

        [DataMember]
        public int? PageNumber { get; set; }
    }

    [DataContract(Namespace = "http://www.bkfs.com/FS/DataContract/Accounting/1.00")]
    [Serializable]
    public class SupplierDisputeExportLogInput
    {
        [DataMember]
        public string BulkId { get; set; }
    }

    [DataContract(Namespace = "http://www.bkfs.com/FS/DataContract/Accounting/1.00")]
    [Serializable]

    public class GetSupplierDisputeSearchRequest : BaseRequestDto
    {
        [DataMember]
        public SupplierDisputeSearchInput SearchInput { get; set; }

        [DataMember]
        public int? SkipCount { get; set; }

        [DataMember]
        public int? PageSize { get; set; }

        [DataMember]
        public int? PageNumber { get; set; }


    }
    [DataContract(Namespace = "http://www.bkfs.com/FS/DataContract/Accounting/1.00")]
    [Serializable]
    public class GetSupplierDisputeSearchResponse : BaseResponseDto
    {
        [DataMember]
        public List<SupplierDisputeSearchResult> SearchResults { get; set; }

        [DataMember]
        public int? TotalCount { get; set; }
    }

    [DataContract(Namespace = "http://www.bkfs.com/FS/DataContract/Accounting/1.00")]
    [Serializable]
    public class GetSupplierDisputeExportLogResponse : BaseResponseDto
    {
        [DataMember]
        public List<SupplierDisputeExportLog> SearchResults { get; set; }

        [DataMember]
        public int? TotalCount { get; set; }
    }
    [DataContract(Namespace = "http://www.bkfs.com/FS/DataContract/Accounting/1.00")]
    [Serializable]
    public class GetSupplierConfigurationBulkFileResponse : BaseResponseDto
    {
        [DataMember]
        public List<SupplierConfigurationBulkFile> supplierConfigurationBulkFiles { get; set; }

        [DataMember]
        public int? TotalCount { get; set; }
    }
    [DataContract(Namespace = "http://www.bkfs.com/FS/DataContract/Accounting/1.00")]
    [Serializable]
    public class GetSupplierConfigurationBulkFilesRequest : BaseResponseDto
    {
        [DataMember]
        public int SupplierId { get; set; }
        [DataMember]
        public DateTime? DateFrom { get; set; }
        [DataMember]
        public DateTime? DateTo { get; set; }
    }

    [DataContract]
    public class SaveSupplierDisputeResponse : BaseResponseDto
    {
        [DataMember]
        public bool Result { get; set; }
    }
    [DataContract]
    public class SaveSupplierDisputeRequest : BaseRequestDto
    {
        [DataMember]
        public SupplierDispute SupplierDispute { get; set; }
    }
    //[DataContract(Namespace = "http://www.bkfs.com/FS/DataContract/Accounting/1.00")]
    [DataContract]
    public class GetSupplierDisputeResponse : BaseResponseDto
    {
        [DataMember]
        public SupplierDispute SupplierDispute { get; set; }
    }
    [DataContract]
    public class SaveSupplierDisputeDocumentResponse : BaseResponseDto
    {
        [DataMember]
        public bool Result { get; set; }

        [DataMember]
        public List<SupplierDisputeDocument> DisputeDocuments { get; set; }
    }
    [DataContract]
    public class SaveSupplierDisputeDocumentRequest : BaseRequestDto
    {
        [DataMember]
        public SupplierDisputeDocument DisputeDocument { get; set; }
    }
    [DataContract]
    public class GetSupplierDisputeDocumentResponse : BaseResponseDto
    {
        [DataMember]
        public List<SupplierDisputeDocument> DisputeDocuments { get; set; }
    }
    [DataContract]
    public class GetSupplierDisputeFollowupResponse : BaseResponseDto
    {
        [DataMember]
        public List<SupplierDisputeFollowup> DisputeFollowups { get; set; }
    }
    [DataContract]
    public class SaveSupplierDisputeFollowupRequest : BaseRequestDto
    {
        [DataMember]
        public List<SupplierDisputeFollowup> DisputeFollowups { get; set; }
    }
    [DataContract]
    public class SaveSupplierDisputeFollowupResponse : BaseRequestDto
    {
        [DataMember]
        public bool Result { get; set; }
    }
    [DataContract]
    public class GetSupplierDisputeEscalationResponse : BaseResponseDto
    {
        [DataMember]
        public List<SupplierDisputeEscalation> SupplierDisputeEscalations { get; set; }
    }
    [DataContract]
    public class SaveSupplierDisputeEscalationRequest : BaseRequestDto
    {
        [DataMember]
        public List<SupplierDisputeEscalation> SupplierDisputeEscalations { get; set; }
    }
    [DataContract]
    public class SaveSupplierDisputeEscalationResponse : BaseRequestDto
    {
        [DataMember]
        public bool Result { get; set; }
    }
    [DataContract]
    public class AssignUserToSupplierDisputesRequest : BaseRequestDto
    {
        [DataMember]
        public List<int> DisputesIds { get; set; }

        [DataMember]
        public int AssignUserId { get; set; }

    }
    [DataContract]
    public class GetRelatedSupplierDisputeResponse : BaseResponseDto
    {
        [DataMember]
        public List<SupplierDispute> SupplierDisputes { get; set; }
    }
    [DataContract]
    public class GetDisputeWorkOrderDetailsResponse : BaseResponseDto
    {
        [DataMember]
        public List<DomainModel.Accounting.DisputeWorkOrderDetail> DisputeWorkOrderDetails { get; set; }
    }

    [DataContract]
    public class SaveVendorEscalationRequest : BaseRequestDto
    {
        [DataMember]
        public SupplierDisputeEscalation SaveVendorEscalation { get; set; }
    }



}
