﻿using BusinessSvcImpl.DataObjects.SpaAccounting.Dto;
using CommonLib.DataObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace BusinessSvcImpl.DataObjects.SpaAccountingService.Dto
{

    [DataContract(Namespace = "http://www.bkfs.com/FS/DataContract/Accounting/1.00")]
    [Serializable]
    public class GetOrderSummaryRequest : BaseRequestDto
    {
        [DataMember]
        public int WorkOrderID { get; set; }


    }
    public class GetOrderSummaryResponse : BaseResponseDto
    {
        [DataMember]
        public OrderSummaryDTO OrderSummary { get; set; }
    }

}
