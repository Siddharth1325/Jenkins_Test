﻿using System.Collections.ObjectModel;
using System.Runtime.Serialization;

namespace BusinessSvcImpl.DataObjects.DocGen
{
  [DataContract(Namespace = "http://www.bkfs.com/FS/DataContract/GenerateDocumentRequest/1.00")]
  public class GenerateDocumentRequest
  {
    [DataMember]
    public int TransactionId { get; set; }

    [DataMember]
    public string UserContext { get; set; }

    [DataMember]
    public Collection<DocumentMetadata> Metadata { get; set; }

    public GenerateDocumentRequest()
    {
      Metadata = new Collection<DocumentMetadata>();
    }
  }
}
