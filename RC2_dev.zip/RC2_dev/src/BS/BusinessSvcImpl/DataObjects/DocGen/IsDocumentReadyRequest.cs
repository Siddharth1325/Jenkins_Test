﻿using System;
using System.Runtime.Serialization;

namespace BusinessSvcImpl.DataObjects.DocGen
{
  [DataContract(Namespace = "http://www.bkfs.com/FS/DataContract/IsDocumentReadyRequest/1.00")]
  public class IsDocumentReadyRequest : GenericRequest<Guid>
  {
  }
}
