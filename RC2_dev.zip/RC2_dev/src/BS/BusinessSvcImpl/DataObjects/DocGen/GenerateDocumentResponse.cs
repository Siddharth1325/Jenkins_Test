﻿using System;
using System.Runtime.Serialization;

namespace BusinessSvcImpl.DataObjects.DocGen
{
  [DataContract(Namespace = "http://www.bkfs.com/FS/DataContract/GenerateDocumentResponse/1.00")]
  public class GenerateDocumentResponse : GenericResponse<Guid>
  {
    
  }
}