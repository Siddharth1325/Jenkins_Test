﻿using System;
using System.Runtime.Serialization;

namespace BusinessSvcImpl.DataObjects.DocGen
{
  [DataContract(Namespace = "http://www.bkfs.com/FS/DataContract/DocumentMetadata/1.00")]
  public class DocumentMetadata
  {
    [DataMember]
    public string Key { get; set; }

    [DataMember]
    public Object Value { get; set; }
  }
}
