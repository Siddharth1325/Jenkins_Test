namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{
    using CommonLib.DataObjects;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using System.Text;
    using CommonLib.ModelAttrib;

    [DataContract(Namespace = "http://www.bkfs.com/FS/DataContract/Accounting/1.00")]
    [Serializable]
    [AutoGenMap]
    [KnownTypeAttribute(typeof(BaseDto))]
    public partial class VendorDisputeComment : BaseDto
    {
        [DataMember]
        [AutoGenMapProp(IsAutoMap = true, IsAutoMapId = true)]
        public int VendorDisputeCommentId { get; set; }

        [DataMember]
        public int vendorId { get; set; }

        [DataMember]
        public int AccountingDisputeId { get; set; }

        [DataMember]
        public decimal? VendorCreditAmount { get; set; }

        [DataMember]
        public decimal? VendorDebitAmount { get; set; }

        [DataMember]
        public string SLFSResponseTVendor { get; set; }

        [DataMember]
        public int CreatedById { get; set; }

        [DataMember]
        public DateTime CreatedDate { get; set; }

        [DataMember]
        public int? LastUpdatedById { get; set; }

        [DataMember]
        public DateTime? LastUpdatedDate { get; set; }

        [DataMember]
        public string Version { get; set; }

        [DataMember]
        public virtual AccountingDispute accountingDispute { get; set; }

        [MapIgnoreProp]
        [DataMember]
        public virtual bool Modified { get; set; }
    }
}
