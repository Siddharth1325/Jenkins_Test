﻿using System;
using System.Collections.Generic;
using System.Linq;
using CommonLib.DataObjects;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using CommonLib.ModelAttrib;
using BusinessSvcImpl.DataObjects.SpaAccounting.Dto;




namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{
    [DataContract(Namespace = "http://www.bkfs.com/FS/DataContract/Accounting/1.00")]
    [Serializable]
    [AutoGenMap]
    [KnownTypeAttribute(typeof(BaseDto))]
    public partial class DisputeSearchResult : BaseDto
    {
        [AutoGenMapProp(IsAutoMap = true, IsAutoMapId = true)]
        [DataMember]
        public int? DisputeId { get; set; }
        [DataMember]
        public string DisputeStatusType { get; set; }
        [DataMember]
        public string AssignedTo { get; set; }
        [DataMember]
        public DateTime? DisputeDueDateFrom { get; set; }
        [DataMember]
        public DateTime? DisputeDueDateTo { get; set; }

        [DataMember]
        public string InvoiceNumber { get; set; }
        [DataMember]
        public string DisputeType { get; set; }
        [DataMember]
        public string ClientName { get; set; }

        [DataMember]
        public string LoanNumber { get; set; }
        [DataMember]
        public int? VendorId { get; set; }
        [DataMember]
        public int? VendorWorkOrderId { get; set; }
        [DataMember]
        public int? InspWorkOrderId { get; set; }
        [DataMember]
        public decimal DisputeAmount { get; set; }

        [DataMember]
        public string DisputeResolution { get; set; }

        [DataMember]
        public DateTime? WorkOrderCompleteDate { get; set; }
    }
}
