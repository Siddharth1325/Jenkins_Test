namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{
    using CommonLib.DataObjects;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using System.Text;
    using CommonLib.ModelAttrib;

    [DataContract(Namespace = "http://www.bkfs.com/FS/DataContract/Accounting/1.00")]
    [Serializable]
    [AutoGenMap]
    [KnownTypeAttribute(typeof(BaseDto))]
    public partial class DisputeFollowup : BaseDto
    {
        [DataMember]
        [AutoGenMapProp(IsAutoMap = true, IsAutoMapId = true)]
        public int DisputeFollowupId { get; set; }

        [DataMember]
        public int AccountingDisputeId { get; set; }      

        [DataMember]
        [GroupCode("FollowUpResearchGroup", GroupCodeEnum.FOLRES)]
        public string FollowUpResearchType { get; set; }

        [DataMember]
        [GroupCode("FollowUpStatusGroup", GroupCodeEnum.FOLSTA)]
        public string FollowUpStatusElement { get; set; }

        [DataMember]
        public int? AssignedToId { get; set; }

        [DataMember]
        public DateTime? FollowUpAssignDate { get; set; }

        [DataMember] 
        public DateTime? FollowUpCompDate { get; set; }

        [DataMember]
        public int CreatedById { get; set; }

        [DataMember]
        public DateTime CreatedDate { get; set; }

        [DataMember]
        public int? LastUpdatedById { get; set; }

        [DataMember]
        public DateTime? LastUpdatedDate { get; set; }

        [DataMember]
        public string Version { get; set; }

        [DataMember]
        public virtual AccountingDispute accountingDispute { get; set; }

        [MapIgnoreProp]
        [DataMember]
        public virtual bool Modified { get; set; }

        [MapIgnoreProp]
        [DataMember]
        public string AssignedToName  { get; set; }

        [MapIgnoreProp]
        [DataMember]
        public string FollowUpResearchTypeName { get; set; }

        [MapIgnoreProp]
        [DataMember]
        public string FollowUpStatusElementName { get; set; }

        
    }
}
