namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{
    using CommonLib.DataObjects;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using System.Text;
    using CommonLib.ModelAttrib;

    [DataContract(Namespace = "http://www.bkfs.com/FS/DataContract/Accounting/1.00")]
    [Serializable]
    [AutoGenMap]
    [KnownTypeAttribute(typeof(BaseDto))]
    public partial class AccountingDispute : BaseDto
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public AccountingDispute()
        {
            disputeDocuments = new HashSet<DisputeDocument>();
            disputeFollowups = new HashSet<DisputeFollowup>();
            VendorDisputeComments = new HashSet<VendorDisputeComment>();
        }

        [DataMember]
        [AutoGenMapProp(IsAutoMap = true, IsAutoMapId = true)]
        public int AccountingDisputeId { get; set; }

        [DataMember]
        public string BulkID { get; set; }     

        [DataMember]
        public string AssignToFirstName { get; set; }

        [DataMember]
        public string AssignToLastName { get; set; }

        [DataMember]
        public string DisputeStatusGroup { get; set; }

        [DataMember]
        public string DisputeStatusType { get; set; }     

        [DataMember]
        [GroupCode("DisputeTypeGroup", GroupCodeEnum.DISTYP)]
        public string DisputeType { get; set; }

        [DataMember]
        public string DisComments { get; set; }

        [DataMember]
        public string SLFSResponseToClient { get; set; }

        [DataMember]
        public string DisInternalComments { get; set; }      

        [DataMember]
        [GroupCode("DisResolutionGroup", GroupCodeEnum.DISRES)]
        public string DisResolutionType { get; set; }       

        [DataMember]
        [GroupCode("DisResDepartGroup", GroupCodeEnum.DISRESD)]
        public string DisResDepartType { get; set; }       

        [DataMember]
        [GroupCode("DisErrorGroup", GroupCodeEnum.DISERR)]
        public string DisErrorType { get; set; }

        [DataMember]
        public int? DisputeErrorCausedById { get; set; }

        [DataMember]
        public decimal? CreditClientAmount { get; set; }

        [DataMember]
        public decimal? DebitClientAmount { get; set; }

        [DataMember]
        public string RebillNumber { get; set; }

        [DataMember]
        public decimal? DisputeAmount { get; set; }

        [DataMember]
        public int? ClientId { get; set; }

        [DataMember]
        public string LoanNumber { get; set; }

        [DataMember]
        public int? VendorId { get; set; }

        [DataMember]
        public int? VendorWorkOrderId { get; set; }

        [DataMember]
        public int? InspWorkOrderId { get; set; }

        [DataMember]
        public string InvoiceNumber { get; set; }

        [DataMember]
        public DateTime? InvoiceDate { get; set; }

        [DataMember]
        public decimal? InvoiceAmount { get; set; }

        [DataMember]
        public decimal? HardLoss { get; set; }

        [DataMember]
        public int? ApprovedById { get; set; }

        [DataMember]
        public DateTime? DisputeDate { get; set; }

        [DataMember]
        public DateTime? DisputeDueDate { get; set; }

        [DataMember]
        public int? DocumentId { get; set; }

        [DataMember]
        public int CreatedById { get; set; }

        [DataMember]
        public DateTime CreatedDate { get; set; }

        [DataMember]
        public int? LastUpdatedById { get; set; }

        [DataMember]
        public DateTime? LastUpdatedDate { get; set; }

        [DataMember]
        public string Version { get; set; }

        [DataMember]
        public DateTime? WorkOrderCompleteDate { get; set; }

        [DataMember]
        public virtual AccountingDispute accountingDispute1 { get; set; }

        [DataMember]
        public virtual AccountingDispute accountingDispute2 { get; set; }

        [DataMember]
        public virtual ICollection<DisputeDocument> disputeDocuments { get; set; }

        [DataMember]
        public virtual ICollection<DisputeFollowup> disputeFollowups { get; set; }

        [DataMember]
        public virtual ICollection<VendorDisputeComment> VendorDisputeComments { get; set; }
    }
}
