﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CommonLib.DataObjects;
using System.Runtime.Serialization;
using CommonLib.ModelAttrib;
using BusinessSvcImpl.DataObjects.SpaAccounting.Dto;

namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{
    [DataContract(Namespace = "http://www.bkfs.com/FS/DataContract/Accounting/1.00")]
    [Serializable]
    [AutoGenMap]
    [KnownTypeAttribute(typeof(BaseDto))]
    [KnownTypeAttribute(typeof(AccountsReceivableAdjustment))]
    public partial class DisputeReceivableAdjustmentHistory : BaseDto
    {
        public DisputeReceivableAdjustmentHistory()
        {
            this.AccountsReceivableAdjustments = new HashSet<AccountsReceivableAdjustment>();
        }

        [DataMember]
        [AutoGenMapProp(IsAutoMapId = true, IsAutoMap = true)]
        public int DisputeReceivableAdjustmentHistoryId { get; set; }

        [DataMember]
        public int ApplicationId { get; set; }

        [DataMember]
        public int? SourceDisputeReceivableAdjustmentHistoryId { get; set; }

        [DataMember]
        public int OrderHierarchyId { get; set; }

        [DataMember]
        public int Quantity { get; set; }

        [DataMember]
        public decimal? AgreedClientUnitPrice { get; set; }

        [DataMember]
        public decimal? AgreedUnitPriceAdjstdAmt { get; set; }

        [DataMember]
        public decimal? ClientPrice { get; set; }

        [DataMember]
        public decimal? ClientPriceAdjstdAmt { get; set; }

        [DataMember]
        public decimal? ClientRushFee { get; set; }

        [DataMember]
        public decimal? ClientRushFeeAdjstdAmt { get; set; }

        [DataMember]
        public decimal? ClientTripFee { get; set; }

        [DataMember]
        public decimal? ClientTripFeeAdjstdAmt { get; set; }

        [DataMember]
        public string ServiceDescription { get; set; }

        [DataMember]
        public string LineItemDescription { get; set; }

        [DataMember]
        public DateTime HistoryDate { get; set; }

        [DataMember]
        public string ClientAdjComments { get; set; }

        [DataMember]
        public int RecordNumber { get; set; }

        [DataMember]
        public string AdjustmentHistoryRecordGroup { get; set; }

        [DataMember]
        public string AdjustmentHistoryRecordType { get; set; }
        [DataMember]
        public int? QuantityAdjusted { get; set; }

        [DataMember]
        public decimal? ClientPriceTax { get; set; }
        [DataMember]
        public decimal? ClientRushFeeTax { get; set; }
        [DataMember]
        public decimal? ClientTripFeeTax { get; set; }

        [DataMember]
        public DateTime? InvoiceDate { get; set; }
        [DataMember]
        public string InvoiceNumber { get; set; }
        [DataMember]
        public string AdjustmentType { get; set; }

        [DataMember]
        public int? FeeTypeId { get; set; }

        [DataMember]
        public int? FeeTypePaymentRefId { get; set; }

        [DataMember]
        public int CreatedById { get; set; }

        [DataMember]
        public DateTime CreatedDate { get; set; }

        [DataMember]
        public int? LastUpdatedById { get; set; }

        [DataMember]
        public DateTime? LastUpdatedDate { get; set; }

        [DataMember]
        public string   Version { get; set; }

        [DataMember]
        public virtual OrderHierarchy OrderHierarchy { get; set; }

        [DataMember]
        [AutoGenMapProp(IsAutoMap = false)]
        public int? OriginalOrFinalHistoryId { get; set; }

        [DataMember]
        public string UnitOfMeasure { get; set; }

        [DataMember]
        public string UnitOfMeasureAdjusted { get; set; }


        [DataMember]
        public virtual ICollection<AccountsReceivableAdjustment> AccountsReceivableAdjustments { get; set; }

        [DataMember]
        public string RecordsToBeSaved { get; set; }
    }
}
