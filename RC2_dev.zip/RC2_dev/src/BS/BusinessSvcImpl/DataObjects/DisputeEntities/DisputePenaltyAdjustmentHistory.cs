﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CommonLib.DataObjects;
using System.Runtime.Serialization;
using CommonLib.ModelAttrib;
using BusinessSvcImpl.DataObjects.SpaAccounting.Dto;

namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{
    [DataContract]
    [Serializable]
    public partial class DisputePenaltyAdjustmentHistory : BaseResponseDto
    {
        [DataMember]
        public int DisputePenaltyAdjustmentHistoryId { get; set; }

        [DataMember]
        public int? ApplicationId { get; set; }

        [DataMember]
        public int VendorWorkOrderId { get; set; }
        [DataMember]
        public int AssignedVendorId { get; set; }
        [DataMember]
        public int? WorkOrderId { get; set; }
        [DataMember]
        public string ProductName { get; set; }
        [DataMember]
        public string ServiceName { get; set; }
        [DataMember]
        public string GoalName { get; set; }
        [DataMember]
        public string AchievementName { get; set; }
        [DataMember]
        public decimal? PenaltyAmount { get; set; }
        [DataMember]
        public decimal? PenaltyAdjustmentAmount { get; set; }
        [DataMember]
        public string InvoiceNumber { get; set; }
        [DataMember]
        public DateTime? InvoiceDate { get; set; }
        [DataMember]
        public string Comments { get; set; }
        [DataMember]
        public string SupplierComment { get; set; }
        [DataMember]
        public string RecType { get; set; }
        [DataMember]
        // public int rnk { get; set; }
        public DateTime? AdjustmentDate { get; set; }
        [DataMember]
        public int RecordNumber { get; set; }
        [DataMember]
        public int OrderHierarchyId { get; set; }

        [DataMember]
        public string Version { get; set; }

        [DataMember]
        public int? FeeTypeId { get; set; }

        [DataMember]
        public decimal? FinalPenaltyAmount { get; set; }
    }
    
}
