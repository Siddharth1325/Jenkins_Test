﻿

namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using CommonLib.DataObjects;
    using System.Runtime.Serialization;

    [DataContract]
    public class RejectCheckRequest : BaseRequestDto
    {
        //[DataMember]
        //public int OrderHierarchyId { get; set; }


        [DataMember]
        public int?  AccountsPayableInvoiceId { get; set; }

        [DataMember]
        public string RejectionReason { get; set; }

        [DataMember]
        public string RejectionComments { get; set; }

        [DataMember]
        public bool IsRejectAndReOrder { get; set; }

        [DataMember]
        public bool IsReOrderOnly { get; set; }

        [DataMember]
        public List<RejectPayee> RejectPayeeList { get; set; }

        [DataMember]
        public TrackingLogSource TrackingLogSource { get; set; }
    }

    [DataContract]
    public class RejectPayee
    {

        [DataMember]
        public int AccountsPayableDetailId { get; set; }

        [DataMember]
        public string PayeeName { get; set; }

        [DataMember]
        public int FeeTypeId { get; set; }

        [DataMember]
        public decimal? Amount { get; set; }

        [DataMember]
        public decimal? DiffAmount { get; set; }

        [DataMember]
        public int? AccountsPayableInvoiceId { get; set; }
    }

    [DataContract]
    public class RejectCheckResponse : BaseResponseDto
    {
        [DataMember]
        public bool IsSuccess { get; set; }
    }

    [DataContract]
    public class PayeeDetailsRequest : BaseRequestDto
    {
    [DataMember]
        public int? PayableInvoiceId { get; set; }

        [DataMember]
        public int OrderHierarchyId { get; set; }
    }

    [DataContract]
    public class PayeeDetailResponse : BaseResponseDto {

        public PayeeDetailResponse()
        {
            PayeeDetails = new List<PayeeDetail>();
        }
        [DataMember]
        public List<PayeeDetail> PayeeDetails { get; set; }
    }

    public class PayeeDetail
    {
        [DataMember]
        public string FeeType { get; set; }

        [DataMember]
        public string PayeeName { get; set; }

        [DataMember]
        public decimal? Amount { get; set; }

        [DataMember]
        public int PayableDetailId { get; set; }

        [DataMember]
        public int? FeeTypeId { get; set; }
    }

}
