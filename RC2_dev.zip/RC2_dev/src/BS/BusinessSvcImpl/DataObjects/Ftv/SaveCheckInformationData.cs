﻿
namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{

    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using CommonLib.DataObjects;
    using System.Runtime.Serialization;


    public class TrackingLogSource
    {
        [DataMember]
        public int OrderHierarchyId { get; set; }

        [DataMember]
        public int PlatFormWorkOrderId { get; set; }

        [DataMember]
        public int? AccountsPayableTrackingLogId { get; set; }

        [DataMember]
        public int? AccountsPayableRemittanceId { get; set; }

        [DataMember]
        public int? AccountsPayableInvoiceId { get; set; }

        [DataMember]
        public int? FeeTypePaymentRefId { get; set; }

    }



    [DataContract]
    public class TrackingLogInfo 
    {
        [DataMember]
        public TrackingLogSource TrackingLogSource { get; set; }

        [DataMember]
        public string ConfirmationNumber { get; set; }

        [DataMember]
        public DateTime? PaymentDate { get; set; }

        [DataMember]
        public string TrackingNumber { get; set; }

        [DataMember]
        public DateTime? PostedDate { get; set; }

        [DataMember]
        public DateTime? DeliveryConfirmationDate { get; set; }

        [DataMember]
        public string OracleId { get; set; }
    }

    [DataContract]
    public class SaveCheckInformationRequest : BaseRequestDto
    {
        public SaveCheckInformationRequest()
        {
            TrackingLogInfo = new List<TrackingLogInfo>();
        }
        [DataMember]
        public List<TrackingLogInfo> TrackingLogInfo { get; set; }
    }

    [DataContract]
    public class SaveCheckInformationResponse : BaseResponseDto
    {
        [DataMember]
        public bool IsSuccess { get; set; }
    }
}
