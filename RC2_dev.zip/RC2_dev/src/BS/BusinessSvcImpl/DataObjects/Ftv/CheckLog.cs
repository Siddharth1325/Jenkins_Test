﻿
namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{

    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Linq;
    using System.Runtime.Serialization;
    using System.Text;
    using System.Threading.Tasks;
    using CommonLib.DataObjects;

    [DataContract]
    public class CheckLogExport
    {

        [DataMember]
        [Description("Client #")]
        public string ClientNumber { get; set; }
        [DataMember]
        [Description("Payable Name")]
        public string PayableName { get; set; }

        [DataMember]
        [Description("Payable Address")]
        public string PayableAddress { get; set; }

        [DataMember]
        [Description("Payable City,Payable State,Payable Zip")]
        public string PayableFields { get; set; }

        [DataMember]
        [Description("Loan #")]
        public string LoanNumber { get; set; }
        [DataMember]
        [Description("Payable City")]
        public string City { get; set; }

        [DataMember]
        [Description("Payable State")]
        public string State { get; set; }

        [DataMember]
        [Description("Payable Zip")]
        public string Zip { get; set; }

        [DataMember]
        [Description("Comments to be Printed on Checks")]
        public string CommentPrintedCheck { get; set; }

        [DataMember]
        [Description("WorkOrder #")]
        public int WorkOrderId { get; set; }

        [DataMember]
        [Description("Work Order Status")]
        public string WorkOrderStatus { get; set; }

        [DataMember]
        [Description("AP Invoice #")]
        public string InvoiceNumber { get; set; }

        [DataMember]
        [Description("Reg Completed  Date")]
        public string RegCompletedDate { get; set; }

        [DataMember]
        [Description("Fee Type")]
        public string FeeTypeName { get; set; }

        [DataMember]
        [Description("Fee Amount")]
        public decimal? FeeAmount { get; set; }

        [DataMember]
        [Description("Payment Type")]
        public string PaymentType { get; set; }

        [DataMember]
        [Description("Payment Conf #")]
        public string ConfirmationNo { get; set; }

        [DataMember]
        [Description("Payment Date")]
        public string PaymentDate { get; set; }

        [DataMember]
        [Description("Mailing Label")]
        public string MailingLabel { get; set; }

        [DataMember]
        [Description("Tracking #")]
        public string TrackingNumber { get; set; }

        [DataMember]
        [Description("Posted Date")]
        public string PostedDate { get; set; }

        [DataMember]
        [Description("Delivery Conf Rec Date")]
        public string DeliveryConfirmDate { get; set; }

        [DataMember]
        [Description("Delivery Status")]
        public string DeliveryConfirmStatus { get; set; }

        [DataMember]
        [Description("Delivery Confirmation Comments")]
        public string DeliveryConfirmComments { get; set; }

        [DataMember]
        [Description("Rejected Date")]
        public string RejectedDate { get; set; }

        [DataMember]
        [Description("Rejection Reason")]
        public string RejectionReason { get; set; }

        [DataMember]
        [Description("Rejection Comments")]
        public string RejectionReasonComments { get; set; }

        [Description("Re-Order Date")]
        [DataMember]
        public string ReOrderDate { get; set; }

        [DataMember]
        [Description("Check Status")]
        public string ApStatus { get; set; }

        [DataMember]
        [Description("Asset Address")]
        public string AssetAddress { get; set; }

         [DataMember]
         [Description("Asset City")]
        public string AssetCity { get; set; }
         [DataMember]
         [Description("Asset StateCode")]
        public string AssetStateCode { get; set; }
         [DataMember]
         [Description("Asset ZipCode")]
        public string AssetZipCode { get; set; }
         [DataMember]
         [Description("Asset ZipPlusFour")]
        public string AssetZipPlusFour { get; set; }
       
        
    }
    
    
    [DataContract]
    public class CheckLogSearch
    {

        [DataMember]
        public string Invoice { get; set; }

        [DataMember]
        public string Check { get; set; }

        [DataMember]
        public int? WorkOrderId { get; set; }

        [DataMember]
        public string LoanNumber { get; set; }

        [DataMember]
        public string ClientNumber { get; set; }

        [DataMember]
        public string Tracking { get; set; }

        [DataMember]
        public bool? IsPosted { get; set; }

        [DataMember]
        public bool? IsDelieveryConfirmation { get; set; }

        [DataMember]
        public string PayableName { get; set; }

        [DataMember]
        public DateTime? CompletedDateFrom { get; set; }

        [DataMember]
        public DateTime? CompletedDateTo { get; set; }

        [DataMember]
        public DateTime? CheckedDateFrom { get; set; }

        [DataMember]
        public DateTime? CheckedDateTo { get; set; }

        [DataMember]
        public int PageSize { get; set; }

        [DataMember]
        public int SkipCount { get; set; }

    }
   
    [DataContract]
    public class CheckLogSearchExportResponse : BaseResponseDto
    {
        public CheckLogSearchExportResponse()
        {
            SearchExportResults = new List<CheckLogExport>();
        }
        [DataMember]
        public List<CheckLogExport> SearchExportResults { get; set; }
    }


    [DataContract]
    public class CheckLogSearchRequest : BaseRequestDto
    {
        [DataMember]
        public CheckLogSearch SearchInput { get; set; }

        [DataMember]
        public int? SkipCount { get; set; }

        [DataMember]
        public int? PageSize { get; set; }

        [DataMember]
        public int? PageNumber { get; set; }
    }

    [DataContract]
    public class CheckLogSearchResponse : BaseResponseDto
    {

        public CheckLogSearchResponse()
        {
            SearchResults = new List<CheckLogSearchResult>();
        }
        [DataMember]
        public List<CheckLogSearchResult> SearchResults { get; set; }
    }

    [DataContract]
    public class CheckLogSearchResult
    {

        [DataMember]
        public int ClientNumber { get; set; }

        [DataMember]
        public string PayableName { get; set; }

        [DataMember]
        public string InvoiceNumber { get; set; }

        [DataMember]
        public string LoanNumber { get; set; }

        [DataMember]
        public int SourceWorkOrderId { get; set; }

        [DataMember]
        public int PlatformWorkOrderId { get; set; }

        [DataMember]
        public string WorkOrderStatus { get; set; }

        [DataMember]
        public string PaymentType { get; set; }

        [DataMember]
        public decimal? FeeAmount { get; set; }

        [DataMember]
        public string ConfirmationNo { get; set; }

        [DataMember]
        public DateTime? PaymentDate { get; set; }

        [DataMember]
        public string TrackingNumber { get; set; }

        [DataMember]
        public DateTime? PostedDate { get; set; }

        [DataMember]
        public DateTime? DeliveryConfirmDate { get; set; }

        [DataMember]
        public int? AccountsPayableRemittanceId { get; set; }

        [DataMember]
        public int? AccountsPayableTrackingLogId { get; set; }

        [DataMember]
        public int OrderHierarchyId { get; set; }

        [DataMember]
        public int? AccountsPayableInvoiceId { get; set; }

        [DataMember]
        public string DeliveryConfirmStatusCode { get; set; }

        [DataMember]
        public string DeliveryConfirmComments { get; set; }

        [DataMember]
        public string RejectionReasonCode { get; set; }

        [DataMember]
        public string RejectionReasonComments { get; set; }

        [DataMember]
        public bool? IsReorderCheck { get; set; }

        [DataMember]
        public string ApStatus { get; set; }

        [DataMember]
        public string ApStatusType { get; set; }

        [DataMember]
        public int? FeeTypePaymentRefId { get; set; }
    }

        
}
