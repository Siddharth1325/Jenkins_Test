﻿
namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using System.Text;
    using System.Threading.Tasks;
    using CommonLib.DataObjects;

    [DataContract]
    public class CheckDeliveryConfirmationRequest : BaseRequestDto
    {
        [DataMember]
        public TrackingLogSource TrackingLogSource { get; set; }

        [DataMember]
        public string ConfirmationStatus { get; set; }

        [DataMember]
        public string ConfirmationComments { get; set; }

        [DataMember]
        public DateTime? ConfirmationReceiptDate { get; set; }

    }


    [DataContract]
    public class CheckDeliveryConfirmationResponse : BaseResponseDto
    {
        [DataMember]
        public bool IsSuccess { get; set; }
    }
}
