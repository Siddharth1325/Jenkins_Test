﻿namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{

    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using CommonLib.DataObjects;
    using System.Runtime.Serialization;

    [DataContract]
    public class SaveNewCheck
    {
        [DataMember]
        public int OrderHierarchyId { get; set; }

        [DataMember]
        public string PayeeName { get; set; }

        [DataMember]
        public int FeeTypeId { get; set; }

        [DataMember]
        public decimal? CheckAmount { get; set; }

        [DataMember]
        public string Comments { get; set; }
    }

    [DataContract]
    public class SaveNewCheckRequest : BaseRequestDto
    {
        [DataMember]
        public List<SaveNewCheck> NewCheckList { get; set; }
    }

    [DataContract]
    public class SaveNewCheckResponse : BaseResponseDto
    {
        [DataMember]
        public bool IsSuccess { get; set; }
    }
}

