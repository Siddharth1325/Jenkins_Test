using CommonLib.DataObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using CommonLib.ModelAttrib;

namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{
    [DataContract(Namespace = "http://www.bkfs.com/FS/DataContract/Accounting/1.00")]
    [Serializable]
    [AutoGenMap]
    [KnownTypeAttribute(typeof(BaseDto))]
    public partial class WorkOrder : BaseDto
    {
        public WorkOrder()
        {
            WorkOrderItems = new List<WorkOrderItem>();
            Cancellations = new List<Cancellation>();
        }

        [DataMember]
        [AutoGenMapProp(IsAutoMap = true, IsAutoMapId = true)]
        public int WorkOrderId { get; set; }

        [DataMember]
        public int ApplicationId { get; set; }

        [DataMember]
        public int SourceWorkOrderId { get; set; }

        [DataMember]
        public int? OrderId { get; set; }

        [DataMember]
        public int ProductId { get; set; }

        [DataMember]
        public int? VendorWorkOrderId { get; set; }

        [DataMember]
        public string WorkOrderStatusGroup { get; set; }

        [DataMember]
        public string WorkOrderStatusType { get; set; }

        [DataMember]
        public string CancellationReasonGroup { get; set; }

        [DataMember]
        public string CancellationReasonType { get; set; }

        [DataMember]
        public int? AssignedVendorId { get; set; }

        [DataMember]
     //   [DateTimeBoth]
        public DateTime? AssignedDate { get; set; }

        [DataMember]
    //    [DateTimeBoth]
        public DateTime RequestedDate { get; set; }

        [DataMember]
     //   [DateTimeBoth]
        public DateTime? WindowStartDate { get; set; }

        [DataMember]
    //    [DateTimeBoth]
        public DateTime? WindowEndDate { get; set; }

        [DataMember]
   //     [DateTimeBoth]
        public DateTime? DueToClientDate { get; set; }

        [DataMember]
    //    [DateTimeBoth]
        public DateTime? OrigVendorDueDate { get; set; }

        [DataMember]
   //     [DateTimeBoth]
        public DateTime? DueFromVendorDate { get; set; }

        [DataMember]
  //      [DateTimeBoth]
        public DateTime? CompletedDate { get; set; }

        [DataMember]
   //     [DateTimeBoth]
        public DateTime? CancellationDate { get; set; }

        [DataMember]
   //     [DateTimeBoth]
        public DateTime? TransmittedDate { get; set; }

        [DataMember]
 //       [DateTimeBoth]
        public DateTime? AcctProcessedDate { get; set; }

        [DataMember]
        public string BorrowerFirstName { get; set; }

        [DataMember]
        public string BorrowerMiddleInitial { get; set; }

        [DataMember]
        public string BorrowerLastName { get; set; }

        [DataMember]
        public string AddressLine1 { get; set; }

        [DataMember]
        public string AddressLine2 { get; set; }

        [DataMember]
        public string CityName { get; set; }

        [DataMember]
        public string StateCode { get; set; }

        [DataMember]
        public string ZipCode { get; set; }

        [DataMember]
        public string ZipPlusFour { get; set; }

        [DataMember]
        public string CountyName { get; set; }

        [DataMember]
        public string SpecialInstructions { get; set; }

        [DataMember]
        public bool IsRushOrder { get; set; }

        [DataMember]
        public bool? IsBillClient { get; set; }

        [DataMember]
        public bool IsFirstTimeVacant { get; set; }

        [DataMember]
        public bool IsVacantToOccupied { get; set; }

        [DataMember]
        public string PayVendorGroup { get; set; }

        [DataMember]
        public string PayVendorType { get; set; }

        [DataMember]
        public bool? IsCountedTowardScore { get; set; }

        [DataMember]
        public string DoorCardTypeGroup { get; set; }

        [DataMember]
        public string DoorCardType { get; set; }

        [DataMember]
        public string DoorCardMessageText { get; set; }

        #region Data Sync// these are needed by Reporting Or some sort of background process. will come as Sync data frm FieldServices.
        [DataMember]
        public string InspectorUniqueId { get; set; }

        [DataMember]
      //  [DateTimeBoth]
        public DateTime? InspectionDate1 { get; set; }

        [DataMember]
      //  [DateTimeBoth]
        public DateTime? InspectionDate2 { get; set; }
      //  [DateTimeBoth]
        [DataMember]
        public DateTime? InspectionDate3 { get; set; }

        [DataMember]
        public string AccessDeniedType { get; set; }

        [DataMember]
        public string BadAddrGroupCode { get; set; }

        [DataMember]
        public bool IsWorkPerformed { get; set; }

        [DataMember]
        public bool IsQCOverride { get; set; }
        #endregion

        [DataMember]
        public decimal? TotalAmountDue { get; set; }

        [DataMember]
        public decimal? SubTotalDue { get; set; }

        //[DateTimeBoth]
        [DataMember]
        public DateTime? InvoiceDate { get; set; }
        
        [DataMember]
        public int? ClientSystemId { get; set; }
        
        [DataMember]
        public int? VendorCoverageId { get; set; }

        [DataMember]
        public string ClientDepartment { get; set; }
        [DataMember]
        public int CreatedById { get; set; }

        [DateTimeBoth]
        [DataMember]
        public DateTime CreatedDate { get; set; }

        [DataMember]
        public int? LastUpdatedById { get; set; }

        [DateTimeBoth]
        [DataMember]
        public DateTime? LastUpdatedDate { get; set; }

        [DataMember]
        public string Version { get; set; }

        [DataMember]
        public int? OrdinanceProfileId { get; set; }

        [DataMember]
        public virtual Order Order { get; set; }

        [DataMember]
        public virtual Product Product { get; set; }

        //[DataMember]
        //public virtual Municipality Municipality { get; set; }

        [DataMember]
        public virtual List<WorkOrderItem> WorkOrderItems { get; set; }

        [DataMember]
        public virtual ICollection<Cancellation> Cancellations { get; set; }

        [DataMember]
      //  [DateTimeBoth]
        public DateTime? SubmissionDate { get; set; }

        [DataMember]
        public virtual VendorProfile VendorProfile { get; set; }

        [DataMember]
        public virtual VendorWorkOrder VendorWorkOrder { get; set; }
    }
}
