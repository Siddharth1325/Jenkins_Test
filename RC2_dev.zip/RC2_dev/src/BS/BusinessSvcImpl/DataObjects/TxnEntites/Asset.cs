using CommonLib.DataObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using CommonLib.ModelAttrib;

namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{
    [DataContract(Namespace = "http://www.bkfs.com/FS/DataContract/Accounting/1.00")]
    [Serializable]
    [AutoGenMap]
    [KnownTypeAttribute(typeof(BaseDto))]
    public partial class Asset : BaseDto
    {
        public Asset()
        {
            Loans = new List<Loan>();
        }

        [DataMember]
        [AutoGenMapProp(IsAutoMap = true, IsAutoMapId = true)]
        public int AssetId { get; set; }

        [DataMember]
        public int ApplicationId { get; set; }

        [DataMember]
        public int SourceAssetId { get; set; }

        [DataMember]
        public string DwellingTypeGroup { get; set; }

        [DataMember]
        public string DwellingType { get; set; }

        [DataMember]
        public string MobileVinNumber { get; set; }

        [DataMember]
        public string MobileHudNumber { get; set; }

        [DataMember]
        public string Latitude { get; set; }

        [DataMember]
        public string Longitude { get; set; }

        [DataMember]
        public bool IsDoNotApproach { get; set; }

        [DataMember]
        public string DoNotApproachReason { get; set; }

        [DataMember]
        public string GateCode { get; set; }

        [DataMember]
        public string HOAName { get; set; }

        [DataMember]
        public string HOAPhone { get; set; }

        [DataMember]
        public string CommunityName { get; set; }

        [DataMember]
        public string CommunityNumber { get; set; }

        [DataMember]
        public string CommunityAddress1 { get; set; }

        [DataMember]
        public string CommunityAddress2 { get; set; }

        [DataMember]
        public string CommunityCityName { get; set; }

      //  [DateTimeBoth]
        [DataMember]
        public DateTime? LastVPROrARTDate { get; set; }

        [DataMember]
        public string VendorNotes { get; set; }

        [DataMember]
        public bool? IsMelissaServiceCalled { get; set; }

        [DataMember]
        public string AddressKey { get; set; }
        [DataMember]
        public int CreatedById { get; set; }

        [DateTimeBoth]
        [DataMember]
        public DateTime CreatedDate { get; set; }

        [DataMember]
        public int? LastUpdatedById { get; set; }

        [DateTimeBoth]
        [DataMember]
        public DateTime? LastUpdatedDate { get; set; }

        [DataMember]
        public string Version { get; set; }

        [DataMember]
        public virtual List<Loan> Loans { get; set; }
    }
}
