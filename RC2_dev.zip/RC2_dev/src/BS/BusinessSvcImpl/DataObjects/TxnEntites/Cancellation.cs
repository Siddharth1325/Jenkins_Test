﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using CommonLib.DataObjects;
using CommonLib.ModelAttrib;

namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{
    [DataContract(Namespace = "http://www.bkfs.com/FS/DataContract/Accounting/1.00")]
    [Serializable]
    [AutoGenMap]
    [KnownTypeAttribute(typeof(BaseDto))]
    public partial class Cancellation : BaseDto
    {
        [DataMember]
        [AutoGenMapProp(IsAutoMap = true, IsAutoMapId = true)]
        public int CancellationId { get; set; }

        [DataMember]
        public int ApplicationId { get; set; }

        [DataMember]
        public int SourceCancellationId { get; set; }

        [DataMember]
        public int? CancelledLoanId { get; set; }

        [DataMember]
        public int? CancelledOrderId { get; set; }

        [DataMember]
        public int? CancelledWorkOrderId { get; set; }
        
        [DataMember]
     //   [DateTimeBoth]
        public DateTime CancellationDate { get; set; }

        [DataMember]
        public string CancellationReasonGroup { get; set; }

        [DataMember]
        public string CancellationReasonType { get; set; }

        [DataMember]
        public string CancellationComments { get; set; }

        [DataMember]
        public int CreatedById { get; set; }

        [DataMember]
        [DateTimeBoth]
        public DateTime CreatedDate { get; set; }

        [DataMember]        
        public int? LastUpdatedById { get; set; }

        [DataMember]
        [DateTimeBoth]
        public DateTime? LastUpdatedDate { get; set; }

        [DataMember]        
        public string Version { get; set; }

    }
}
