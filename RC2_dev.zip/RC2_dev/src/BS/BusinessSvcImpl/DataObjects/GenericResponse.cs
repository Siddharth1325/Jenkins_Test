﻿using System.Runtime.Serialization;

namespace BusinessSvcImpl.DataObjects
{
  [DataContract(Name = "ResponseOfType{0}", Namespace = "http://www.bkfs.com/FS/DataContract/Insp/1.00")]
  public class GenericResponse<T>
  {
    [DataMember]
    public bool Success { get; set; }

    [DataMember]
    public string Message { get; set; }

    [DataMember]
    public T Data { get; set; }
  }
}
