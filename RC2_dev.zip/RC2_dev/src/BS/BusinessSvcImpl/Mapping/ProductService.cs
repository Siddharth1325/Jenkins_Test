using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using CommonLib.DataObjects;
using CommonLib.ModelAttrib;
using Domain = DomainModel.Accounting;
namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{ 
[System.CodeDom.Compiler.GeneratedCode("EF", "6.1.0")]
	public partial class ProductService : BaseDto
	{ 
		public Domain.ProductService MapToDomainModelWithoutCollections(Domain.ProductService ProductService)
		{ 
			ProductService.ApplicationId = this.ApplicationId;
			ProductService.ProductId = this.ProductId;
			ProductService.ServiceId = this.ServiceId;
			ProductService.CreatedById = this.CreatedById;
			ProductService.CreatedDate = this.CreatedDate;
			ProductService.LastUpdatedById = this.LastUpdatedById;
			ProductService.LastUpdatedDate = this.LastUpdatedDate;
            ProductService.Version = string.IsNullOrEmpty(this.Version) ? null: Convert.FromBase64String(this.Version);
			if (this.Product != null)
			{ 
				ProductService.Product = new Domain.Product();
				ProductService.Product = this.Product.MapToDomainModelWithoutCollections(ProductService.Product);
			} 
			if (this.Service != null)
			{ 
				ProductService.Service = new Domain.Service();
				ProductService.Service = this.Service.MapToDomainModelWithoutCollections(ProductService.Service);
			} 
			ProductService.ProductServiceId = this.ProductServiceId;
			return ProductService;
		} 
		public void MapToDtoWithoutCollections(Domain.ProductService ProductService)
		{ 
			this.ApplicationId = ProductService.ApplicationId;
			this.ProductId = ProductService.ProductId;
			this.ServiceId = ProductService.ServiceId;
			this.CreatedById = ProductService.CreatedById;
			this.CreatedDate = ProductService.CreatedDate;
			this.LastUpdatedById = ProductService.LastUpdatedById;
			this.LastUpdatedDate = ProductService.LastUpdatedDate;
            this.Version = ProductService.Version == null ? null:Convert.ToBase64String(ProductService.Version);
			if (ProductService.Product != null)
			{ 
				this.Product = new Product();
				this.Product.MapToDtoWithoutCollections(ProductService.Product);
			} 
			if (ProductService.Service != null)
			{ 
				this.Service = new Service();
				this.Service.MapToDtoWithoutCollections(ProductService.Service);
			} 
			this.ProductServiceId = ProductService.ProductServiceId;
		} 
		public override TDto MapFromDomainModel<TDomain, TDto>(TDomain domainModel)
		{ 
			Domain.ProductService ProductServiceModel = domainModel as Domain.ProductService;
			if(ProductServiceModel != null)
			{ 
				MapToDtoWithoutCollections(ProductServiceModel);
			} 
				return this as TDto;
		} 
		public override TDomain MapToDomainModel<TDomain>(TDomain domainModel)
		{ 
			Domain.ProductService ProductServiceModel = domainModel as Domain.ProductService;
			Domain.ProductService destObj = MapToDomainModelWithoutCollections(ProductServiceModel);
		    return destObj as TDomain;
		} 
	} 
} 

