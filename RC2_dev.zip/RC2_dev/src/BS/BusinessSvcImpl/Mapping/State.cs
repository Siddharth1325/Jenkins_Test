using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using CommonLib.DataObjects;
using CommonLib.ModelAttrib;
using Domain = DomainModel.Accounting;
namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{ 
[System.CodeDom.Compiler.GeneratedCode("EF", "6.1.0")]
	public partial class State : BaseDto
	{ 
		public Domain.State MapToDomainModelWithoutCollections(Domain.State State)
		{ 
			State.StateId = this.StateId;
			State.StateCode = this.StateCode;
			State.StateName = this.StateName;
			State.CreatedById = this.CreatedById;
			State.CreatedDate = this.CreatedDate;
			State.LastUpdatedById = this.LastUpdatedById;
			State.LastUpdatedDate = this.LastUpdatedDate;
            State.Version = string.IsNullOrEmpty(this.Version) ? null: Convert.FromBase64String(this.Version);
			return State;
		} 
		public void MapToDtoWithoutCollections(Domain.State State)
		{ 
			this.StateId = State.StateId;
			this.StateCode = State.StateCode;
			this.StateName = State.StateName;
			this.CreatedById = State.CreatedById;
			this.CreatedDate = State.CreatedDate;
			this.LastUpdatedById = State.LastUpdatedById;
			this.LastUpdatedDate = State.LastUpdatedDate;
            this.Version = State.Version == null ? null:Convert.ToBase64String(State.Version);
		} 
		public override TDto MapFromDomainModel<TDomain, TDto>(TDomain domainModel)
		{ 
			Domain.State StateModel = domainModel as Domain.State;
			if(StateModel != null)
			{ 
				MapToDtoWithoutCollections(StateModel);
				foreach(Domain.StateTaxConfiguration StateTaxConfiguration in StateModel.StateTaxConfigurations)
				{ 
					  StateTaxConfiguration StateTaxConfigurationDto = new StateTaxConfiguration();
					  StateTaxConfigurationDto = StateTaxConfigurationDto.MapFromDomainModel<Domain.StateTaxConfiguration, StateTaxConfiguration>(StateTaxConfiguration);
					  this.StateTaxConfigurations.Add(StateTaxConfigurationDto);
				} 
			} 
				return this as TDto;
		} 
		private void MapStateTaxConfigurations(Domain.State destObj)
		{ 
			if (StateTaxConfigurations != null)
			{ 
				foreach(StateTaxConfiguration StateTaxConfiguration in StateTaxConfigurations)
				{ 
					Domain.StateTaxConfiguration StateTaxConfigurationModel;
				   if(StateTaxConfiguration.StateTaxConfigurationId == 0)
				   { 
						StateTaxConfigurationModel = new Domain.StateTaxConfiguration();
						StateTaxConfigurationModel = StateTaxConfiguration.MapToDomainModel<Domain.StateTaxConfiguration>(StateTaxConfigurationModel) as Domain.StateTaxConfiguration;
					    destObj.StateTaxConfigurations.Add(StateTaxConfigurationModel);
				   } 
				   else 
				   { 
						StateTaxConfigurationModel = destObj.StateTaxConfigurations.FirstOrDefault(a => a.StateTaxConfigurationId == StateTaxConfiguration.StateTaxConfigurationId);
					   if (StateTaxConfigurationModel != null)
					   {
							if (StateTaxConfiguration.HardDelete)
							{ 
								destObj.StateTaxConfigurations.Remove(StateTaxConfigurationModel);
							} 
							else 
							{ 
								StateTaxConfigurationModel = StateTaxConfiguration.MapToDomainModel<Domain.StateTaxConfiguration>(StateTaxConfigurationModel) as Domain.StateTaxConfiguration;
							} 
					   } 
					} 
				} 
			} 
		} 
		public override TDomain MapToDomainModel<TDomain>(TDomain domainModel)
		{ 
			Domain.State StateModel = domainModel as Domain.State;
			Domain.State destObj = MapToDomainModelWithoutCollections(StateModel);
		    MapStateTaxConfigurations(destObj);
		    return destObj as TDomain;
		} 
	} 
} 

