using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using CommonLib.DataObjects;
using CommonLib.ModelAttrib;
using Domain = DomainModel.Accounting;
namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{ 
[System.CodeDom.Compiler.GeneratedCode("EF", "6.1.0")]
	public partial class CostingInfoView : BaseDto
	{ 
		public Domain.CostingInfoView MapToDomainModelWithoutCollections(Domain.CostingInfoView CostingInfoView)
		{ 
			CostingInfoView.Amount = this.Amount;
			CostingInfoView.AdjustmentType = this.AdjustmentType;
			CostingInfoView.TotalAmountDue = this.TotalAmountDue;
			CostingInfoView.InvoiceNumber = this.InvoiceNumber;
			CostingInfoView.VendorId = this.VendorId;
			CostingInfoView.VendorName = this.VendorName;
			CostingInfoView.WorkOrderId = this.WorkOrderId;
            //CostingInfoView.Municipality = this.Municipality;
            //CostingInfoView.MunicipalityZipCode = this.MunicipalityZipCode;
            CostingInfoView.isVPR = this.isVPR;
			return CostingInfoView;
		} 
		public void MapToDtoWithoutCollections(Domain.CostingInfoView CostingInfoView)
		{ 
			this.Amount = CostingInfoView.Amount;
			this.AdjustmentType = CostingInfoView.AdjustmentType;
			this.TotalAmountDue = CostingInfoView.TotalAmountDue;
			this.InvoiceNumber = CostingInfoView.InvoiceNumber;
			this.VendorId = CostingInfoView.VendorId;
			this.VendorName = CostingInfoView.VendorName;
			this.WorkOrderId = CostingInfoView.WorkOrderId;
            //this.MunicipalityZipCode = CostingInfoView.MunicipalityZipCode;
            //this.Municipality = CostingInfoView.Municipality;
            this.isVPR = CostingInfoView.isVPR;
		} 
		public override TDto MapFromDomainModel<TDomain, TDto>(TDomain domainModel)
		{ 
			Domain.CostingInfoView CostingInfoViewModel = domainModel as Domain.CostingInfoView;
			if(CostingInfoViewModel != null)
			{ 
				MapToDtoWithoutCollections(CostingInfoViewModel);
			} 
				return this as TDto;
		} 
		public override TDomain MapToDomainModel<TDomain>(TDomain domainModel)
		{ 
			Domain.CostingInfoView CostingInfoViewModel = domainModel as Domain.CostingInfoView;
			Domain.CostingInfoView destObj = MapToDomainModelWithoutCollections(CostingInfoViewModel);
		    return destObj as TDomain;
		} 
	} 
} 

