using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using CommonLib.DataObjects;
using CommonLib.ModelAttrib;
using Domain = DomainModel.Accounting;
namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{ 
[System.CodeDom.Compiler.GeneratedCode("EF", "6.1.0")]
	public partial class BulkException : BaseDto
	{ 
		public Domain.BulkException MapToDomainModelWithoutCollections(Domain.BulkException BulkException)
		{ 
			BulkException.ExceptionCategoryGrpCde = this.ExceptionCategoryGrpCde;
			BulkException.ExceptionCategoryEleCde = this.ExceptionCategoryEleCde;
			BulkException.BulkID = this.BulkID;
			BulkException.FileName = this.FileName;
			BulkException.FileTypeGrpCde = this.FileTypeGrpCde;
			BulkException.FileTypeEleCde = this.FileTypeEleCde;
			BulkException.FileDate = this.FileDate;
			BulkException.FileCount = this.FileCount;
			BulkException.ClientID = this.ClientID;
			BulkException.Status = this.Status;
			BulkException.LineNumber = this.LineNumber;
			BulkException.ErrorDescription = this.ErrorDescription;
			BulkException.BulkExceptionId = this.BulkExceptionId;
			return BulkException;
		} 
		public void MapToDtoWithoutCollections(Domain.BulkException BulkException)
		{ 
			this.ExceptionCategoryGrpCde = BulkException.ExceptionCategoryGrpCde;
			this.ExceptionCategoryEleCde = BulkException.ExceptionCategoryEleCde;
			this.BulkID = BulkException.BulkID;
			this.FileName = BulkException.FileName;
			this.FileTypeGrpCde = BulkException.FileTypeGrpCde;
			this.FileTypeEleCde = BulkException.FileTypeEleCde;
			this.FileDate = BulkException.FileDate;
			this.FileCount = BulkException.FileCount;
			this.ClientID = BulkException.ClientID;
			this.Status = BulkException.Status;
			this.LineNumber = BulkException.LineNumber;
			this.ErrorDescription = BulkException.ErrorDescription;
			this.BulkExceptionId = BulkException.BulkExceptionId;
		} 
		public override TDto MapFromDomainModel<TDomain, TDto>(TDomain domainModel)
		{ 
			Domain.BulkException BulkExceptionModel = domainModel as Domain.BulkException;
			if(BulkExceptionModel != null)
			{ 
				MapToDtoWithoutCollections(BulkExceptionModel);
			} 
				return this as TDto;
		} 
		public override TDomain MapToDomainModel<TDomain>(TDomain domainModel)
		{ 
			Domain.BulkException BulkExceptionModel = domainModel as Domain.BulkException;
			Domain.BulkException destObj = MapToDomainModelWithoutCollections(BulkExceptionModel);
		    return destObj as TDomain;
		} 
	} 
} 

