using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using CommonLib.DataObjects;
using CommonLib.ModelAttrib;
using Domain = DomainModel.Accounting;
namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{ 
[System.CodeDom.Compiler.GeneratedCode("EF", "6.1.0")]
	public partial class AccountsPayableInvoice : BaseDto
	{ 
		public Domain.AccountsPayableInvoice MapToDomainModelWithoutCollections(Domain.AccountsPayableInvoice AccountsPayableInvoice)
		{ 
			AccountsPayableInvoice.ApplicationId = this.ApplicationId;
			AccountsPayableInvoice.VendorProfileId = this.VendorProfileId;
			AccountsPayableInvoice.InvoiceNumber = this.InvoiceNumber;
			AccountsPayableInvoice.InvoiceDate = this.InvoiceDate;
			AccountsPayableInvoice.InvoiceAmount = this.InvoiceAmount;
			AccountsPayableInvoice.CreatedById = this.CreatedById;
			if(this.CreatedDate!=null)
			{
				if(this.CreatedDate.Kind == DateTimeKind.Utc)
					AccountsPayableInvoice.CreatedDate = this.CreatedDate;
				else if(this.CreatedDate.Kind == DateTimeKind.Local)
					AccountsPayableInvoice.CreatedDate = TimeZoneInfo.ConvertTimeToUtc(this.CreatedDate);
				else
					AccountsPayableInvoice.CreatedDate = TimeZoneInfo.ConvertTimeToUtc(this.CreatedDate, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
			}
			else
			{
				AccountsPayableInvoice.CreatedDate = this.CreatedDate;
			}
			AccountsPayableInvoice.LastUpdatedById = this.LastUpdatedById;
			if(this.LastUpdatedDate.HasValue)
			{
				if(this.LastUpdatedDate.Value.Kind == DateTimeKind.Utc)
					AccountsPayableInvoice.LastUpdatedDate = this.LastUpdatedDate;
				else if(this.LastUpdatedDate.Value.Kind == DateTimeKind.Local)
					AccountsPayableInvoice.LastUpdatedDate = TimeZoneInfo.ConvertTimeToUtc(this.LastUpdatedDate.Value);
				else
					AccountsPayableInvoice.LastUpdatedDate = TimeZoneInfo.ConvertTimeToUtc(this.LastUpdatedDate.Value, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
			}
			else
			{
				AccountsPayableInvoice.LastUpdatedDate = this.LastUpdatedDate;
			}
            AccountsPayableInvoice.Version = string.IsNullOrEmpty(this.Version) ? null: Convert.FromBase64String(this.Version);
			AccountsPayableInvoice.AccountsPayableInvoiceId = this.AccountsPayableInvoiceId;
			return AccountsPayableInvoice;
		} 
		public void MapToDtoWithoutCollections(Domain.AccountsPayableInvoice AccountsPayableInvoice)
		{ 
			this.ApplicationId = AccountsPayableInvoice.ApplicationId;
			this.VendorProfileId = AccountsPayableInvoice.VendorProfileId;
			this.InvoiceNumber = AccountsPayableInvoice.InvoiceNumber;
			this.InvoiceDate = AccountsPayableInvoice.InvoiceDate;
			this.InvoiceAmount = AccountsPayableInvoice.InvoiceAmount;
			this.CreatedById = AccountsPayableInvoice.CreatedById;
			if(AccountsPayableInvoice.CreatedDate!=null)
			{
				if(AccountsPayableInvoice.CreatedDate.Kind == DateTimeKind.Utc || AccountsPayableInvoice.CreatedDate.Kind == DateTimeKind.Unspecified)
					this.CreatedDate = TimeZoneInfo.ConvertTimeFromUtc(AccountsPayableInvoice.CreatedDate, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
				else
					this.CreatedDate = TimeZoneInfo.ConvertTime(AccountsPayableInvoice.CreatedDate, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
			}
			else
			{
				this.CreatedDate = AccountsPayableInvoice.CreatedDate;
			}
			this.LastUpdatedById = AccountsPayableInvoice.LastUpdatedById;
			if(AccountsPayableInvoice.LastUpdatedDate.HasValue)
			{
				if(AccountsPayableInvoice.LastUpdatedDate.Value.Kind == DateTimeKind.Utc || AccountsPayableInvoice.LastUpdatedDate.Value.Kind == DateTimeKind.Unspecified)
					this.LastUpdatedDate = TimeZoneInfo.ConvertTimeFromUtc(AccountsPayableInvoice.LastUpdatedDate.Value, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
				else
					this.LastUpdatedDate = TimeZoneInfo.ConvertTime(AccountsPayableInvoice.LastUpdatedDate.Value, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
			}
			else
			{
				this.LastUpdatedDate = AccountsPayableInvoice.LastUpdatedDate;
			}
            this.Version = AccountsPayableInvoice.Version == null ? null:Convert.ToBase64String(AccountsPayableInvoice.Version);
			this.AccountsPayableInvoiceId = AccountsPayableInvoice.AccountsPayableInvoiceId;
		} 
		public override TDto MapFromDomainModel<TDomain, TDto>(TDomain domainModel)
		{ 
			Domain.AccountsPayableInvoice AccountsPayableInvoiceModel = domainModel as Domain.AccountsPayableInvoice;
			if(AccountsPayableInvoiceModel != null)
			{ 
				MapToDtoWithoutCollections(AccountsPayableInvoiceModel);
				foreach(Domain.AccountsPayableAdjustment AccountsPayableAdjustment in AccountsPayableInvoiceModel.AccountsPayableAdjustments)
				{ 
					  AccountsPayableAdjustment AccountsPayableAdjustmentDto = new AccountsPayableAdjustment();
					  AccountsPayableAdjustmentDto = AccountsPayableAdjustmentDto.MapFromDomainModel<Domain.AccountsPayableAdjustment, AccountsPayableAdjustment>(AccountsPayableAdjustment);
					  this.AccountsPayableAdjustments.Add(AccountsPayableAdjustmentDto);
				} 
				foreach(Domain.AccountsPayableRemittance AccountsPayableRemittance in AccountsPayableInvoiceModel.AccountsPayableRemittances)
				{ 
					  AccountsPayableRemittance AccountsPayableRemittanceDto = new AccountsPayableRemittance();
					  AccountsPayableRemittanceDto = AccountsPayableRemittanceDto.MapFromDomainModel<Domain.AccountsPayableRemittance, AccountsPayableRemittance>(AccountsPayableRemittance);
					  this.AccountsPayableRemittances.Add(AccountsPayableRemittanceDto);
				} 
			} 
				return this as TDto;
		} 
		private void MapAccountsPayableAdjustments(Domain.AccountsPayableInvoice destObj)
		{ 
			if (AccountsPayableAdjustments != null)
			{ 
				foreach(AccountsPayableAdjustment AccountsPayableAdjustment in AccountsPayableAdjustments)
				{ 
					Domain.AccountsPayableAdjustment AccountsPayableAdjustmentModel;
				   if(AccountsPayableAdjustment.AccountsPayableAdjustmentId == 0)
				   { 
						AccountsPayableAdjustmentModel = new Domain.AccountsPayableAdjustment();
						AccountsPayableAdjustmentModel = AccountsPayableAdjustment.MapToDomainModel<Domain.AccountsPayableAdjustment>(AccountsPayableAdjustmentModel) as Domain.AccountsPayableAdjustment;
					    destObj.AccountsPayableAdjustments.Add(AccountsPayableAdjustmentModel);
				   } 
				   else 
				   { 
						AccountsPayableAdjustmentModel = destObj.AccountsPayableAdjustments.FirstOrDefault(a => a.AccountsPayableAdjustmentId == AccountsPayableAdjustment.AccountsPayableAdjustmentId);
					   if (AccountsPayableAdjustmentModel != null)
					   {
							if (AccountsPayableAdjustment.HardDelete)
							{ 
								destObj.AccountsPayableAdjustments.Remove(AccountsPayableAdjustmentModel);
							} 
							else 
							{ 
								AccountsPayableAdjustmentModel = AccountsPayableAdjustment.MapToDomainModel<Domain.AccountsPayableAdjustment>(AccountsPayableAdjustmentModel) as Domain.AccountsPayableAdjustment;
							} 
					   } 
					} 
				} 
			} 
		} 
		private void MapAccountsPayableRemittances(Domain.AccountsPayableInvoice destObj)
		{ 
			if (AccountsPayableRemittances != null)
			{ 
				foreach(AccountsPayableRemittance AccountsPayableRemittance in AccountsPayableRemittances)
				{ 
					Domain.AccountsPayableRemittance AccountsPayableRemittanceModel;
				   if(AccountsPayableRemittance.AccountsPayableRemittanceId == 0)
				   { 
						AccountsPayableRemittanceModel = new Domain.AccountsPayableRemittance();
						AccountsPayableRemittanceModel = AccountsPayableRemittance.MapToDomainModel<Domain.AccountsPayableRemittance>(AccountsPayableRemittanceModel) as Domain.AccountsPayableRemittance;
					    destObj.AccountsPayableRemittances.Add(AccountsPayableRemittanceModel);
				   } 
				   else 
				   { 
						AccountsPayableRemittanceModel = destObj.AccountsPayableRemittances.FirstOrDefault(a => a.AccountsPayableRemittanceId == AccountsPayableRemittance.AccountsPayableRemittanceId);
					   if (AccountsPayableRemittanceModel != null)
					   {
							if (AccountsPayableRemittance.HardDelete)
							{ 
								destObj.AccountsPayableRemittances.Remove(AccountsPayableRemittanceModel);
							} 
							else 
							{ 
								AccountsPayableRemittanceModel = AccountsPayableRemittance.MapToDomainModel<Domain.AccountsPayableRemittance>(AccountsPayableRemittanceModel) as Domain.AccountsPayableRemittance;
							} 
					   } 
					} 
				} 
			} 
		} 
		public override TDomain MapToDomainModel<TDomain>(TDomain domainModel)
		{ 
			Domain.AccountsPayableInvoice AccountsPayableInvoiceModel = domainModel as Domain.AccountsPayableInvoice;
			Domain.AccountsPayableInvoice destObj = MapToDomainModelWithoutCollections(AccountsPayableInvoiceModel);
		    MapAccountsPayableAdjustments(destObj);
		    MapAccountsPayableRemittances(destObj);
		    return destObj as TDomain;
		} 
	} 
} 

