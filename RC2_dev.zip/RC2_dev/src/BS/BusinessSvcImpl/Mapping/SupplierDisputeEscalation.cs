using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using CommonLib.DataObjects;
using CommonLib.ModelAttrib;
using Domain = DomainModel.Accounting;
namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{ 
[System.CodeDom.Compiler.GeneratedCode("EF", "6.1.0")]
	public partial class SupplierDisputeEscalation : BaseDto
	{ 
		public Domain.SupplierDisputeEscalation MapToDomainModelWithoutCollections(Domain.SupplierDisputeEscalation SupplierDisputeEscalation)
		{ 
			SupplierDisputeEscalation.SupplierDisputeId = this.SupplierDisputeId;
			SupplierDisputeEscalation.EscalationDisputeStatusGroup = this.EscalationDisputeStatusGroup;
			SupplierDisputeEscalation.EscalationDisputeStatusType = this.EscalationDisputeStatusType;
			SupplierDisputeEscalation.AssignedToUserId = this.AssignedToUserId;
			SupplierDisputeEscalation.EscalationAssignDate = this.EscalationAssignDate;
			SupplierDisputeEscalation.EscalationCompleteDate = this.EscalationCompleteDate;
			SupplierDisputeEscalation.EscalationResolutionStatusGroup = this.EscalationResolutionStatusGroup;
			SupplierDisputeEscalation.EscalationResolutionStatusType = this.EscalationResolutionStatusType;

            SupplierDisputeEscalation.EscalationComments = this.EscalationComments;
            SupplierDisputeEscalation.SLFSEscalationComments = this.SLFSEscalationComments;
            SupplierDisputeEscalation.EscalatedByVendor = this.EscalatedByVendor;
            SupplierDisputeEscalation.EscalationDueDate = this.EscalationDueDate;
			SupplierDisputeEscalation.CreatedById = this.CreatedById;
			SupplierDisputeEscalation.CreatedDate = this.CreatedDate;
			SupplierDisputeEscalation.LastUpdatedById = this.LastUpdatedById;
			SupplierDisputeEscalation.LastUpdatedDate = this.LastUpdatedDate;
            SupplierDisputeEscalation.Version = string.IsNullOrEmpty(this.Version) ? null: Convert.FromBase64String(this.Version);
			SupplierDisputeEscalation.SupplierDisputeEscalationId = this.SupplierDisputeEscalationId;
			return SupplierDisputeEscalation;
		} 
		public void MapToDtoWithoutCollections(Domain.SupplierDisputeEscalation SupplierDisputeEscalation)
		{ 
			this.SupplierDisputeId = SupplierDisputeEscalation.SupplierDisputeId;
			this.EscalationDisputeStatusGroup = SupplierDisputeEscalation.EscalationDisputeStatusGroup;
			this.EscalationDisputeStatusType = SupplierDisputeEscalation.EscalationDisputeStatusType;
			this.AssignedToUserId = SupplierDisputeEscalation.AssignedToUserId;
			this.EscalationAssignDate = SupplierDisputeEscalation.EscalationAssignDate;
			this.EscalationCompleteDate = SupplierDisputeEscalation.EscalationCompleteDate;
			this.EscalationResolutionStatusGroup = SupplierDisputeEscalation.EscalationResolutionStatusGroup;
			this.EscalationResolutionStatusType = SupplierDisputeEscalation.EscalationResolutionStatusType;
			this.CreatedById = SupplierDisputeEscalation.CreatedById;
			this.CreatedDate = SupplierDisputeEscalation.CreatedDate;
			this.LastUpdatedById = SupplierDisputeEscalation.LastUpdatedById;
			this.LastUpdatedDate = SupplierDisputeEscalation.LastUpdatedDate;
            this.Version = SupplierDisputeEscalation.Version == null ? null:Convert.ToBase64String(SupplierDisputeEscalation.Version);
			this.SupplierDisputeEscalationId = SupplierDisputeEscalation.SupplierDisputeEscalationId;


            this.EscalationComments = SupplierDisputeEscalation.EscalationComments;
            this.SLFSEscalationComments = SupplierDisputeEscalation.SLFSEscalationComments;
            this.EscalatedByVendor = SupplierDisputeEscalation.EscalatedByVendor;

            this.EscalationDueDate = SupplierDisputeEscalation.EscalationDueDate;
            
		} 
		public override TDto MapFromDomainModel<TDomain, TDto>(TDomain domainModel)
		{ 
			Domain.SupplierDisputeEscalation SupplierDisputeEscalationModel = domainModel as Domain.SupplierDisputeEscalation;
			if(SupplierDisputeEscalationModel != null)
			{ 
				MapToDtoWithoutCollections(SupplierDisputeEscalationModel);
			} 
				return this as TDto;
		} 
		public override TDomain MapToDomainModel<TDomain>(TDomain domainModel)
		{ 
			Domain.SupplierDisputeEscalation SupplierDisputeEscalationModel = domainModel as Domain.SupplierDisputeEscalation;
			Domain.SupplierDisputeEscalation destObj = MapToDomainModelWithoutCollections(SupplierDisputeEscalationModel);
		    return destObj as TDomain;
		} 
	} 
} 

