using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using CommonLib.DataObjects;
using CommonLib.ModelAttrib;
using Domain = DomainModel.Accounting;
namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{
    [System.CodeDom.Compiler.GeneratedCode("EF", "6.1.0")]
    public partial class FeeType : BaseDto
    {
        public Domain.FeeType MapToDomainModelWithoutCollections(Domain.FeeType FeeType)
        {
            FeeType.IsRevenue = this.IsRevenue;
            FeeType.FeeTypeCode = this.FeeTypeCode;
            FeeType.FeeTypeName = this.FeeTypeName;
            FeeType.CreatedById = this.CreatedById;
            FeeType.CreatedDate = this.CreatedDate;
            FeeType.LastUpdatedById = this.LastUpdatedById;
            FeeType.LastUpdatedDate = this.LastUpdatedDate;
            FeeType.Version = string.IsNullOrEmpty(this.Version) ? null : Convert.FromBase64String(this.Version);
            FeeType.FeeTypeId = this.FeeTypeId;
            return FeeType;
        }
        public void MapToDtoWithoutCollections(Domain.FeeType FeeType)
        {
            this.IsRevenue = FeeType.IsRevenue;
            this.FeeTypeCode = FeeType.FeeTypeCode;
            this.FeeTypeName = FeeType.FeeTypeName;
            this.CreatedById = FeeType.CreatedById;
            this.CreatedDate = FeeType.CreatedDate;
            this.LastUpdatedById = FeeType.LastUpdatedById;
            this.LastUpdatedDate = FeeType.LastUpdatedDate;
            this.Version = FeeType.Version == null ? null : Convert.ToBase64String(FeeType.Version);
            this.FeeTypeId = FeeType.FeeTypeId;
        }
        public override TDto MapFromDomainModel<TDomain, TDto>(TDomain domainModel)
        {
            Domain.FeeType FeeTypeModel = domainModel as Domain.FeeType;
            if (FeeTypeModel != null)
            {
                MapToDtoWithoutCollections(FeeTypeModel);
                foreach (Domain.ProductFeeType ProductFeeType in FeeTypeModel.ProductFeeTypes)
                {
                    ProductFeeType ProductFeeTypeDto = new ProductFeeType();
                    ProductFeeTypeDto = ProductFeeTypeDto.MapFromDomainModel<Domain.ProductFeeType, ProductFeeType>(ProductFeeType);
                    this.ProductFeeTypes.Add(ProductFeeTypeDto);
                }
            }
            return this as TDto;
        }
        private void MapProductFeeTypes(Domain.FeeType destObj)
        {
            if (ProductFeeTypes != null)
            {
                foreach (ProductFeeType ProductFeeType in ProductFeeTypes)
                {
                    Domain.ProductFeeType ProductFeeTypeModel;
                    if (ProductFeeType.ProductFeeTypeId == 0)
                    {
                        ProductFeeTypeModel = new Domain.ProductFeeType();
                        ProductFeeTypeModel = ProductFeeType.MapToDomainModel<Domain.ProductFeeType>(ProductFeeTypeModel) as Domain.ProductFeeType;
                        destObj.ProductFeeTypes.Add(ProductFeeTypeModel);
                    }
                    else
                    {
                        ProductFeeTypeModel = destObj.ProductFeeTypes.FirstOrDefault(a => a.ProductFeeTypeId == ProductFeeType.ProductFeeTypeId);
                        if (ProductFeeTypeModel != null)
                        {
                            if (ProductFeeType.HardDelete)
                            {
                                destObj.ProductFeeTypes.Remove(ProductFeeTypeModel);
                            }
                            else
                            {
                                ProductFeeTypeModel = ProductFeeType.MapToDomainModel<Domain.ProductFeeType>(ProductFeeTypeModel) as Domain.ProductFeeType;
                            }
                        }
                    }
                }
            }
        }
        public override TDomain MapToDomainModel<TDomain>(TDomain domainModel)
        {
            Domain.FeeType FeeTypeModel = domainModel as Domain.FeeType;
            Domain.FeeType destObj = MapToDomainModelWithoutCollections(FeeTypeModel);
            MapProductFeeTypes(destObj);
            return destObj as TDomain;
        }
    }
}

