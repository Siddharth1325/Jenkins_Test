using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using CommonLib.DataObjects;
using CommonLib.ModelAttrib;
using Domain = DomainModel.Accounting;
namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{
    [System.CodeDom.Compiler.GeneratedCode("EF", "6.1.0")]
    public partial class VendorDisputeComment : BaseDto
    {
        public Domain.VendorDisputeComment MapToDomainModelWithoutCollections(Domain.VendorDisputeComment VendorDisputeComment)
        {
            VendorDisputeComment.vendorId = this.vendorId;
            VendorDisputeComment.AccountingDisputeId = this.AccountingDisputeId;
            VendorDisputeComment.VendorCreditAmount = this.VendorCreditAmount;
            VendorDisputeComment.VendorDebitAmount = this.VendorDebitAmount;
            VendorDisputeComment.SLFSResponseTVendor = this.SLFSResponseTVendor;
            VendorDisputeComment.CreatedById = this.CreatedById;
            VendorDisputeComment.CreatedDate = this.CreatedDate;
            VendorDisputeComment.LastUpdatedById = this.LastUpdatedById;
            VendorDisputeComment.LastUpdatedDate = this.LastUpdatedDate;
            VendorDisputeComment.Version = string.IsNullOrEmpty(this.Version) ? null : Convert.FromBase64String(this.Version);
            if (this.accountingDispute != null)
            {
                VendorDisputeComment.accountingDispute = new Domain.AccountingDispute();
                VendorDisputeComment.accountingDispute = this.accountingDispute.MapToDomainModelWithoutCollections(VendorDisputeComment.accountingDispute);
            }
            VendorDisputeComment.VendorDisputeCommentId = this.VendorDisputeCommentId;
            return VendorDisputeComment;
        }
        public void MapToDtoWithoutCollections(Domain.VendorDisputeComment VendorDisputeComment)
        {
            this.vendorId = VendorDisputeComment.vendorId;
            this.AccountingDisputeId = VendorDisputeComment.AccountingDisputeId;
            this.VendorCreditAmount = VendorDisputeComment.VendorCreditAmount;
            this.VendorDebitAmount = VendorDisputeComment.VendorDebitAmount;
            this.SLFSResponseTVendor = VendorDisputeComment.SLFSResponseTVendor;
            this.CreatedById = VendorDisputeComment.CreatedById;
            this.CreatedDate = VendorDisputeComment.CreatedDate;
            this.LastUpdatedById = VendorDisputeComment.LastUpdatedById;
            this.LastUpdatedDate = VendorDisputeComment.LastUpdatedDate;
            this.Version = VendorDisputeComment.Version == null ? null : Convert.ToBase64String(VendorDisputeComment.Version);
            if (VendorDisputeComment.accountingDispute != null)
            {
                this.accountingDispute = new AccountingDispute();
                this.accountingDispute.MapToDtoWithoutCollections(VendorDisputeComment.accountingDispute);
            }
            this.VendorDisputeCommentId = VendorDisputeComment.VendorDisputeCommentId;
        }
        public override TDto MapFromDomainModel<TDomain, TDto>(TDomain domainModel)
        {
            Domain.VendorDisputeComment VendorDisputeCommentModel = domainModel as Domain.VendorDisputeComment;
            if (VendorDisputeCommentModel != null)
            {
                MapToDtoWithoutCollections(VendorDisputeCommentModel);
            }
            return this as TDto;
        }
        public override TDomain MapToDomainModel<TDomain>(TDomain domainModel)
        {
            Domain.VendorDisputeComment VendorDisputeCommentModel = domainModel as Domain.VendorDisputeComment;
            Domain.VendorDisputeComment destObj = MapToDomainModelWithoutCollections(VendorDisputeCommentModel);
            return destObj as TDomain;
        }
    }
}

