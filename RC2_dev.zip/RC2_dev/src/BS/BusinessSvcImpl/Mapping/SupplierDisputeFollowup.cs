using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using CommonLib.DataObjects;
using CommonLib.ModelAttrib;
using Domain = DomainModel.Accounting;
namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{ 
[System.CodeDom.Compiler.GeneratedCode("EF", "6.1.0")]
	public partial class SupplierDisputeFollowup : BaseDto
	{ 
		public Domain.SupplierDisputeFollowup MapToDomainModelWithoutCollections(Domain.SupplierDisputeFollowup SupplierDisputeFollowup)
		{ 
			SupplierDisputeFollowup.SupplierDisputeId = this.SupplierDisputeId;
			SupplierDisputeFollowup.FollowupStatusGroup = this.FollowupStatusGroup;
			SupplierDisputeFollowup.FollowupStatusType = this.FollowupStatusType;
			SupplierDisputeFollowup.AssignedToUserId = this.AssignedToUserId;
			SupplierDisputeFollowup.FollowupAssignDate = this.FollowupAssignDate;
			SupplierDisputeFollowup.FollowupCompleteDate = this.FollowupCompleteDate;
			SupplierDisputeFollowup.FollowupResolutionStatusGroup = this.FollowupResolutionStatusGroup;
			SupplierDisputeFollowup.FollowupResolutionStatusType = this.FollowupResolutionStatusType;
			SupplierDisputeFollowup.CreatedById = this.CreatedById;
			SupplierDisputeFollowup.CreatedDate = this.CreatedDate;
			SupplierDisputeFollowup.LastUpdatedById = this.LastUpdatedById;
			SupplierDisputeFollowup.LastUpdatedDate = this.LastUpdatedDate;
            SupplierDisputeFollowup.Version = string.IsNullOrEmpty(this.Version) ? null: Convert.FromBase64String(this.Version);
			SupplierDisputeFollowup.SupplierDisputeFollowupId = this.SupplierDisputeFollowupId;
			return SupplierDisputeFollowup;
		} 
		public void MapToDtoWithoutCollections(Domain.SupplierDisputeFollowup SupplierDisputeFollowup)
		{ 
			this.SupplierDisputeId = SupplierDisputeFollowup.SupplierDisputeId;
			this.FollowupStatusGroup = SupplierDisputeFollowup.FollowupStatusGroup;
			this.FollowupStatusType = SupplierDisputeFollowup.FollowupStatusType;
			this.AssignedToUserId = SupplierDisputeFollowup.AssignedToUserId;
			this.FollowupAssignDate = SupplierDisputeFollowup.FollowupAssignDate;
			this.FollowupCompleteDate = SupplierDisputeFollowup.FollowupCompleteDate;
			this.FollowupResolutionStatusGroup = SupplierDisputeFollowup.FollowupResolutionStatusGroup;
			this.FollowupResolutionStatusType = SupplierDisputeFollowup.FollowupResolutionStatusType;
			this.CreatedById = SupplierDisputeFollowup.CreatedById;
			this.CreatedDate = SupplierDisputeFollowup.CreatedDate;
			this.LastUpdatedById = SupplierDisputeFollowup.LastUpdatedById;
			this.LastUpdatedDate = SupplierDisputeFollowup.LastUpdatedDate;
            this.Version = SupplierDisputeFollowup.Version == null ? null:Convert.ToBase64String(SupplierDisputeFollowup.Version);
			this.SupplierDisputeFollowupId = SupplierDisputeFollowup.SupplierDisputeFollowupId;
		} 
		public override TDto MapFromDomainModel<TDomain, TDto>(TDomain domainModel)
		{ 
			Domain.SupplierDisputeFollowup SupplierDisputeFollowupModel = domainModel as Domain.SupplierDisputeFollowup;
			if(SupplierDisputeFollowupModel != null)
			{ 
				MapToDtoWithoutCollections(SupplierDisputeFollowupModel);
			} 
				return this as TDto;
		} 
		public override TDomain MapToDomainModel<TDomain>(TDomain domainModel)
		{ 
			Domain.SupplierDisputeFollowup SupplierDisputeFollowupModel = domainModel as Domain.SupplierDisputeFollowup;
			Domain.SupplierDisputeFollowup destObj = MapToDomainModelWithoutCollections(SupplierDisputeFollowupModel);
		    return destObj as TDomain;
		} 
	} 
} 

