using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using CommonLib.DataObjects;
using CommonLib.ModelAttrib;
using Domain = DomainModel.Accounting;
namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{ 
[System.CodeDom.Compiler.GeneratedCode("EF", "6.1.0")]
	public partial class StateTaxConfiguration : BaseDto
	{ 
		public Domain.StateTaxConfiguration MapToDomainModelWithoutCollections(Domain.StateTaxConfiguration StateTaxConfiguration)
		{ 
			StateTaxConfiguration.ApplicationId = this.ApplicationId;
			StateTaxConfiguration.StateCode = this.StateCode;
			StateTaxConfiguration.ProductCategoryGroup = this.ProductCategoryGroup;
			StateTaxConfiguration.ProductCategory = this.ProductCategory;
			StateTaxConfiguration.EnableStateTax = this.EnableStateTax;
			StateTaxConfiguration.CreatedById = this.CreatedById;
			StateTaxConfiguration.CreatedDate = this.CreatedDate;
			StateTaxConfiguration.LastUpdatedById = this.LastUpdatedById;
			StateTaxConfiguration.LastUpdatedDate = this.LastUpdatedDate;
            StateTaxConfiguration.Version = string.IsNullOrEmpty(this.Version) ? null: Convert.FromBase64String(this.Version);
			StateTaxConfiguration.StateTaxConfigurationId = this.StateTaxConfigurationId;
			return StateTaxConfiguration;
		} 
		public void MapToDtoWithoutCollections(Domain.StateTaxConfiguration StateTaxConfiguration)
		{ 
			this.ApplicationId = StateTaxConfiguration.ApplicationId;
			this.StateCode = StateTaxConfiguration.StateCode;
			this.ProductCategoryGroup = StateTaxConfiguration.ProductCategoryGroup;
			this.ProductCategory = StateTaxConfiguration.ProductCategory;
			this.EnableStateTax = StateTaxConfiguration.EnableStateTax;
			this.CreatedById = StateTaxConfiguration.CreatedById;
			this.CreatedDate = StateTaxConfiguration.CreatedDate;
			this.LastUpdatedById = StateTaxConfiguration.LastUpdatedById;
			this.LastUpdatedDate = StateTaxConfiguration.LastUpdatedDate;
            this.Version = StateTaxConfiguration.Version == null ? null:Convert.ToBase64String(StateTaxConfiguration.Version);
			this.StateTaxConfigurationId = StateTaxConfiguration.StateTaxConfigurationId;
		} 
		public override TDto MapFromDomainModel<TDomain, TDto>(TDomain domainModel)
		{ 
			Domain.StateTaxConfiguration StateTaxConfigurationModel = domainModel as Domain.StateTaxConfiguration;
			if(StateTaxConfigurationModel != null)
			{ 
				MapToDtoWithoutCollections(StateTaxConfigurationModel);
			} 
				return this as TDto;
		} 
		public override TDomain MapToDomainModel<TDomain>(TDomain domainModel)
		{ 
			Domain.StateTaxConfiguration StateTaxConfigurationModel = domainModel as Domain.StateTaxConfiguration;
			Domain.StateTaxConfiguration destObj = MapToDomainModelWithoutCollections(StateTaxConfigurationModel);
		    return destObj as TDomain;
		} 
	} 
} 

