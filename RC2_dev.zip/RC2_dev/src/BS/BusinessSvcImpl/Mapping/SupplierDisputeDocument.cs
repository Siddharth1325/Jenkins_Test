using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using CommonLib.DataObjects;
using CommonLib.ModelAttrib;
using Domain = DomainModel.Accounting;
namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{ 
[System.CodeDom.Compiler.GeneratedCode("EF", "6.1.0")]
	public partial class SupplierDisputeDocument : BaseDto
	{ 
		public Domain.SupplierDisputeDocument MapToDomainModelWithoutCollections(Domain.SupplierDisputeDocument SupplierDisputeDocument)
		{ 
			SupplierDisputeDocument.DocumentId = this.DocumentId;
			SupplierDisputeDocument.SupplierDisputeId = this.SupplierDisputeId;
			SupplierDisputeDocument.AdditionalDocumentGroup = this.AdditionalDocumentGroup;
			SupplierDisputeDocument.AdditionalDocumentType = this.AdditionalDocumentType;
            SupplierDisputeDocument.VisibleToVendor = this.VisibleToVendor;
			SupplierDisputeDocument.CreatedById = this.CreatedById;
			SupplierDisputeDocument.CreatedDate = this.CreatedDate;
			SupplierDisputeDocument.LastUpdatedById = this.LastUpdatedById;
			SupplierDisputeDocument.LastUpdatedDate = this.LastUpdatedDate;
            SupplierDisputeDocument.Version = string.IsNullOrEmpty(this.Version) ? null: Convert.FromBase64String(this.Version);
			SupplierDisputeDocument.SupplierDisputeDocumentId = this.SupplierDisputeDocumentId;
			return SupplierDisputeDocument;
		} 
		public void MapToDtoWithoutCollections(Domain.SupplierDisputeDocument SupplierDisputeDocument)
		{ 
			this.DocumentId = SupplierDisputeDocument.DocumentId;
			this.SupplierDisputeId = SupplierDisputeDocument.SupplierDisputeId;
			this.AdditionalDocumentGroup = SupplierDisputeDocument.AdditionalDocumentGroup;
			this.AdditionalDocumentType = SupplierDisputeDocument.AdditionalDocumentType;
            this.VisibleToVendor = SupplierDisputeDocument.VisibleToVendor;
			this.CreatedById = SupplierDisputeDocument.CreatedById;
			this.CreatedDate = SupplierDisputeDocument.CreatedDate;
			this.LastUpdatedById = SupplierDisputeDocument.LastUpdatedById;
			this.LastUpdatedDate = SupplierDisputeDocument.LastUpdatedDate;
            this.Version = SupplierDisputeDocument.Version == null ? null:Convert.ToBase64String(SupplierDisputeDocument.Version);
			this.SupplierDisputeDocumentId = SupplierDisputeDocument.SupplierDisputeDocumentId;
		} 
		public override TDto MapFromDomainModel<TDomain, TDto>(TDomain domainModel)
		{ 
			Domain.SupplierDisputeDocument SupplierDisputeDocumentModel = domainModel as Domain.SupplierDisputeDocument;
			if(SupplierDisputeDocumentModel != null)
			{ 
				MapToDtoWithoutCollections(SupplierDisputeDocumentModel);
			} 
				return this as TDto;
		} 
		public override TDomain MapToDomainModel<TDomain>(TDomain domainModel)
		{ 
			Domain.SupplierDisputeDocument SupplierDisputeDocumentModel = domainModel as Domain.SupplierDisputeDocument;
			Domain.SupplierDisputeDocument destObj = MapToDomainModelWithoutCollections(SupplierDisputeDocumentModel);
		    return destObj as TDomain;
		} 
	} 
} 

