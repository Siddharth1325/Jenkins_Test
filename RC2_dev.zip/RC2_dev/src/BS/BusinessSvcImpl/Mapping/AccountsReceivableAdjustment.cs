using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using CommonLib.DataObjects;
using CommonLib.ModelAttrib;
using Domain = DomainModel.Accounting;
namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{ 
[System.CodeDom.Compiler.GeneratedCode("EF", "6.1.0")]
	public partial class AccountsReceivableAdjustment : BaseDto
	{ 
		public Domain.AccountsReceivableAdjustment MapToDomainModelWithoutCollections(Domain.AccountsReceivableAdjustment AccountsReceivableAdjustment)
		{ 
			AccountsReceivableAdjustment.ApplicationId = this.ApplicationId;
			AccountsReceivableAdjustment.AccountsReceivableInvoiceId = this.AccountsReceivableInvoiceId;
            AccountsReceivableAdjustment.AccountsReceivableDetailId = this.AccountsReceivableDetailId;
            AccountsReceivableAdjustment.DisputeReceivableAdjustmentHistoryId = this.DisputeReceivableAdjustmentHistoryId;
			AccountsReceivableAdjustment.WorkOrderId = this.WorkOrderId;
			AccountsReceivableAdjustment.AdjustmentType = this.AdjustmentType;
			AccountsReceivableAdjustment.AdjustmentCode = this.AdjustmentCode;
			AccountsReceivableAdjustment.AdjustmentDate = this.AdjustmentDate;
			AccountsReceivableAdjustment.Amount = this.Amount;
			AccountsReceivableAdjustment.GLTransTypeGroup = this.GLTransTypeGroup;
			AccountsReceivableAdjustment.GLTransType = this.GLTransType;
			AccountsReceivableAdjustment.ReserveType = this.ReserveType;
			AccountsReceivableAdjustment.Operation = this.Operation;
			AccountsReceivableAdjustment.Function = this.Function;
			AccountsReceivableAdjustment.NaturalAccount = this.NaturalAccount;
			AccountsReceivableAdjustment.Comments = this.Comments;
			AccountsReceivableAdjustment.CreatedById = this.CreatedById;
			if(this.CreatedDate!=null)
			{
				if(this.CreatedDate.Kind == DateTimeKind.Utc)
					AccountsReceivableAdjustment.CreatedDate = this.CreatedDate;
				else if(this.CreatedDate.Kind == DateTimeKind.Local)
					AccountsReceivableAdjustment.CreatedDate = TimeZoneInfo.ConvertTimeToUtc(this.CreatedDate);
				else
					AccountsReceivableAdjustment.CreatedDate = TimeZoneInfo.ConvertTimeToUtc(this.CreatedDate, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
			}
			else
			{
				AccountsReceivableAdjustment.CreatedDate = this.CreatedDate;
			}
			AccountsReceivableAdjustment.LastUpdatedById = this.LastUpdatedById;
			if(this.LastUpdatedDate.HasValue)
			{
				if(this.LastUpdatedDate.Value.Kind == DateTimeKind.Utc)
					AccountsReceivableAdjustment.LastUpdatedDate = this.LastUpdatedDate;
				else if(this.LastUpdatedDate.Value.Kind == DateTimeKind.Local)
					AccountsReceivableAdjustment.LastUpdatedDate = TimeZoneInfo.ConvertTimeToUtc(this.LastUpdatedDate.Value);
				else
					AccountsReceivableAdjustment.LastUpdatedDate = TimeZoneInfo.ConvertTimeToUtc(this.LastUpdatedDate.Value, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
			}
			else
			{
				AccountsReceivableAdjustment.LastUpdatedDate = this.LastUpdatedDate;
			}
            AccountsReceivableAdjustment.Version = string.IsNullOrEmpty(this.Version) ? null: Convert.FromBase64String(this.Version);
			AccountsReceivableAdjustment.AccountsReceivableAdjustmentId = this.AccountsReceivableAdjustmentId;
			return AccountsReceivableAdjustment;
		} 
		public void MapToDtoWithoutCollections(Domain.AccountsReceivableAdjustment AccountsReceivableAdjustment)
		{ 
			this.ApplicationId = AccountsReceivableAdjustment.ApplicationId;
			this.AccountsReceivableInvoiceId = AccountsReceivableAdjustment.AccountsReceivableInvoiceId;
            this.AccountsReceivableDetailId = AccountsReceivableAdjustment.AccountsReceivableDetailId;
            this.DisputeReceivableAdjustmentHistoryId = AccountsReceivableAdjustment.DisputeReceivableAdjustmentHistoryId;
			this.WorkOrderId = AccountsReceivableAdjustment.WorkOrderId;
			this.AdjustmentType = AccountsReceivableAdjustment.AdjustmentType;
			this.AdjustmentCode = AccountsReceivableAdjustment.AdjustmentCode;
			this.AdjustmentDate = AccountsReceivableAdjustment.AdjustmentDate;
			this.Amount = AccountsReceivableAdjustment.Amount;
			this.GLTransTypeGroup = AccountsReceivableAdjustment.GLTransTypeGroup;
			this.GLTransType = AccountsReceivableAdjustment.GLTransType;
			this.ReserveType = AccountsReceivableAdjustment.ReserveType;
			this.Operation = AccountsReceivableAdjustment.Operation;
			this.Function = AccountsReceivableAdjustment.Function;
			this.NaturalAccount = AccountsReceivableAdjustment.NaturalAccount;
			this.Comments = AccountsReceivableAdjustment.Comments;
			this.CreatedById = AccountsReceivableAdjustment.CreatedById;
			if(AccountsReceivableAdjustment.CreatedDate!=null)
			{
				if(AccountsReceivableAdjustment.CreatedDate.Kind == DateTimeKind.Utc || AccountsReceivableAdjustment.CreatedDate.Kind == DateTimeKind.Unspecified)
					this.CreatedDate = TimeZoneInfo.ConvertTimeFromUtc(AccountsReceivableAdjustment.CreatedDate, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
				else
					this.CreatedDate = TimeZoneInfo.ConvertTime(AccountsReceivableAdjustment.CreatedDate, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
			}
			else
			{
				this.CreatedDate = AccountsReceivableAdjustment.CreatedDate;
			}
			this.LastUpdatedById = AccountsReceivableAdjustment.LastUpdatedById;
			if(AccountsReceivableAdjustment.LastUpdatedDate.HasValue)
			{
				if(AccountsReceivableAdjustment.LastUpdatedDate.Value.Kind == DateTimeKind.Utc || AccountsReceivableAdjustment.LastUpdatedDate.Value.Kind == DateTimeKind.Unspecified)
					this.LastUpdatedDate = TimeZoneInfo.ConvertTimeFromUtc(AccountsReceivableAdjustment.LastUpdatedDate.Value, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
				else
					this.LastUpdatedDate = TimeZoneInfo.ConvertTime(AccountsReceivableAdjustment.LastUpdatedDate.Value, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
			}
			else
			{
				this.LastUpdatedDate = AccountsReceivableAdjustment.LastUpdatedDate;
			}
            this.Version = AccountsReceivableAdjustment.Version == null ? null:Convert.ToBase64String(AccountsReceivableAdjustment.Version);
			this.AccountsReceivableAdjustmentId = AccountsReceivableAdjustment.AccountsReceivableAdjustmentId;
		} 
		public override TDto MapFromDomainModel<TDomain, TDto>(TDomain domainModel)
		{ 
			Domain.AccountsReceivableAdjustment AccountsReceivableAdjustmentModel = domainModel as Domain.AccountsReceivableAdjustment;
			if(AccountsReceivableAdjustmentModel != null)
			{ 
				MapToDtoWithoutCollections(AccountsReceivableAdjustmentModel);
				foreach(Domain.AccountsTax AccountsTax in AccountsReceivableAdjustmentModel.AccountsTax)
				{ 
					  AccountsTax AccountsTaxDto = new AccountsTax();
					  AccountsTaxDto = AccountsTaxDto.MapFromDomainModel<Domain.AccountsTax, AccountsTax>(AccountsTax);
					  this.AccountsTax.Add(AccountsTaxDto);
				} 
			} 
				return this as TDto;
		} 
		private void MapAccountsTax(Domain.AccountsReceivableAdjustment destObj)
		{ 
			if (AccountsTax != null)
			{ 
				foreach(AccountsTax accountsTax in AccountsTax)
				{ 
					Domain.AccountsTax AccountsTaxModel;
				   if(accountsTax.AccountsTaxId == 0)
				   { 
						AccountsTaxModel = new Domain.AccountsTax();
						AccountsTaxModel = accountsTax.MapToDomainModel<Domain.AccountsTax>(AccountsTaxModel) as Domain.AccountsTax;
					    destObj.AccountsTax.Add(AccountsTaxModel);
				   } 
				   else 
				   { 
						AccountsTaxModel = destObj.AccountsTax.FirstOrDefault(a => a.AccountsTaxId == accountsTax.AccountsTaxId);
					   if (AccountsTaxModel != null)
					   {
							if (accountsTax.HardDelete)
							{ 
								destObj.AccountsTax.Remove(AccountsTaxModel);
							} 
							else 
							{ 
								AccountsTaxModel = accountsTax.MapToDomainModel<Domain.AccountsTax>(AccountsTaxModel) as Domain.AccountsTax;
							} 
					   } 
					} 
				} 
			} 
		} 
		public override TDomain MapToDomainModel<TDomain>(TDomain domainModel)
		{ 
			Domain.AccountsReceivableAdjustment AccountsReceivableAdjustmentModel = domainModel as Domain.AccountsReceivableAdjustment;
			Domain.AccountsReceivableAdjustment destObj = MapToDomainModelWithoutCollections(AccountsReceivableAdjustmentModel);
		    MapAccountsTax(destObj);
		    return destObj as TDomain;
		} 
	} 
} 

