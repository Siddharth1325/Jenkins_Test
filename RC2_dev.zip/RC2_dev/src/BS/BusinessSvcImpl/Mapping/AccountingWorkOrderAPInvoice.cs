using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using CommonLib.DataObjects;
using CommonLib.ModelAttrib;
using Domain = DomainModel.Accounting;
namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{ 
[System.CodeDom.Compiler.GeneratedCode("EF", "6.1.0")]
	public partial class AccountingWorkOrderAPInvoice : BaseDto
	{ 
		public Domain.AccountingWorkOrderAPInvoice MapToDomainModelWithoutCollections(Domain.AccountingWorkOrderAPInvoice AccountingWorkOrderAPInvoice)
		{ 
			AccountingWorkOrderAPInvoice.WorkOrderId = this.WorkOrderId;
			AccountingWorkOrderAPInvoice.AccountsPayableInvoiceId = this.AccountsPayableInvoiceId;
			AccountingWorkOrderAPInvoice.CreatedById = this.CreatedById;
			if(this.CreatedDate!=null)
			{
				if(this.CreatedDate.Kind == DateTimeKind.Utc)
					AccountingWorkOrderAPInvoice.CreatedDate = this.CreatedDate;
				else if(this.CreatedDate.Kind == DateTimeKind.Local)
					AccountingWorkOrderAPInvoice.CreatedDate = TimeZoneInfo.ConvertTimeToUtc(this.CreatedDate);
				else
					AccountingWorkOrderAPInvoice.CreatedDate = TimeZoneInfo.ConvertTimeToUtc(this.CreatedDate, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
			}
			else
			{
				AccountingWorkOrderAPInvoice.CreatedDate = this.CreatedDate;
			}
			AccountingWorkOrderAPInvoice.LastUpdatedById = this.LastUpdatedById;
			if(this.LastUpdatedDate.HasValue)
			{
				if(this.LastUpdatedDate.Value.Kind == DateTimeKind.Utc)
					AccountingWorkOrderAPInvoice.LastUpdatedDate = this.LastUpdatedDate;
				else if(this.LastUpdatedDate.Value.Kind == DateTimeKind.Local)
					AccountingWorkOrderAPInvoice.LastUpdatedDate = TimeZoneInfo.ConvertTimeToUtc(this.LastUpdatedDate.Value);
				else
					AccountingWorkOrderAPInvoice.LastUpdatedDate = TimeZoneInfo.ConvertTimeToUtc(this.LastUpdatedDate.Value, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
			}
			else
			{
				AccountingWorkOrderAPInvoice.LastUpdatedDate = this.LastUpdatedDate;
			}
            AccountingWorkOrderAPInvoice.Version = string.IsNullOrEmpty(this.Version) ? null: Convert.FromBase64String(this.Version);
			AccountingWorkOrderAPInvoice.WorkOrderAPInvoiceId = this.WorkOrderAPInvoiceId;
			return AccountingWorkOrderAPInvoice;
		} 
		public void MapToDtoWithoutCollections(Domain.AccountingWorkOrderAPInvoice AccountingWorkOrderAPInvoice)
		{ 
			this.WorkOrderId = AccountingWorkOrderAPInvoice.WorkOrderId;
			this.AccountsPayableInvoiceId = AccountingWorkOrderAPInvoice.AccountsPayableInvoiceId;
			this.CreatedById = AccountingWorkOrderAPInvoice.CreatedById;
			if(AccountingWorkOrderAPInvoice.CreatedDate!=null)
			{
				if(AccountingWorkOrderAPInvoice.CreatedDate.Kind == DateTimeKind.Utc || AccountingWorkOrderAPInvoice.CreatedDate.Kind == DateTimeKind.Unspecified)
					this.CreatedDate = TimeZoneInfo.ConvertTimeFromUtc(AccountingWorkOrderAPInvoice.CreatedDate, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
				else
					this.CreatedDate = TimeZoneInfo.ConvertTime(AccountingWorkOrderAPInvoice.CreatedDate, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
			}
			else
			{
				this.CreatedDate = AccountingWorkOrderAPInvoice.CreatedDate;
			}
			this.LastUpdatedById = AccountingWorkOrderAPInvoice.LastUpdatedById;
			if(AccountingWorkOrderAPInvoice.LastUpdatedDate.HasValue)
			{
				if(AccountingWorkOrderAPInvoice.LastUpdatedDate.Value.Kind == DateTimeKind.Utc || AccountingWorkOrderAPInvoice.LastUpdatedDate.Value.Kind == DateTimeKind.Unspecified)
					this.LastUpdatedDate = TimeZoneInfo.ConvertTimeFromUtc(AccountingWorkOrderAPInvoice.LastUpdatedDate.Value, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
				else
					this.LastUpdatedDate = TimeZoneInfo.ConvertTime(AccountingWorkOrderAPInvoice.LastUpdatedDate.Value, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
			}
			else
			{
				this.LastUpdatedDate = AccountingWorkOrderAPInvoice.LastUpdatedDate;
			}
            this.Version = AccountingWorkOrderAPInvoice.Version == null ? null:Convert.ToBase64String(AccountingWorkOrderAPInvoice.Version);
			this.WorkOrderAPInvoiceId = AccountingWorkOrderAPInvoice.WorkOrderAPInvoiceId;
		} 
		public override TDto MapFromDomainModel<TDomain, TDto>(TDomain domainModel)
		{ 
			Domain.AccountingWorkOrderAPInvoice AccountingWorkOrderAPInvoiceModel = domainModel as Domain.AccountingWorkOrderAPInvoice;
			if(AccountingWorkOrderAPInvoiceModel != null)
			{ 
				MapToDtoWithoutCollections(AccountingWorkOrderAPInvoiceModel);
			} 
				return this as TDto;
		} 
		public override TDomain MapToDomainModel<TDomain>(TDomain domainModel)
		{ 
			Domain.AccountingWorkOrderAPInvoice AccountingWorkOrderAPInvoiceModel = domainModel as Domain.AccountingWorkOrderAPInvoice;
			Domain.AccountingWorkOrderAPInvoice destObj = MapToDomainModelWithoutCollections(AccountingWorkOrderAPInvoiceModel);
		    return destObj as TDomain;
		} 
	} 
} 

