using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using CommonLib.DataObjects;
using CommonLib.ModelAttrib;
using Domain = DomainModel.Accounting;
namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{ 
[System.CodeDom.Compiler.GeneratedCode("EF", "6.1.0")]
	public partial class Application : BaseDto
	{ 
		public Domain.Application MapToDomainModelWithoutCollections(Domain.Application Application)
		{ 
			Application.ApplicationName = this.ApplicationName;
			Application.ApplicationCode = this.ApplicationCode;
			Application.ApplicationDesc = this.ApplicationDesc;
			Application.IsActive = this.IsActive;
			Application.CreatedById = this.CreatedById;
			if(this.CreatedDate!=null)
			{
				if(this.CreatedDate.Kind == DateTimeKind.Utc)
					Application.CreatedDate = this.CreatedDate;
				else if(this.CreatedDate.Kind == DateTimeKind.Local)
					Application.CreatedDate = TimeZoneInfo.ConvertTimeToUtc(this.CreatedDate);
				else
					Application.CreatedDate = TimeZoneInfo.ConvertTimeToUtc(this.CreatedDate, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
			}
			else
			{
				Application.CreatedDate = this.CreatedDate;
			}
			Application.LastUpdatedById = this.LastUpdatedById;
			if(this.LastUpdatedDate.HasValue)
			{
				if(this.LastUpdatedDate.Value.Kind == DateTimeKind.Utc)
					Application.LastUpdatedDate = this.LastUpdatedDate;
				else if(this.LastUpdatedDate.Value.Kind == DateTimeKind.Local)
					Application.LastUpdatedDate = TimeZoneInfo.ConvertTimeToUtc(this.LastUpdatedDate.Value);
				else
					Application.LastUpdatedDate = TimeZoneInfo.ConvertTimeToUtc(this.LastUpdatedDate.Value, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
			}
			else
			{
				Application.LastUpdatedDate = this.LastUpdatedDate;
			}
            Application.Version = string.IsNullOrEmpty(this.Version) ? null: Convert.FromBase64String(this.Version);
			Application.ApplicationId = this.ApplicationId;
			return Application;
		} 
		public void MapToDtoWithoutCollections(Domain.Application Application)
		{ 
			this.ApplicationName = Application.ApplicationName;
			this.ApplicationCode = Application.ApplicationCode;
			this.ApplicationDesc = Application.ApplicationDesc;
			this.IsActive = Application.IsActive;
			this.CreatedById = Application.CreatedById;
			if(Application.CreatedDate!=null)
			{
				if(Application.CreatedDate.Kind == DateTimeKind.Utc || Application.CreatedDate.Kind == DateTimeKind.Unspecified)
					this.CreatedDate = TimeZoneInfo.ConvertTimeFromUtc(Application.CreatedDate, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
				else
					this.CreatedDate = TimeZoneInfo.ConvertTime(Application.CreatedDate, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
			}
			else
			{
				this.CreatedDate = Application.CreatedDate;
			}
			this.LastUpdatedById = Application.LastUpdatedById;
			if(Application.LastUpdatedDate.HasValue)
			{
				if(Application.LastUpdatedDate.Value.Kind == DateTimeKind.Utc || Application.LastUpdatedDate.Value.Kind == DateTimeKind.Unspecified)
					this.LastUpdatedDate = TimeZoneInfo.ConvertTimeFromUtc(Application.LastUpdatedDate.Value, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
				else
					this.LastUpdatedDate = TimeZoneInfo.ConvertTime(Application.LastUpdatedDate.Value, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
			}
			else
			{
				this.LastUpdatedDate = Application.LastUpdatedDate;
			}
            this.Version = Application.Version == null ? null:Convert.ToBase64String(Application.Version);
			this.ApplicationId = Application.ApplicationId;
		} 
		public override TDto MapFromDomainModel<TDomain, TDto>(TDomain domainModel)
		{ 
			Domain.Application ApplicationModel = domainModel as Domain.Application;
			if(ApplicationModel != null)
			{ 
				MapToDtoWithoutCollections(ApplicationModel);
			} 
				return this as TDto;
		} 
		public override TDomain MapToDomainModel<TDomain>(TDomain domainModel)
		{ 
			Domain.Application ApplicationModel = domainModel as Domain.Application;
			Domain.Application destObj = MapToDomainModelWithoutCollections(ApplicationModel);
		    return destObj as TDomain;
		} 
	} 
} 

