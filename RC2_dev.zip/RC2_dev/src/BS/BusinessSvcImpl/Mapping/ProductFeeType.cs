using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using CommonLib.DataObjects;
using CommonLib.ModelAttrib;
using Domain = DomainModel.Accounting;
namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{ 
[System.CodeDom.Compiler.GeneratedCode("EF", "6.1.0")]
	public partial class ProductFeeType : BaseDto
	{ 
		public Domain.ProductFeeType MapToDomainModelWithoutCollections(Domain.ProductFeeType ProductFeeType)
		{ 
			ProductFeeType.FeeTypeId = this.FeeTypeId;
			ProductFeeType.ProductId = this.ProductId;
			ProductFeeType.CreatedById = this.CreatedById;
			ProductFeeType.CreatedDate = this.CreatedDate;
			ProductFeeType.LastUpdatedById = this.LastUpdatedById;
			ProductFeeType.LastUpdatedDate = this.LastUpdatedDate;
            ProductFeeType.Version = string.IsNullOrEmpty(this.Version) ? null: Convert.FromBase64String(this.Version);
			if (this.FeeType != null)
			{ 
				ProductFeeType.FeeType = new Domain.FeeType();
				ProductFeeType.FeeType = this.FeeType.MapToDomainModelWithoutCollections(ProductFeeType.FeeType);
			} 
			ProductFeeType.ProductFeeTypeId = this.ProductFeeTypeId;
			return ProductFeeType;
		} 
		public void MapToDtoWithoutCollections(Domain.ProductFeeType ProductFeeType)
		{ 
			this.FeeTypeId = ProductFeeType.FeeTypeId;
			this.ProductId = ProductFeeType.ProductId;
			this.CreatedById = ProductFeeType.CreatedById;
			this.CreatedDate = ProductFeeType.CreatedDate;
			this.LastUpdatedById = ProductFeeType.LastUpdatedById;
			this.LastUpdatedDate = ProductFeeType.LastUpdatedDate;
            this.Version = ProductFeeType.Version == null ? null:Convert.ToBase64String(ProductFeeType.Version);
			if (ProductFeeType.FeeType != null)
			{ 
				this.FeeType = new FeeType();
				this.FeeType.MapToDtoWithoutCollections(ProductFeeType.FeeType);
			} 
			this.ProductFeeTypeId = ProductFeeType.ProductFeeTypeId;
		} 
		public override TDto MapFromDomainModel<TDomain, TDto>(TDomain domainModel)
		{ 
			Domain.ProductFeeType ProductFeeTypeModel = domainModel as Domain.ProductFeeType;
			if(ProductFeeTypeModel != null)
			{ 
				MapToDtoWithoutCollections(ProductFeeTypeModel);
			} 
				return this as TDto;
		} 
		public override TDomain MapToDomainModel<TDomain>(TDomain domainModel)
		{ 
			Domain.ProductFeeType ProductFeeTypeModel = domainModel as Domain.ProductFeeType;
			Domain.ProductFeeType destObj = MapToDomainModelWithoutCollections(ProductFeeTypeModel);
		    return destObj as TDomain;
		} 
	} 
} 

