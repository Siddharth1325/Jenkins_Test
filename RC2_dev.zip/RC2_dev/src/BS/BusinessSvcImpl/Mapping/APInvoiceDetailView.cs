using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using CommonLib.DataObjects;
using CommonLib.ModelAttrib;
using Domain = DomainModel.Accounting;
namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{ 
[System.CodeDom.Compiler.GeneratedCode("EF", "6.1.0")]
	public partial class APInvoiceDetailView : BaseDto
	{ 
		public Domain.APInvoiceDetailView MapToDomainModelWithoutCollections(Domain.APInvoiceDetailView APInvoiceDetailView)
		{ 
			APInvoiceDetailView.InvoiceNumber = this.InvoiceNumber;
			APInvoiceDetailView.ApplicationId = this.ApplicationId;
			APInvoiceDetailView.VendorProfileId = this.VendorProfileId;
			APInvoiceDetailView.WorkOrderId = this.WorkOrderId;
			APInvoiceDetailView.InspectorUniqueId = this.InspectorUniqueId;
            APInvoiceDetailView.FinalTotalCost = this.InvoiceAmount;
			APInvoiceDetailView.AssignedDate = this.AssignedDate;
			APInvoiceDetailView.CompletedDate = this.CompletedDate;
			APInvoiceDetailView.ProductCategory = this.ProductCode;
			APInvoiceDetailView.EligibleOccupancyType = this.Occupancy;
			APInvoiceDetailView.PropertyAddress = this.PropertyAddress;
			APInvoiceDetailView.PriceAdjReason = this.PriceAdjReason;
            APInvoiceDetailView.ServiceName = this.ProductName;
            APInvoiceDetailView.AccountsPayableAdjustmentId = this.AccountsPayableAdjustmentId;
            APInvoiceDetailView.SourceVendorWorkOrderId = this.SourceVendorWorkOrderId;
			return APInvoiceDetailView;
		} 
		public void MapToDtoWithoutCollections(Domain.APInvoiceDetailView APInvoiceDetailView)
		{ 
			this.InvoiceNumber = APInvoiceDetailView.InvoiceNumber;
			this.ApplicationId = APInvoiceDetailView.ApplicationId;
			this.VendorProfileId = APInvoiceDetailView.VendorProfileId;
			this.WorkOrderId = APInvoiceDetailView.WorkOrderId;
			this.InspectorUniqueId = APInvoiceDetailView.InspectorUniqueId;
            this.InvoiceAmount = APInvoiceDetailView.FinalTotalCost;
			this.AssignedDate = APInvoiceDetailView.AssignedDate;
			this.CompletedDate = APInvoiceDetailView.CompletedDate;
			this.ProductCode = APInvoiceDetailView.ProductCategory;
			this.Occupancy = APInvoiceDetailView.EligibleOccupancyType;
			this.PropertyAddress = APInvoiceDetailView.PropertyAddress;
			this.PriceAdjReason = APInvoiceDetailView.PriceAdjReason;
            this.ProductName = APInvoiceDetailView.ServiceName;
            this.AccountsPayableAdjustmentId = APInvoiceDetailView.AccountsPayableAdjustmentId;
            this.SourceVendorWorkOrderId = APInvoiceDetailView.SourceVendorWorkOrderId;
            this.QCSupplierComment = APInvoiceDetailView.QCSupplierComment;
		} 
		public override TDto MapFromDomainModel<TDomain, TDto>(TDomain domainModel)
		{ 
			Domain.APInvoiceDetailView APInvoiceDetailViewModel = domainModel as Domain.APInvoiceDetailView;
			if(APInvoiceDetailViewModel != null)
			{ 
				MapToDtoWithoutCollections(APInvoiceDetailViewModel);
			} 
				return this as TDto;
		} 
		public override TDomain MapToDomainModel<TDomain>(TDomain domainModel)
		{ 
			Domain.APInvoiceDetailView APInvoiceDetailViewModel = domainModel as Domain.APInvoiceDetailView;
			Domain.APInvoiceDetailView destObj = MapToDomainModelWithoutCollections(APInvoiceDetailViewModel);
		    return destObj as TDomain;
		} 
	} 
} 

