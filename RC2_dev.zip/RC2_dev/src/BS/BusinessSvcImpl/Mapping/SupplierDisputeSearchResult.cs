using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using CommonLib.DataObjects;
using CommonLib.ModelAttrib;
using Domain = DomainModel.Accounting;
namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{ 
[System.CodeDom.Compiler.GeneratedCode("EF", "6.1.0")]
	public partial class SupplierDisputeSearchResult : BaseDto
	{ 
		public Domain.SupplierDisputeSearchResult MapToDomainModelWithoutCollections(Domain.SupplierDisputeSearchResult SupplierDisputeSearchResult)
		{ 
			SupplierDisputeSearchResult.BulkId = this.BulkId;
			SupplierDisputeSearchResult.VendorId = this.VendorId;
			SupplierDisputeSearchResult.FieldScapeWorkOrderId = this.FieldScapeWorkOrderId;
			SupplierDisputeSearchResult.InspWorkOrderId = this.InspWorkOrderId;
			SupplierDisputeSearchResult.VendorWorkOrderId = this.VendorWorkOrderId;
			SupplierDisputeSearchResult.DisputeDate = this.DisputeDate;
			SupplierDisputeSearchResult.DisputeDueDate = this.DisputeDueDate;
			SupplierDisputeSearchResult.DisputeStatus = this.DisputeStatus;
			SupplierDisputeSearchResult.DisputeStatusType = this.DisputeStatusType;
			SupplierDisputeSearchResult.EscalationResolutionStatusType = this.EscalationResolutionStatusType;
			SupplierDisputeSearchResult.EscalationResolutionStatus = this.EscalationResolutionStatus;
			SupplierDisputeSearchResult.EscalationDueDate = this.EscalationDueDate;
			SupplierDisputeSearchResult.AdditionalAmtApproved = this.AdditionalAmtApproved;
			SupplierDisputeSearchResult.DisputeReason = this.DisputeReason;
			SupplierDisputeSearchResult.VendorDisputeComments = this.VendorDisputeComments;
			SupplierDisputeSearchResult.DisputeResolutionType = this.DisputeResolutionType;
			SupplierDisputeSearchResult.DisputeResolution = this.DisputeResolution;
			SupplierDisputeSearchResult.DisputeCompletedDate = this.DisputeCompletedDate;
			SupplierDisputeSearchResult.SLFSResponseToVendor = this.SLFSResponseToVendor;
			SupplierDisputeSearchResult.EscalationCompleteDate = this.EscalationCompleteDate;
			SupplierDisputeSearchResult.EscalationComments = this.EscalationComments;
			SupplierDisputeSearchResult.EscalationDate = this.EscalationDate;
			SupplierDisputeSearchResult.SLFSResponseToEscalation = this.SLFSResponseToEscalation;
			SupplierDisputeSearchResult.SupplierDisputeId = this.SupplierDisputeId;
            SupplierDisputeSearchResult.EscalatedByVendor = this.EscalatedByVendor;
            SupplierDisputeSearchResult.VendorName = this.VendorName;
            SupplierDisputeSearchResult.PropertyAddress1 = this.PropertyAddress1;
            SupplierDisputeSearchResult.PropertyAddress2 = this.PropertyAddress2;
            SupplierDisputeSearchResult.PropertyCity = this.PropertyCity;
            SupplierDisputeSearchResult.PropertyState = this.PropertyState;
            SupplierDisputeSearchResult.PropertyZip = this.PropertyZip;
            SupplierDisputeSearchResult.ProductName = this.ProductName;
            SupplierDisputeSearchResult.ClientNumber = this.ClientNumber;
            SupplierDisputeSearchResult.DisputeAmount = this.DisputeAmount;
            SupplierDisputeSearchResult.Decision = this.Decision;
            SupplierDisputeSearchResult.Resolution = this.Resolution;
            SupplierDisputeSearchResult.EscalationDecision = this.EscalationDecision;
            SupplierDisputeSearchResult.SLFSEscalationComments = this.SLFSEscalationComments;
			return SupplierDisputeSearchResult;
		} 
		public void MapToDtoWithoutCollections(Domain.SupplierDisputeSearchResult SupplierDisputeSearchResult)
		{ 
			this.BulkId = SupplierDisputeSearchResult.BulkId;
			this.VendorId = SupplierDisputeSearchResult.VendorId;
			this.FieldScapeWorkOrderId = SupplierDisputeSearchResult.FieldScapeWorkOrderId;
			this.InspWorkOrderId = SupplierDisputeSearchResult.InspWorkOrderId;
			this.VendorWorkOrderId = SupplierDisputeSearchResult.VendorWorkOrderId;
			this.DisputeDate = SupplierDisputeSearchResult.DisputeDate;
			this.DisputeDueDate = SupplierDisputeSearchResult.DisputeDueDate;
			this.DisputeStatus = SupplierDisputeSearchResult.DisputeStatus;
			this.DisputeStatusType = SupplierDisputeSearchResult.DisputeStatusType;
			this.EscalationResolutionStatusType = SupplierDisputeSearchResult.EscalationResolutionStatusType;
			this.EscalationResolutionStatus = SupplierDisputeSearchResult.EscalationResolutionStatus;
			this.EscalationDueDate = SupplierDisputeSearchResult.EscalationDueDate;
			this.AdditionalAmtApproved = SupplierDisputeSearchResult.AdditionalAmtApproved;
			this.DisputeReason = SupplierDisputeSearchResult.DisputeReason;
			this.VendorDisputeComments = SupplierDisputeSearchResult.VendorDisputeComments;
			this.DisputeResolutionType = SupplierDisputeSearchResult.DisputeResolutionType;
			this.DisputeResolution = SupplierDisputeSearchResult.DisputeResolution;
			this.DisputeCompletedDate = SupplierDisputeSearchResult.DisputeCompletedDate;
			this.SLFSResponseToVendor = SupplierDisputeSearchResult.SLFSResponseToVendor;
			this.EscalationCompleteDate = SupplierDisputeSearchResult.EscalationCompleteDate;
			this.EscalationComments = SupplierDisputeSearchResult.EscalationComments;
			this.EscalationDate = SupplierDisputeSearchResult.EscalationDate;
			this.SLFSResponseToEscalation = SupplierDisputeSearchResult.SLFSResponseToEscalation;
			this.SupplierDisputeId = SupplierDisputeSearchResult.SupplierDisputeId;
            this.EscalatedByVendor = SupplierDisputeSearchResult.EscalatedByVendor;
            this.VendorName = SupplierDisputeSearchResult.VendorName;
            this.PropertyAddress1 = SupplierDisputeSearchResult.PropertyAddress1;
            this.PropertyAddress2 = SupplierDisputeSearchResult.PropertyAddress2;
            this.PropertyCity = SupplierDisputeSearchResult.PropertyCity;
            this.PropertyState = SupplierDisputeSearchResult.PropertyState;
            this.PropertyZip = SupplierDisputeSearchResult.PropertyZip;
            this.ProductName = SupplierDisputeSearchResult.ProductName;
            this.ClientNumber = SupplierDisputeSearchResult.ClientNumber;
            this.DisputeAmount = SupplierDisputeSearchResult.DisputeAmount;
            this.Decision = SupplierDisputeSearchResult.Decision;
            this.Resolution = SupplierDisputeSearchResult.Resolution;
            this.EscalationDecision = SupplierDisputeSearchResult.EscalationDecision;
            this.SLFSEscalationComments = SupplierDisputeSearchResult.SLFSEscalationComments;
            this.PropertyAddress = this.PropertyAddress1 + (string.IsNullOrEmpty(SupplierDisputeSearchResult.PropertyAddress2) ? "" : ", ") + SupplierDisputeSearchResult.PropertyAddress2 + ", " + SupplierDisputeSearchResult.PropertyCity + ", " + SupplierDisputeSearchResult.PropertyState + ", " + SupplierDisputeSearchResult.PropertyZip;

		} 
		public override TDto MapFromDomainModel<TDomain, TDto>(TDomain domainModel)
		{ 
			Domain.SupplierDisputeSearchResult SupplierDisputeSearchResultModel = domainModel as Domain.SupplierDisputeSearchResult;
			if(SupplierDisputeSearchResultModel != null)
			{ 
				MapToDtoWithoutCollections(SupplierDisputeSearchResultModel);
			} 
				return this as TDto;
		} 
		public override TDomain MapToDomainModel<TDomain>(TDomain domainModel)
		{ 
			Domain.SupplierDisputeSearchResult SupplierDisputeSearchResultModel = domainModel as Domain.SupplierDisputeSearchResult;
			Domain.SupplierDisputeSearchResult destObj = MapToDomainModelWithoutCollections(SupplierDisputeSearchResultModel);
		    return destObj as TDomain;
		} 
	} 
} 

