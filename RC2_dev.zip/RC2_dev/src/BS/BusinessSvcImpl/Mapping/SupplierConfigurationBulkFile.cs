using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using CommonLib.DataObjects;
using CommonLib.ModelAttrib;
using Domain = DomainModel.Accounting;
namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{ 
    [System.CodeDom.Compiler.GeneratedCode("EF", "6.1.0")]
	public partial class SupplierConfigurationBulkFile : BaseDto
	{ 
		public Domain.SupplierConfigurationBulkFile MapToDomainModelWithoutCollections(Domain.SupplierConfigurationBulkFile SupplierConfigurationBulkFile)
		{ 
			SupplierConfigurationBulkFile.ConfigurationType = this.ConfigurationType;
			SupplierConfigurationBulkFile.FileName = this.FileName;
			SupplierConfigurationBulkFile.DocumentId = this.DocumentId;
			SupplierConfigurationBulkFile.Status = this.Status;
			SupplierConfigurationBulkFile.TotalRecordCount = this.TotalRecordCount;
			SupplierConfigurationBulkFile.SuccessRecordCount = this.SuccessRecordCount;
			SupplierConfigurationBulkFile.FailedRecordCount = this.FailedRecordCount;
			SupplierConfigurationBulkFile.FailureMessage = this.FailureMessage;
			SupplierConfigurationBulkFile.MasterClientProfileId = this.MasterClientProfileId;
			SupplierConfigurationBulkFile.SubClientProfileId = this.SubClientProfileId;
			SupplierConfigurationBulkFile.ClientNumber = this.ClientNumber;
			SupplierConfigurationBulkFile.ClientName = this.ClientName;
			SupplierConfigurationBulkFile.CreatedById = this.CreatedById;
            SupplierConfigurationBulkFile.AppUserID = this.AppUserID;
			if(this.CreatedDate!=null)
			{
				if(this.CreatedDate.Kind == DateTimeKind.Utc)
					SupplierConfigurationBulkFile.CreatedDate = this.CreatedDate;
				else if(this.CreatedDate.Kind == DateTimeKind.Local)
					SupplierConfigurationBulkFile.CreatedDate = TimeZoneInfo.ConvertTimeToUtc(this.CreatedDate);
				else
					SupplierConfigurationBulkFile.CreatedDate = TimeZoneInfo.ConvertTimeToUtc(this.CreatedDate, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
			}
			else
			{
				SupplierConfigurationBulkFile.CreatedDate = this.CreatedDate;
			}
			SupplierConfigurationBulkFile.LastUpdatedById = this.LastUpdatedById;
			if(this.LastUpdatedDate.HasValue)
			{
				if(this.LastUpdatedDate.Value.Kind == DateTimeKind.Utc)
					SupplierConfigurationBulkFile.LastUpdatedDate = this.LastUpdatedDate;
				else if(this.LastUpdatedDate.Value.Kind == DateTimeKind.Local)
					SupplierConfigurationBulkFile.LastUpdatedDate = TimeZoneInfo.ConvertTimeToUtc(this.LastUpdatedDate.Value);
				else
					SupplierConfigurationBulkFile.LastUpdatedDate = TimeZoneInfo.ConvertTimeToUtc(this.LastUpdatedDate.Value, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
			}
			else
			{
				SupplierConfigurationBulkFile.LastUpdatedDate = this.LastUpdatedDate;
			}
            SupplierConfigurationBulkFile.Version = string.IsNullOrEmpty(this.Version) ? null: Convert.FromBase64String(this.Version);
			SupplierConfigurationBulkFile.BulkId = this.BulkId;
			SupplierConfigurationBulkFile.UploadedBy = this.UploadedBy;
            SupplierConfigurationBulkFile.SupplierConfigurationBulkFileId = this.SupplierConfigurationBulkFileId;
			return SupplierConfigurationBulkFile;
		} 
		public void MapToDtoWithoutCollections(Domain.SupplierConfigurationBulkFile SupplierConfigurationBulkFile)
		{ 
			this.ConfigurationType = SupplierConfigurationBulkFile.ConfigurationType;
			this.FileName = SupplierConfigurationBulkFile.FileName;
			this.DocumentId = SupplierConfigurationBulkFile.DocumentId;
			this.Status = SupplierConfigurationBulkFile.Status;
			this.TotalRecordCount = SupplierConfigurationBulkFile.TotalRecordCount;
			this.SuccessRecordCount = SupplierConfigurationBulkFile.SuccessRecordCount;
			this.FailedRecordCount = SupplierConfigurationBulkFile.FailedRecordCount;
			this.FailureMessage = SupplierConfigurationBulkFile.FailureMessage;
			this.MasterClientProfileId = SupplierConfigurationBulkFile.MasterClientProfileId;
			this.SubClientProfileId = SupplierConfigurationBulkFile.SubClientProfileId;
			this.ClientNumber = SupplierConfigurationBulkFile.ClientNumber;
			this.ClientName = SupplierConfigurationBulkFile.ClientName;
			this.CreatedById = SupplierConfigurationBulkFile.CreatedById;
            this.AppUserID = SupplierConfigurationBulkFile.AppUserID;
            //if(SupplierConfigurationBulkFile.CreatedDate!=null)
            //{
            //    if(SupplierConfigurationBulkFile.CreatedDate.Value.Kind == DateTimeKind.Utc || SupplierConfigurationBulkFile.CreatedDate.Value.Kind == DateTimeKind.Unspecified)
            //        this.CreatedDate = TimeZoneInfo.ConvertTimeFromUtc(SupplierConfigurationBulkFile.CreatedDate.Value, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
            //    else
            //        this.CreatedDate = TimeZoneInfo.ConvertTime(SupplierConfigurationBulkFile.CreatedDate.Value, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
            //}
            //else
            //{
            //    this.CreatedDate = default(DateTime);
            //}
            this.CreatedDate = SupplierConfigurationBulkFile.CreatedDate.Value;
			this.LastUpdatedById = SupplierConfigurationBulkFile.LastUpdatedById;
			if(SupplierConfigurationBulkFile.LastUpdatedDate.HasValue)
			{
				if(SupplierConfigurationBulkFile.LastUpdatedDate.Value.Kind == DateTimeKind.Utc || SupplierConfigurationBulkFile.LastUpdatedDate.Value.Kind == DateTimeKind.Unspecified)
					this.LastUpdatedDate = TimeZoneInfo.ConvertTimeFromUtc(SupplierConfigurationBulkFile.LastUpdatedDate.Value, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
				else
					this.LastUpdatedDate = TimeZoneInfo.ConvertTime(SupplierConfigurationBulkFile.LastUpdatedDate.Value, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
			}
			else
			{
				this.LastUpdatedDate = SupplierConfigurationBulkFile.LastUpdatedDate;
			}
            this.Version = SupplierConfigurationBulkFile.Version == null ? null:Convert.ToBase64String(SupplierConfigurationBulkFile.Version);
			this.BulkId = SupplierConfigurationBulkFile.BulkId;
			this.UploadedBy = SupplierConfigurationBulkFile.UploadedBy;
            this.SupplierConfigurationBulkFileId = SupplierConfigurationBulkFile.SupplierConfigurationBulkFileId;
		} 
		public override TDto MapFromDomainModel<TDomain, TDto>(TDomain domainModel)
		{ 
			Domain.SupplierConfigurationBulkFile SupplierConfigurationBulkFileModel = domainModel as Domain.SupplierConfigurationBulkFile;
			if(SupplierConfigurationBulkFileModel != null)
			{ 
				MapToDtoWithoutCollections(SupplierConfigurationBulkFileModel);
			} 
				return this as TDto;
		} 
		public override TDomain MapToDomainModel<TDomain>(TDomain domainModel)
		{ 
			Domain.SupplierConfigurationBulkFile SupplierConfigurationBulkFileModel = domainModel as Domain.SupplierConfigurationBulkFile;
			Domain.SupplierConfigurationBulkFile destObj = MapToDomainModelWithoutCollections(SupplierConfigurationBulkFileModel);
		    return destObj as TDomain;
		} 
	} 
} 

