using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using CommonLib.DataObjects;
using CommonLib.ModelAttrib;
using Domain = DomainModel.Accounting;
namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{ 
[System.CodeDom.Compiler.GeneratedCode("EF", "6.1.0")]
	public partial class ARDetailView : BaseDto
	{ 
		public Domain.ARDetailView MapToDomainModelWithoutCollections(Domain.ARDetailView ARDetailView)
		{ 
			ARDetailView.ClientNumber = this.ClientNumber;
			ARDetailView.ClientName = this.ClientName;
			ARDetailView.ProductName = this.ProductName;
			ARDetailView.ARDate = this.ARDate;
			ARDetailView.BaseAmount = this.BaseAmount;
			ARDetailView.EligibleAmount = this.EligibleAmount;
			ARDetailView.TaxRate = this.TaxRate;
			ARDetailView.TaxAmount = this.TaxAmount;
			ARDetailView.TotalAmount = this.TotalAmount;
			ARDetailView.PriceAdjReason = this.PriceAdjReason;
			ARDetailView.InvoiceNumber = this.InvoiceNumber;
			ARDetailView.InvoiceDate = this.InvoiceDate;
			ARDetailView.Status = this.Status;
			ARDetailView.WorkOrderId = this.WorkOrderId;
			ARDetailView.SourceWorkOrderId = this.SourceWorkOrderId;
			ARDetailView.Date = this.Date;
			ARDetailView.ApplicationId = this.ApplicationId;
            ARDetailView.OrderId = this.OrderId;
            ARDetailView.ProductCategory = this.ProductCategory;
            ARDetailView.OrderHierarchyId = this.OrderHierarchyId;
			return ARDetailView;
		} 
		public void MapToDtoWithoutCollections(Domain.ARDetailView ARDetailView)
		{ 
			this.ClientNumber = ARDetailView.ClientNumber;
			this.ClientName = ARDetailView.ClientName;
			this.ProductName = ARDetailView.ProductName;
			this.ARDate = ARDetailView.ARDate;
			this.BaseAmount = ARDetailView.BaseAmount;
			this.EligibleAmount = ARDetailView.EligibleAmount;
			this.TaxRate = ARDetailView.TaxRate;
			this.TaxAmount = ARDetailView.TaxAmount;
			this.TotalAmount = ARDetailView.TotalAmount;
			this.PriceAdjReason = ARDetailView.PriceAdjReason;
			this.InvoiceNumber = ARDetailView.InvoiceNumber;
			this.InvoiceDate = ARDetailView.InvoiceDate;
			this.Status = ARDetailView.Status;
			this.WorkOrderId = ARDetailView.WorkOrderId;
			this.SourceWorkOrderId = ARDetailView.SourceWorkOrderId;
			this.Date = ARDetailView.Date;
			this.ApplicationId = ARDetailView.ApplicationId;
            this.OrderId = ARDetailView.OrderId;
            this.ProductCategory = ARDetailView.ProductCategory;
            this.OrderHierarchyId = ARDetailView.OrderHierarchyId;
		} 
		public override TDto MapFromDomainModel<TDomain, TDto>(TDomain domainModel)
		{ 
			Domain.ARDetailView ARDetailViewModel = domainModel as Domain.ARDetailView;
			if(ARDetailViewModel != null)
			{ 
				MapToDtoWithoutCollections(ARDetailViewModel);
			} 
				return this as TDto;
		} 
		public override TDomain MapToDomainModel<TDomain>(TDomain domainModel)
		{ 
			Domain.ARDetailView ARDetailViewModel = domainModel as Domain.ARDetailView;
			Domain.ARDetailView destObj = MapToDomainModelWithoutCollections(ARDetailViewModel);
		    return destObj as TDomain;
		} 
	} 
} 

