using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using CommonLib.DataObjects;
using CommonLib.ModelAttrib;
using Domain = DomainModel.Accounting;
namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{ 
[System.CodeDom.Compiler.GeneratedCode("EF", "6.1.0")]
	public partial class SupplierDisputeSearchInput : BaseDto
	{ 
		public Domain.SupplierDisputeSearchInput MapToDomainModelWithoutCollections(Domain.SupplierDisputeSearchInput SupplierDisputeSearchInput)
		{ 
			SupplierDisputeSearchInput.VendorId = this.VendorId;
            SupplierDisputeSearchInput.AssignUserId = this.AssignUserId;
			SupplierDisputeSearchInput.BulkId = this.BulkId;
            SupplierDisputeSearchInput.State = string.Join(",", this.State ?? new List<string>());
			SupplierDisputeSearchInput.FieldScapeWorkOrderId = this.FieldScapeWorkOrderId;
			SupplierDisputeSearchInput.VendorWorkOrderId = this.VendorWorkOrderId;
			SupplierDisputeSearchInput.InspWorkOrderId = this.InspWorkOrderId;
            SupplierDisputeSearchInput.DisputeStatusType = string.Join(",", this.DisputeStatusType ?? new List<string>());
			SupplierDisputeSearchInput.DisputeSubmittedFromDate = this.DisputeSubmittedFromDate;
			SupplierDisputeSearchInput.DisputeSubmittedToDate = this.DisputeSubmittedToDate;
			SupplierDisputeSearchInput.DisputeDueDateFrom = this.DisputeDueDateFrom;
			SupplierDisputeSearchInput.DisputeDueDateTo = this.DisputeDueDateTo;
            SupplierDisputeSearchInput.EscalationResolution = string.Join(",", this.EscalationResolution ?? new List<string>());
			SupplierDisputeSearchInput.EscalationResolutionFromDate = this.EscalationResolutionFromDate;
			SupplierDisputeSearchInput.EscalationResolutionToDate = this.EscalationResolutionToDate;
			return SupplierDisputeSearchInput;
		} 
		public void MapToDtoWithoutCollections(Domain.SupplierDisputeSearchInput SupplierDisputeSearchInput)
		{ 
			this.VendorId = SupplierDisputeSearchInput.VendorId;
            this.AssignUserId = SupplierDisputeSearchInput.AssignUserId;
			this.BulkId = SupplierDisputeSearchInput.BulkId;
            this.State = SupplierDisputeSearchInput.State.Split(new char[] { ',' }).ToList(); 
			this.FieldScapeWorkOrderId = SupplierDisputeSearchInput.FieldScapeWorkOrderId;
			this.VendorWorkOrderId = SupplierDisputeSearchInput.VendorWorkOrderId;
			this.InspWorkOrderId = SupplierDisputeSearchInput.InspWorkOrderId;
            this.DisputeStatusType = SupplierDisputeSearchInput.DisputeStatusType.Split(new char[] { ',' }).ToList();
			this.DisputeSubmittedFromDate = SupplierDisputeSearchInput.DisputeSubmittedFromDate;
			this.DisputeSubmittedToDate = SupplierDisputeSearchInput.DisputeSubmittedToDate;
			this.DisputeDueDateFrom = SupplierDisputeSearchInput.DisputeDueDateFrom;
			this.DisputeDueDateTo = SupplierDisputeSearchInput.DisputeDueDateTo;
            this.EscalationResolution = SupplierDisputeSearchInput.EscalationResolution.Split(new char[] { ',' }).ToList();
			this.EscalationResolutionFromDate = SupplierDisputeSearchInput.EscalationResolutionFromDate;
			this.EscalationResolutionToDate = SupplierDisputeSearchInput.EscalationResolutionToDate;
		} 
		public override TDto MapFromDomainModel<TDomain, TDto>(TDomain domainModel)
		{ 
			Domain.SupplierDisputeSearchInput SupplierDisputeSearchInputModel = domainModel as Domain.SupplierDisputeSearchInput;
			if(SupplierDisputeSearchInputModel != null)
			{ 
				MapToDtoWithoutCollections(SupplierDisputeSearchInputModel);
			} 
				return this as TDto;
		} 
		
		public override TDomain MapToDomainModel<TDomain>(TDomain domainModel)
		{ 
			Domain.SupplierDisputeSearchInput SupplierDisputeSearchInputModel = domainModel as Domain.SupplierDisputeSearchInput;
			Domain.SupplierDisputeSearchInput destObj = MapToDomainModelWithoutCollections(SupplierDisputeSearchInputModel);
		    return destObj as TDomain;
		} 
	} 
} 

