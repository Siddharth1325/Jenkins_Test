using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using CommonLib.DataObjects;
using CommonLib.ModelAttrib;
using Domain = DomainModel.Accounting;
namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{ 
[System.CodeDom.Compiler.GeneratedCode("EF", "6.1.0")]
	public partial class AccountsTax : BaseDto
	{ 
		public Domain.AccountsTax MapToDomainModelWithoutCollections(Domain.AccountsTax AccountsTax)
		{ 
			AccountsTax.AccountsReceivableAdjustmentId = this.AccountsReceivableAdjustmentId;
			AccountsTax.AccountsReceivableDetailId = this.AccountsReceivableDetailId;
			AccountsTax.ApplicationId = this.ApplicationId;
			AccountsTax.TaxAmount = this.TaxAmount;
			AccountsTax.TaxRate = this.TaxRate;
			AccountsTax.TransmissionStatus = this.TransmissionStatus;
			AccountsTax.TransmissionStatusGroup = this.TransmissionStatusGroup;
			AccountsTax.ErrorMsg = this.ErrorMsg;
			if(this.ErrorDate.HasValue)
			{
				if(this.ErrorDate.Value.Kind == DateTimeKind.Utc)
					AccountsTax.ErrorDate = this.ErrorDate;
				else if(this.ErrorDate.Value.Kind == DateTimeKind.Local)
					AccountsTax.ErrorDate = TimeZoneInfo.ConvertTimeToUtc(this.ErrorDate.Value);
				else
					AccountsTax.ErrorDate = TimeZoneInfo.ConvertTimeToUtc(this.ErrorDate.Value, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
			}
			else
			{
				AccountsTax.ErrorDate = this.ErrorDate;
			}
			AccountsTax.CreatedById = this.CreatedById;
			if(this.CreatedDate!=null)
			{
				if(this.CreatedDate.Kind == DateTimeKind.Utc)
					AccountsTax.CreatedDate = this.CreatedDate;
				else if(this.CreatedDate.Kind == DateTimeKind.Local)
					AccountsTax.CreatedDate = TimeZoneInfo.ConvertTimeToUtc(this.CreatedDate);
				else
					AccountsTax.CreatedDate = TimeZoneInfo.ConvertTimeToUtc(this.CreatedDate, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
			}
			else
			{
				AccountsTax.CreatedDate = this.CreatedDate;
			}
			AccountsTax.LastUpdatedById = this.LastUpdatedById;
			AccountsTax.LastUpdatedDate = this.LastUpdatedDate;
            AccountsTax.Version = string.IsNullOrEmpty(this.Version) ? null: Convert.FromBase64String(this.Version);
			if (this.AccountsReceivableDetail != null)
			{ 
				AccountsTax.AccountsReceivableDetail = new Domain.AccountsReceivableDetail();
				AccountsTax.AccountsReceivableDetail = this.AccountsReceivableDetail.MapToDomainModelWithoutCollections(AccountsTax.AccountsReceivableDetail);
			} 
			AccountsTax.AccountsTaxId = this.AccountsTaxId;
			return AccountsTax;
		} 
		public void MapToDtoWithoutCollections(Domain.AccountsTax AccountsTax)
		{ 
			this.AccountsReceivableAdjustmentId = AccountsTax.AccountsReceivableAdjustmentId;
			this.AccountsReceivableDetailId = AccountsTax.AccountsReceivableDetailId;
			this.ApplicationId = AccountsTax.ApplicationId;
			this.TaxAmount = AccountsTax.TaxAmount;
			this.TaxRate = AccountsTax.TaxRate;
			this.TransmissionStatus = AccountsTax.TransmissionStatus;
			this.TransmissionStatusGroup = AccountsTax.TransmissionStatusGroup;
			this.ErrorMsg = AccountsTax.ErrorMsg;
			if(AccountsTax.ErrorDate.HasValue)
			{
				if(AccountsTax.ErrorDate.Value.Kind == DateTimeKind.Utc || AccountsTax.ErrorDate.Value.Kind == DateTimeKind.Unspecified)
					this.ErrorDate = TimeZoneInfo.ConvertTimeFromUtc(AccountsTax.ErrorDate.Value, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
				else
					this.ErrorDate = TimeZoneInfo.ConvertTime(AccountsTax.ErrorDate.Value, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
			}
			else
			{
				this.ErrorDate = AccountsTax.ErrorDate;
			}
			this.CreatedById = AccountsTax.CreatedById;
			if(AccountsTax.CreatedDate!=null)
			{
				if(AccountsTax.CreatedDate.Kind == DateTimeKind.Utc || AccountsTax.CreatedDate.Kind == DateTimeKind.Unspecified)
					this.CreatedDate = TimeZoneInfo.ConvertTimeFromUtc(AccountsTax.CreatedDate, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
				else
					this.CreatedDate = TimeZoneInfo.ConvertTime(AccountsTax.CreatedDate, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
			}
			else
			{
				this.CreatedDate = AccountsTax.CreatedDate;
			}
			this.LastUpdatedById = AccountsTax.LastUpdatedById;
			this.LastUpdatedDate = AccountsTax.LastUpdatedDate;
            this.Version = AccountsTax.Version == null ? null:Convert.ToBase64String(AccountsTax.Version);
			if (AccountsTax.AccountsReceivableDetail != null)
			{ 
				this.AccountsReceivableDetail = new AccountsReceivableDetail();
				this.AccountsReceivableDetail.MapToDtoWithoutCollections(AccountsTax.AccountsReceivableDetail);
			} 
			this.AccountsTaxId = AccountsTax.AccountsTaxId;
		} 
		public override TDto MapFromDomainModel<TDomain, TDto>(TDomain domainModel)
		{ 
			Domain.AccountsTax AccountsTaxModel = domainModel as Domain.AccountsTax;
			if(AccountsTaxModel != null)
			{ 
				MapToDtoWithoutCollections(AccountsTaxModel);
			} 
				return this as TDto;
		} 
		public override TDomain MapToDomainModel<TDomain>(TDomain domainModel)
		{ 
			Domain.AccountsTax AccountsTaxModel = domainModel as Domain.AccountsTax;
			Domain.AccountsTax destObj = MapToDomainModelWithoutCollections(AccountsTaxModel);
		    return destObj as TDomain;
		} 
	} 
} 

