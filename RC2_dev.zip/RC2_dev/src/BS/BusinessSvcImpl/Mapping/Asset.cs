using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using CommonLib.DataObjects;
using CommonLib.ModelAttrib;
using Domain = DomainModel.Accounting;
namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{ 
[System.CodeDom.Compiler.GeneratedCode("EF", "6.1.0")]
	public partial class Asset : BaseDto
	{ 
		public Domain.Asset MapToDomainModelWithoutCollections(Domain.Asset Asset)
		{ 
			Asset.ApplicationId = this.ApplicationId;
			Asset.SourceAssetId = this.SourceAssetId;
			Asset.DwellingTypeGroup = this.DwellingTypeGroup;
			Asset.DwellingType = this.DwellingType;
			Asset.MobileVinNumber = this.MobileVinNumber;
			Asset.MobileHudNumber = this.MobileHudNumber;
			Asset.Latitude = this.Latitude;
			Asset.Longitude = this.Longitude;
			Asset.IsDoNotApproach = this.IsDoNotApproach;
			Asset.DoNotApproachReason = this.DoNotApproachReason;
			Asset.GateCode = this.GateCode;
			Asset.HOAName = this.HOAName;
			Asset.HOAPhone = this.HOAPhone;
			Asset.CommunityName = this.CommunityName;
			Asset.CommunityNumber = this.CommunityNumber;
			Asset.CommunityAddress1 = this.CommunityAddress1;
			Asset.CommunityAddress2 = this.CommunityAddress2;
			Asset.CommunityCityName = this.CommunityCityName;
            Asset.IsMelissaServiceCalled = this.IsMelissaServiceCalled;
            Asset.AddressKey = this.AddressKey;
            //if(this.LastVPROrARTDate.HasValue)
            //{
            //    if(this.LastVPROrARTDate.Value.Kind == DateTimeKind.Utc)
            //        Asset.LastVPROrARTDate = this.LastVPROrARTDate;
            //    else if(this.LastVPROrARTDate.Value.Kind == DateTimeKind.Local)
            //        Asset.LastVPROrARTDate = TimeZoneInfo.ConvertTimeToUtc(this.LastVPROrARTDate.Value);
            //    else
            //        Asset.LastVPROrARTDate = TimeZoneInfo.ConvertTimeToUtc(this.LastVPROrARTDate.Value, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
            //}
            //else
            //{
            //    Asset.LastVPROrARTDate = this.LastVPROrARTDate;
            //}
            Asset.LastVPROrARTDate = this.LastVPROrARTDate;
			Asset.VendorNotes = this.VendorNotes;
			Asset.CreatedById = this.CreatedById;
			if(this.CreatedDate!=null)
			{
				if(this.CreatedDate.Kind == DateTimeKind.Utc)
					Asset.CreatedDate = this.CreatedDate;
				else if(this.CreatedDate.Kind == DateTimeKind.Local)
					Asset.CreatedDate = TimeZoneInfo.ConvertTimeToUtc(this.CreatedDate);
				else
					Asset.CreatedDate = TimeZoneInfo.ConvertTimeToUtc(this.CreatedDate, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
			}
			else
			{
				Asset.CreatedDate = this.CreatedDate;
			}
			Asset.LastUpdatedById = this.LastUpdatedById;
			if(this.LastUpdatedDate.HasValue)
			{
				if(this.LastUpdatedDate.Value.Kind == DateTimeKind.Utc)
					Asset.LastUpdatedDate = this.LastUpdatedDate;
				else if(this.LastUpdatedDate.Value.Kind == DateTimeKind.Local)
					Asset.LastUpdatedDate = TimeZoneInfo.ConvertTimeToUtc(this.LastUpdatedDate.Value);
				else
					Asset.LastUpdatedDate = TimeZoneInfo.ConvertTimeToUtc(this.LastUpdatedDate.Value, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
			}
			else
			{
				Asset.LastUpdatedDate = this.LastUpdatedDate;
			}
            Asset.Version = string.IsNullOrEmpty(this.Version) ? null: Convert.FromBase64String(this.Version);
			Asset.AssetId = this.AssetId;
			return Asset;
		} 
		public void MapToDtoWithoutCollections(Domain.Asset Asset)
		{ 
			this.ApplicationId = Asset.ApplicationId;
			this.SourceAssetId = Asset.SourceAssetId;
			this.DwellingTypeGroup = Asset.DwellingTypeGroup;
			this.DwellingType = Asset.DwellingType;
			this.MobileVinNumber = Asset.MobileVinNumber;
			this.MobileHudNumber = Asset.MobileHudNumber;
			this.Latitude = Asset.Latitude;
			this.Longitude = Asset.Longitude;
			this.IsDoNotApproach = Asset.IsDoNotApproach;
			this.DoNotApproachReason = Asset.DoNotApproachReason;
			this.GateCode = Asset.GateCode;
			this.HOAName = Asset.HOAName;
			this.HOAPhone = Asset.HOAPhone;
			this.CommunityName = Asset.CommunityName;
			this.CommunityNumber = Asset.CommunityNumber;
			this.CommunityAddress1 = Asset.CommunityAddress1;
			this.CommunityAddress2 = Asset.CommunityAddress2;
			this.CommunityCityName = Asset.CommunityCityName;
            this.IsMelissaServiceCalled = Asset.IsMelissaServiceCalled;
            this.AddressKey = Asset.AddressKey;
            //if(Asset.LastVPROrARTDate.HasValue)
            //{
            //    if(Asset.LastVPROrARTDate.Value.Kind == DateTimeKind.Utc || Asset.LastVPROrARTDate.Value.Kind == DateTimeKind.Unspecified)
            //        this.LastVPROrARTDate = TimeZoneInfo.ConvertTimeFromUtc(Asset.LastVPROrARTDate.Value, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
            //    else
            //        this.LastVPROrARTDate = TimeZoneInfo.ConvertTime(Asset.LastVPROrARTDate.Value, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
            //}
            //else
            //{
            //    this.LastVPROrARTDate = Asset.LastVPROrARTDate;
            //}
            this.LastVPROrARTDate = Asset.LastVPROrARTDate;
			this.VendorNotes = Asset.VendorNotes;
			this.CreatedById = Asset.CreatedById;
			if(Asset.CreatedDate!=null)
			{
				if(Asset.CreatedDate.Kind == DateTimeKind.Utc || Asset.CreatedDate.Kind == DateTimeKind.Unspecified)
					this.CreatedDate = TimeZoneInfo.ConvertTimeFromUtc(Asset.CreatedDate, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
				else
					this.CreatedDate = TimeZoneInfo.ConvertTime(Asset.CreatedDate, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
			}
			else
			{
				this.CreatedDate = Asset.CreatedDate;
			}
			this.LastUpdatedById = Asset.LastUpdatedById;
			if(Asset.LastUpdatedDate.HasValue)
			{
				if(Asset.LastUpdatedDate.Value.Kind == DateTimeKind.Utc || Asset.LastUpdatedDate.Value.Kind == DateTimeKind.Unspecified)
					this.LastUpdatedDate = TimeZoneInfo.ConvertTimeFromUtc(Asset.LastUpdatedDate.Value, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
				else
					this.LastUpdatedDate = TimeZoneInfo.ConvertTime(Asset.LastUpdatedDate.Value, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
			}
			else
			{
				this.LastUpdatedDate = Asset.LastUpdatedDate;
			}
            this.Version = Asset.Version == null ? null:Convert.ToBase64String(Asset.Version);
			this.AssetId = Asset.AssetId;
		} 
		public override TDto MapFromDomainModel<TDomain, TDto>(TDomain domainModel)
		{ 
			Domain.Asset AssetModel = domainModel as Domain.Asset;
			if(AssetModel != null)
			{ 
				MapToDtoWithoutCollections(AssetModel);
				foreach(Domain.Loan Loan in AssetModel.Loans)
				{ 
					  Loan LoanDto = new Loan();
					  LoanDto = LoanDto.MapFromDomainModel<Domain.Loan, Loan>(Loan);
					  this.Loans.Add(LoanDto);
				} 
			} 
				return this as TDto;
		} 
		private void MapLoans(Domain.Asset destObj)
		{ 
			if (Loans != null)
			{ 
				foreach(Loan Loan in Loans)
				{ 
					Domain.Loan LoanModel;
				   if(Loan.LoanId == 0)
				   { 
						LoanModel = new Domain.Loan();
						LoanModel = Loan.MapToDomainModel<Domain.Loan>(LoanModel) as Domain.Loan;
					    destObj.Loans.Add(LoanModel);
				   } 
				   else 
				   { 
						LoanModel = destObj.Loans.FirstOrDefault(a => a.LoanId == Loan.LoanId);
					   if (LoanModel != null)
					   {
							if (Loan.HardDelete)
							{ 
								destObj.Loans.Remove(LoanModel);
							} 
							else 
							{ 
								LoanModel = Loan.MapToDomainModel<Domain.Loan>(LoanModel) as Domain.Loan;
							} 
					   } 
					} 
				} 
			} 
		} 
		public override TDomain MapToDomainModel<TDomain>(TDomain domainModel)
		{ 
			Domain.Asset AssetModel = domainModel as Domain.Asset;
			Domain.Asset destObj = MapToDomainModelWithoutCollections(AssetModel);
		    MapLoans(destObj);
		    return destObj as TDomain;
		} 
	} 
} 

