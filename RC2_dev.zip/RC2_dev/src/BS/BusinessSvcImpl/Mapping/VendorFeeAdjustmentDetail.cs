using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using CommonLib.DataObjects;
using CommonLib.ModelAttrib;
using Domain = DomainModel.Accounting;
namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{ 
[System.CodeDom.Compiler.GeneratedCode("EF", "6.1.0")]
	public partial class VendorFeeAdjustmentDetail : BaseDto
	{ 
		public Domain.VendorFeeAdjustmentDetail MapToDomainModelWithoutCollections(Domain.VendorFeeAdjustmentDetail VendorFeeAdjustmentDetail)
		{ 
			VendorFeeAdjustmentDetail.IsAdjusted = Convert.ToInt32(this.IsAdjusted);
			VendorFeeAdjustmentDetail.OrderHierarchyId = this.OrderHierarchyId;
			VendorFeeAdjustmentDetail.VendorWorkOrderId = this.VendorWorkOrderId;
			VendorFeeAdjustmentDetail.VendorId = this.VendorId;
			VendorFeeAdjustmentDetail.OneTimeFee = this.OneTimeFee;
			VendorFeeAdjustmentDetail.OneTimeFeeAdjAmount = this.OneTimeFeeAdjAmount;
			VendorFeeAdjustmentDetail.TripFee = this.TripFee;
			VendorFeeAdjustmentDetail.TripFeeAdjAmount = this.TripFeeAdjAmount;
			VendorFeeAdjustmentDetail.MinServiceFee = this.MinServiceFee;
			VendorFeeAdjustmentDetail.MinServiceFeeAdjAmount = this.MinServiceFeeAdjAmount;
			VendorFeeAdjustmentDetail.InvoicedDate = this.InvoicedDate;
			VendorFeeAdjustmentDetail.AdjustmentDate = this.AdjustmentDate;
			VendorFeeAdjustmentDetail.Comments = this.Comments;
			VendorFeeAdjustmentDetail.RecType = this.RecType;
			VendorFeeAdjustmentDetail.AdjustmentDetailHistoryId = this.AdjustmentDetailHistoryId;
            VendorFeeAdjustmentDetail.RecordNumber = this.RecordNumber;
            VendorFeeAdjustmentDetail.InvoiceNumber = this.InvoiceNumber;
            VendorFeeAdjustmentDetail.IsApInvoiced = this.IsApInvoiced;
            VendorFeeAdjustmentDetail.Version = string.IsNullOrEmpty(this.Version) ? null : Convert.FromBase64String(this.Version);
			return VendorFeeAdjustmentDetail;
		} 
		public void MapToDtoWithoutCollections(Domain.VendorFeeAdjustmentDetail VendorFeeAdjustmentDetail)
		{ 
			this.IsAdjusted = Convert.ToBoolean(VendorFeeAdjustmentDetail.IsAdjusted);
			this.OrderHierarchyId = VendorFeeAdjustmentDetail.OrderHierarchyId;
			this.VendorWorkOrderId = VendorFeeAdjustmentDetail.VendorWorkOrderId;
			this.VendorId = VendorFeeAdjustmentDetail.VendorId;
			this.OneTimeFee = VendorFeeAdjustmentDetail.OneTimeFee;
			this.OneTimeFeeAdjAmount = VendorFeeAdjustmentDetail.OneTimeFeeAdjAmount;
			this.TripFee = VendorFeeAdjustmentDetail.TripFee;
			this.TripFeeAdjAmount = VendorFeeAdjustmentDetail.TripFeeAdjAmount;
			this.MinServiceFee = VendorFeeAdjustmentDetail.MinServiceFee;
			this.MinServiceFeeAdjAmount = VendorFeeAdjustmentDetail.MinServiceFeeAdjAmount;
			this.InvoicedDate = VendorFeeAdjustmentDetail.InvoicedDate;
			this.AdjustmentDate = VendorFeeAdjustmentDetail.AdjustmentDate;
			this.Comments = VendorFeeAdjustmentDetail.Comments;
			this.RecType = VendorFeeAdjustmentDetail.RecType;
            this.RecordNumber = VendorFeeAdjustmentDetail.RecordNumber;
			this.AdjustmentDetailHistoryId = VendorFeeAdjustmentDetail.AdjustmentDetailHistoryId;
            this.InvoiceNumber = VendorFeeAdjustmentDetail.InvoiceNumber;
            this.IsApInvoiced=VendorFeeAdjustmentDetail.IsApInvoiced;
            this.Version = VendorFeeAdjustmentDetail.Version == null ? null : Convert.ToBase64String(VendorFeeAdjustmentDetail.Version);
            this.VwoPenalty = VendorFeeAdjustmentDetail.VwoPenalty;
		} 
		public override TDto MapFromDomainModel<TDomain, TDto>(TDomain domainModel)
		{ 
			Domain.VendorFeeAdjustmentDetail VendorFeeAdjustmentDetailModel = domainModel as Domain.VendorFeeAdjustmentDetail;
			if(VendorFeeAdjustmentDetailModel != null)
			{ 
				MapToDtoWithoutCollections(VendorFeeAdjustmentDetailModel);
			} 
				return this as TDto;
		} 
		public override TDomain MapToDomainModel<TDomain>(TDomain domainModel)
		{ 
			Domain.VendorFeeAdjustmentDetail VendorFeeAdjustmentDetailModel = domainModel as Domain.VendorFeeAdjustmentDetail;
			Domain.VendorFeeAdjustmentDetail destObj = MapToDomainModelWithoutCollections(VendorFeeAdjustmentDetailModel);
		    return destObj as TDomain;
		} 
	} 
} 

