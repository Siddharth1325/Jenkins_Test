using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using CommonLib.DataObjects;
using CommonLib.ModelAttrib;
using Domain = DomainModel.Accounting;
namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{
    [System.CodeDom.Compiler.GeneratedCode("EF", "6.1.0")]
    public partial class WorkOrder : BaseDto
    {
        public Domain.WorkOrder MapToDomainModelWithoutCollections(Domain.WorkOrder WorkOrder)
        {
            WorkOrder.ApplicationId = this.ApplicationId;
            WorkOrder.SourceWorkOrderId = this.SourceWorkOrderId;
            WorkOrder.OrderId = this.OrderId;
            WorkOrder.ProductId = this.ProductId;
            WorkOrder.VendorWorkOrderId = this.VendorWorkOrderId;
            WorkOrder.WorkOrderStatusGroup = this.WorkOrderStatusGroup;
            WorkOrder.WorkOrderStatusType = this.WorkOrderStatusType;
            WorkOrder.CancellationReasonGroup = this.CancellationReasonGroup;
            WorkOrder.CancellationReasonType = this.CancellationReasonType;
            WorkOrder.AssignedVendorId = this.AssignedVendorId;
            WorkOrder.AssignedDate = this.AssignedDate;
            WorkOrder.RequestedDate = this.RequestedDate;
            WorkOrder.WindowStartDate = this.WindowStartDate;
            WorkOrder.WindowEndDate = this.WindowEndDate;
            WorkOrder.DueToClientDate = this.DueToClientDate;
            WorkOrder.OrigVendorDueDate = this.OrigVendorDueDate;
            WorkOrder.DueFromVendorDate = this.DueFromVendorDate;
            WorkOrder.CompletedDate = this.CompletedDate;
            WorkOrder.CancellationDate = this.CancellationDate;
            WorkOrder.TransmittedDate = this.TransmittedDate;
            WorkOrder.AcctProcessedDate = this.AcctProcessedDate;
            WorkOrder.BorrowerFirstName = this.BorrowerFirstName;
            WorkOrder.BorrowerMiddleInitial = this.BorrowerMiddleInitial;
            WorkOrder.BorrowerLastName = this.BorrowerLastName;
            WorkOrder.AddressLine1 = this.AddressLine1;
            WorkOrder.AddressLine2 = this.AddressLine2;
            WorkOrder.CityName = this.CityName;
            WorkOrder.StateCode = this.StateCode;
            WorkOrder.ZipCode = this.ZipCode;
            WorkOrder.ZipPlusFour = this.ZipPlusFour;
            WorkOrder.CountyName = this.CountyName;
            WorkOrder.SpecialInstructions = this.SpecialInstructions;
            WorkOrder.IsRushOrder = this.IsRushOrder;
            WorkOrder.IsBillClient = this.IsBillClient;
            WorkOrder.IsFirstTimeVacant = this.IsFirstTimeVacant;
            WorkOrder.IsVacantToOccupied = this.IsVacantToOccupied;
            WorkOrder.PayVendorGroup = this.PayVendorGroup;
            WorkOrder.PayVendorType = this.PayVendorType;
            WorkOrder.IsCountedTowardScore = this.IsCountedTowardScore;
            WorkOrder.DoorCardTypeGroup = this.DoorCardTypeGroup;
            WorkOrder.DoorCardType = this.DoorCardType;
            WorkOrder.DoorCardMessageText = this.DoorCardMessageText;
            WorkOrder.InspectorUniqueId = this.InspectorUniqueId;
            WorkOrder.ClientSystemId = this.ClientSystemId;
            WorkOrder.ClientDepartment = this.ClientDepartment;
            WorkOrder.InspectionDate1 = this.InspectionDate1;
            WorkOrder.InspectionDate2 = this.InspectionDate2;
            WorkOrder.InspectionDate3 = this.InspectionDate3;
            WorkOrder.AccessDeniedType = this.AccessDeniedType;
            WorkOrder.BadAddrGroupCode = this.BadAddrGroupCode;
            WorkOrder.IsWorkPerformed = this.IsWorkPerformed;
            WorkOrder.IsQCOverride = this.IsQCOverride;
            WorkOrder.TotalAmountDue = this.TotalAmountDue;
            WorkOrder.SubTotalDue = this.SubTotalDue;
            WorkOrder.InvoiceDate = this.InvoiceDate;
            WorkOrder.VendorCoverageId = this.VendorCoverageId;
            WorkOrder.CreatedById = this.CreatedById;
            if (this.CreatedDate != null)
            {
                if (this.CreatedDate.Kind == DateTimeKind.Utc)
                    WorkOrder.CreatedDate = this.CreatedDate;
                else if (this.CreatedDate.Kind == DateTimeKind.Local)
                    WorkOrder.CreatedDate = TimeZoneInfo.ConvertTimeToUtc(this.CreatedDate);
                else
                    WorkOrder.CreatedDate = TimeZoneInfo.ConvertTimeToUtc(this.CreatedDate, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
            }
            else
            {
                WorkOrder.CreatedDate = this.CreatedDate;
            }
            WorkOrder.LastUpdatedById = this.LastUpdatedById;
            if (this.LastUpdatedDate.HasValue)
            {
                if (this.LastUpdatedDate.Value.Kind == DateTimeKind.Utc)
                    WorkOrder.LastUpdatedDate = this.LastUpdatedDate;
                else if (this.LastUpdatedDate.Value.Kind == DateTimeKind.Local)
                    WorkOrder.LastUpdatedDate = TimeZoneInfo.ConvertTimeToUtc(this.LastUpdatedDate.Value);
                else
                    WorkOrder.LastUpdatedDate = TimeZoneInfo.ConvertTimeToUtc(this.LastUpdatedDate.Value, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
            }
            else
            {
                WorkOrder.LastUpdatedDate = this.LastUpdatedDate;
            }
            WorkOrder.Version = string.IsNullOrEmpty(this.Version) ? null : Convert.FromBase64String(this.Version);
            WorkOrder.OrdinanceProfileId = this.OrdinanceProfileId;
            if (this.Order != null)
            {
                WorkOrder.Order = new Domain.Order();
                WorkOrder.Order = this.Order.MapToDomainModelWithoutCollections(WorkOrder.Order);
            }
            if (this.Product != null)
            {
                WorkOrder.Product = new Domain.Product();
                WorkOrder.Product = this.Product.MapToDomainModelWithoutCollections(WorkOrder.Product);
            }
            WorkOrder.SubmissionDate = this.SubmissionDate;
            if (this.VendorProfile != null)
            {
                WorkOrder.VendorProfile = new Domain.VendorProfile();
            }
            if (this.VendorWorkOrder != null)
            {
                WorkOrder.VendorWorkOrder = new Domain.VendorWorkOrder();
                WorkOrder.VendorWorkOrder = this.VendorWorkOrder.MapToDomainModelWithoutCollections(WorkOrder.VendorWorkOrder);
            }
            WorkOrder.WorkOrderId = this.WorkOrderId;
            return WorkOrder;
        }
        public void MapToDtoWithoutCollections(Domain.WorkOrder WorkOrder)
        {
            this.ApplicationId = WorkOrder.ApplicationId;
            this.SourceWorkOrderId = WorkOrder.SourceWorkOrderId;
            this.OrderId = WorkOrder.OrderId;
            this.ProductId = WorkOrder.ProductId;
            this.VendorWorkOrderId = WorkOrder.VendorWorkOrderId;
            this.WorkOrderStatusGroup = WorkOrder.WorkOrderStatusGroup;
            this.WorkOrderStatusType = WorkOrder.WorkOrderStatusType;
            this.CancellationReasonGroup = WorkOrder.CancellationReasonGroup;
            this.CancellationReasonType = WorkOrder.CancellationReasonType;
            this.AssignedVendorId = WorkOrder.AssignedVendorId;
            this.AssignedDate = WorkOrder.AssignedDate;
            this.RequestedDate = WorkOrder.RequestedDate;
            this.WindowStartDate = WorkOrder.WindowStartDate;
            this.WindowEndDate = WorkOrder.WindowEndDate;
            this.DueToClientDate = WorkOrder.DueToClientDate;
            this.OrigVendorDueDate = WorkOrder.OrigVendorDueDate;
            this.DueFromVendorDate = WorkOrder.DueFromVendorDate;
            this.CompletedDate = WorkOrder.CompletedDate;
            this.CancellationDate = WorkOrder.CancellationDate;
            this.TransmittedDate = WorkOrder.TransmittedDate;
            this.AcctProcessedDate = WorkOrder.AcctProcessedDate;
            this.BorrowerFirstName = WorkOrder.BorrowerFirstName;
            this.BorrowerMiddleInitial = WorkOrder.BorrowerMiddleInitial;
            this.BorrowerLastName = WorkOrder.BorrowerLastName;
            this.AddressLine1 = WorkOrder.AddressLine1;
            this.AddressLine2 = WorkOrder.AddressLine2;
            this.CityName = WorkOrder.CityName;
            this.StateCode = WorkOrder.StateCode;
            this.ZipCode = WorkOrder.ZipCode;
            this.ZipPlusFour = WorkOrder.ZipPlusFour;
            this.CountyName = WorkOrder.CountyName;
            this.SpecialInstructions = WorkOrder.SpecialInstructions;
            this.IsRushOrder = WorkOrder.IsRushOrder;
            this.IsBillClient = WorkOrder.IsBillClient;
            this.IsFirstTimeVacant = WorkOrder.IsFirstTimeVacant;
            this.IsVacantToOccupied = WorkOrder.IsVacantToOccupied;
            this.PayVendorGroup = WorkOrder.PayVendorGroup;
            this.PayVendorType = WorkOrder.PayVendorType;
            this.IsCountedTowardScore = WorkOrder.IsCountedTowardScore;
            this.DoorCardTypeGroup = WorkOrder.DoorCardTypeGroup;
            this.DoorCardType = WorkOrder.DoorCardType;
            this.DoorCardMessageText = WorkOrder.DoorCardMessageText;
            this.InspectorUniqueId = WorkOrder.InspectorUniqueId;
            this.ClientSystemId = WorkOrder.ClientSystemId;
            this.ClientDepartment = WorkOrder.ClientDepartment;
            this.InspectionDate1 = WorkOrder.InspectionDate1;
            this.InspectionDate2 = WorkOrder.InspectionDate2;
            this.InspectionDate3 = WorkOrder.InspectionDate3;
            this.AccessDeniedType = WorkOrder.AccessDeniedType;
            this.BadAddrGroupCode = WorkOrder.BadAddrGroupCode;
            this.IsWorkPerformed = WorkOrder.IsWorkPerformed;
            this.IsQCOverride = WorkOrder.IsQCOverride;
            this.TotalAmountDue = WorkOrder.TotalAmountDue;
            this.SubTotalDue = WorkOrder.SubTotalDue;
            this.InvoiceDate = WorkOrder.InvoiceDate;
            this.VendorCoverageId = WorkOrder.VendorCoverageId;
            this.CreatedById = WorkOrder.CreatedById;
            if (WorkOrder.CreatedDate != null)
            {
                if (WorkOrder.CreatedDate.Kind == DateTimeKind.Utc || WorkOrder.CreatedDate.Kind == DateTimeKind.Unspecified)
                    this.CreatedDate = TimeZoneInfo.ConvertTimeFromUtc(WorkOrder.CreatedDate, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
                else
                    this.CreatedDate = TimeZoneInfo.ConvertTime(WorkOrder.CreatedDate, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
            }
            else
            {
                this.CreatedDate = WorkOrder.CreatedDate;
            }
            this.LastUpdatedById = WorkOrder.LastUpdatedById;
            if (WorkOrder.LastUpdatedDate.HasValue)
            {
                if (WorkOrder.LastUpdatedDate.Value.Kind == DateTimeKind.Utc || WorkOrder.LastUpdatedDate.Value.Kind == DateTimeKind.Unspecified)
                    this.LastUpdatedDate = TimeZoneInfo.ConvertTimeFromUtc(WorkOrder.LastUpdatedDate.Value, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
                else
                    this.LastUpdatedDate = TimeZoneInfo.ConvertTime(WorkOrder.LastUpdatedDate.Value, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
            }
            else
            {
                this.LastUpdatedDate = WorkOrder.LastUpdatedDate;
            }
            this.Version = WorkOrder.Version == null ? null : Convert.ToBase64String(WorkOrder.Version);
            this.OrdinanceProfileId = WorkOrder.OrdinanceProfileId;
            if (WorkOrder.Order != null)
            {
                this.Order = new Order();
                this.Order.MapToDtoWithoutCollections(WorkOrder.Order);
            }
            if (WorkOrder.Product != null)
            {
                this.Product = new Product();
                //this.Product.MapToDtoWithoutCollections(WorkOrder.Product);   //This line commented to map the Product Service as well
                this.Product.MapFromDomainModel<Domain.Product, Product>(WorkOrder.Product);
            }
            this.SubmissionDate = WorkOrder.SubmissionDate;
            if (WorkOrder.VendorProfile != null)
            {
                this.VendorProfile = new VendorProfile();
            }
            if (WorkOrder.VendorWorkOrder != null)
            {
                this.VendorWorkOrder = new VendorWorkOrder();
                this.VendorWorkOrder.MapToDtoWithoutCollections(WorkOrder.VendorWorkOrder);
            }
            this.WorkOrderId = WorkOrder.WorkOrderId;
        }
        public override TDto MapFromDomainModel<TDomain, TDto>(TDomain domainModel)
        {
            Domain.WorkOrder WorkOrderModel = domainModel as Domain.WorkOrder;
            if (WorkOrderModel != null)
            {
                MapToDtoWithoutCollections(WorkOrderModel);
                foreach (Domain.WorkOrderItem WorkOrderItem in WorkOrderModel.WorkOrderItems)
                {
                    WorkOrderItem WorkOrderItemDto = new WorkOrderItem();
                    WorkOrderItemDto = WorkOrderItemDto.MapFromDomainModel<Domain.WorkOrderItem, WorkOrderItem>(WorkOrderItem);
                    this.WorkOrderItems.Add(WorkOrderItemDto);
                }
                foreach (Domain.Cancellation Cancellation in WorkOrderModel.Cancellations)
                {
                    Cancellation CancellationDto = new Cancellation();
                    CancellationDto = CancellationDto.MapFromDomainModel<Domain.Cancellation, Cancellation>(Cancellation);
                    this.Cancellations.Add(CancellationDto);
                }
            }
            return this as TDto;
        }
        private void MapWorkOrderItems(Domain.WorkOrder destObj)
        {
            if (WorkOrderItems != null)
            {
                foreach (WorkOrderItem WorkOrderItem in WorkOrderItems)
                {
                    Domain.WorkOrderItem WorkOrderItemModel;
                    if (WorkOrderItem.WorkOrderItemId == 0)
                    {
                        WorkOrderItemModel = new Domain.WorkOrderItem();
                        WorkOrderItemModel = WorkOrderItem.MapToDomainModel<Domain.WorkOrderItem>(WorkOrderItemModel) as Domain.WorkOrderItem;
                        destObj.WorkOrderItems.Add(WorkOrderItemModel);
                    }
                    else
                    {
                        WorkOrderItemModel = destObj.WorkOrderItems.FirstOrDefault(a => a.WorkOrderItemId == WorkOrderItem.WorkOrderItemId);
                        if (WorkOrderItemModel != null)
                        {
                            if (WorkOrderItem.HardDelete)
                            {
                                destObj.WorkOrderItems.Remove(WorkOrderItemModel);
                            }
                            else
                            {
                                WorkOrderItemModel = WorkOrderItem.MapToDomainModel<Domain.WorkOrderItem>(WorkOrderItemModel) as Domain.WorkOrderItem;
                            }
                        }
                    }
                }
            }
        }
        private void MapCancellations(Domain.WorkOrder destObj)
        {
            if (Cancellations != null)
            {
                foreach (Cancellation Cancellation in Cancellations)
                {
                    Domain.Cancellation CancellationModel;
                    if (Cancellation.CancellationId == 0)
                    {
                        CancellationModel = new Domain.Cancellation();
                        CancellationModel = Cancellation.MapToDomainModel<Domain.Cancellation>(CancellationModel) as Domain.Cancellation;
                        destObj.Cancellations.Add(CancellationModel);
                    }
                    else
                    {
                        CancellationModel = destObj.Cancellations.FirstOrDefault(a => a.CancellationId == Cancellation.CancellationId);
                        if (CancellationModel != null)
                        {
                            if (Cancellation.HardDelete)
                            {
                                destObj.Cancellations.Remove(CancellationModel);
                            }
                            else
                            {
                                CancellationModel = Cancellation.MapToDomainModel<Domain.Cancellation>(CancellationModel) as Domain.Cancellation;
                            }
                        }
                    }
                }
            }
        }
        public override TDomain MapToDomainModel<TDomain>(TDomain domainModel)
        {
            Domain.WorkOrder WorkOrderModel = domainModel as Domain.WorkOrder;
            Domain.WorkOrder destObj = MapToDomainModelWithoutCollections(WorkOrderModel);
            MapWorkOrderItems(destObj);
            MapCancellations(destObj);
            return destObj as TDomain;
        }
    }
}

