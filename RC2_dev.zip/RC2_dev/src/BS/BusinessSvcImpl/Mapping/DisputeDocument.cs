using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using CommonLib.DataObjects;
using CommonLib.ModelAttrib;
using Domain = DomainModel.Accounting;
namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{
    [System.CodeDom.Compiler.GeneratedCode("EF", "6.1.0")]
    public partial class DisputeDocument : BaseDto
    {
        public Domain.DisputeDocument MapToDomainModelWithoutCollections(Domain.DisputeDocument DisputeDocument)
        {
            DisputeDocument.DocumentId = this.DocumentId;
            DisputeDocument.AccountingDisputeId = this.AccountingDisputeId;
            DisputeDocument.AdditionalDocGroup = string.IsNullOrEmpty(this.AdditionalDocType) ? null : GroupCodeEnum.DOC.ToString();
            DisputeDocument.AdditionalDocType = this.AdditionalDocType;
            DisputeDocument.CreatedById = this.CreatedById;
            DisputeDocument.CreatedDate = this.CreatedDate;
            DisputeDocument.LastUpdatedById = this.LastUpdatedById;
            DisputeDocument.LastUpdatedDate = this.LastUpdatedDate;
            DisputeDocument.Version = string.IsNullOrEmpty(this.Version) ? null : Convert.FromBase64String(this.Version);
            DisputeDocument.DisputeDocumentId = this.DisputeDocumentId;
            return DisputeDocument;
        }
        public void MapToDtoWithoutCollections(Domain.DisputeDocument DisputeDocument)
        {
            this.DocumentId = DisputeDocument.DocumentId;
            this.AccountingDisputeId = DisputeDocument.AccountingDisputeId;
            this.AdditionalDocType = DisputeDocument.AdditionalDocType;
            this.CreatedById = DisputeDocument.CreatedById;
            this.CreatedDate = DisputeDocument.CreatedDate;
            this.LastUpdatedById = DisputeDocument.LastUpdatedById;
            this.LastUpdatedDate = DisputeDocument.LastUpdatedDate;
            this.Version = DisputeDocument.Version == null ? null : Convert.ToBase64String(DisputeDocument.Version);
            this.DisputeDocumentId = DisputeDocument.DisputeDocumentId;
        }
        public override TDto MapFromDomainModel<TDomain, TDto>(TDomain domainModel)
        {
            Domain.DisputeDocument DisputeDocumentModel = domainModel as Domain.DisputeDocument;
            if (DisputeDocumentModel != null)
            {
                MapToDtoWithoutCollections(DisputeDocumentModel);
            }
            return this as TDto;
        }
        public override TDomain MapToDomainModel<TDomain>(TDomain domainModel)
        {
            Domain.DisputeDocument DisputeDocumentModel = domainModel as Domain.DisputeDocument;
            Domain.DisputeDocument destObj = MapToDomainModelWithoutCollections(DisputeDocumentModel);
            return destObj as TDomain;
        }
    }
}

