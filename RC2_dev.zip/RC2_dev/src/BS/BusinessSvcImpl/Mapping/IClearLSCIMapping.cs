using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using CommonLib.DataObjects;
using CommonLib.ModelAttrib;
using Domain = DomainModel.Accounting;
namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{ 
[System.CodeDom.Compiler.GeneratedCode("EF", "6.1.0")]
	public partial class IClearLSCIMapping : BaseDto
	{ 
		public Domain.IClearLSCIMapping MapToDomainModelWithoutCollections(Domain.IClearLSCIMapping IClearLSCIMapping)
		{ 
			IClearLSCIMapping.ApplicationId = this.ApplicationId;
			IClearLSCIMapping.MasterClientProfileId = this.MasterClientProfileId;
			IClearLSCIMapping.SubClientProfileId = this.SubClientProfileId;
			IClearLSCIMapping.IClearClientCode = this.IClearClientCode;
			IClearLSCIMapping.LOBTypeGroup = this.LOBTypeGroup;
			IClearLSCIMapping.LOBType = this.LOBType;
			IClearLSCIMapping.CreatedById = this.CreatedById;
            IClearLSCIMapping.LineItemId = this.LineItemId;
			if(this.CreatedDate!=null)
			{
				if(this.CreatedDate.Kind == DateTimeKind.Utc)
					IClearLSCIMapping.CreatedDate = this.CreatedDate;
				else if(this.CreatedDate.Kind == DateTimeKind.Local)
					IClearLSCIMapping.CreatedDate = TimeZoneInfo.ConvertTimeToUtc(this.CreatedDate);
				else
					IClearLSCIMapping.CreatedDate = TimeZoneInfo.ConvertTimeToUtc(this.CreatedDate, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
			}
			else
			{
				IClearLSCIMapping.CreatedDate = this.CreatedDate;
			}
			IClearLSCIMapping.LastUpdatedById = this.LastUpdatedById;
			if(this.LastUpdatedDate.HasValue)
			{
				if(this.LastUpdatedDate.Value.Kind == DateTimeKind.Utc)
					IClearLSCIMapping.LastUpdatedDate = this.LastUpdatedDate;
				else if(this.LastUpdatedDate.Value.Kind == DateTimeKind.Local)
					IClearLSCIMapping.LastUpdatedDate = TimeZoneInfo.ConvertTimeToUtc(this.LastUpdatedDate.Value);
				else
					IClearLSCIMapping.LastUpdatedDate = TimeZoneInfo.ConvertTimeToUtc(this.LastUpdatedDate.Value, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
			}
			else
			{
				IClearLSCIMapping.LastUpdatedDate = this.LastUpdatedDate;
			}
            IClearLSCIMapping.Version = string.IsNullOrEmpty(this.Version) ? null: Convert.FromBase64String(this.Version);
			IClearLSCIMapping.IClearLSCIMappingId = this.IClearLSCIMappingId;
			return IClearLSCIMapping;
		} 
		public void MapToDtoWithoutCollections(Domain.IClearLSCIMapping IClearLSCIMapping)
		{ 
			this.ApplicationId = IClearLSCIMapping.ApplicationId;
			this.MasterClientProfileId = IClearLSCIMapping.MasterClientProfileId;
			this.SubClientProfileId = IClearLSCIMapping.SubClientProfileId;
			this.IClearClientCode = IClearLSCIMapping.IClearClientCode;
			this.LOBTypeGroup = IClearLSCIMapping.LOBTypeGroup;
			this.LOBType = IClearLSCIMapping.LOBType;
			this.CreatedById = IClearLSCIMapping.CreatedById;
            this.LineItemId = IClearLSCIMapping.LineItemId;
			if(IClearLSCIMapping.CreatedDate!=null)
			{
				if(IClearLSCIMapping.CreatedDate.Kind == DateTimeKind.Utc || IClearLSCIMapping.CreatedDate.Kind == DateTimeKind.Unspecified)
					this.CreatedDate = TimeZoneInfo.ConvertTimeFromUtc(IClearLSCIMapping.CreatedDate, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
				else
					this.CreatedDate = TimeZoneInfo.ConvertTime(IClearLSCIMapping.CreatedDate, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
			}
			else
			{
				this.CreatedDate = IClearLSCIMapping.CreatedDate;
			}
			this.LastUpdatedById = IClearLSCIMapping.LastUpdatedById;
			if(IClearLSCIMapping.LastUpdatedDate.HasValue)
			{
				if(IClearLSCIMapping.LastUpdatedDate.Value.Kind == DateTimeKind.Utc || IClearLSCIMapping.LastUpdatedDate.Value.Kind == DateTimeKind.Unspecified)
					this.LastUpdatedDate = TimeZoneInfo.ConvertTimeFromUtc(IClearLSCIMapping.LastUpdatedDate.Value, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
				else
					this.LastUpdatedDate = TimeZoneInfo.ConvertTime(IClearLSCIMapping.LastUpdatedDate.Value, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
			}
			else
			{
				this.LastUpdatedDate = IClearLSCIMapping.LastUpdatedDate;
			}
            this.Version = IClearLSCIMapping.Version == null ? null:Convert.ToBase64String(IClearLSCIMapping.Version);
			this.IClearLSCIMappingId = IClearLSCIMapping.IClearLSCIMappingId;
		} 
		public override TDto MapFromDomainModel<TDomain, TDto>(TDomain domainModel)
		{ 
			Domain.IClearLSCIMapping IClearLSCIMappingModel = domainModel as Domain.IClearLSCIMapping;
			if(IClearLSCIMappingModel != null)
			{ 
				MapToDtoWithoutCollections(IClearLSCIMappingModel);
			} 
				return this as TDto;
		} 
		public override TDomain MapToDomainModel<TDomain>(TDomain domainModel)
		{ 
			Domain.IClearLSCIMapping IClearLSCIMappingModel = domainModel as Domain.IClearLSCIMapping;
			Domain.IClearLSCIMapping destObj = MapToDomainModelWithoutCollections(IClearLSCIMappingModel);
		    return destObj as TDomain;
		} 
	} 
} 

