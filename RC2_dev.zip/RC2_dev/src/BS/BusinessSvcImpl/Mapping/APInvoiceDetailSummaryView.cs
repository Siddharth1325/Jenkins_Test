 
 
 
         
 

 


using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using CommonLib.DataObjects;
using CommonLib.ModelAttrib;
using Domain = DomainModel.Accounting;
namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{ 
[System.CodeDom.Compiler.GeneratedCode("EF", "6.1.0")]
	public partial class APInvoiceDetailSummaryView : BaseDto
	{ 
		public Domain.APInvoiceDetailSummaryView MapToDomainModelWithoutCollections(Domain.APInvoiceDetailSummaryView APInvoiceDetailSummaryView)
		{ 
			APInvoiceDetailSummaryView.VendorId = this.VendorId;
			APInvoiceDetailSummaryView.VendorName = this.VendorName;
			APInvoiceDetailSummaryView.InvoiceNumber = this.InvoiceNumber;
			APInvoiceDetailSummaryView.InvoiceDate = this.InvoiceDate;
			APInvoiceDetailSummaryView.InvoiceAmount = this.InvoiceAmount;
			APInvoiceDetailSummaryView.CheckDate = this.CheckDate;
			APInvoiceDetailSummaryView.CheckNumber = this.CheckNumber;
			APInvoiceDetailSummaryView.PaidAmount = this.PaidAmount;
            APInvoiceDetailSummaryView.OrdinanceProfileId = this.OrdinanceProfileId;
           // APInvoiceDetailSummaryView.Municipality = this.Municipality;
            //APInvoiceDetailSummaryView.MunicipalityZipCode = this.MunicipalityZipCode;
            APInvoiceDetailSummaryView.VendorWorkOrderId = this.VendorWorkOrderId;
			return APInvoiceDetailSummaryView;
		} 
		public void MapToDtoWithoutCollections(Domain.APInvoiceDetailSummaryView APInvoiceDetailSummaryView)
		{ 
			this.VendorId = APInvoiceDetailSummaryView.VendorId;
			this.VendorName = APInvoiceDetailSummaryView.VendorName;
			this.InvoiceNumber = APInvoiceDetailSummaryView.InvoiceNumber;
			this.InvoiceDate = APInvoiceDetailSummaryView.InvoiceDate;
			this.InvoiceAmount = APInvoiceDetailSummaryView.InvoiceAmount;
			this.CheckDate = APInvoiceDetailSummaryView.CheckDate;
			this.CheckNumber = APInvoiceDetailSummaryView.CheckNumber;
			this.PaidAmount = APInvoiceDetailSummaryView.PaidAmount;
            this.OrdinanceProfileId = APInvoiceDetailSummaryView.OrdinanceProfileId;
            //this.MunicipalityZipCode = APInvoiceDetailSummaryView.MunicipalityZipCode;
            //this.Municipality = APInvoiceDetailSummaryView.Municipality;
            this.VendorWorkOrderId = APInvoiceDetailSummaryView.VendorWorkOrderId;
		} 
		public override TDto MapFromDomainModel<TDomain, TDto>(TDomain domainModel)
		{ 
			Domain.APInvoiceDetailSummaryView APInvoiceDetailSummaryViewModel = domainModel as Domain.APInvoiceDetailSummaryView;
			if(APInvoiceDetailSummaryViewModel != null)
			{ 
				MapToDtoWithoutCollections(APInvoiceDetailSummaryViewModel);
			} 
				return this as TDto;
		} 
		public override TDomain MapToDomainModel<TDomain>(TDomain domainModel)
		{ 
			Domain.APInvoiceDetailSummaryView APInvoiceDetailSummaryViewModel = domainModel as Domain.APInvoiceDetailSummaryView;
			Domain.APInvoiceDetailSummaryView destObj = MapToDomainModelWithoutCollections(APInvoiceDetailSummaryViewModel);
		    return destObj as TDomain;
		} 
	} 
} 

