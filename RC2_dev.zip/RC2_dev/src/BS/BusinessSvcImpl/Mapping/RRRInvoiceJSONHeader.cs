﻿
using CommonLib.DataObjects;
using System;
using System.Collections.Generic;

namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{
    public partial class RRRInvoiceJSONHeader : BaseDto
    {
        //public DomainModel.Accounting.RRRInvoiceJSONHeader MapToDomainModelWithoutCollections(DomainModel.Accounting.RRRInvoiceJSONHeader RRRInvoiceJSONHeader)
        //{
        //    RRRInvoiceJSONHeader.AccountingExportMasterId = this.AccountingExportMasterId;
        //    RRRInvoiceJSONHeader.ApplicationId = this.ApplicationId;
        //    RRRInvoiceJSONHeader.BillTo = this.BillTo;
        //    RRRInvoiceJSONHeader.ClientInvoiceNumber = this.ClientInvoiceNumber;
        //    RRRInvoiceJSONHeader.ClientOrderNumber = this.ClientOrderNumber;
        //    RRRInvoiceJSONHeader.CompletionDate = this.CompletionDate;
        //    RRRInvoiceJSONHeader.HUDCostToDate = this.HUDCostToDate;
        //    RRRInvoiceJSONHeader.InvoiceApprovedAmount = this.InvoiceApprovedAmount;
        //    RRRInvoiceJSONHeader.InvoiceDate = this.InvoiceDate;
        //    RRRInvoiceJSONHeader.InvoiceDecisionComments = this.InvoiceDecisionComments;
        //    RRRInvoiceJSONHeader.InvoiceDecisionStatus = this.InvoiceDecisionStatus;
        //    RRRInvoiceJSONHeader.InvoiceExportId = this.InvoiceExportId;
        //    RRRInvoiceJSONHeader.InvoiceNumber = this.InvoiceNumber;
        //    RRRInvoiceJSONHeader.InvoiceSubtotal = this.InvoiceSubtotal;
        //    RRRInvoiceJSONHeader.InvoiceTax = this.InvoiceTax;
        //    RRRInvoiceJSONHeader.InvoiceTotal = this.InvoiceTotal;
        //    RRRInvoiceJSONHeader.LoanNumber = this.LoanNumber;
        //    RRRInvoiceJSONHeader.LoanType = this.LoanType;
        //    RRRInvoiceJSONHeader.OrderBy = this.OrderBy;
        //    RRRInvoiceJSONHeader.OrderId = this.OrderId;
        //    RRRInvoiceJSONHeader.OrderOpenDate = this.OrderOpenDate;
        //    RRRInvoiceJSONHeader.PackageName = this.PackageName;
        //    RRRInvoiceJSONHeader.PartnerID = this.PartnerID;
        //    RRRInvoiceJSONHeader.PartnerSystemID = this.PartnerSystemID;
        //    RRRInvoiceJSONHeader.RecordId = this.RecordId;
        //    RRRInvoiceJSONHeader.RecordStatusGroup = this.RecordStatusGroup;
        //    RRRInvoiceJSONHeader.RecordStatusType = this.RecordStatusType;
        //    RRRInvoiceJSONHeader.RRRInvoiceJSONHeaderId = this.RRRInvoiceJSONHeaderId;
        //    RRRInvoiceJSONHeader.CreatedById = this.CreatedById;
        //    if (this.CreatedDate != null)
        //    {
        //        if (this.CreatedDate.Kind == DateTimeKind.Utc)
        //            RRRInvoiceJSONHeader.CreatedDate = this.CreatedDate;
        //        else if (this.CreatedDate.Kind == DateTimeKind.Local)
        //            RRRInvoiceJSONHeader.CreatedDate = TimeZoneInfo.ConvertTimeToUtc(this.CreatedDate);
        //        else
        //            RRRInvoiceJSONHeader.CreatedDate = TimeZoneInfo.ConvertTimeToUtc(this.CreatedDate, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
        //    }
        //    else
        //    {
        //        RRRInvoiceJSONHeader.CreatedDate = this.CreatedDate;
        //    }
        //    RRRInvoiceJSONHeader.LastUpdatedById = this.LastUpdatedById;
        //    if (this.LastUpdatedDate.HasValue)
        //    {
        //        if (this.LastUpdatedDate.Value.Kind == DateTimeKind.Utc)
        //            RRRInvoiceJSONHeader.LastUpdatedDate = this.LastUpdatedDate;
        //        else if (this.LastUpdatedDate.Value.Kind == DateTimeKind.Local)
        //            RRRInvoiceJSONHeader.LastUpdatedDate = TimeZoneInfo.ConvertTimeToUtc(this.LastUpdatedDate.Value);
        //        else
        //            RRRInvoiceJSONHeader.LastUpdatedDate = TimeZoneInfo.ConvertTimeToUtc(this.LastUpdatedDate.Value, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
        //    }
        //    else
        //    {
        //        RRRInvoiceJSONHeader.LastUpdatedDate = this.LastUpdatedDate;
        //    }
        //    RRRInvoiceJSONHeader.Version = string.IsNullOrEmpty(this.Version) ? null : Convert.FromBase64String(this.Version);
        //    RRRInvoiceJSONHeader.RRRInvoiceJSONDetails = new List<DomainModel.Accounting.RRRInvoiceJSONDetail>();
        //    foreach (var invoiceJsonDetails in this.RRRInvoiceJSONDetails)
        //    {
        //        var invoiceDetail = new DomainModel.Accounting.RRRInvoiceJSONDetail();
        //        invoiceDetail.AccountingExportDetailId = invoiceJsonDetails.AccountingExportDetailId;
        //        invoiceDetail.AccountsReceivableDetailId = invoiceJsonDetails.AccountsReceivableDetailId;
        //        invoiceDetail.ApplicationId = invoiceJsonDetails.ApplicationId;
        //        invoiceDetail.BillingCode = invoiceJsonDetails.BillingCode;
        //        invoiceDetail.Category = invoiceJsonDetails.Category;
        //        invoiceDetail.Description = invoiceJsonDetails.Description;
        //        invoiceDetail.ItemApprovedAmount = invoiceJsonDetails.ItemApprovedAmount;
        //        invoiceDetail.ItemDecisionComments = invoiceJsonDetails.ItemDecisionComments;
        //        invoiceDetail.ItemDecisionStatus = invoiceJsonDetails.ItemDecisionStatus;
        //        invoiceDetail.ItemPrice = invoiceJsonDetails.ItemPrice;
        //        invoiceDetail.ItemSubtotal = invoiceJsonDetails.ItemSubtotal;
        //        invoiceDetail.ItemTax = invoiceJsonDetails.ItemTax;
        //        invoiceDetail.ItemTotal = invoiceJsonDetails.ItemTotal;
        //        invoiceDetail.Quantity = invoiceJsonDetails.Quantity;
        //        invoiceDetail.RecordStatusGroup = invoiceJsonDetails.RecordStatusGroup;
        //        invoiceDetail.RecordStatusType = invoiceJsonDetails.RecordStatusType;
        //        invoiceDetail.RRRInvoiceJSONHeaderId = invoiceJsonDetails.RRRInvoiceJSONHeaderId;
        //        invoiceDetail.CreatedById = invoiceJsonDetails.CreatedById;
        //        if (invoiceJsonDetails.CreatedDate != null)
        //        {
        //            if (invoiceJsonDetails.CreatedDate.Kind == DateTimeKind.Utc)
        //                invoiceDetail.CreatedDate = invoiceJsonDetails.CreatedDate;
        //            else if (invoiceJsonDetails.CreatedDate.Kind == DateTimeKind.Local)
        //                invoiceDetail.CreatedDate = TimeZoneInfo.ConvertTimeToUtc(invoiceJsonDetails.CreatedDate);
        //            else
        //                invoiceDetail.CreatedDate = TimeZoneInfo.ConvertTimeToUtc(invoiceJsonDetails.CreatedDate, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
        //        }
        //        else
        //        {
        //            invoiceDetail.CreatedDate = invoiceJsonDetails.CreatedDate;
        //        }
        //        invoiceDetail.LastUpdatedById = invoiceJsonDetails.LastUpdatedById;
        //        if (invoiceJsonDetails.LastUpdatedDate.HasValue)
        //        {
        //            if (invoiceJsonDetails.LastUpdatedDate.Value.Kind == DateTimeKind.Utc)
        //                invoiceDetail.LastUpdatedDate = invoiceJsonDetails.LastUpdatedDate;
        //            else if (invoiceJsonDetails.LastUpdatedDate.Value.Kind == DateTimeKind.Local)
        //                invoiceDetail.LastUpdatedDate = TimeZoneInfo.ConvertTimeToUtc(invoiceJsonDetails.LastUpdatedDate.Value);
        //            else
        //                invoiceDetail.LastUpdatedDate = TimeZoneInfo.ConvertTimeToUtc(invoiceJsonDetails.LastUpdatedDate.Value, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
        //        }
        //        else
        //        {
        //            invoiceDetail.LastUpdatedDate = invoiceJsonDetails.LastUpdatedDate;
        //        }
        //        invoiceDetail.Version = string.IsNullOrEmpty(invoiceJsonDetails.Version) ? null : Convert.FromBase64String(invoiceJsonDetails.Version);
        //        RRRInvoiceJSONHeader.RRRInvoiceJSONDetails.Add(invoiceDetail);
        //    }
        //    return RRRInvoiceJSONHeader;
        //}
        //public override TDomain MapToDomainModel<TDomain>(TDomain domainModel)
        //{
        //    DomainModel.Accounting.RRRInvoiceJSONHeader headerDetail = domainModel as DomainModel.Accounting.RRRInvoiceJSONHeader;
        //    DomainModel.Accounting.RRRInvoiceJSONHeader destObj = MapToDomainModelWithoutCollections(headerDetail);
        //    return destObj as TDomain;
        //}
    }
}

