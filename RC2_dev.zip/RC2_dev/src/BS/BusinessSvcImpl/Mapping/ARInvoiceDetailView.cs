using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using CommonLib.DataObjects;
using CommonLib.ModelAttrib;
using Domain = DomainModel.Accounting;
namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{ 
[System.CodeDom.Compiler.GeneratedCode("EF", "6.1.0")]
	public partial class ARInvoiceDetailView : BaseDto
	{ 
		public Domain.ARInvoiceDetailView MapToDomainModelWithoutCollections(Domain.ARInvoiceDetailView ARInvoiceDetailView)
		{ 
			ARInvoiceDetailView.InvoiceNumber = this.InvoiceNumber;
			ARInvoiceDetailView.ApplicationId = this.ApplicationId;
			ARInvoiceDetailView.WorkOrderId = this.WorkOrderId;
			ARInvoiceDetailView.LoanNumber = this.LoanNumber;
			ARInvoiceDetailView.InvoiceAmount = this.InvoiceAmount;
			ARInvoiceDetailView.OrderDate = this.OrderDate;
			ARInvoiceDetailView.CompletedDate = this.CompletedDate;
			ARInvoiceDetailView.ProductCode = this.ProductCode;
			ARInvoiceDetailView.LoanType = this.LoanType;
			ARInvoiceDetailView.Occupancy = this.Occupancy;
			ARInvoiceDetailView.MBACode = this.MBACode;
			ARInvoiceDetailView.MortgagorName = this.MortgagorName;
			ARInvoiceDetailView.ClientPrice = this.ClientPrice;
			ARInvoiceDetailView.TaxAmount = this.TaxAmount;
            ARInvoiceDetailView.ProductCategory = this.ProductCategory;
            ARInvoiceDetailView.AccountsReceivableAdjustmentId = this.AccountsReceivableAdjustmentId;
            ARInvoiceDetailView.OrderId = this.OrderId;
			return ARInvoiceDetailView;
		} 
		public void MapToDtoWithoutCollections(Domain.ARInvoiceDetailView ARInvoiceDetailView)
		{ 
			this.InvoiceNumber = ARInvoiceDetailView.InvoiceNumber;
			this.ApplicationId = ARInvoiceDetailView.ApplicationId;
			this.WorkOrderId = ARInvoiceDetailView.WorkOrderId;
			this.LoanNumber = ARInvoiceDetailView.LoanNumber;
			this.InvoiceAmount = ARInvoiceDetailView.InvoiceAmount;
			this.OrderDate = ARInvoiceDetailView.OrderDate;
			this.CompletedDate = ARInvoiceDetailView.CompletedDate;
			this.ProductCode = ARInvoiceDetailView.ProductCode;
			this.LoanType = ARInvoiceDetailView.LoanType;
			this.Occupancy = ARInvoiceDetailView.Occupancy;
			this.MBACode = ARInvoiceDetailView.MBACode;
			this.MortgagorName = ARInvoiceDetailView.MortgagorName;
			this.ClientPrice = ARInvoiceDetailView.ClientPrice;
			this.TaxAmount = ARInvoiceDetailView.TaxAmount;
            this.ProductCategory = ARInvoiceDetailView.ProductCategory;
            this.AccountsReceivableAdjustmentId = ARInvoiceDetailView.AccountsReceivableAdjustmentId;
            this.OrderId = ARInvoiceDetailView.OrderId;
		} 
		public override TDto MapFromDomainModel<TDomain, TDto>(TDomain domainModel)
		{ 
			Domain.ARInvoiceDetailView ARInvoiceDetailViewModel = domainModel as Domain.ARInvoiceDetailView;
			if(ARInvoiceDetailViewModel != null)
			{ 
				MapToDtoWithoutCollections(ARInvoiceDetailViewModel);
			} 
				return this as TDto;
		} 
		public override TDomain MapToDomainModel<TDomain>(TDomain domainModel)
		{ 
			Domain.ARInvoiceDetailView ARInvoiceDetailViewModel = domainModel as Domain.ARInvoiceDetailView;
			Domain.ARInvoiceDetailView destObj = MapToDomainModelWithoutCollections(ARInvoiceDetailViewModel);
		    return destObj as TDomain;
		} 
	} 
} 

