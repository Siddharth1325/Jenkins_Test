using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using CommonLib.DataObjects;
using CommonLib.ModelAttrib;
using Domain = DomainModel.Accounting;
namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{
    [System.CodeDom.Compiler.GeneratedCode("EF", "6.1.0")]
    public partial class Product : BaseDto
    {
        public Domain.Product MapToDomainModelWithoutCollections(Domain.Product Product)
        {
            Product.ApplicationId = this.ApplicationId;
            Product.ProductCode = this.ProductCode;
            Product.ProductName = this.ProductName;
            Product.ProductDesc = this.ProductDesc;
            Product.Instructions = this.Instructions;
            Product.ProductCategoryGroup = this.ProductCategoryGroup;
            Product.ProductCategory = this.ProductCategory;
            Product.IsBundle = this.IsBundle;
            Product.IsInternal = this.IsInternal;
            Product.IsSeasonal = this.IsSeasonal;
            Product.IsRecurring = this.IsRecurring;
            Product.IsAutoAssign = this.IsAutoAssign;
            Product.IsActive = this.IsActive;
            Product.IsFeeBased = this.IsFeeBased;
            if (this.ActiveChangedDate.HasValue)
            {
                if (this.ActiveChangedDate.Value.Kind == DateTimeKind.Utc)
                    Product.ActiveChangedDate = this.ActiveChangedDate;
                else if (this.ActiveChangedDate.Value.Kind == DateTimeKind.Local)
                    Product.ActiveChangedDate = TimeZoneInfo.ConvertTimeToUtc(this.ActiveChangedDate.Value);
                else
                    Product.ActiveChangedDate = TimeZoneInfo.ConvertTimeToUtc(this.ActiveChangedDate.Value, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
            }
            else
            {
                Product.ActiveChangedDate = this.ActiveChangedDate;
            }
            Product.ActiveChangedById = this.ActiveChangedById;
            Product.IsAssignable = this.IsAssignable;
            Product.CreatedById = this.CreatedById;
            if (this.CreatedDate != null)
            {
                if (this.CreatedDate.Kind == DateTimeKind.Utc)
                    Product.CreatedDate = this.CreatedDate;
                else if (this.CreatedDate.Kind == DateTimeKind.Local)
                    Product.CreatedDate = TimeZoneInfo.ConvertTimeToUtc(this.CreatedDate);
                else
                    Product.CreatedDate = TimeZoneInfo.ConvertTimeToUtc(this.CreatedDate, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
            }
            else
            {
                Product.CreatedDate = this.CreatedDate;
            }
            Product.LastUpdatedById = this.LastUpdatedById;
            if (this.LastUpdatedDate.HasValue)
            {
                if (this.LastUpdatedDate.Value.Kind == DateTimeKind.Utc)
                    Product.LastUpdatedDate = this.LastUpdatedDate;
                else if (this.LastUpdatedDate.Value.Kind == DateTimeKind.Local)
                    Product.LastUpdatedDate = TimeZoneInfo.ConvertTimeToUtc(this.LastUpdatedDate.Value);
                else
                    Product.LastUpdatedDate = TimeZoneInfo.ConvertTimeToUtc(this.LastUpdatedDate.Value, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
            }
            else
            {
                Product.LastUpdatedDate = this.LastUpdatedDate;
            }
            Product.Version = string.IsNullOrEmpty(this.Version) ? null : Convert.FromBase64String(this.Version);
            Product.ProductId = this.ProductId;
            return Product;
        }
        public void MapToDtoWithoutCollections(Domain.Product Product)
        {
            this.ApplicationId = Product.ApplicationId;
            this.ProductCode = Product.ProductCode;
            this.ProductName = Product.ProductName;
            this.ProductDesc = Product.ProductDesc;
            this.Instructions = Product.Instructions;
            this.ProductCategoryGroup = Product.ProductCategoryGroup;
            this.ProductCategory = Product.ProductCategory;
            this.IsBundle = Product.IsBundle;
            this.IsInternal = Product.IsInternal;
            this.IsSeasonal = Product.IsSeasonal;
            this.IsRecurring = Product.IsRecurring;
            this.IsAutoAssign = Product.IsAutoAssign;
            this.IsActive = Product.IsActive;
            this.IsFeeBased = Product.IsFeeBased;
            if (Product.ActiveChangedDate.HasValue)
            {
                if (Product.ActiveChangedDate.Value.Kind == DateTimeKind.Utc || Product.ActiveChangedDate.Value.Kind == DateTimeKind.Unspecified)
                    this.ActiveChangedDate = TimeZoneInfo.ConvertTimeFromUtc(Product.ActiveChangedDate.Value, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
                else
                    this.ActiveChangedDate = TimeZoneInfo.ConvertTime(Product.ActiveChangedDate.Value, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
            }
            else
            {
                this.ActiveChangedDate = Product.ActiveChangedDate;
            }
            this.ActiveChangedById = Product.ActiveChangedById;
            this.IsAssignable = Product.IsAssignable;
            this.CreatedById = Product.CreatedById;
            if (Product.CreatedDate != null)
            {
                if (Product.CreatedDate.Kind == DateTimeKind.Utc || Product.CreatedDate.Kind == DateTimeKind.Unspecified)
                    this.CreatedDate = TimeZoneInfo.ConvertTimeFromUtc(Product.CreatedDate, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
                else
                    this.CreatedDate = TimeZoneInfo.ConvertTime(Product.CreatedDate, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
            }
            else
            {
                this.CreatedDate = Product.CreatedDate;
            }
            this.LastUpdatedById = Product.LastUpdatedById;
            if (Product.LastUpdatedDate.HasValue)
            {
                if (Product.LastUpdatedDate.Value.Kind == DateTimeKind.Utc || Product.LastUpdatedDate.Value.Kind == DateTimeKind.Unspecified)
                    this.LastUpdatedDate = TimeZoneInfo.ConvertTimeFromUtc(Product.LastUpdatedDate.Value, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
                else
                    this.LastUpdatedDate = TimeZoneInfo.ConvertTime(Product.LastUpdatedDate.Value, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
            }
            else
            {
                this.LastUpdatedDate = Product.LastUpdatedDate;
            }
            this.Version = Product.Version == null ? null : Convert.ToBase64String(Product.Version);
            this.ProductId = Product.ProductId;
        }
        public override TDto MapFromDomainModel<TDomain, TDto>(TDomain domainModel)
        {
            Domain.Product ProductModel = domainModel as Domain.Product;
            if (ProductModel != null)
            {
                MapToDtoWithoutCollections(ProductModel);
                if (ProductModel.ProductServices != null && ProductModel.ProductServices.Count > 0)
                {
                    foreach (Domain.ProductService ProductService in ProductModel.ProductServices)
                    {
                        ProductService ProductServiceDto = new ProductService();
                        ProductServiceDto = ProductServiceDto.MapFromDomainModel<Domain.ProductService, ProductService>(ProductService);
                        this.ProductServices.Add(ProductServiceDto);
                    }
                }
            }
            return this as TDto;
        }
        private void MapProductServices(Domain.Product destObj)
        {
            if (ProductServices != null)
            {
                foreach (ProductService ProductService in ProductServices)
                {
                    Domain.ProductService ProductServiceModel;
                    if (ProductService.ProductServiceId == 0)
                    {
                        ProductServiceModel = new Domain.ProductService();
                        ProductServiceModel = ProductService.MapToDomainModel<Domain.ProductService>(ProductServiceModel) as Domain.ProductService;
                        destObj.ProductServices.Add(ProductServiceModel);
                    }
                    else
                    {
                        ProductServiceModel = destObj.ProductServices.FirstOrDefault(a => a.ProductServiceId == ProductService.ProductServiceId);
                        if (ProductServiceModel != null)
                        {
                            if (ProductService.HardDelete)
                            {
                                destObj.ProductServices.Remove(ProductServiceModel);
                            }
                            else
                            {
                                ProductServiceModel = ProductService.MapToDomainModel<Domain.ProductService>(ProductServiceModel) as Domain.ProductService;
                            }
                        }
                    }
                }
            }
        }
        public override TDomain MapToDomainModel<TDomain>(TDomain domainModel)
        {
            Domain.Product ProductModel = domainModel as Domain.Product;
            Domain.Product destObj = MapToDomainModelWithoutCollections(ProductModel);
            MapProductServices(destObj);
            return destObj as TDomain;
        }
    }
}

