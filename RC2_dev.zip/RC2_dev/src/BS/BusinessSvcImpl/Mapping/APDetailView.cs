using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using CommonLib.DataObjects;
using CommonLib.ModelAttrib;
using Domain = DomainModel.Accounting;
namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{ 
[System.CodeDom.Compiler.GeneratedCode("EF", "6.1.0")]
	public partial class APDetailView : BaseDto
	{ 
		public Domain.APDetailView MapToDomainModelWithoutCollections(Domain.APDetailView APDetailView)
		{ 
			APDetailView.VendorId = this.VendorId;
			APDetailView.VendorName = this.VendorName;
			APDetailView.ProductName = this.ProductName;
			APDetailView.APDate = this.APDate;
			APDetailView.BaseAmount = this.BaseAmount;
			APDetailView.EligibleAmount = this.EligibleAmount;
			APDetailView.PriceAdjReason = this.PriceAdjReason;
			APDetailView.InvoiceNumber = this.InvoiceNumber;
			APDetailView.InvoiceDate = this.InvoiceDate;
			APDetailView.CheckDate = this.CheckDate;
			APDetailView.CheckNumber = this.CheckNumber;
			APDetailView.PaidAmount = this.PaidAmount;
			APDetailView.WorkOrderId = this.WorkOrderId;
			APDetailView.SourceWorkOrderId = this.SourceWorkOrderId;
			APDetailView.Date = this.Date;
            APDetailView.Status = this.Status;
            APDetailView.VendorWorkOrderId = this.VendorWorkOrderId;
            APDetailView.ProductCode = this.ProductCode;
			return APDetailView;
		} 
		public void MapToDtoWithoutCollections(Domain.APDetailView APDetailView)
		{ 
			this.VendorId = APDetailView.VendorId;
			this.VendorName = APDetailView.VendorName;
			this.ProductName = APDetailView.ProductName;
			this.APDate = APDetailView.APDate;
			this.BaseAmount = APDetailView.BaseAmount;
			this.EligibleAmount = APDetailView.EligibleAmount;
			this.PriceAdjReason = APDetailView.PriceAdjReason;
			this.InvoiceNumber = APDetailView.InvoiceNumber;
			this.InvoiceDate = APDetailView.InvoiceDate;
			this.CheckDate = APDetailView.CheckDate;
			this.CheckNumber = APDetailView.CheckNumber;
			this.PaidAmount = APDetailView.PaidAmount;
			this.WorkOrderId = APDetailView.WorkOrderId;
			this.SourceWorkOrderId = APDetailView.SourceWorkOrderId;
			this.Date = APDetailView.Date;
            this.Status = APDetailView.Status;
            this.VendorWorkOrderId = APDetailView.VendorWorkOrderId;
            this.ProductCode = APDetailView.ProductCode;
		} 
		public override TDto MapFromDomainModel<TDomain, TDto>(TDomain domainModel)
		{ 
			Domain.APDetailView APDetailViewModel = domainModel as Domain.APDetailView;
			if(APDetailViewModel != null)
			{ 
				MapToDtoWithoutCollections(APDetailViewModel);
			} 
				return this as TDto;
		} 
		public override TDomain MapToDomainModel<TDomain>(TDomain domainModel)
		{ 
			Domain.APDetailView APDetailViewModel = domainModel as Domain.APDetailView;
			Domain.APDetailView destObj = MapToDomainModelWithoutCollections(APDetailViewModel);
		    return destObj as TDomain;
		} 
	} 
} 

