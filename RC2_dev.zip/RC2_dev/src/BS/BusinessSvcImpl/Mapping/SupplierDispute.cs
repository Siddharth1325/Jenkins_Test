using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using CommonLib.DataObjects;
using CommonLib.ModelAttrib;
using Domain = DomainModel.Accounting;
namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{ 
[System.CodeDom.Compiler.GeneratedCode("EF", "6.1.0")]
	public partial class SupplierDispute : BaseDto
	{ 
		public Domain.SupplierDispute MapToDomainModelWithoutCollections(Domain.SupplierDispute SupplierDispute)
		{ 
			SupplierDispute.FieldScapeWorkOrderId = this.FieldScapeWorkOrderId;
			SupplierDispute.VendorWorkOrderId = this.VendorWorkOrderId;
			SupplierDispute.InspWorkOrderId = this.InspWorkOrderId;
			SupplierDispute.BulkId = this.BulkId;
			SupplierDispute.VendorDisputeComments = this.VendorDisputeComments;
			SupplierDispute.SLFSResponseToVendor = this.SLFSResponseToVendor;
			SupplierDispute.VendorEscalationComments = this.VendorEscalationComments;
			SupplierDispute.SLFSResponseToEscalation = this.SLFSResponseToEscalation;
			SupplierDispute.DisputeStatusGroup = this.DisputeStatusGroup;
			SupplierDispute.DisputeStatusType = this.DisputeStatusType;
			SupplierDispute.DisputeResolutionGroup = this.DisputeResolutionGroup;
			SupplierDispute.DisputeResolutionType = this.DisputeResolutionType;
			SupplierDispute.DisputeCompleteDate = this.DisputeCompleteDate;
			SupplierDispute.ResponsibleDepartmentGroup = this.ResponsibleDepartmentGroup;
			SupplierDispute.ResponsibleDepartmentType = this.ResponsibleDepartmentType;
			SupplierDispute.DisputeGroup = this.DisputeGroup;
			SupplierDispute.DisputeType = this.DisputeType;
			SupplierDispute.DisputeErrorCausedById = this.DisputeErrorCausedById;
			SupplierDispute.CreditVendorAmount = this.CreditVendorAmount;
			SupplierDispute.DebitVendorAmount = this.DebitVendorAmount;
			SupplierDispute.RebillNumber = this.RebillNumber;
			SupplierDispute.HardLossAmount = this.HardLossAmount;
			SupplierDispute.DisputeErrorGroup = this.DisputeErrorGroup;
			SupplierDispute.DisputeErrorType = this.DisputeErrorType;
			SupplierDispute.ApprovedById = this.ApprovedById;
			SupplierDispute.VendorId = this.VendorId;
			SupplierDispute.CreatedById = this.CreatedById;
			SupplierDispute.CreatedDate = this.CreatedDate;
			SupplierDispute.LastUpdatedById = this.LastUpdatedById;
			SupplierDispute.LastUpdatedDate = this.LastUpdatedDate;
            SupplierDispute.Version = string.IsNullOrEmpty(this.Version) ? null: Convert.FromBase64String(this.Version);
			SupplierDispute.SupplierDisputeId = this.SupplierDisputeId;
            SupplierDispute.AssignUserId = this.AssignUserId;
            SupplierDispute.DisputeReasonType = this.DisputeReasonType;
            SupplierDispute.DisputeReasonGroup = this.DisputeReasonGroup;
            SupplierDispute.DisputeAmount = this.DisputeAmount;
            SupplierDispute.DisputecompletedById = this.DisputecompletedById;
            SupplierDispute.EscalatedByVendor = this.EscalatedByVendor;
			return SupplierDispute;
		} 
		public void MapToDtoWithoutCollections(Domain.SupplierDispute SupplierDispute)
		{ 
			this.FieldScapeWorkOrderId = SupplierDispute.FieldScapeWorkOrderId;
			this.VendorWorkOrderId = SupplierDispute.VendorWorkOrderId;
			this.InspWorkOrderId = SupplierDispute.InspWorkOrderId;
            this.BulkId = SupplierDispute.BulkId;
			this.VendorDisputeComments = SupplierDispute.VendorDisputeComments;
			this.SLFSResponseToVendor = SupplierDispute.SLFSResponseToVendor;
			this.VendorEscalationComments = SupplierDispute.VendorEscalationComments;
			this.SLFSResponseToEscalation = SupplierDispute.SLFSResponseToEscalation;
			this.DisputeStatusGroup = SupplierDispute.DisputeStatusGroup;
			this.DisputeStatusType = SupplierDispute.DisputeStatusType;
			this.DisputeResolutionGroup = SupplierDispute.DisputeResolutionGroup;
			this.DisputeResolutionType = SupplierDispute.DisputeResolutionType;
			this.DisputeCompleteDate = SupplierDispute.DisputeCompleteDate;
			this.ResponsibleDepartmentGroup = SupplierDispute.ResponsibleDepartmentGroup;
			this.ResponsibleDepartmentType = SupplierDispute.ResponsibleDepartmentType;
			this.DisputeGroup = SupplierDispute.DisputeGroup;
			this.DisputeType = SupplierDispute.DisputeType;
			this.DisputeErrorCausedById = SupplierDispute.DisputeErrorCausedById;
			this.CreditVendorAmount = SupplierDispute.CreditVendorAmount;
			this.DebitVendorAmount = SupplierDispute.DebitVendorAmount;
			this.RebillNumber = SupplierDispute.RebillNumber;
			this.HardLossAmount = SupplierDispute.HardLossAmount;
			this.DisputeErrorGroup = SupplierDispute.DisputeErrorGroup;
			this.DisputeErrorType = SupplierDispute.DisputeErrorType;
			this.ApprovedById = SupplierDispute.ApprovedById;
			this.VendorId = SupplierDispute.VendorId;
			this.CreatedById = SupplierDispute.CreatedById;
			this.CreatedDate = SupplierDispute.CreatedDate;
			this.LastUpdatedById = SupplierDispute.LastUpdatedById;
			this.LastUpdatedDate = SupplierDispute.LastUpdatedDate;
            this.Version = SupplierDispute.Version == null ? null:Convert.ToBase64String(SupplierDispute.Version);
			this.SupplierDisputeId = SupplierDispute.SupplierDisputeId;
            this.AssignUserId = SupplierDispute.AssignUserId;
            this.DisputeReasonGroup = SupplierDispute.DisputeReasonGroup;
            this.DisputeReasonType = SupplierDispute.DisputeReasonType;
            this.DisputeAmount = SupplierDispute.DisputeAmount;
            this.DisputecompletedById = SupplierDispute.DisputecompletedById;
            this.EscalatedByVendor = SupplierDispute.EscalatedByVendor;
		} 
		public override TDto MapFromDomainModel<TDomain, TDto>(TDomain domainModel)
		{ 
			Domain.SupplierDispute SupplierDisputeModel = domainModel as Domain.SupplierDispute;
			if(SupplierDisputeModel != null)
			{ 
				MapToDtoWithoutCollections(SupplierDisputeModel);
			} 
				return this as TDto;
		} 
		public override TDomain MapToDomainModel<TDomain>(TDomain domainModel)
		{ 
			Domain.SupplierDispute SupplierDisputeModel = domainModel as Domain.SupplierDispute;
			Domain.SupplierDispute destObj = MapToDomainModelWithoutCollections(SupplierDisputeModel);
		    return destObj as TDomain;
		} 
	} 
} 

