using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using CommonLib.DataObjects;
using CommonLib.ModelAttrib;
using Domain = DomainModel.Accounting;
namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{
    [System.CodeDom.Compiler.GeneratedCode("EF", "6.1.0")]
    public partial class DisputeSearchResult : BaseDto
    {
        public Domain.DisputeSearchResult MapToDomainModelWithoutCollections(Domain.DisputeSearchResult DisputeSearchResult)
        {
            DisputeSearchResult.DisputeStatusType = this.DisputeStatusType;
            //DisputeSearchResult.AssignedTo = this.AssignedTo;
            DisputeSearchResult.DisputeDate = this.DisputeDueDateTo;
            DisputeSearchResult.DisputeDueDate = this.DisputeDueDateFrom;
            DisputeSearchResult.InvoiceNumber = this.InvoiceNumber;
            DisputeSearchResult.DisputeTType = this.DisputeType;
            //DisputeSearchResult.ClientName = this.ClientName;
            DisputeSearchResult.LoanNumber = this.LoanNumber;
            DisputeSearchResult.VendorId = this.VendorId;
            DisputeSearchResult.VendorWorkOrderId = this.VendorWorkOrderId;
            DisputeSearchResult.InspWorkOrder = this.InspWorkOrderId;
            DisputeSearchResult.DisputeAmount = this.DisputeAmount;
            DisputeSearchResult.DisputeId = this.DisputeId;
            DisputeSearchResult.DisputeResolution = this.DisputeResolution;
            DisputeSearchResult.WorkOrderCompleteDate = this.WorkOrderCompleteDate;
            return DisputeSearchResult;
        }
        public void MapToDtoWithoutCollections(Domain.DisputeSearchResult DisputeSearchResult)
        {
            this.DisputeStatusType = DisputeSearchResult.DisputeStatusType;
            //this.AssignedTo = DisputeSearchResult.AssignedTo;
            this.DisputeDueDateTo = DisputeSearchResult.DisputeDate;
            this.DisputeDueDateFrom = DisputeSearchResult.DisputeDueDate;
            this.InvoiceNumber = DisputeSearchResult.InvoiceNumber;
            this.DisputeType = DisputeSearchResult.DisputeTType;
            //this.ClientName = DisputeSearchResult.ClientName;
            this.LoanNumber = DisputeSearchResult.LoanNumber;
            this.VendorId = DisputeSearchResult.VendorId;
            this.VendorWorkOrderId = DisputeSearchResult.VendorWorkOrderId;
            this.InspWorkOrderId = DisputeSearchResult.InspWorkOrder;
            this.DisputeAmount = DisputeSearchResult.DisputeAmount;
            this.DisputeId = DisputeSearchResult.DisputeId;
            this.DisputeResolution = DisputeSearchResult.DisputeResolution;
            this.WorkOrderCompleteDate = DisputeSearchResult.WorkOrderCompleteDate;
        }
        public override TDto MapFromDomainModel<TDomain, TDto>(TDomain domainModel)
        {
            Domain.DisputeSearchResult DisputeSearchResultModel = domainModel as Domain.DisputeSearchResult;
            if (DisputeSearchResultModel != null)
            {
                MapToDtoWithoutCollections(DisputeSearchResultModel);
            }
            return this as TDto;
        }
        public override TDomain MapToDomainModel<TDomain>(TDomain domainModel)
        {
            Domain.DisputeSearchResult DisputeSearchResultModel = domainModel as Domain.DisputeSearchResult;
            Domain.DisputeSearchResult destObj = MapToDomainModelWithoutCollections(DisputeSearchResultModel);
            return destObj as TDomain;
        }
    }
}

