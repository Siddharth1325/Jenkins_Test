using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using CommonLib.DataObjects;
using CommonLib.ModelAttrib;
using Domain = DomainModel.Accounting;
namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{ 
[System.CodeDom.Compiler.GeneratedCode("EF", "6.1.0")]
	public partial class AccountingAPInvoicePayable : BaseDto
	{ 
		public Domain.AccountingAPInvoicePayable MapToDomainModelWithoutCollections(Domain.AccountingAPInvoicePayable AccountingAPInvoicePayable)
		{ 
			AccountingAPInvoicePayable.ApplicationId = this.ApplicationId;
			AccountingAPInvoicePayable.AccountsPayableInvoiceId = this.AccountsPayableInvoiceId;
			AccountingAPInvoicePayable.AccountsPayableId = this.AccountsPayableId;
			AccountingAPInvoicePayable.CreatedById = this.CreatedById;
			if(this.CreatedDate!=null)
			{
				if(this.CreatedDate.Kind == DateTimeKind.Utc)
					AccountingAPInvoicePayable.CreatedDate = this.CreatedDate;
				else if(this.CreatedDate.Kind == DateTimeKind.Local)
					AccountingAPInvoicePayable.CreatedDate = TimeZoneInfo.ConvertTimeToUtc(this.CreatedDate);
				else
					AccountingAPInvoicePayable.CreatedDate = TimeZoneInfo.ConvertTimeToUtc(this.CreatedDate, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
			}
			else
			{
				AccountingAPInvoicePayable.CreatedDate = this.CreatedDate;
			}
			AccountingAPInvoicePayable.LastUpdatedById = this.LastUpdatedById;
			if(this.LastUpdatedDate.HasValue)
			{
				if(this.LastUpdatedDate.Value.Kind == DateTimeKind.Utc)
					AccountingAPInvoicePayable.LastUpdatedDate = this.LastUpdatedDate;
				else if(this.LastUpdatedDate.Value.Kind == DateTimeKind.Local)
					AccountingAPInvoicePayable.LastUpdatedDate = TimeZoneInfo.ConvertTimeToUtc(this.LastUpdatedDate.Value);
				else
					AccountingAPInvoicePayable.LastUpdatedDate = TimeZoneInfo.ConvertTimeToUtc(this.LastUpdatedDate.Value, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
			}
			else
			{
				AccountingAPInvoicePayable.LastUpdatedDate = this.LastUpdatedDate;
			}
            AccountingAPInvoicePayable.Version = string.IsNullOrEmpty(this.Version) ? null: Convert.FromBase64String(this.Version);
			if (this.AccountsPayableInvoice != null)
			{ 
				AccountingAPInvoicePayable.AccountsPayableInvoice = new Domain.AccountsPayableInvoice();
				AccountingAPInvoicePayable.AccountsPayableInvoice = this.AccountsPayableInvoice.MapToDomainModelWithoutCollections(AccountingAPInvoicePayable.AccountsPayableInvoice);
			} 
			AccountingAPInvoicePayable.AccountingAPInvoicePayableId = this.AccountingAPInvoicePayableId;
			return AccountingAPInvoicePayable;
		} 
		public void MapToDtoWithoutCollections(Domain.AccountingAPInvoicePayable AccountingAPInvoicePayable)
		{ 
			this.ApplicationId = AccountingAPInvoicePayable.ApplicationId;
			this.AccountsPayableInvoiceId = AccountingAPInvoicePayable.AccountsPayableInvoiceId;
			this.AccountsPayableId = AccountingAPInvoicePayable.AccountsPayableId;
			this.CreatedById = AccountingAPInvoicePayable.CreatedById;
			if(AccountingAPInvoicePayable.CreatedDate!=null)
			{
				if(AccountingAPInvoicePayable.CreatedDate.Kind == DateTimeKind.Utc || AccountingAPInvoicePayable.CreatedDate.Kind == DateTimeKind.Unspecified)
					this.CreatedDate = TimeZoneInfo.ConvertTimeFromUtc(AccountingAPInvoicePayable.CreatedDate, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
				else
					this.CreatedDate = TimeZoneInfo.ConvertTime(AccountingAPInvoicePayable.CreatedDate, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
			}
			else
			{
				this.CreatedDate = AccountingAPInvoicePayable.CreatedDate;
			}
			this.LastUpdatedById = AccountingAPInvoicePayable.LastUpdatedById;
			if(AccountingAPInvoicePayable.LastUpdatedDate.HasValue)
			{
				if(AccountingAPInvoicePayable.LastUpdatedDate.Value.Kind == DateTimeKind.Utc || AccountingAPInvoicePayable.LastUpdatedDate.Value.Kind == DateTimeKind.Unspecified)
					this.LastUpdatedDate = TimeZoneInfo.ConvertTimeFromUtc(AccountingAPInvoicePayable.LastUpdatedDate.Value, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
				else
					this.LastUpdatedDate = TimeZoneInfo.ConvertTime(AccountingAPInvoicePayable.LastUpdatedDate.Value, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
			}
			else
			{
				this.LastUpdatedDate = AccountingAPInvoicePayable.LastUpdatedDate;
			}
            this.Version = AccountingAPInvoicePayable.Version == null ? null:Convert.ToBase64String(AccountingAPInvoicePayable.Version);
			if (AccountingAPInvoicePayable.AccountsPayableInvoice != null)
			{ 
				this.AccountsPayableInvoice = new AccountsPayableInvoice();
				this.AccountsPayableInvoice.MapToDtoWithoutCollections(AccountingAPInvoicePayable.AccountsPayableInvoice);
			} 
			this.AccountingAPInvoicePayableId = AccountingAPInvoicePayable.AccountingAPInvoicePayableId;
		} 
		public override TDto MapFromDomainModel<TDomain, TDto>(TDomain domainModel)
		{ 
			Domain.AccountingAPInvoicePayable AccountingAPInvoicePayableModel = domainModel as Domain.AccountingAPInvoicePayable;
			if(AccountingAPInvoicePayableModel != null)
			{ 
				MapToDtoWithoutCollections(AccountingAPInvoicePayableModel);
			} 
				return this as TDto;
		} 
		public override TDomain MapToDomainModel<TDomain>(TDomain domainModel)
		{ 
			Domain.AccountingAPInvoicePayable AccountingAPInvoicePayableModel = domainModel as Domain.AccountingAPInvoicePayable;
			Domain.AccountingAPInvoicePayable destObj = MapToDomainModelWithoutCollections(AccountingAPInvoicePayableModel);
		    return destObj as TDomain;
		} 
	} 
} 

