using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using CommonLib.DataObjects;
using CommonLib.ModelAttrib;
using Domain = DomainModel.Accounting;
namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{ 
[System.CodeDom.Compiler.GeneratedCode("EF", "6.1.0")]
	public partial class IClearMBAMapping : BaseDto
	{ 
		public Domain.IClearMBAMapping MapToDomainModelWithoutCollections(Domain.IClearMBAMapping IClearMBAMapping)
		{ 
			IClearMBAMapping.ApplicationId = this.ApplicationId;
			IClearMBAMapping.MasterClientProfileId = this.MasterClientProfileId;
			IClearMBAMapping.MBACodeType = this.MBACodeType;
            IClearMBAMapping.MBACodeGroup = string.IsNullOrEmpty(this.MBACodeType) ? null: GroupCodeEnum.MBACD.ToString();
			IClearMBAMapping.IClearLineItem = this.IClearLineItem;
			IClearMBAMapping.LOBTypeGroup = this.LOBTypeGroup;
			IClearMBAMapping.LOBType = this.LOBType;
			IClearMBAMapping.CreatedById = this.CreatedById;
            IClearMBAMapping.LineItemId = this.LineItemId;
			if(this.CreatedDate!=null)
			{
				if(this.CreatedDate.Kind == DateTimeKind.Utc)
					IClearMBAMapping.CreatedDate = this.CreatedDate;
				else if(this.CreatedDate.Kind == DateTimeKind.Local)
					IClearMBAMapping.CreatedDate = TimeZoneInfo.ConvertTimeToUtc(this.CreatedDate);
				else
					IClearMBAMapping.CreatedDate = TimeZoneInfo.ConvertTimeToUtc(this.CreatedDate, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
			}
			else
			{
				IClearMBAMapping.CreatedDate = this.CreatedDate;
			}
			IClearMBAMapping.LastUpdatedById = this.LastUpdatedById;
			if(this.LastUpdatedDate.HasValue)
			{
				if(this.LastUpdatedDate.Value.Kind == DateTimeKind.Utc)
					IClearMBAMapping.LastUpdatedDate = this.LastUpdatedDate;
				else if(this.LastUpdatedDate.Value.Kind == DateTimeKind.Local)
					IClearMBAMapping.LastUpdatedDate = TimeZoneInfo.ConvertTimeToUtc(this.LastUpdatedDate.Value);
				else
					IClearMBAMapping.LastUpdatedDate = TimeZoneInfo.ConvertTimeToUtc(this.LastUpdatedDate.Value, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
			}
			else
			{
				IClearMBAMapping.LastUpdatedDate = this.LastUpdatedDate;
			}
            IClearMBAMapping.Version = string.IsNullOrEmpty(this.Version) ? null: Convert.FromBase64String(this.Version);
			IClearMBAMapping.IClearMBAMappingId = this.IClearMBAMappingId;
			return IClearMBAMapping;
		} 
		public void MapToDtoWithoutCollections(Domain.IClearMBAMapping IClearMBAMapping)
		{ 
			this.ApplicationId = IClearMBAMapping.ApplicationId;
			this.MasterClientProfileId = IClearMBAMapping.MasterClientProfileId;
			this.MBACodeType = IClearMBAMapping.MBACodeType;
			this.IClearLineItem = IClearMBAMapping.IClearLineItem;
			this.LOBTypeGroup = IClearMBAMapping.LOBTypeGroup;
			this.LOBType = IClearMBAMapping.LOBType;
			this.CreatedById = IClearMBAMapping.CreatedById;
            this.LineItemId = IClearMBAMapping.LineItemId;
			if(IClearMBAMapping.CreatedDate!=null)
			{
				if(IClearMBAMapping.CreatedDate.Kind == DateTimeKind.Utc || IClearMBAMapping.CreatedDate.Kind == DateTimeKind.Unspecified)
					this.CreatedDate = TimeZoneInfo.ConvertTimeFromUtc(IClearMBAMapping.CreatedDate, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
				else
					this.CreatedDate = TimeZoneInfo.ConvertTime(IClearMBAMapping.CreatedDate, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
			}
			else
			{
				this.CreatedDate = IClearMBAMapping.CreatedDate;
			}
			this.LastUpdatedById = IClearMBAMapping.LastUpdatedById;
			if(IClearMBAMapping.LastUpdatedDate.HasValue)
			{
				if(IClearMBAMapping.LastUpdatedDate.Value.Kind == DateTimeKind.Utc || IClearMBAMapping.LastUpdatedDate.Value.Kind == DateTimeKind.Unspecified)
					this.LastUpdatedDate = TimeZoneInfo.ConvertTimeFromUtc(IClearMBAMapping.LastUpdatedDate.Value, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
				else
					this.LastUpdatedDate = TimeZoneInfo.ConvertTime(IClearMBAMapping.LastUpdatedDate.Value, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
			}
			else
			{
				this.LastUpdatedDate = IClearMBAMapping.LastUpdatedDate;
			}
            this.Version = IClearMBAMapping.Version == null ? null:Convert.ToBase64String(IClearMBAMapping.Version);
			this.IClearMBAMappingId = IClearMBAMapping.IClearMBAMappingId;
		} 
		public override TDto MapFromDomainModel<TDomain, TDto>(TDomain domainModel)
		{ 
			Domain.IClearMBAMapping IClearMBAMappingModel = domainModel as Domain.IClearMBAMapping;
			if(IClearMBAMappingModel != null)
			{ 
				MapToDtoWithoutCollections(IClearMBAMappingModel);
			} 
				return this as TDto;
		} 
		public override TDomain MapToDomainModel<TDomain>(TDomain domainModel)
		{ 
			Domain.IClearMBAMapping IClearMBAMappingModel = domainModel as Domain.IClearMBAMapping;
			Domain.IClearMBAMapping destObj = MapToDomainModelWithoutCollections(IClearMBAMappingModel);
		    return destObj as TDomain;
		} 
	} 
} 

