using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using CommonLib.DataObjects;
using CommonLib.ModelAttrib;
using Domain = DomainModel.Accounting;
namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{
    [System.CodeDom.Compiler.GeneratedCode("EF", "6.1.0")]
    public partial class DisputeReceivableAdjustmentHistory : BaseDto
    {
        public Domain.DisputeReceivableAdjustmentHistory MapToDomainModelWithoutCollections(Domain.DisputeReceivableAdjustmentHistory DisputeReceivableAdjustmentHistory)
        {
            DisputeReceivableAdjustmentHistory.ApplicationId = this.ApplicationId;
            DisputeReceivableAdjustmentHistory.OrderHierarchyId = this.OrderHierarchyId;
            DisputeReceivableAdjustmentHistory.Quantity = this.Quantity;
            DisputeReceivableAdjustmentHistory.AgreedClientUnitPrice = this.AgreedClientUnitPrice;
            DisputeReceivableAdjustmentHistory.AgreedUnitPriceAdjstdAmt = this.AgreedUnitPriceAdjstdAmt;
            DisputeReceivableAdjustmentHistory.ClientPrice = this.ClientPrice;
            DisputeReceivableAdjustmentHistory.ClientPriceAdjstdAmt = this.ClientPriceAdjstdAmt;
            DisputeReceivableAdjustmentHistory.ClientRushFee = this.ClientRushFee;
            DisputeReceivableAdjustmentHistory.ClientRushFeeAdjstdAmt = this.ClientRushFeeAdjstdAmt;
            DisputeReceivableAdjustmentHistory.ClientTripFee = this.ClientTripFee;
            DisputeReceivableAdjustmentHistory.ClientTripFeeAdjstdAmt = this.ClientTripFeeAdjstdAmt;
            DisputeReceivableAdjustmentHistory.ServiceDescription = this.ServiceDescription;
            DisputeReceivableAdjustmentHistory.LineItemDescription = this.LineItemDescription;
            DisputeReceivableAdjustmentHistory.HistoryDate = this.HistoryDate;
            DisputeReceivableAdjustmentHistory.ClientAdjComments = this.ClientAdjComments;
            DisputeReceivableAdjustmentHistory.RecordNumber = this.RecordNumber;
            DisputeReceivableAdjustmentHistory.AdjustmentHistoryRecordGroup = this.AdjustmentHistoryRecordGroup;
            DisputeReceivableAdjustmentHistory.AdjustmentHistoryRecordType = this.AdjustmentHistoryRecordType;
            DisputeReceivableAdjustmentHistory.QuantityAdjusted = this.QuantityAdjusted;
            DisputeReceivableAdjustmentHistory.CreatedById = this.CreatedById;
            DisputeReceivableAdjustmentHistory.CreatedDate = this.CreatedDate;
            DisputeReceivableAdjustmentHistory.LastUpdatedById = this.LastUpdatedById;
            DisputeReceivableAdjustmentHistory.LastUpdatedDate = this.LastUpdatedDate;
            DisputeReceivableAdjustmentHistory.ClientPriceTax = this.ClientPriceTax;
            DisputeReceivableAdjustmentHistory.ClientRushFeeTax = this.ClientRushFeeTax;
            DisputeReceivableAdjustmentHistory.ClientTripFeeTax = this.ClientTripFeeTax;
            DisputeReceivableAdjustmentHistory.InvoiceDate = this.InvoiceDate;
            DisputeReceivableAdjustmentHistory.InvoiceNumber = this.InvoiceNumber;
            DisputeReceivableAdjustmentHistory.AdjustmentType = this.AdjustmentType;
            DisputeReceivableAdjustmentHistory.FeeTypeId = this.FeeTypeId;
            DisputeReceivableAdjustmentHistory.FeeTypePaymentRefId = this.FeeTypePaymentRefId;

            if (this.OrderHierarchy != null)
            {
                DisputeReceivableAdjustmentHistory.OrderHierarchy = new Domain.OrderHierarchy();
                DisputeReceivableAdjustmentHistory.OrderHierarchy = this.OrderHierarchy.MapToDomainModelWithoutCollections(DisputeReceivableAdjustmentHistory.OrderHierarchy);
            }
            DisputeReceivableAdjustmentHistory.DisputeReceivableAdjustmentHistoryId = this.DisputeReceivableAdjustmentHistoryId;
            DisputeReceivableAdjustmentHistory.SourceDisputeReceivableAdjustmentHistoryId = this.SourceDisputeReceivableAdjustmentHistoryId;
            return DisputeReceivableAdjustmentHistory;
        }
        public void MapToDtoWithoutCollections(Domain.DisputeReceivableAdjustmentHistory DisputeReceivableAdjustmentHistory)
        {
            this.ApplicationId = DisputeReceivableAdjustmentHistory.ApplicationId;
            this.OrderHierarchyId = DisputeReceivableAdjustmentHistory.OrderHierarchyId;
            this.Quantity = DisputeReceivableAdjustmentHistory.Quantity;
            this.AgreedClientUnitPrice = DisputeReceivableAdjustmentHistory.AgreedClientUnitPrice;
            this.AgreedUnitPriceAdjstdAmt = DisputeReceivableAdjustmentHistory.AgreedUnitPriceAdjstdAmt;
            this.ClientPrice = DisputeReceivableAdjustmentHistory.ClientPrice;
            this.ClientPriceAdjstdAmt = DisputeReceivableAdjustmentHistory.ClientPriceAdjstdAmt;
            this.ClientRushFee = DisputeReceivableAdjustmentHistory.ClientRushFee;
            this.ClientRushFeeAdjstdAmt = DisputeReceivableAdjustmentHistory.ClientRushFeeAdjstdAmt;
            this.ClientTripFee = DisputeReceivableAdjustmentHistory.ClientTripFee;
            this.ClientTripFeeAdjstdAmt = DisputeReceivableAdjustmentHistory.ClientTripFeeAdjstdAmt;
            this.ServiceDescription = DisputeReceivableAdjustmentHistory.ServiceDescription;
            this.LineItemDescription = DisputeReceivableAdjustmentHistory.LineItemDescription;
            this.HistoryDate = DisputeReceivableAdjustmentHistory.HistoryDate;
            this.ClientAdjComments = DisputeReceivableAdjustmentHistory.ClientAdjComments;
            this.RecordNumber = DisputeReceivableAdjustmentHistory.RecordNumber;
            this.AdjustmentHistoryRecordGroup = DisputeReceivableAdjustmentHistory.AdjustmentHistoryRecordGroup;
            this.AdjustmentHistoryRecordType = DisputeReceivableAdjustmentHistory.AdjustmentHistoryRecordType;
            this.QuantityAdjusted = DisputeReceivableAdjustmentHistory.QuantityAdjusted;
            this.CreatedById = DisputeReceivableAdjustmentHistory.CreatedById;
            this.CreatedDate = DisputeReceivableAdjustmentHistory.CreatedDate;
            this.LastUpdatedById = DisputeReceivableAdjustmentHistory.LastUpdatedById;
            this.LastUpdatedDate = DisputeReceivableAdjustmentHistory.LastUpdatedDate;
            this.ClientPriceTax = DisputeReceivableAdjustmentHistory.ClientPriceTax;
            this.ClientRushFeeTax = DisputeReceivableAdjustmentHistory.ClientRushFeeTax;
            this.ClientTripFeeTax = DisputeReceivableAdjustmentHistory.ClientTripFeeTax;
            this.InvoiceDate = DisputeReceivableAdjustmentHistory.InvoiceDate;
            this.InvoiceNumber = DisputeReceivableAdjustmentHistory.InvoiceNumber;
            this.AdjustmentType = DisputeReceivableAdjustmentHistory.AdjustmentType;
            this.FeeTypeId = DisputeReceivableAdjustmentHistory.FeeTypeId;
            this.FeeTypePaymentRefId= DisputeReceivableAdjustmentHistory.FeeTypePaymentRefId;
            if (DisputeReceivableAdjustmentHistory.OrderHierarchy != null)
            {
                this.OrderHierarchy = new OrderHierarchy();
                this.OrderHierarchy.MapToDtoWithoutCollections(DisputeReceivableAdjustmentHistory.OrderHierarchy);
            }
            this.DisputeReceivableAdjustmentHistoryId = DisputeReceivableAdjustmentHistory.DisputeReceivableAdjustmentHistoryId;
            this.SourceDisputeReceivableAdjustmentHistoryId = DisputeReceivableAdjustmentHistory.SourceDisputeReceivableAdjustmentHistoryId;
        }
        public override TDto MapFromDomainModel<TDomain, TDto>(TDomain domainModel)
        {
            Domain.DisputeReceivableAdjustmentHistory DisputeReceivableAdjustmentHistoryModel = domainModel as Domain.DisputeReceivableAdjustmentHistory;
            if (DisputeReceivableAdjustmentHistoryModel != null)
            {
                MapToDtoWithoutCollections(DisputeReceivableAdjustmentHistoryModel);
            }
            return this as TDto;
        }
        public override TDomain MapToDomainModel<TDomain>(TDomain domainModel)
        {
            Domain.DisputeReceivableAdjustmentHistory DisputeReceivableAdjustmentHistoryModel = domainModel as Domain.DisputeReceivableAdjustmentHistory;
            Domain.DisputeReceivableAdjustmentHistory destObj = MapToDomainModelWithoutCollections(DisputeReceivableAdjustmentHistoryModel);
            return destObj as TDomain;
        }
    }
}

