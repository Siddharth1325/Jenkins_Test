using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using CommonLib.DataObjects;
using CommonLib.ModelAttrib;
using Domain = DomainModel.Accounting;
namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{ 
[System.CodeDom.Compiler.GeneratedCode("EF", "6.1.0")]
	public partial class Service : BaseDto
	{ 
		public Domain.Service MapToDomainModelWithoutCollections(Domain.Service Service)
		{ 
			Service.ApplicationId = this.ApplicationId;
			Service.ServiceCode = this.ServiceCode;
			Service.ServiceName = this.ServiceName;
			Service.ServiceDesc = this.ServiceDesc;
			Service.Instructions = this.Instructions;
			Service.ProductCategoryGroup = this.ProductCategoryGroup;
			Service.ProductCategory = this.ProductCategory;
			Service.ServiceCategoryGroup = this.ServiceCategoryGroup;
			Service.ServiceCategoryType = this.ServiceCategoryType;
			Service.DefaultPrice = this.DefaultPrice;
			Service.IsActive = this.IsActive;
			Service.ActiveChangedDate = this.ActiveChangedDate;
			Service.ActiveChangedById = this.ActiveChangedById;
			Service.CreatedById = this.CreatedById;
			Service.CreatedDate = this.CreatedDate;
			Service.LastUpdatedById = this.LastUpdatedById;
			Service.LastUpdatedDate = this.LastUpdatedDate;
            Service.Version = string.IsNullOrEmpty(this.Version) ? null: Convert.FromBase64String(this.Version);
			Service.ServiceId = this.ServiceId;
			return Service;
		} 
		public void MapToDtoWithoutCollections(Domain.Service Service)
		{ 
			this.ApplicationId = Service.ApplicationId;
			this.ServiceCode = Service.ServiceCode;
			this.ServiceName = Service.ServiceName;
			this.ServiceDesc = Service.ServiceDesc;
			this.Instructions = Service.Instructions;
			this.ProductCategoryGroup = Service.ProductCategoryGroup;
			this.ProductCategory = Service.ProductCategory;
			this.ServiceCategoryGroup = Service.ServiceCategoryGroup;
			this.ServiceCategoryType = Service.ServiceCategoryType;
			this.DefaultPrice = Service.DefaultPrice;
			this.IsActive = Service.IsActive;
			this.ActiveChangedDate = Service.ActiveChangedDate;
			this.ActiveChangedById = Service.ActiveChangedById;
			this.CreatedById = Service.CreatedById;
			this.CreatedDate = Service.CreatedDate;
			this.LastUpdatedById = Service.LastUpdatedById;
			this.LastUpdatedDate = Service.LastUpdatedDate;
            this.Version = Service.Version == null ? null:Convert.ToBase64String(Service.Version);
			this.ServiceId = Service.ServiceId;
		} 
		public override TDto MapFromDomainModel<TDomain, TDto>(TDomain domainModel)
		{ 
			Domain.Service ServiceModel = domainModel as Domain.Service;
			if(ServiceModel != null)
			{ 
				MapToDtoWithoutCollections(ServiceModel);
			} 
				return this as TDto;
		} 
		public override TDomain MapToDomainModel<TDomain>(TDomain domainModel)
		{ 
			Domain.Service ServiceModel = domainModel as Domain.Service;
			Domain.Service destObj = MapToDomainModelWithoutCollections(ServiceModel);
		    return destObj as TDomain;
		} 
	} 
} 

