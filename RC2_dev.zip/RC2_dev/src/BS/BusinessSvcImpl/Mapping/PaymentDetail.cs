using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using CommonLib.DataObjects;
using CommonLib.ModelAttrib;
using Domain = DomainModel.Accounting;
namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{ 
[System.CodeDom.Compiler.GeneratedCode("EF", "6.1.0")]
	public partial class PaymentDetail : BaseDto
	{ 
		public Domain.PaymentDetail MapToDomainModelWithoutCollections(Domain.PaymentDetail PaymentDetail)
		{ 
			PaymentDetail.VPRGenInformationId = this.VPRGenInformationId;
			PaymentDetail.WorkOrderId = this.WorkOrderId;
			PaymentDetail.Payee = this.Payee;
			PaymentDetail.Amount = this.Amount;
			PaymentDetail.MunicipalityReferenceNo = this.MunicipalityReferenceNo;
			PaymentDetail.IsCreditCardPayment = this.IsCreditCardPayment;
			PaymentDetail.ConfirmationNo = this.ConfirmationNo;
			PaymentDetail.PaymentDate = this.PaymentDate;
			PaymentDetail.PaymentType = this.PaymentType;
			PaymentDetail.CreatedById = this.CreatedById;
			PaymentDetail.CreatedDate = this.CreatedDate;
			PaymentDetail.LastUpdatedById = this.LastUpdatedById;
			PaymentDetail.LastUpdatedDate = this.LastUpdatedDate;
            PaymentDetail.Version = string.IsNullOrEmpty(this.Version) ? null: Convert.FromBase64String(this.Version);
			PaymentDetail.FeeTypeName = this.FeeTypeName;
			if (this.VPRGenInformation != null)
			{ 
				PaymentDetail.VPRGenInformation = new Domain.VPRGenInformation();
				PaymentDetail.VPRGenInformation = this.VPRGenInformation.MapToDomainModelWithoutCollections(PaymentDetail.VPRGenInformation);
			} 
			PaymentDetail.PaymentDetailsId = this.PaymentDetailsId;
			return PaymentDetail;
		} 
		public void MapToDtoWithoutCollections(Domain.PaymentDetail PaymentDetail)
		{ 
			this.VPRGenInformationId = PaymentDetail.VPRGenInformationId;
			this.WorkOrderId = PaymentDetail.WorkOrderId;
			this.Payee = PaymentDetail.Payee;
			this.Amount = PaymentDetail.Amount;
			this.MunicipalityReferenceNo = PaymentDetail.MunicipalityReferenceNo;
			this.IsCreditCardPayment = PaymentDetail.IsCreditCardPayment;
			this.ConfirmationNo = PaymentDetail.ConfirmationNo;
			this.PaymentDate = PaymentDetail.PaymentDate;
			this.PaymentType = PaymentDetail.PaymentType;
			this.CreatedById = PaymentDetail.CreatedById;
			this.CreatedDate = PaymentDetail.CreatedDate;
			this.LastUpdatedById = PaymentDetail.LastUpdatedById;
			this.LastUpdatedDate = PaymentDetail.LastUpdatedDate;
            this.Version = PaymentDetail.Version == null ? null:Convert.ToBase64String(PaymentDetail.Version);
			this.FeeTypeName = PaymentDetail.FeeTypeName;
			if (PaymentDetail.VPRGenInformation != null)
			{ 
				this.VPRGenInformation = new VPRGenInformation();
				this.VPRGenInformation.MapToDtoWithoutCollections(PaymentDetail.VPRGenInformation);
			} 
			this.PaymentDetailsId = PaymentDetail.PaymentDetailsId;
		} 
		public override TDto MapFromDomainModel<TDomain, TDto>(TDomain domainModel)
		{ 
			Domain.PaymentDetail PaymentDetailModel = domainModel as Domain.PaymentDetail;
			if(PaymentDetailModel != null)
			{ 
				MapToDtoWithoutCollections(PaymentDetailModel);
			} 
				return this as TDto;
		} 
		public override TDomain MapToDomainModel<TDomain>(TDomain domainModel)
		{ 
			Domain.PaymentDetail PaymentDetailModel = domainModel as Domain.PaymentDetail;
			Domain.PaymentDetail destObj = MapToDomainModelWithoutCollections(PaymentDetailModel);
		    return destObj as TDomain;
		} 
	} 
} 

