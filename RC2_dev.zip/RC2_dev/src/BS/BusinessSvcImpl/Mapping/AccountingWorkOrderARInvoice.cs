using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using CommonLib.DataObjects;
using CommonLib.ModelAttrib;
using Domain = DomainModel.Accounting;
namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{ 
[System.CodeDom.Compiler.GeneratedCode("EF", "6.1.0")]
	public partial class AccountingWorkOrderARInvoice : BaseDto
	{ 
		public Domain.AccountingWorkOrderARInvoice MapToDomainModelWithoutCollections(Domain.AccountingWorkOrderARInvoice AccountingWorkOrderARInvoice)
		{ 
			AccountingWorkOrderARInvoice.WorkOrderId = this.WorkOrderId;
			AccountingWorkOrderARInvoice.AccountsReceivableInvoiceId = this.AccountsReceivableInvoiceId;
			AccountingWorkOrderARInvoice.CreatedById = this.CreatedById;
			if(this.CreatedDate!=null)
			{
				if(this.CreatedDate.Kind == DateTimeKind.Utc)
					AccountingWorkOrderARInvoice.CreatedDate = this.CreatedDate;
				else if(this.CreatedDate.Kind == DateTimeKind.Local)
					AccountingWorkOrderARInvoice.CreatedDate = TimeZoneInfo.ConvertTimeToUtc(this.CreatedDate);
				else
					AccountingWorkOrderARInvoice.CreatedDate = TimeZoneInfo.ConvertTimeToUtc(this.CreatedDate, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
			}
			else
			{
				AccountingWorkOrderARInvoice.CreatedDate = this.CreatedDate;
			}
			AccountingWorkOrderARInvoice.LastUpdatedById = this.LastUpdatedById;
			if(this.LastUpdatedDate.HasValue)
			{
				if(this.LastUpdatedDate.Value.Kind == DateTimeKind.Utc)
					AccountingWorkOrderARInvoice.LastUpdatedDate = this.LastUpdatedDate;
				else if(this.LastUpdatedDate.Value.Kind == DateTimeKind.Local)
					AccountingWorkOrderARInvoice.LastUpdatedDate = TimeZoneInfo.ConvertTimeToUtc(this.LastUpdatedDate.Value);
				else
					AccountingWorkOrderARInvoice.LastUpdatedDate = TimeZoneInfo.ConvertTimeToUtc(this.LastUpdatedDate.Value, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
			}
			else
			{
				AccountingWorkOrderARInvoice.LastUpdatedDate = this.LastUpdatedDate;
			}
            AccountingWorkOrderARInvoice.Version = string.IsNullOrEmpty(this.Version) ? null: Convert.FromBase64String(this.Version);
			AccountingWorkOrderARInvoice.WorkOrderARInvoiceId = this.WorkOrderARInvoiceId;
			return AccountingWorkOrderARInvoice;
		} 
		public void MapToDtoWithoutCollections(Domain.AccountingWorkOrderARInvoice AccountingWorkOrderARInvoice)
		{ 
			this.WorkOrderId = AccountingWorkOrderARInvoice.WorkOrderId;
			this.AccountsReceivableInvoiceId = AccountingWorkOrderARInvoice.AccountsReceivableInvoiceId;
			this.CreatedById = AccountingWorkOrderARInvoice.CreatedById;
			if(AccountingWorkOrderARInvoice.CreatedDate!=null)
			{
				if(AccountingWorkOrderARInvoice.CreatedDate.Kind == DateTimeKind.Utc || AccountingWorkOrderARInvoice.CreatedDate.Kind == DateTimeKind.Unspecified)
					this.CreatedDate = TimeZoneInfo.ConvertTimeFromUtc(AccountingWorkOrderARInvoice.CreatedDate, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
				else
					this.CreatedDate = TimeZoneInfo.ConvertTime(AccountingWorkOrderARInvoice.CreatedDate, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
			}
			else
			{
				this.CreatedDate = AccountingWorkOrderARInvoice.CreatedDate;
			}
			this.LastUpdatedById = AccountingWorkOrderARInvoice.LastUpdatedById;
			if(AccountingWorkOrderARInvoice.LastUpdatedDate.HasValue)
			{
				if(AccountingWorkOrderARInvoice.LastUpdatedDate.Value.Kind == DateTimeKind.Utc || AccountingWorkOrderARInvoice.LastUpdatedDate.Value.Kind == DateTimeKind.Unspecified)
					this.LastUpdatedDate = TimeZoneInfo.ConvertTimeFromUtc(AccountingWorkOrderARInvoice.LastUpdatedDate.Value, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
				else
					this.LastUpdatedDate = TimeZoneInfo.ConvertTime(AccountingWorkOrderARInvoice.LastUpdatedDate.Value, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
			}
			else
			{
				this.LastUpdatedDate = AccountingWorkOrderARInvoice.LastUpdatedDate;
			}
            this.Version = AccountingWorkOrderARInvoice.Version == null ? null:Convert.ToBase64String(AccountingWorkOrderARInvoice.Version);
			this.WorkOrderARInvoiceId = AccountingWorkOrderARInvoice.WorkOrderARInvoiceId;
		} 
		public override TDto MapFromDomainModel<TDomain, TDto>(TDomain domainModel)
		{ 
			Domain.AccountingWorkOrderARInvoice AccountingWorkOrderARInvoiceModel = domainModel as Domain.AccountingWorkOrderARInvoice;
			if(AccountingWorkOrderARInvoiceModel != null)
			{ 
				MapToDtoWithoutCollections(AccountingWorkOrderARInvoiceModel);
			} 
				return this as TDto;
		} 
		public override TDomain MapToDomainModel<TDomain>(TDomain domainModel)
		{ 
			Domain.AccountingWorkOrderARInvoice AccountingWorkOrderARInvoiceModel = domainModel as Domain.AccountingWorkOrderARInvoice;
			Domain.AccountingWorkOrderARInvoice destObj = MapToDomainModelWithoutCollections(AccountingWorkOrderARInvoiceModel);
		    return destObj as TDomain;
		} 
	} 
} 

