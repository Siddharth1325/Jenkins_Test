using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using CommonLib.DataObjects;
using CommonLib.ModelAttrib;
using Domain = DomainModel.Accounting;
namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{ 
[System.CodeDom.Compiler.GeneratedCode("EF", "6.1.0")]
	public partial class ClientFeeAdjustmentDetail : BaseDto
	{ 
		public Domain.ClientFeeAdjustmentDetail MapToDomainModelWithoutCollections(Domain.ClientFeeAdjustmentDetail ClientFeeAdjustmentDetail)
		{ 
			ClientFeeAdjustmentDetail.IsAdjusted = Convert.ToInt32(this.IsAdjusted);
			ClientFeeAdjustmentDetail.RecType = this.RecType;
			ClientFeeAdjustmentDetail.OrderId = this.OrderId;
			ClientFeeAdjustmentDetail.ARInvoiceNumber = this.ARInvoiceNumber;
			ClientFeeAdjustmentDetail.ClientTripFee = this.ClientTripFee;
			ClientFeeAdjustmentDetail.ClientTripFeeAdj = this.ClientTripFeeAdj;
			ClientFeeAdjustmentDetail.RushFee = this.RushFee;
			ClientFeeAdjustmentDetail.RushFeeAdj = this.RushFeeAdj;
			ClientFeeAdjustmentDetail.ClientTripFeeTaxAmount = this.ClientTripFeeTaxAmount;
			ClientFeeAdjustmentDetail.RushFeeTaxAmount = this.RushFeeTaxAmount;
			ClientFeeAdjustmentDetail.InvoicedDate = this.InvoicedDate;
			ClientFeeAdjustmentDetail.AdjustmentDate = this.AdjustmentDate;
			ClientFeeAdjustmentDetail.Comments = this.Comments;
            ClientFeeAdjustmentDetail.SupplierComment = this.SupplierComment;
			ClientFeeAdjustmentDetail.OrderHierarchyId = this.OrderHierarchyId;
			ClientFeeAdjustmentDetail.AdjustmentDetailHistoryId = this.AdjustmentDetailHistoryId;
            ClientFeeAdjustmentDetail.RecordNumber = this.RecordNumber;
            ClientFeeAdjustmentDetail.IsArInvoiced = this.IsArInvoiced;
            ClientFeeAdjustmentDetail.Version = string.IsNullOrEmpty(this.Version) ? null : Convert.FromBase64String(this.Version);
			return ClientFeeAdjustmentDetail;
		} 
		public void MapToDtoWithoutCollections(Domain.ClientFeeAdjustmentDetail ClientFeeAdjustmentDetail)
		{ 
			this.IsAdjusted = Convert.ToBoolean(ClientFeeAdjustmentDetail.IsAdjusted);
			this.RecType = ClientFeeAdjustmentDetail.RecType;
			this.OrderId = ClientFeeAdjustmentDetail.OrderId;
			this.ARInvoiceNumber = ClientFeeAdjustmentDetail.ARInvoiceNumber;
			this.ClientTripFee = ClientFeeAdjustmentDetail.ClientTripFee;
			this.ClientTripFeeAdj = ClientFeeAdjustmentDetail.ClientTripFeeAdj;
			this.RushFee = ClientFeeAdjustmentDetail.RushFee;
			this.RushFeeAdj = ClientFeeAdjustmentDetail.RushFeeAdj;
			this.ClientTripFeeTaxAmount = ClientFeeAdjustmentDetail.ClientTripFeeTaxAmount;
			this.RushFeeTaxAmount = ClientFeeAdjustmentDetail.RushFeeTaxAmount;
			this.InvoicedDate = ClientFeeAdjustmentDetail.InvoicedDate;
			this.AdjustmentDate = ClientFeeAdjustmentDetail.AdjustmentDate;
			this.Comments = ClientFeeAdjustmentDetail.Comments;
			this.OrderHierarchyId = ClientFeeAdjustmentDetail.OrderHierarchyId;
			this.AdjustmentDetailHistoryId = ClientFeeAdjustmentDetail.AdjustmentDetailHistoryId;
            this.RecordNumber = ClientFeeAdjustmentDetail.RecordNumber;
            this.IsArInvoiced= ClientFeeAdjustmentDetail.IsArInvoiced;
            this.Version = ClientFeeAdjustmentDetail.Version == null ? null : Convert.ToBase64String(ClientFeeAdjustmentDetail.Version);
		} 
		public override TDto MapFromDomainModel<TDomain, TDto>(TDomain domainModel)
		{ 
			Domain.ClientFeeAdjustmentDetail ClientFeeAdjustmentDetailModel = domainModel as Domain.ClientFeeAdjustmentDetail;
			if(ClientFeeAdjustmentDetailModel != null)
			{ 
				MapToDtoWithoutCollections(ClientFeeAdjustmentDetailModel);
			} 
				return this as TDto;
		} 
		public override TDomain MapToDomainModel<TDomain>(TDomain domainModel)
		{ 
			Domain.ClientFeeAdjustmentDetail ClientFeeAdjustmentDetailModel = domainModel as Domain.ClientFeeAdjustmentDetail;
			Domain.ClientFeeAdjustmentDetail destObj = MapToDomainModelWithoutCollections(ClientFeeAdjustmentDetailModel);
		    return destObj as TDomain;
		} 
	} 
} 

