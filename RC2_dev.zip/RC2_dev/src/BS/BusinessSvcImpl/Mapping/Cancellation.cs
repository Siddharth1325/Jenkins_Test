using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using CommonLib.DataObjects;
using CommonLib.ModelAttrib;
using Domain = DomainModel.Accounting;
namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{ 
[System.CodeDom.Compiler.GeneratedCode("EF", "6.1.0")]
	public partial class Cancellation : BaseDto
	{ 
		public Domain.Cancellation MapToDomainModelWithoutCollections(Domain.Cancellation Cancellation)
		{ 
			Cancellation.ApplicationId = this.ApplicationId;
			Cancellation.SourceCancellationId = this.SourceCancellationId;
			Cancellation.CancelledLoanId = this.CancelledLoanId;
			Cancellation.CancelledOrderId = this.CancelledOrderId;
			Cancellation.CancelledWorkOrderId = this.CancelledWorkOrderId;
            //if(this.CancellationDate!=null)
            //{
            //    if(this.CancellationDate.Kind == DateTimeKind.Utc)
            //        Cancellation.CancellationDate = this.CancellationDate;
            //    else if(this.CancellationDate.Kind == DateTimeKind.Local)
            //        Cancellation.CancellationDate = TimeZoneInfo.ConvertTimeToUtc(this.CancellationDate);
            //    else
            //        Cancellation.CancellationDate = TimeZoneInfo.ConvertTimeToUtc(this.CancellationDate, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
            //}
            //else
            //{
            //    Cancellation.CancellationDate = this.CancellationDate;
            //}
            Cancellation.CancellationDate = this.CancellationDate;
			Cancellation.CancellationReasonGroup = this.CancellationReasonGroup;
			Cancellation.CancellationReasonType = this.CancellationReasonType;
			Cancellation.CancellationComments = this.CancellationComments;
			Cancellation.CreatedById = this.CreatedById;
			if(this.CreatedDate!=null)
			{
				if(this.CreatedDate.Kind == DateTimeKind.Utc)
					Cancellation.CreatedDate = this.CreatedDate;
				else if(this.CreatedDate.Kind == DateTimeKind.Local)
					Cancellation.CreatedDate = TimeZoneInfo.ConvertTimeToUtc(this.CreatedDate);
				else
					Cancellation.CreatedDate = TimeZoneInfo.ConvertTimeToUtc(this.CreatedDate, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
			}
			else
			{
				Cancellation.CreatedDate = this.CreatedDate;
			}
			Cancellation.LastUpdatedById = this.LastUpdatedById;
			if(this.LastUpdatedDate.HasValue)
			{
				if(this.LastUpdatedDate.Value.Kind == DateTimeKind.Utc)
					Cancellation.LastUpdatedDate = this.LastUpdatedDate;
				else if(this.LastUpdatedDate.Value.Kind == DateTimeKind.Local)
					Cancellation.LastUpdatedDate = TimeZoneInfo.ConvertTimeToUtc(this.LastUpdatedDate.Value);
				else
					Cancellation.LastUpdatedDate = TimeZoneInfo.ConvertTimeToUtc(this.LastUpdatedDate.Value, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
			}
			else
			{
				Cancellation.LastUpdatedDate = this.LastUpdatedDate;
			}
            Cancellation.Version = string.IsNullOrEmpty(this.Version) ? null: Convert.FromBase64String(this.Version);
			Cancellation.CancellationId = this.CancellationId;
			return Cancellation;
		} 
		public void MapToDtoWithoutCollections(Domain.Cancellation Cancellation)
		{ 
			this.ApplicationId = Cancellation.ApplicationId;
			this.SourceCancellationId = Cancellation.SourceCancellationId;
			this.CancelledLoanId = Cancellation.CancelledLoanId;
			this.CancelledOrderId = Cancellation.CancelledOrderId;
			this.CancelledWorkOrderId = Cancellation.CancelledWorkOrderId;
            //if(Cancellation.CancellationDate!=null)
            //{
            //    if(Cancellation.CancellationDate.Kind == DateTimeKind.Utc || Cancellation.CancellationDate.Kind == DateTimeKind.Unspecified)
            //        this.CancellationDate = TimeZoneInfo.ConvertTimeFromUtc(Cancellation.CancellationDate, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
            //    else
            //        this.CancellationDate = TimeZoneInfo.ConvertTime(Cancellation.CancellationDate, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
            //}
            //else
            //{
            //    this.CancellationDate = Cancellation.CancellationDate;
            //}
            this.CancellationDate = Cancellation.CancellationDate;
			this.CancellationReasonGroup = Cancellation.CancellationReasonGroup;
			this.CancellationReasonType = Cancellation.CancellationReasonType;
			this.CancellationComments = Cancellation.CancellationComments;
			this.CreatedById = Cancellation.CreatedById;
			if(Cancellation.CreatedDate!=null)
			{
				if(Cancellation.CreatedDate.Kind == DateTimeKind.Utc || Cancellation.CreatedDate.Kind == DateTimeKind.Unspecified)
					this.CreatedDate = TimeZoneInfo.ConvertTimeFromUtc(Cancellation.CreatedDate, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
				else
					this.CreatedDate = TimeZoneInfo.ConvertTime(Cancellation.CreatedDate, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
			}
			else
			{
				this.CreatedDate = Cancellation.CreatedDate;
			}
			this.LastUpdatedById = Cancellation.LastUpdatedById;
			if(Cancellation.LastUpdatedDate.HasValue)
			{
				if(Cancellation.LastUpdatedDate.Value.Kind == DateTimeKind.Utc || Cancellation.LastUpdatedDate.Value.Kind == DateTimeKind.Unspecified)
					this.LastUpdatedDate = TimeZoneInfo.ConvertTimeFromUtc(Cancellation.LastUpdatedDate.Value, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
				else
					this.LastUpdatedDate = TimeZoneInfo.ConvertTime(Cancellation.LastUpdatedDate.Value, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
			}
			else
			{
				this.LastUpdatedDate = Cancellation.LastUpdatedDate;
			}
            this.Version = Cancellation.Version == null ? null:Convert.ToBase64String(Cancellation.Version);
			this.CancellationId = Cancellation.CancellationId;
		} 
		public override TDto MapFromDomainModel<TDomain, TDto>(TDomain domainModel)
		{ 
			Domain.Cancellation CancellationModel = domainModel as Domain.Cancellation;
			if(CancellationModel != null)
			{ 
				MapToDtoWithoutCollections(CancellationModel);
			} 
				return this as TDto;
		} 
		public override TDomain MapToDomainModel<TDomain>(TDomain domainModel)
		{ 
			Domain.Cancellation CancellationModel = domainModel as Domain.Cancellation;
			Domain.Cancellation destObj = MapToDomainModelWithoutCollections(CancellationModel);
		    return destObj as TDomain;
		} 
	} 
} 

