using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using CommonLib.DataObjects;
using CommonLib.ModelAttrib;
using Domain = DomainModel.Accounting;
namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{
    [System.CodeDom.Compiler.GeneratedCode("EF", "6.1.0")]
    public partial class DisputeFollowup : BaseDto
    {
        public Domain.DisputeFollowup MapToDomainModelWithoutCollections(Domain.DisputeFollowup DisputeFollowup)
        {
            DisputeFollowup.AccountingDisputeId = this.AccountingDisputeId;
            DisputeFollowup.FollowUpResearchGroup = string.IsNullOrEmpty(this.FollowUpResearchType) ? null : GroupCodeEnum.FOLRES.ToString();
            DisputeFollowup.FollowUpResearchType = this.FollowUpResearchType;
            DisputeFollowup.FollowUpStatusGroup = string.IsNullOrEmpty(this.FollowUpStatusElement) ? null : GroupCodeEnum.FOLSTA.ToString();
            DisputeFollowup.FollowUpStatusElement = this.FollowUpStatusElement;
            DisputeFollowup.AssignedToId = this.AssignedToId;
            DisputeFollowup.FollowUpAssignDate = this.FollowUpAssignDate;
            DisputeFollowup.FollowUpCompDate = this.FollowUpCompDate;
            DisputeFollowup.CreatedById = this.CreatedById;
            DisputeFollowup.CreatedDate = this.CreatedDate;
            DisputeFollowup.LastUpdatedById = this.LastUpdatedById;
            DisputeFollowup.LastUpdatedDate = this.LastUpdatedDate;
            DisputeFollowup.Version = string.IsNullOrEmpty(this.Version) ? null : Convert.FromBase64String(this.Version);
            DisputeFollowup.DisputeFollowupId = this.DisputeFollowupId;
            return DisputeFollowup;
        }
        public void MapToDtoWithoutCollections(Domain.DisputeFollowup DisputeFollowup)
        {
            this.AccountingDisputeId = DisputeFollowup.AccountingDisputeId;
            this.FollowUpStatusElement = DisputeFollowup.FollowUpStatusElement;
            this.FollowUpResearchType = DisputeFollowup.FollowUpResearchType;
            this.AssignedToId = DisputeFollowup.AssignedToId;
            this.FollowUpAssignDate = DisputeFollowup.FollowUpAssignDate;
            this.FollowUpCompDate = DisputeFollowup.FollowUpCompDate;
            this.CreatedById = DisputeFollowup.CreatedById;
            this.CreatedDate = DisputeFollowup.CreatedDate;
            this.LastUpdatedById = DisputeFollowup.LastUpdatedById;
            this.LastUpdatedDate = DisputeFollowup.LastUpdatedDate;
            this.Version = DisputeFollowup.Version == null ? null : Convert.ToBase64String(DisputeFollowup.Version);
            this.DisputeFollowupId = DisputeFollowup.DisputeFollowupId;
        }
        public override TDto MapFromDomainModel<TDomain, TDto>(TDomain domainModel)
        {
            Domain.DisputeFollowup DisputeFollowupModel = domainModel as Domain.DisputeFollowup;
            if (DisputeFollowupModel != null)
            {
                MapToDtoWithoutCollections(DisputeFollowupModel);
            }
            return this as TDto;
        }
        public override TDomain MapToDomainModel<TDomain>(TDomain domainModel)
        {
            Domain.DisputeFollowup DisputeFollowupModel = domainModel as Domain.DisputeFollowup;
            Domain.DisputeFollowup destObj = MapToDomainModelWithoutCollections(DisputeFollowupModel);
            return destObj as TDomain;
        }
    }
}

