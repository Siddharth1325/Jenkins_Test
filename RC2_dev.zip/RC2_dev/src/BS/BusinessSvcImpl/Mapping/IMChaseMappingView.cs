using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using CommonLib.DataObjects;
using CommonLib.ModelAttrib;
using Domain = DomainModel.Accounting;
namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{ 
[System.CodeDom.Compiler.GeneratedCode("EF", "6.1.0")]
	public partial class IMChaseMappingView : BaseDto
	{ 
		public Domain.IMChaseMappingView MapToDomainModelWithoutCollections(Domain.IMChaseMappingView IMChaseMappingView)
		{ 
			IMChaseMappingView.IMChaseMappingId = this.IMChaseMappingId;
			IMChaseMappingView.ApplicationId = this.ApplicationId;
			IMChaseMappingView.ClientNumber = this.ClientNumber;
			IMChaseMappingView.ClientLSCI = this.ClientLSCI;
			IMChaseMappingView.RequestorCode = this.RequestorCode;
			IMChaseMappingView.MBACodeType = this.MBACodeType;
			IMChaseMappingView.IMInvoiceType = this.IMInvoiceType;
			IMChaseMappingView.IMOrderType = this.IMOrderType;
			IMChaseMappingView.IMLineItem = this.IMLineItem;
			IMChaseMappingView.LOBType = this.LOBType;
			IMChaseMappingView.IsTax = this.IsTax;
			IMChaseMappingView.IsRush = this.IsRush;
			IMChaseMappingView.ServiceName = this.ServiceName;
			IMChaseMappingView.ServiceId = this.ServiceId;
			IMChaseMappingView.FeeTypeName = this.FeeTypeName;
            IMChaseMappingView.ProductId = this.ProductId;
            IMChaseMappingView.Product = this.Product;
            IMChaseMappingView.ProductCode = this.ProductCode;
            IMChaseMappingView.LineItemId = this.LineItemId;
            IMChaseMappingView.ServiceItem = this.ServiceItem;
			return IMChaseMappingView;
		} 
		public void MapToDtoWithoutCollections(Domain.IMChaseMappingView IMChaseMappingView)
		{ 
			this.IMChaseMappingId = IMChaseMappingView.IMChaseMappingId;
			this.ApplicationId = IMChaseMappingView.ApplicationId;
			this.ClientNumber = IMChaseMappingView.ClientNumber;
			this.ClientLSCI = IMChaseMappingView.ClientLSCI;
			this.RequestorCode = IMChaseMappingView.RequestorCode;
			this.MBACodeType = IMChaseMappingView.MBACodeType;
			this.IMInvoiceType = IMChaseMappingView.IMInvoiceType;
			this.IMOrderType = IMChaseMappingView.IMOrderType;
			this.IMLineItem = IMChaseMappingView.IMLineItem;
			this.LOBType = IMChaseMappingView.LOBType;
			this.IsTax = IMChaseMappingView.IsTax;
			this.IsRush = IMChaseMappingView.IsRush;
			this.ServiceName = IMChaseMappingView.ServiceName;
			this.ServiceId = IMChaseMappingView.ServiceId;
			this.FeeTypeName = IMChaseMappingView.FeeTypeName;
			this.Product = IMChaseMappingView.Product;
            this.LineItemId = IMChaseMappingView.LineItemId;
            this.ServiceItem = IMChaseMappingView.ServiceItem;
            this.ProductId = IMChaseMappingView.ProductId;
            this.ProductCode = IMChaseMappingView.ProductCode;
		} 
		public override TDto MapFromDomainModel<TDomain, TDto>(TDomain domainModel)
		{ 
			Domain.IMChaseMappingView IMChaseMappingViewModel = domainModel as Domain.IMChaseMappingView;
			if(IMChaseMappingViewModel != null)
			{ 
				MapToDtoWithoutCollections(IMChaseMappingViewModel);
			} 
				return this as TDto;
		} 
		public override TDomain MapToDomainModel<TDomain>(TDomain domainModel)
		{ 
			Domain.IMChaseMappingView IMChaseMappingViewModel = domainModel as Domain.IMChaseMappingView;
			Domain.IMChaseMappingView destObj = MapToDomainModelWithoutCollections(IMChaseMappingViewModel);
		    return destObj as TDomain;
		} 
	} 
} 

