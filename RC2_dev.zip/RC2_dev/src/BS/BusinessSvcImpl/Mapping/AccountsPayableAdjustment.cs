using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using CommonLib.DataObjects;
using CommonLib.ModelAttrib;
using Domain = DomainModel.Accounting;
namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{ 
[System.CodeDom.Compiler.GeneratedCode("EF", "6.1.0")]
	public partial class AccountsPayableAdjustment : BaseDto
	{ 
		public Domain.AccountsPayableAdjustment MapToDomainModelWithoutCollections(Domain.AccountsPayableAdjustment AccountsPayableAdjustment)
		{ 
			AccountsPayableAdjustment.ApplicationId = this.ApplicationId;
			AccountsPayableAdjustment.AccountsPayableInvoiceId = this.AccountsPayableInvoiceId;
            AccountsPayableAdjustment.AccountsPayableDetailId = this.AccountsPayableDetailId;
            AccountsPayableAdjustment.DisputePayableAdjustmentHistoryId = this.DisputePayableAdjustmentHistoryId;
			AccountsPayableAdjustment.WorkOrderId = this.WorkOrderId;
			AccountsPayableAdjustment.AdjustmentType = this.AdjustmentType;
			AccountsPayableAdjustment.AdjustmentCode = this.AdjustmentCode;
			if(this.AdjustmentDate!=null)
			{
				if(this.AdjustmentDate.Kind == DateTimeKind.Utc)
					AccountsPayableAdjustment.AdjustmentDate = this.AdjustmentDate;
				else if(this.AdjustmentDate.Kind == DateTimeKind.Local)
					AccountsPayableAdjustment.AdjustmentDate = TimeZoneInfo.ConvertTimeToUtc(this.AdjustmentDate);
				else
					AccountsPayableAdjustment.AdjustmentDate = TimeZoneInfo.ConvertTimeToUtc(this.AdjustmentDate, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
			}
			else
			{
				AccountsPayableAdjustment.AdjustmentDate = this.AdjustmentDate;
			}
			AccountsPayableAdjustment.Amount = this.Amount;
			AccountsPayableAdjustment.GLTransTypeGroup = this.GLTransTypeGroup;
			AccountsPayableAdjustment.GLTransType = this.GLTransType;
			AccountsPayableAdjustment.Operation = this.Operation;
			AccountsPayableAdjustment.Function = this.Function;
			AccountsPayableAdjustment.NaturalAccount = this.NaturalAccount;
			AccountsPayableAdjustment.Comments = this.Comments;
            AccountsPayableAdjustment.SupplierComment = this.SupplierComment;
			AccountsPayableAdjustment.CreatedById = this.CreatedById;
			if(this.CreatedDate!=null)
			{
				if(this.CreatedDate.Kind == DateTimeKind.Utc)
					AccountsPayableAdjustment.CreatedDate = this.CreatedDate;
				else if(this.CreatedDate.Kind == DateTimeKind.Local)
					AccountsPayableAdjustment.CreatedDate = TimeZoneInfo.ConvertTimeToUtc(this.CreatedDate);
				else
					AccountsPayableAdjustment.CreatedDate = TimeZoneInfo.ConvertTimeToUtc(this.CreatedDate, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
			}
			else
			{
				AccountsPayableAdjustment.CreatedDate = this.CreatedDate;
			}
			AccountsPayableAdjustment.LastUpdatedById = this.LastUpdatedById;
			if(this.LastUpdatedDate.HasValue)
			{
				if(this.LastUpdatedDate.Value.Kind == DateTimeKind.Utc)
					AccountsPayableAdjustment.LastUpdatedDate = this.LastUpdatedDate;
				else if(this.LastUpdatedDate.Value.Kind == DateTimeKind.Local)
					AccountsPayableAdjustment.LastUpdatedDate = TimeZoneInfo.ConvertTimeToUtc(this.LastUpdatedDate.Value);
				else
					AccountsPayableAdjustment.LastUpdatedDate = TimeZoneInfo.ConvertTimeToUtc(this.LastUpdatedDate.Value, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
			}
			else
			{
				AccountsPayableAdjustment.LastUpdatedDate = this.LastUpdatedDate;
			}
            AccountsPayableAdjustment.Version = string.IsNullOrEmpty(this.Version) ? null: Convert.FromBase64String(this.Version);
			AccountsPayableAdjustment.AccountsPayableAdjustmentId = this.AccountsPayableAdjustmentId;
			return AccountsPayableAdjustment;
		} 
		public void MapToDtoWithoutCollections(Domain.AccountsPayableAdjustment AccountsPayableAdjustment)
		{ 
			this.ApplicationId = AccountsPayableAdjustment.ApplicationId;
			this.AccountsPayableInvoiceId = AccountsPayableAdjustment.AccountsPayableInvoiceId;
            this.AccountsPayableDetailId = AccountsPayableAdjustment.AccountsPayableDetailId;
            this.DisputePayableAdjustmentHistoryId = AccountsPayableAdjustment.DisputePayableAdjustmentHistoryId;
			this.WorkOrderId = AccountsPayableAdjustment.WorkOrderId;
			this.AdjustmentType = AccountsPayableAdjustment.AdjustmentType;
			this.AdjustmentCode = AccountsPayableAdjustment.AdjustmentCode;
			if(AccountsPayableAdjustment.AdjustmentDate!=null)
			{
				if(AccountsPayableAdjustment.AdjustmentDate.Kind == DateTimeKind.Utc || AccountsPayableAdjustment.AdjustmentDate.Kind == DateTimeKind.Unspecified)
					this.AdjustmentDate = TimeZoneInfo.ConvertTimeFromUtc(AccountsPayableAdjustment.AdjustmentDate, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
				else
					this.AdjustmentDate = TimeZoneInfo.ConvertTime(AccountsPayableAdjustment.AdjustmentDate, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
			}
			else
			{
				this.AdjustmentDate = AccountsPayableAdjustment.AdjustmentDate;
			}
			this.Amount = AccountsPayableAdjustment.Amount;
			this.GLTransTypeGroup = AccountsPayableAdjustment.GLTransTypeGroup;
			this.GLTransType = AccountsPayableAdjustment.GLTransType;
			this.Operation = AccountsPayableAdjustment.Operation;
			this.Function = AccountsPayableAdjustment.Function;
			this.NaturalAccount = AccountsPayableAdjustment.NaturalAccount;
			this.Comments = AccountsPayableAdjustment.Comments;
            this.SupplierComment = AccountsPayableAdjustment.SupplierComment;
			this.CreatedById = AccountsPayableAdjustment.CreatedById;
			if(AccountsPayableAdjustment.CreatedDate!=null)
			{
				if(AccountsPayableAdjustment.CreatedDate.Kind == DateTimeKind.Utc || AccountsPayableAdjustment.CreatedDate.Kind == DateTimeKind.Unspecified)
					this.CreatedDate = TimeZoneInfo.ConvertTimeFromUtc(AccountsPayableAdjustment.CreatedDate, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
				else
					this.CreatedDate = TimeZoneInfo.ConvertTime(AccountsPayableAdjustment.CreatedDate, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
			}
			else
			{
				this.CreatedDate = AccountsPayableAdjustment.CreatedDate;
			}
			this.LastUpdatedById = AccountsPayableAdjustment.LastUpdatedById;
			if(AccountsPayableAdjustment.LastUpdatedDate.HasValue)
			{
				if(AccountsPayableAdjustment.LastUpdatedDate.Value.Kind == DateTimeKind.Utc || AccountsPayableAdjustment.LastUpdatedDate.Value.Kind == DateTimeKind.Unspecified)
					this.LastUpdatedDate = TimeZoneInfo.ConvertTimeFromUtc(AccountsPayableAdjustment.LastUpdatedDate.Value, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
				else
					this.LastUpdatedDate = TimeZoneInfo.ConvertTime(AccountsPayableAdjustment.LastUpdatedDate.Value, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
			}
			else
			{
				this.LastUpdatedDate = AccountsPayableAdjustment.LastUpdatedDate;
			}
            this.Version = AccountsPayableAdjustment.Version == null ? null:Convert.ToBase64String(AccountsPayableAdjustment.Version);
			this.AccountsPayableAdjustmentId = AccountsPayableAdjustment.AccountsPayableAdjustmentId;
		} 
		public override TDto MapFromDomainModel<TDomain, TDto>(TDomain domainModel)
		{ 
			Domain.AccountsPayableAdjustment AccountsPayableAdjustmentModel = domainModel as Domain.AccountsPayableAdjustment;
			if(AccountsPayableAdjustmentModel != null)
			{ 
				MapToDtoWithoutCollections(AccountsPayableAdjustmentModel);
			} 
				return this as TDto;
		} 
		public override TDomain MapToDomainModel<TDomain>(TDomain domainModel)
		{ 
			Domain.AccountsPayableAdjustment AccountsPayableAdjustmentModel = domainModel as Domain.AccountsPayableAdjustment;
			Domain.AccountsPayableAdjustment destObj = MapToDomainModelWithoutCollections(AccountsPayableAdjustmentModel);
		    return destObj as TDomain;
		} 
	} 
} 

