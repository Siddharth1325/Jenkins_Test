using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using CommonLib.DataObjects;
using CommonLib.ModelAttrib;
using Domain = DomainModel.Accounting;
namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{ 
[System.CodeDom.Compiler.GeneratedCode("EF", "6.1.0")]
	public partial class IMChaseMapping : BaseDto
	{ 
		public Domain.IMChaseMapping MapToDomainModelWithoutCollections(Domain.IMChaseMapping IMChaseMapping)
		{ 
			IMChaseMapping.ApplicationId = this.ApplicationId;
			IMChaseMapping.MasterClientProfileId = this.MasterClientProfileId;
			IMChaseMapping.SubClientProfileId = this.SubClientProfileId;
			IMChaseMapping.RequestorCode = this.RequestorCode;
			IMChaseMapping.MBACodeType = this.MBACodeType;
            IMChaseMapping.MBACodeGroup = string.IsNullOrEmpty(this.MBACodeType) ? null: GroupCodeEnum.MBACD.ToString();
			IMChaseMapping.IMInvoiceType = this.IMInvoiceType;
			IMChaseMapping.IMOrderType = this.IMOrderType;
            IMChaseMapping.IMOrderTypeGroup = string.IsNullOrEmpty(this.IMOrderType) ? null: GroupCodeEnum.IMORT.ToString();
			IMChaseMapping.IMLineItem = this.IMLineItem;
			IMChaseMapping.LOBTypeGroup = this.LOBTypeGroup;
			IMChaseMapping.LOBType = this.LOBType;
			IMChaseMapping.IsTax = this.IsTax;
			IMChaseMapping.IsRush = this.IsRush;
			IMChaseMapping.ProductId = this.ProductId;
			IMChaseMapping.ServiceId = this.ServiceId;
			IMChaseMapping.FeeTypeId = this.FeeTypeId;
			IMChaseMapping.CreatedById = this.CreatedById;
            IMChaseMapping.LineItemId = this.LineItemId;
			if(this.CreatedDate!=null)
			{
				if(this.CreatedDate.Kind == DateTimeKind.Utc)
					IMChaseMapping.CreatedDate = this.CreatedDate;
				else if(this.CreatedDate.Kind == DateTimeKind.Local)
					IMChaseMapping.CreatedDate = TimeZoneInfo.ConvertTimeToUtc(this.CreatedDate);
				else
					IMChaseMapping.CreatedDate = TimeZoneInfo.ConvertTimeToUtc(this.CreatedDate, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
			}
			else
			{
				IMChaseMapping.CreatedDate = this.CreatedDate;
			}
			IMChaseMapping.LastUpdatedById = this.LastUpdatedById;
			if(this.LastUpdatedDate.HasValue)
			{
				if(this.LastUpdatedDate.Value.Kind == DateTimeKind.Utc)
					IMChaseMapping.LastUpdatedDate = this.LastUpdatedDate;
				else if(this.LastUpdatedDate.Value.Kind == DateTimeKind.Local)
					IMChaseMapping.LastUpdatedDate = TimeZoneInfo.ConvertTimeToUtc(this.LastUpdatedDate.Value);
				else
					IMChaseMapping.LastUpdatedDate = TimeZoneInfo.ConvertTimeToUtc(this.LastUpdatedDate.Value, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
			}
			else
			{
				IMChaseMapping.LastUpdatedDate = this.LastUpdatedDate;
			}
            IMChaseMapping.Version = string.IsNullOrEmpty(this.Version) ? null: Convert.FromBase64String(this.Version);
			if (this.FeeType != null)
			{ 
				IMChaseMapping.FeeType = new Domain.FeeType();
				IMChaseMapping.FeeType = this.FeeType.MapToDomainModelWithoutCollections(IMChaseMapping.FeeType);
			} 
			if (this.Service != null)
			{ 
				IMChaseMapping.Service = new Domain.Service();
				IMChaseMapping.Service = this.Service.MapToDomainModelWithoutCollections(IMChaseMapping.Service);
			} 
			IMChaseMapping.IMChaseMappingId = this.IMChaseMappingId;
			return IMChaseMapping;
		} 
		public void MapToDtoWithoutCollections(Domain.IMChaseMapping IMChaseMapping)
		{ 
			this.ApplicationId = IMChaseMapping.ApplicationId;
			this.MasterClientProfileId = IMChaseMapping.MasterClientProfileId;
			this.SubClientProfileId = IMChaseMapping.SubClientProfileId;
			this.RequestorCode = IMChaseMapping.RequestorCode;
			this.MBACodeType = IMChaseMapping.MBACodeType;
			this.IMInvoiceType = IMChaseMapping.IMInvoiceType;
			this.IMOrderType = IMChaseMapping.IMOrderType;
			this.IMLineItem = IMChaseMapping.IMLineItem;
			this.LOBTypeGroup = IMChaseMapping.LOBTypeGroup;
			this.LOBType = IMChaseMapping.LOBType;
			this.IsTax = IMChaseMapping.IsTax;
			this.IsRush = IMChaseMapping.IsRush;
			this.ProductId = IMChaseMapping.ProductId;
			this.ServiceId = IMChaseMapping.ServiceId;
			this.FeeTypeId = IMChaseMapping.FeeTypeId;
			this.CreatedById = IMChaseMapping.CreatedById;
            this.LineItemId = IMChaseMapping.LineItemId;
			if(IMChaseMapping.CreatedDate!=null)
			{
				if(IMChaseMapping.CreatedDate.Kind == DateTimeKind.Utc || IMChaseMapping.CreatedDate.Kind == DateTimeKind.Unspecified)
					this.CreatedDate = TimeZoneInfo.ConvertTimeFromUtc(IMChaseMapping.CreatedDate, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
				else
					this.CreatedDate = TimeZoneInfo.ConvertTime(IMChaseMapping.CreatedDate, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
			}
			else
			{
				this.CreatedDate = IMChaseMapping.CreatedDate;
			}
			this.LastUpdatedById = IMChaseMapping.LastUpdatedById;
			if(IMChaseMapping.LastUpdatedDate.HasValue)
			{
				if(IMChaseMapping.LastUpdatedDate.Value.Kind == DateTimeKind.Utc || IMChaseMapping.LastUpdatedDate.Value.Kind == DateTimeKind.Unspecified)
					this.LastUpdatedDate = TimeZoneInfo.ConvertTimeFromUtc(IMChaseMapping.LastUpdatedDate.Value, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
				else
					this.LastUpdatedDate = TimeZoneInfo.ConvertTime(IMChaseMapping.LastUpdatedDate.Value, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
			}
			else
			{
				this.LastUpdatedDate = IMChaseMapping.LastUpdatedDate;
			}
            this.Version = IMChaseMapping.Version == null ? null:Convert.ToBase64String(IMChaseMapping.Version);
			if (IMChaseMapping.FeeType != null)
			{ 
				this.FeeType = new FeeType();
				this.FeeType.MapToDtoWithoutCollections(IMChaseMapping.FeeType);
			} 
			if (IMChaseMapping.Service != null)
			{ 
				this.Service = new Service();
				this.Service.MapToDtoWithoutCollections(IMChaseMapping.Service);
			} 
			this.IMChaseMappingId = IMChaseMapping.IMChaseMappingId;
		} 
		public override TDto MapFromDomainModel<TDomain, TDto>(TDomain domainModel)
		{ 
			Domain.IMChaseMapping IMChaseMappingModel = domainModel as Domain.IMChaseMapping;
			if(IMChaseMappingModel != null)
			{ 
				MapToDtoWithoutCollections(IMChaseMappingModel);
			} 
				return this as TDto;
		} 
		public override TDomain MapToDomainModel<TDomain>(TDomain domainModel)
		{ 
			Domain.IMChaseMapping IMChaseMappingModel = domainModel as Domain.IMChaseMapping;
			Domain.IMChaseMapping destObj = MapToDomainModelWithoutCollections(IMChaseMappingModel);
		    return destObj as TDomain;
		} 
	} 
} 

