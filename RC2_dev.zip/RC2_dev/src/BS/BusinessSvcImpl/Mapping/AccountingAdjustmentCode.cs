using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using CommonLib.DataObjects;
using CommonLib.ModelAttrib;
using Domain = DomainModel.Accounting;
namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{ 
[System.CodeDom.Compiler.GeneratedCode("EF", "6.1.0")]
	public partial class AccountingAdjustmentCode : BaseDto
	{ 
		public Domain.AccountingAdjustmentCode MapToDomainModelWithoutCollections(Domain.AccountingAdjustmentCode AccountingAdjustmentCode)
		{ 
			AccountingAdjustmentCode.AdjustmentCategoryType = this.AdjustmentCategoryType;
            AccountingAdjustmentCode.AdjustmentCategoryGroup = string.IsNullOrEmpty(this.AdjustmentCategoryType) ? null: GroupCodeEnum.ADCAT.ToString();
			AccountingAdjustmentCode.AdjustmentType = this.AdjustmentType;
            AccountingAdjustmentCode.AdjustmentTypeGroup = string.IsNullOrEmpty(this.AdjustmentType) ? null: GroupCodeEnum.ADTYP.ToString();
			AccountingAdjustmentCode.ApplicationId = this.ApplicationId;
			AccountingAdjustmentCode.AdjustmentCode = this.AdjustmentCode;
			AccountingAdjustmentCode.Description = this.Description;
			AccountingAdjustmentCode.IsActive = this.IsActive;
			AccountingAdjustmentCode.CreatedById = this.CreatedById;
			if(this.CreatedDate!=null)
			{
				if(this.CreatedDate.Kind == DateTimeKind.Utc)
					AccountingAdjustmentCode.CreatedDate = this.CreatedDate;
				else if(this.CreatedDate.Kind == DateTimeKind.Local)
					AccountingAdjustmentCode.CreatedDate = TimeZoneInfo.ConvertTimeToUtc(this.CreatedDate);
				else
					AccountingAdjustmentCode.CreatedDate = TimeZoneInfo.ConvertTimeToUtc(this.CreatedDate, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
			}
			else
			{
				AccountingAdjustmentCode.CreatedDate = this.CreatedDate;
			}
			AccountingAdjustmentCode.LastUpdatedById = this.LastUpdatedById;
			if(this.LastUpdatedDate.HasValue)
			{
				if(this.LastUpdatedDate.Value.Kind == DateTimeKind.Utc)
					AccountingAdjustmentCode.LastUpdatedDate = this.LastUpdatedDate;
				else if(this.LastUpdatedDate.Value.Kind == DateTimeKind.Local)
					AccountingAdjustmentCode.LastUpdatedDate = TimeZoneInfo.ConvertTimeToUtc(this.LastUpdatedDate.Value);
				else
					AccountingAdjustmentCode.LastUpdatedDate = TimeZoneInfo.ConvertTimeToUtc(this.LastUpdatedDate.Value, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
			}
			else
			{
				AccountingAdjustmentCode.LastUpdatedDate = this.LastUpdatedDate;
			}
            AccountingAdjustmentCode.Version = string.IsNullOrEmpty(this.Version) ? null: Convert.FromBase64String(this.Version);
			AccountingAdjustmentCode.AccountingAdjustmentCodeId = this.AccountingAdjustmentCodeId;
			return AccountingAdjustmentCode;
		} 
		public void MapToDtoWithoutCollections(Domain.AccountingAdjustmentCode AccountingAdjustmentCode)
		{ 
			this.AdjustmentCategoryType = AccountingAdjustmentCode.AdjustmentCategoryType;
			this.AdjustmentType = AccountingAdjustmentCode.AdjustmentType;
			this.ApplicationId = AccountingAdjustmentCode.ApplicationId;
			this.AdjustmentCode = AccountingAdjustmentCode.AdjustmentCode;
			this.Description = AccountingAdjustmentCode.Description;
			this.IsActive = AccountingAdjustmentCode.IsActive;
			this.CreatedById = AccountingAdjustmentCode.CreatedById;
			if(AccountingAdjustmentCode.CreatedDate!=null)
			{
				if(AccountingAdjustmentCode.CreatedDate.Kind == DateTimeKind.Utc || AccountingAdjustmentCode.CreatedDate.Kind == DateTimeKind.Unspecified)
					this.CreatedDate = TimeZoneInfo.ConvertTimeFromUtc(AccountingAdjustmentCode.CreatedDate, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
				else
					this.CreatedDate = TimeZoneInfo.ConvertTime(AccountingAdjustmentCode.CreatedDate, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
			}
			else
			{
				this.CreatedDate = AccountingAdjustmentCode.CreatedDate;
			}
			this.LastUpdatedById = AccountingAdjustmentCode.LastUpdatedById;
			if(AccountingAdjustmentCode.LastUpdatedDate.HasValue)
			{
				if(AccountingAdjustmentCode.LastUpdatedDate.Value.Kind == DateTimeKind.Utc || AccountingAdjustmentCode.LastUpdatedDate.Value.Kind == DateTimeKind.Unspecified)
					this.LastUpdatedDate = TimeZoneInfo.ConvertTimeFromUtc(AccountingAdjustmentCode.LastUpdatedDate.Value, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
				else
					this.LastUpdatedDate = TimeZoneInfo.ConvertTime(AccountingAdjustmentCode.LastUpdatedDate.Value, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
			}
			else
			{
				this.LastUpdatedDate = AccountingAdjustmentCode.LastUpdatedDate;
			}
            this.Version = AccountingAdjustmentCode.Version == null ? null:Convert.ToBase64String(AccountingAdjustmentCode.Version);
			this.AccountingAdjustmentCodeId = AccountingAdjustmentCode.AccountingAdjustmentCodeId;
		} 
		public override TDto MapFromDomainModel<TDomain, TDto>(TDomain domainModel)
		{ 
			Domain.AccountingAdjustmentCode AccountingAdjustmentCodeModel = domainModel as Domain.AccountingAdjustmentCode;
			if(AccountingAdjustmentCodeModel != null)
			{ 
				MapToDtoWithoutCollections(AccountingAdjustmentCodeModel);
			} 
				return this as TDto;
		} 
		public override TDomain MapToDomainModel<TDomain>(TDomain domainModel)
		{ 
			Domain.AccountingAdjustmentCode AccountingAdjustmentCodeModel = domainModel as Domain.AccountingAdjustmentCode;
			Domain.AccountingAdjustmentCode destObj = MapToDomainModelWithoutCollections(AccountingAdjustmentCodeModel);
		    return destObj as TDomain;
		} 
	} 
} 

