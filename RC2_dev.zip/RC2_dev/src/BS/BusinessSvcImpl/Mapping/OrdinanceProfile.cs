using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using CommonLib.DataObjects;
using CommonLib.ModelAttrib;
using Domain = DomainModel.Accounting;
namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{ 
[System.CodeDom.Compiler.GeneratedCode("EF", "6.1.0")]
	public partial class OrdinanceProfile : BaseDto
	{ 
		public Domain.OrdinanceProfile MapToDomainModelWithoutCollections(Domain.OrdinanceProfile OrdinanceProfile)
		{ 
            //OrdinanceProfile.Municipality = this.Municipality;
            //OrdinanceProfile.MunicipalityZipCode = this.MunicipalityZipCode;
			OrdinanceProfile.OrdinanceStatus = this.OrdinanceStatus;
            OrdinanceProfile.OrdinanceStatusGroup = string.IsNullOrEmpty(this.OrdinanceStatus) ? null: GroupCodeEnum.ODT.ToString();
			OrdinanceProfile.EffectiveDate = this.EffectiveDate;
			OrdinanceProfile.CommonName = this.CommonName;
			OrdinanceProfile.IsActive = this.IsActive;
			OrdinanceProfile.RenewalBasis = this.RenewalBasis;
            OrdinanceProfile.RenewalBasisGroup = string.IsNullOrEmpty(this.RenewalBasis) ? null: GroupCodeEnum.RENBASIS.ToString();
			OrdinanceProfile.RenewalDueText = this.RenewalDueText;
			//OrdinanceProfile.RegistrationType = this.RegistrationType;
           // OrdinanceProfile.RegistrationTypeGroup = string.IsNullOrEmpty(this.RegistrationType) ? null: GroupCodeEnum.REGTYP.ToString();
			OrdinanceProfile.GoverningEntity = this.GoverningEntity;
            OrdinanceProfile.GoverningEntityGroup = string.IsNullOrEmpty(this.GoverningEntity) ? null: GroupCodeEnum.GOVENT.ToString();
			OrdinanceProfile.Citation = this.Citation;
			OrdinanceProfile.FormsLink = this.FormsLink;
			OrdinanceProfile.DeRegistration = this.DeRegistration;
			OrdinanceProfile.BondRequired = this.BondRequired;
			OrdinanceProfile.OrdinanceLink = this.OrdinanceLink;
			OrdinanceProfile.BondAmount = this.BondAmount;
			OrdinanceProfile.BondEnforce = this.BondEnforce;
			OrdinanceProfile.PostPropertySign = this.PostPropertySign;
			//OrdinanceProfile.SignateType = this.SignateType;
			OrdinanceProfile.InsuranceRequired = this.InsuranceRequired;
			OrdinanceProfile.InsuranceEnforce = this.InsuranceEnforce;
			OrdinanceProfile.MinimumInsuranceText = this.MinimumInsuranceText;
			OrdinanceProfile.PropertyLookupLink = this.PropertyLookupLink;
			OrdinanceProfile.PropertyLookupPhone = this.PropertyLookupPhone;
			OrdinanceProfile.ApprovedToSignForms = this.ApprovedToSignForms;
			OrdinanceProfile.ApprovedToSignNotary = this.ApprovedToSignNotary;
			OrdinanceProfile.ApprovedToSignAttestation = this.ApprovedToSignAttestation;
			OrdinanceProfile.AttentionTo = this.AttentionTo;
			OrdinanceProfile.Address1 = this.Address1;
			OrdinanceProfile.Address2 = this.Address2;
			OrdinanceProfile.CityName = this.CityName;
			OrdinanceProfile.CountyName = this.CountyName;
			OrdinanceProfile.StateCode = this.StateCode;
			OrdinanceProfile.ZipCode = this.ZipCode;
			OrdinanceProfile.SubmitPropertyManager = this.SubmitPropertyManager;
			OrdinanceProfile.LocalPropertyManager = this.LocalPropertyManager;
			OrdinanceProfile.ExplainLocal = this.ExplainLocal;
			OrdinanceProfile.PropertyManagerEnforce = this.PropertyManagerEnforce;
			OrdinanceProfile.PropertyManagerToSendDoc = this.PropertyManagerToSendDoc;
			OrdinanceProfile.MailingCityName = this.MailingCityName;
			OrdinanceProfile.MailingState = this.MailingState;
			OrdinanceProfile.MailingZipCode = this.MailingZipCode;
			OrdinanceProfile.CreatedById = this.CreatedById;
			if(this.CreatedDate!=null)
			{
				if(this.CreatedDate.Kind == DateTimeKind.Utc)
					OrdinanceProfile.CreatedDate = this.CreatedDate;
				else if(this.CreatedDate.Kind == DateTimeKind.Local)
					OrdinanceProfile.CreatedDate = TimeZoneInfo.ConvertTimeToUtc(this.CreatedDate);
				else
					OrdinanceProfile.CreatedDate = TimeZoneInfo.ConvertTimeToUtc(this.CreatedDate, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
			}
			else
			{
				OrdinanceProfile.CreatedDate = this.CreatedDate;
			}
			OrdinanceProfile.LastUpdatedById = this.LastUpdatedById;
			if(this.LastUpdatedDate.HasValue)
			{
				if(this.LastUpdatedDate.Value.Kind == DateTimeKind.Utc)
					OrdinanceProfile.LastUpdatedDate = this.LastUpdatedDate;
				else if(this.LastUpdatedDate.Value.Kind == DateTimeKind.Local)
					OrdinanceProfile.LastUpdatedDate = TimeZoneInfo.ConvertTimeToUtc(this.LastUpdatedDate.Value);
				else
					OrdinanceProfile.LastUpdatedDate = TimeZoneInfo.ConvertTimeToUtc(this.LastUpdatedDate.Value, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
			}
			else
			{
				OrdinanceProfile.LastUpdatedDate = this.LastUpdatedDate;
			}
            OrdinanceProfile.Version = string.IsNullOrEmpty(this.Version) ? null: Convert.FromBase64String(this.Version);
			OrdinanceProfile.OrdinanceProfileId = this.OrdinanceProfileId;
			return OrdinanceProfile;
		} 
		public void MapToDtoWithoutCollections(Domain.OrdinanceProfile OrdinanceProfile)
		{ 
            //this.Municipality = OrdinanceProfile.Municipality;
            //this.MunicipalityZipCode = OrdinanceProfile.MunicipalityZipCode;
			this.OrdinanceStatus = OrdinanceProfile.OrdinanceStatus;
			this.EffectiveDate = OrdinanceProfile.EffectiveDate;
			this.CommonName = OrdinanceProfile.CommonName;
			this.IsActive = OrdinanceProfile.IsActive;
			this.RenewalBasis = OrdinanceProfile.RenewalBasis;
			this.RenewalDueText = OrdinanceProfile.RenewalDueText;
			//this.RegistrationType = OrdinanceProfile.RegistrationType;
			this.GoverningEntity = OrdinanceProfile.GoverningEntity;
			this.Citation = OrdinanceProfile.Citation;
			this.FormsLink = OrdinanceProfile.FormsLink;
			this.DeRegistration = OrdinanceProfile.DeRegistration;
			this.BondRequired = OrdinanceProfile.BondRequired;
			this.OrdinanceLink = OrdinanceProfile.OrdinanceLink;
			this.BondAmount = OrdinanceProfile.BondAmount;
			this.BondEnforce = OrdinanceProfile.BondEnforce;
			this.PostPropertySign = OrdinanceProfile.PostPropertySign;
			//this.SignateType = OrdinanceProfile.SignateType;
			this.InsuranceRequired = OrdinanceProfile.InsuranceRequired;
			this.InsuranceEnforce = OrdinanceProfile.InsuranceEnforce;
			this.MinimumInsuranceText = OrdinanceProfile.MinimumInsuranceText;
			this.PropertyLookupLink = OrdinanceProfile.PropertyLookupLink;
			this.PropertyLookupPhone = OrdinanceProfile.PropertyLookupPhone;
			this.ApprovedToSignForms = OrdinanceProfile.ApprovedToSignForms;
			this.ApprovedToSignNotary = OrdinanceProfile.ApprovedToSignNotary;
			this.ApprovedToSignAttestation = OrdinanceProfile.ApprovedToSignAttestation;
			this.AttentionTo = OrdinanceProfile.AttentionTo;
			this.Address1 = OrdinanceProfile.Address1;
			this.Address2 = OrdinanceProfile.Address2;
			this.CityName = OrdinanceProfile.CityName;
			this.CountyName = OrdinanceProfile.CountyName;
			this.StateCode = OrdinanceProfile.StateCode;
			this.ZipCode = OrdinanceProfile.ZipCode;
			this.SubmitPropertyManager = OrdinanceProfile.SubmitPropertyManager;
			this.LocalPropertyManager = OrdinanceProfile.LocalPropertyManager;
			this.ExplainLocal = OrdinanceProfile.ExplainLocal;
			this.PropertyManagerEnforce = OrdinanceProfile.PropertyManagerEnforce;
			this.PropertyManagerToSendDoc = OrdinanceProfile.PropertyManagerToSendDoc;
			this.MailingCityName = OrdinanceProfile.MailingCityName;
			this.MailingState = OrdinanceProfile.MailingState;
			this.MailingZipCode = OrdinanceProfile.MailingZipCode;
			this.CreatedById = OrdinanceProfile.CreatedById;
			if(OrdinanceProfile.CreatedDate!=null)
			{
				if(OrdinanceProfile.CreatedDate.Kind == DateTimeKind.Utc || OrdinanceProfile.CreatedDate.Kind == DateTimeKind.Unspecified)
					this.CreatedDate = TimeZoneInfo.ConvertTimeFromUtc(OrdinanceProfile.CreatedDate, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
				else
					this.CreatedDate = TimeZoneInfo.ConvertTime(OrdinanceProfile.CreatedDate, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
			}
			else
			{
				this.CreatedDate = OrdinanceProfile.CreatedDate;
			}
			this.LastUpdatedById = OrdinanceProfile.LastUpdatedById;
			if(OrdinanceProfile.LastUpdatedDate.HasValue)
			{
				if(OrdinanceProfile.LastUpdatedDate.Value.Kind == DateTimeKind.Utc || OrdinanceProfile.LastUpdatedDate.Value.Kind == DateTimeKind.Unspecified)
					this.LastUpdatedDate = TimeZoneInfo.ConvertTimeFromUtc(OrdinanceProfile.LastUpdatedDate.Value, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
				else
					this.LastUpdatedDate = TimeZoneInfo.ConvertTime(OrdinanceProfile.LastUpdatedDate.Value, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
			}
			else
			{
				this.LastUpdatedDate = OrdinanceProfile.LastUpdatedDate;
			}
            this.Version = OrdinanceProfile.Version == null ? null:Convert.ToBase64String(OrdinanceProfile.Version);
			this.OrdinanceProfileId = OrdinanceProfile.OrdinanceProfileId;
		} 
		public override TDto MapFromDomainModel<TDomain, TDto>(TDomain domainModel)
		{ 
			Domain.OrdinanceProfile OrdinanceProfileModel = domainModel as Domain.OrdinanceProfile;
			if(OrdinanceProfileModel != null)
			{ 
				MapToDtoWithoutCollections(OrdinanceProfileModel);
			} 
				return this as TDto;
		} 
		public override TDomain MapToDomainModel<TDomain>(TDomain domainModel)
		{ 
			Domain.OrdinanceProfile OrdinanceProfileModel = domainModel as Domain.OrdinanceProfile;
			Domain.OrdinanceProfile destObj = MapToDomainModelWithoutCollections(OrdinanceProfileModel);
		    return destObj as TDomain;
		} 
	} 
} 

