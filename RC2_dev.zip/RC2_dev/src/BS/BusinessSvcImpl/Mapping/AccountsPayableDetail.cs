using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using CommonLib.DataObjects;
using CommonLib.ModelAttrib;
using Domain = DomainModel.Accounting;
namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{
    [System.CodeDom.Compiler.GeneratedCode("EF", "6.1.0")]
    public partial class AccountsPayableDetail : BaseDto
    {
        public Domain.AccountsPayableDetail MapToDomainModelWithoutCollections(Domain.AccountsPayableDetail AccountsPayableDetail)
        {
            AccountsPayableDetail.ApplicationId = this.ApplicationId;
            AccountsPayableDetail.OrderHierarchyId = this.OrderHierarchyId;
            AccountsPayableDetail.AccountsPayableId = this.AccountsPayableId;
            AccountsPayableDetail.WorkOrderItemId = this.WorkOrderItemId;
            AccountsPayableDetail.Quantity = this.Quantity;
            AccountsPayableDetail.UnitsGroup = this.UnitsGroup;
            AccountsPayableDetail.UnitsType = this.UnitsType;
            AccountsPayableDetail.BaseCostPerUnit = this.BaseCostPerUnit;
            AccountsPayableDetail.BaseTotalCost = this.BaseTotalCost;
            AccountsPayableDetail.FinalTotalCost = this.FinalTotalCost;
            AccountsPayableDetail.FeeTypeId = this.FeeTypeId;
            AccountsPayableDetail.APStatusGroup = this.APStatusGroup;
            AccountsPayableDetail.APStatusType = this.APStatusType;
            AccountsPayableDetail.CreatedById = this.CreatedById;
            if (this.CreatedDate != null)
            {
                if (this.CreatedDate.Kind == DateTimeKind.Utc)
                    AccountsPayableDetail.CreatedDate = this.CreatedDate;
                else if (this.CreatedDate.Kind == DateTimeKind.Local)
                    AccountsPayableDetail.CreatedDate = TimeZoneInfo.ConvertTimeToUtc(this.CreatedDate);
                else
                    AccountsPayableDetail.CreatedDate = TimeZoneInfo.ConvertTimeToUtc(this.CreatedDate, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
            }
            else
            {
                AccountsPayableDetail.CreatedDate = this.CreatedDate;
            }
            AccountsPayableDetail.LastUpdatedById = this.LastUpdatedById;
            AccountsPayableDetail.QCSupplierComment = this.QCSupplierComment;
            if (this.LastUpdatedDate.HasValue)
            {
                if (this.LastUpdatedDate.Value.Kind == DateTimeKind.Utc)
                    AccountsPayableDetail.LastUpdatedDate = this.LastUpdatedDate;
                else if (this.LastUpdatedDate.Value.Kind == DateTimeKind.Local)
                    AccountsPayableDetail.LastUpdatedDate = TimeZoneInfo.ConvertTimeToUtc(this.LastUpdatedDate.Value);
                else
                    AccountsPayableDetail.LastUpdatedDate = TimeZoneInfo.ConvertTimeToUtc(this.LastUpdatedDate.Value, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
            }
            else
            {
                AccountsPayableDetail.LastUpdatedDate = this.LastUpdatedDate;
            }
            AccountsPayableDetail.Version = string.IsNullOrEmpty(this.Version) ? null : Convert.FromBase64String(this.Version);
            if (this.OrderHierarchy != null)
            {
                AccountsPayableDetail.OrderHierarchy = new Domain.OrderHierarchy();
                AccountsPayableDetail.OrderHierarchy = this.OrderHierarchy.MapToDomainModelWithoutCollections(AccountsPayableDetail.OrderHierarchy);
            }
            if (this.FeeType != null)
            {
                AccountsPayableDetail.FeeType = new Domain.FeeType();
                AccountsPayableDetail.FeeType = this.FeeType.MapToDomainModelWithoutCollections(AccountsPayableDetail.FeeType);
            }
            AccountsPayableDetail.AccountsPayableDetailId = this.AccountsPayableDetailId;
            AccountsPayableDetail.SourceAccountsPayableDetailId = this.SourceAccountsPayableDetailId;
            return AccountsPayableDetail;
        }
        public void MapToDtoWithoutCollections(Domain.AccountsPayableDetail AccountsPayableDetail)
        {
            this.ApplicationId = AccountsPayableDetail.ApplicationId;
            this.OrderHierarchyId = AccountsPayableDetail.OrderHierarchyId;
            this.AccountsPayableId = AccountsPayableDetail.AccountsPayableId;
            this.WorkOrderItemId = AccountsPayableDetail.WorkOrderItemId;
            this.Quantity = AccountsPayableDetail.Quantity;
            this.UnitsGroup = AccountsPayableDetail.UnitsGroup;
            this.UnitsType = AccountsPayableDetail.UnitsType;
            this.BaseCostPerUnit = AccountsPayableDetail.BaseCostPerUnit;
            this.BaseTotalCost = AccountsPayableDetail.BaseTotalCost;
            this.FinalTotalCost = AccountsPayableDetail.FinalTotalCost;
            this.FeeTypeId = AccountsPayableDetail.FeeTypeId;
            this.APStatusGroup = AccountsPayableDetail.APStatusGroup;
            this.APStatusType = AccountsPayableDetail.APStatusType;
            this.CreatedById = AccountsPayableDetail.CreatedById;
            this.QCSupplierComment = AccountsPayableDetail.QCSupplierComment;
            if (AccountsPayableDetail.CreatedDate != null)
            {
                if (AccountsPayableDetail.CreatedDate.Kind == DateTimeKind.Utc || AccountsPayableDetail.CreatedDate.Kind == DateTimeKind.Unspecified)
                    this.CreatedDate = TimeZoneInfo.ConvertTimeFromUtc(AccountsPayableDetail.CreatedDate, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
                else
                    this.CreatedDate = TimeZoneInfo.ConvertTime(AccountsPayableDetail.CreatedDate, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
            }
            else
            {
                this.CreatedDate = AccountsPayableDetail.CreatedDate;
            }
            this.LastUpdatedById = AccountsPayableDetail.LastUpdatedById;
            if (AccountsPayableDetail.LastUpdatedDate.HasValue)
            {
                if (AccountsPayableDetail.LastUpdatedDate.Value.Kind == DateTimeKind.Utc || AccountsPayableDetail.LastUpdatedDate.Value.Kind == DateTimeKind.Unspecified)
                    this.LastUpdatedDate = TimeZoneInfo.ConvertTimeFromUtc(AccountsPayableDetail.LastUpdatedDate.Value, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
                else
                    this.LastUpdatedDate = TimeZoneInfo.ConvertTime(AccountsPayableDetail.LastUpdatedDate.Value, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
            }
            else
            {
                this.LastUpdatedDate = AccountsPayableDetail.LastUpdatedDate;
            }
            this.Version = AccountsPayableDetail.Version == null ? null : Convert.ToBase64String(AccountsPayableDetail.Version);
            if (AccountsPayableDetail.OrderHierarchy != null)
            {
                this.OrderHierarchy = new OrderHierarchy();
                this.OrderHierarchy.MapToDtoWithoutCollections(AccountsPayableDetail.OrderHierarchy);
            }
            if (AccountsPayableDetail.FeeType != null)
            {
                this.FeeType = new FeeType();
                this.FeeType.MapToDtoWithoutCollections(AccountsPayableDetail.FeeType);
            }
            this.AccountsPayableDetailId = AccountsPayableDetail.AccountsPayableDetailId;
            this.SourceAccountsPayableDetailId = AccountsPayableDetail.SourceAccountsPayableDetailId;
        }
        public override TDto MapFromDomainModel<TDomain, TDto>(TDomain domainModel)
        {
            Domain.AccountsPayableDetail AccountsPayableDetailModel = domainModel as Domain.AccountsPayableDetail;
            if (AccountsPayableDetailModel != null)
            {
                MapToDtoWithoutCollections(AccountsPayableDetailModel);
                foreach (Domain.AccountsPayableTrace AccountsPayableTrace in AccountsPayableDetailModel.AccountsPayableTraces)
                {
                    AccountsPayableTrace AccountsPayableTraceDto = new AccountsPayableTrace();
                    AccountsPayableTraceDto = AccountsPayableTraceDto.MapFromDomainModel<Domain.AccountsPayableTrace, AccountsPayableTrace>(AccountsPayableTrace);
                    this.AccountsPayableTraces.Add(AccountsPayableTraceDto);
                }
                foreach (Domain.AccountingAPInvoicePayable AccountingAPInvoicePayable in AccountsPayableDetailModel.AccountingAPInvoicePayables)
                {
                    AccountingAPInvoicePayable AccountingAPInvoicePayableDto = new AccountingAPInvoicePayable();
                    AccountingAPInvoicePayableDto = AccountingAPInvoicePayableDto.MapFromDomainModel<Domain.AccountingAPInvoicePayable, AccountingAPInvoicePayable>(AccountingAPInvoicePayable);
                    this.AccountingAPInvoicePayables.Add(AccountingAPInvoicePayableDto);
                }
            }
            return this as TDto;
        }
        private void MapAccountsPayableTraces(Domain.AccountsPayableDetail destObj)
        {
            if (AccountsPayableTraces != null)
            {
                foreach (AccountsPayableTrace AccountsPayableTrace in AccountsPayableTraces)
                {
                    Domain.AccountsPayableTrace AccountsPayableTraceModel;
                    if (AccountsPayableTrace.AccountsPayableTraceId == 0)
                    {
                        AccountsPayableTraceModel = new Domain.AccountsPayableTrace();
                        AccountsPayableTraceModel = AccountsPayableTrace.MapToDomainModel<Domain.AccountsPayableTrace>(AccountsPayableTraceModel) as Domain.AccountsPayableTrace;
                        destObj.AccountsPayableTraces.Add(AccountsPayableTraceModel);
                    }
                    else
                    {
                        AccountsPayableTraceModel = destObj.AccountsPayableTraces.FirstOrDefault(a => a.AccountsPayableTraceId == AccountsPayableTrace.AccountsPayableTraceId);
                        if (AccountsPayableTraceModel != null)
                        {
                            if (AccountsPayableTrace.HardDelete)
                            {
                                destObj.AccountsPayableTraces.Remove(AccountsPayableTraceModel);
                            }
                            else
                            {
                                AccountsPayableTraceModel = AccountsPayableTrace.MapToDomainModel<Domain.AccountsPayableTrace>(AccountsPayableTraceModel) as Domain.AccountsPayableTrace;
                            }
                        }
                    }
                }
            }
        }
        private void MapAccountingAPInvoicePayables(Domain.AccountsPayableDetail destObj)
        {
            if (AccountingAPInvoicePayables != null)
            {
                foreach (AccountingAPInvoicePayable AccountingAPInvoicePayable in AccountingAPInvoicePayables)
                {
                    Domain.AccountingAPInvoicePayable AccountingAPInvoicePayableModel;
                    if (AccountingAPInvoicePayable.AccountingAPInvoicePayableId == 0)
                    {
                        AccountingAPInvoicePayableModel = new Domain.AccountingAPInvoicePayable();
                        AccountingAPInvoicePayableModel = AccountingAPInvoicePayable.MapToDomainModel<Domain.AccountingAPInvoicePayable>(AccountingAPInvoicePayableModel) as Domain.AccountingAPInvoicePayable;
                        destObj.AccountingAPInvoicePayables.Add(AccountingAPInvoicePayableModel);
                    }
                    else
                    {
                        AccountingAPInvoicePayableModel = destObj.AccountingAPInvoicePayables.FirstOrDefault(a => a.AccountingAPInvoicePayableId == AccountingAPInvoicePayable.AccountingAPInvoicePayableId);
                        if (AccountingAPInvoicePayableModel != null)
                        {
                            if (AccountingAPInvoicePayable.HardDelete)
                            {
                                destObj.AccountingAPInvoicePayables.Remove(AccountingAPInvoicePayableModel);
                            }
                            else
                            {
                                AccountingAPInvoicePayableModel = AccountingAPInvoicePayable.MapToDomainModel<Domain.AccountingAPInvoicePayable>(AccountingAPInvoicePayableModel) as Domain.AccountingAPInvoicePayable;
                            }
                        }
                    }
                }
            }
        }
        public override TDomain MapToDomainModel<TDomain>(TDomain domainModel)
        {
            Domain.AccountsPayableDetail AccountsPayableDetailModel = domainModel as Domain.AccountsPayableDetail;
            Domain.AccountsPayableDetail destObj = MapToDomainModelWithoutCollections(AccountsPayableDetailModel);
            MapAccountsPayableTraces(destObj);
            MapAccountingAPInvoicePayables(destObj);
            return destObj as TDomain;
        }
    }
}

