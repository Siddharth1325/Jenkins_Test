using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using CommonLib.DataObjects;
using CommonLib.ModelAttrib;
using Domain = DomainModel.Accounting;
namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{ 
[System.CodeDom.Compiler.GeneratedCode("EF", "6.1.0")]
	public partial class AccountingARInvoiceReceivable : BaseDto
	{ 
		public Domain.AccountingARInvoiceReceivable MapToDomainModelWithoutCollections(Domain.AccountingARInvoiceReceivable AccountingARInvoiceReceivable)
		{ 
			AccountingARInvoiceReceivable.ApplicationId = this.ApplicationId;
			AccountingARInvoiceReceivable.AccountsReceivableInvoiceId = this.AccountsReceivableInvoiceId;
			AccountingARInvoiceReceivable.AccountsReceivableId = this.AccountsReceivableId;
			AccountingARInvoiceReceivable.CreatedById = this.CreatedById;
			if(this.CreatedDate!=null)
			{
				if(this.CreatedDate.Kind == DateTimeKind.Utc)
					AccountingARInvoiceReceivable.CreatedDate = this.CreatedDate;
				else if(this.CreatedDate.Kind == DateTimeKind.Local)
					AccountingARInvoiceReceivable.CreatedDate = TimeZoneInfo.ConvertTimeToUtc(this.CreatedDate);
				else
					AccountingARInvoiceReceivable.CreatedDate = TimeZoneInfo.ConvertTimeToUtc(this.CreatedDate, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
			}
			else
			{
				AccountingARInvoiceReceivable.CreatedDate = this.CreatedDate;
			}
			AccountingARInvoiceReceivable.LastUpdatedById = this.LastUpdatedById;
			if(this.LastUpdatedDate.HasValue)
			{
				if(this.LastUpdatedDate.Value.Kind == DateTimeKind.Utc)
					AccountingARInvoiceReceivable.LastUpdatedDate = this.LastUpdatedDate;
				else if(this.LastUpdatedDate.Value.Kind == DateTimeKind.Local)
					AccountingARInvoiceReceivable.LastUpdatedDate = TimeZoneInfo.ConvertTimeToUtc(this.LastUpdatedDate.Value);
				else
					AccountingARInvoiceReceivable.LastUpdatedDate = TimeZoneInfo.ConvertTimeToUtc(this.LastUpdatedDate.Value, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
			}
			else
			{
				AccountingARInvoiceReceivable.LastUpdatedDate = this.LastUpdatedDate;
			}
            AccountingARInvoiceReceivable.Version = string.IsNullOrEmpty(this.Version) ? null: Convert.FromBase64String(this.Version);
			if (this.AccountsReceivableInvoice != null)
			{ 
				AccountingARInvoiceReceivable.AccountsReceivableInvoice = new Domain.AccountsReceivableInvoice();
				AccountingARInvoiceReceivable.AccountsReceivableInvoice = this.AccountsReceivableInvoice.MapToDomainModelWithoutCollections(AccountingARInvoiceReceivable.AccountsReceivableInvoice);
			} 
			if (this.AccountsReceivableDetail != null)
			{ 
				AccountingARInvoiceReceivable.AccountsReceivableDetail = new Domain.AccountsReceivableDetail();
				AccountingARInvoiceReceivable.AccountsReceivableDetail = this.AccountsReceivableDetail.MapToDomainModelWithoutCollections(AccountingARInvoiceReceivable.AccountsReceivableDetail);
			} 
			AccountingARInvoiceReceivable.AccountingARInvoiceReceivableId = this.AccountingARInvoiceReceivableId;
			return AccountingARInvoiceReceivable;
		} 
		public void MapToDtoWithoutCollections(Domain.AccountingARInvoiceReceivable AccountingARInvoiceReceivable)
		{ 
			this.ApplicationId = AccountingARInvoiceReceivable.ApplicationId;
			this.AccountsReceivableInvoiceId = AccountingARInvoiceReceivable.AccountsReceivableInvoiceId;
			this.AccountsReceivableId = AccountingARInvoiceReceivable.AccountsReceivableId;
			this.CreatedById = AccountingARInvoiceReceivable.CreatedById;
			if(AccountingARInvoiceReceivable.CreatedDate!=null)
			{
				if(AccountingARInvoiceReceivable.CreatedDate.Kind == DateTimeKind.Utc || AccountingARInvoiceReceivable.CreatedDate.Kind == DateTimeKind.Unspecified)
					this.CreatedDate = TimeZoneInfo.ConvertTimeFromUtc(AccountingARInvoiceReceivable.CreatedDate, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
				else
					this.CreatedDate = TimeZoneInfo.ConvertTime(AccountingARInvoiceReceivable.CreatedDate, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
			}
			else
			{
				this.CreatedDate = AccountingARInvoiceReceivable.CreatedDate;
			}
			this.LastUpdatedById = AccountingARInvoiceReceivable.LastUpdatedById;
			if(AccountingARInvoiceReceivable.LastUpdatedDate.HasValue)
			{
				if(AccountingARInvoiceReceivable.LastUpdatedDate.Value.Kind == DateTimeKind.Utc || AccountingARInvoiceReceivable.LastUpdatedDate.Value.Kind == DateTimeKind.Unspecified)
					this.LastUpdatedDate = TimeZoneInfo.ConvertTimeFromUtc(AccountingARInvoiceReceivable.LastUpdatedDate.Value, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
				else
					this.LastUpdatedDate = TimeZoneInfo.ConvertTime(AccountingARInvoiceReceivable.LastUpdatedDate.Value, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
			}
			else
			{
				this.LastUpdatedDate = AccountingARInvoiceReceivable.LastUpdatedDate;
			}
            this.Version = AccountingARInvoiceReceivable.Version == null ? null:Convert.ToBase64String(AccountingARInvoiceReceivable.Version);
			if (AccountingARInvoiceReceivable.AccountsReceivableInvoice != null)
			{ 
				this.AccountsReceivableInvoice = new AccountsReceivableInvoice();
				this.AccountsReceivableInvoice.MapToDtoWithoutCollections(AccountingARInvoiceReceivable.AccountsReceivableInvoice);
			} 
			if (AccountingARInvoiceReceivable.AccountsReceivableDetail != null)
			{ 
				this.AccountsReceivableDetail = new AccountsReceivableDetail();
				this.AccountsReceivableDetail.MapToDtoWithoutCollections(AccountingARInvoiceReceivable.AccountsReceivableDetail);
			} 
			this.AccountingARInvoiceReceivableId = AccountingARInvoiceReceivable.AccountingARInvoiceReceivableId;
		} 
		public override TDto MapFromDomainModel<TDomain, TDto>(TDomain domainModel)
		{ 
			Domain.AccountingARInvoiceReceivable AccountingARInvoiceReceivableModel = domainModel as Domain.AccountingARInvoiceReceivable;
			if(AccountingARInvoiceReceivableModel != null)
			{ 
				MapToDtoWithoutCollections(AccountingARInvoiceReceivableModel);
			} 
				return this as TDto;
		} 
		public override TDomain MapToDomainModel<TDomain>(TDomain domainModel)
		{ 
			Domain.AccountingARInvoiceReceivable AccountingARInvoiceReceivableModel = domainModel as Domain.AccountingARInvoiceReceivable;
			Domain.AccountingARInvoiceReceivable destObj = MapToDomainModelWithoutCollections(AccountingARInvoiceReceivableModel);
		    return destObj as TDomain;
		} 
	} 
} 

