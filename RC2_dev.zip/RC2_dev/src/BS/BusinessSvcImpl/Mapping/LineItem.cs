using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using CommonLib.DataObjects;
using CommonLib.ModelAttrib;
using Domain = DomainModel.Accounting;
namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{ 
[System.CodeDom.Compiler.GeneratedCode("EF", "6.1.0")]
	public partial class LineItem : BaseDto
	{ 
		public Domain.LineItem MapToDomainModelWithoutCollections(Domain.LineItem LineItem)
		{ 
			LineItem.ApplicationId = this.ApplicationId;
			LineItem.LineItemCode = this.LineItemCode;
			LineItem.LineItemName = this.LineItemName;
			LineItem.LineItemDesc = this.LineItemDesc;
			LineItem.CreatedById = this.CreatedById;
			LineItem.CreatedDate = this.CreatedDate;
			LineItem.LastUpdatedById = this.LastUpdatedById;
			LineItem.LastUpdatedDate = this.LastUpdatedDate;
            LineItem.Version = string.IsNullOrEmpty(this.Version) ? null: Convert.FromBase64String(this.Version);
			LineItem.LineItemId = this.LineItemId;
			return LineItem;
		} 
		public void MapToDtoWithoutCollections(Domain.LineItem LineItem)
		{ 
			this.ApplicationId = LineItem.ApplicationId;
			this.LineItemCode = LineItem.LineItemCode;
			this.LineItemName = LineItem.LineItemName;
			this.LineItemDesc = LineItem.LineItemDesc;
			this.CreatedById = LineItem.CreatedById;
			this.CreatedDate = LineItem.CreatedDate;
			this.LastUpdatedById = LineItem.LastUpdatedById;
			this.LastUpdatedDate = LineItem.LastUpdatedDate;
            this.Version = LineItem.Version == null ? null:Convert.ToBase64String(LineItem.Version);
			this.LineItemId = LineItem.LineItemId;
		} 
		public override TDto MapFromDomainModel<TDomain, TDto>(TDomain domainModel)
		{ 
			Domain.LineItem LineItemModel = domainModel as Domain.LineItem;
			if(LineItemModel != null)
			{ 
				MapToDtoWithoutCollections(LineItemModel);
			} 
				return this as TDto;
		} 
		public override TDomain MapToDomainModel<TDomain>(TDomain domainModel)
		{ 
			Domain.LineItem LineItemModel = domainModel as Domain.LineItem;
			Domain.LineItem destObj = MapToDomainModelWithoutCollections(LineItemModel);
		    return destObj as TDomain;
		} 
	} 
} 

