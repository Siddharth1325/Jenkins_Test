using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using CommonLib.DataObjects;
using CommonLib.ModelAttrib;
using Domain = DomainModel.Accounting;
namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{ 
[System.CodeDom.Compiler.GeneratedCode("EF", "6.1.0")]
	public partial class AccountsReceivableInvoice : BaseDto
	{ 
		public Domain.AccountsReceivableInvoice MapToDomainModelWithoutCollections(Domain.AccountsReceivableInvoice AccountsReceivableInvoice)
		{ 
			AccountsReceivableInvoice.ApplicationId = this.ApplicationId;
			AccountsReceivableInvoice.MasterClientProfileId = this.MasterClientProfileId;
			AccountsReceivableInvoice.ProductCategory = this.ProductCategory;
            AccountsReceivableInvoice.ProductCategoryGroup = string.IsNullOrEmpty(this.ProductCategory) ? null: GroupCodeEnum.LOB.ToString();
			AccountsReceivableInvoice.InvoiceType = this.InvoiceType;
            AccountsReceivableInvoice.InvoiceTypeGroup = string.IsNullOrEmpty(this.InvoiceType) ? null: GroupCodeEnum.INV.ToString();
			AccountsReceivableInvoice.BillFreqType = this.BillFreqType;
            AccountsReceivableInvoice.BillFreqGroup = string.IsNullOrEmpty(this.BillFreqType) ? null: GroupCodeEnum.BILLF.ToString();
			AccountsReceivableInvoice.DepartmentCode = this.DepartmentCode;
			AccountsReceivableInvoice.InvoiceNumber = this.InvoiceNumber;
			AccountsReceivableInvoice.InvoiceDate = this.InvoiceDate;
			AccountsReceivableInvoice.InvoiceAmount = this.InvoiceAmount;
			AccountsReceivableInvoice.CreatedById = this.CreatedById;
			if(this.CreatedDate!=null)
			{
				if(this.CreatedDate.Kind == DateTimeKind.Utc)
					AccountsReceivableInvoice.CreatedDate = this.CreatedDate;
				else if(this.CreatedDate.Kind == DateTimeKind.Local)
					AccountsReceivableInvoice.CreatedDate = TimeZoneInfo.ConvertTimeToUtc(this.CreatedDate);
				else
					AccountsReceivableInvoice.CreatedDate = TimeZoneInfo.ConvertTimeToUtc(this.CreatedDate, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
			}
			else
			{
				AccountsReceivableInvoice.CreatedDate = this.CreatedDate;
			}
			AccountsReceivableInvoice.LastUpdatedById = this.LastUpdatedById;
			if(this.LastUpdatedDate.HasValue)
			{
				if(this.LastUpdatedDate.Value.Kind == DateTimeKind.Utc)
					AccountsReceivableInvoice.LastUpdatedDate = this.LastUpdatedDate;
				else if(this.LastUpdatedDate.Value.Kind == DateTimeKind.Local)
					AccountsReceivableInvoice.LastUpdatedDate = TimeZoneInfo.ConvertTimeToUtc(this.LastUpdatedDate.Value);
				else
					AccountsReceivableInvoice.LastUpdatedDate = TimeZoneInfo.ConvertTimeToUtc(this.LastUpdatedDate.Value, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
			}
			else
			{
				AccountsReceivableInvoice.LastUpdatedDate = this.LastUpdatedDate;
			}
            AccountsReceivableInvoice.Version = string.IsNullOrEmpty(this.Version) ? null: Convert.FromBase64String(this.Version);
			AccountsReceivableInvoice.AccountsReceivableInvoiceId = this.AccountsReceivableInvoiceId;
			return AccountsReceivableInvoice;
		} 
		public void MapToDtoWithoutCollections(Domain.AccountsReceivableInvoice AccountsReceivableInvoice)
		{ 
			this.ApplicationId = AccountsReceivableInvoice.ApplicationId;
			this.MasterClientProfileId = AccountsReceivableInvoice.MasterClientProfileId;
			this.ProductCategory = AccountsReceivableInvoice.ProductCategory;
			this.InvoiceType = AccountsReceivableInvoice.InvoiceType;
			this.BillFreqType = AccountsReceivableInvoice.BillFreqType;
			this.DepartmentCode = AccountsReceivableInvoice.DepartmentCode;
			this.InvoiceNumber = AccountsReceivableInvoice.InvoiceNumber;
			this.InvoiceDate = AccountsReceivableInvoice.InvoiceDate;
			this.InvoiceAmount = AccountsReceivableInvoice.InvoiceAmount;
			this.CreatedById = AccountsReceivableInvoice.CreatedById;
			if(AccountsReceivableInvoice.CreatedDate!=null)
			{
				if(AccountsReceivableInvoice.CreatedDate.Kind == DateTimeKind.Utc || AccountsReceivableInvoice.CreatedDate.Kind == DateTimeKind.Unspecified)
					this.CreatedDate = TimeZoneInfo.ConvertTimeFromUtc(AccountsReceivableInvoice.CreatedDate, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
				else
					this.CreatedDate = TimeZoneInfo.ConvertTime(AccountsReceivableInvoice.CreatedDate, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
			}
			else
			{
				this.CreatedDate = AccountsReceivableInvoice.CreatedDate;
			}
			this.LastUpdatedById = AccountsReceivableInvoice.LastUpdatedById;
			if(AccountsReceivableInvoice.LastUpdatedDate.HasValue)
			{
				if(AccountsReceivableInvoice.LastUpdatedDate.Value.Kind == DateTimeKind.Utc || AccountsReceivableInvoice.LastUpdatedDate.Value.Kind == DateTimeKind.Unspecified)
					this.LastUpdatedDate = TimeZoneInfo.ConvertTimeFromUtc(AccountsReceivableInvoice.LastUpdatedDate.Value, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
				else
					this.LastUpdatedDate = TimeZoneInfo.ConvertTime(AccountsReceivableInvoice.LastUpdatedDate.Value, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
			}
			else
			{
				this.LastUpdatedDate = AccountsReceivableInvoice.LastUpdatedDate;
			}
            this.Version = AccountsReceivableInvoice.Version == null ? null:Convert.ToBase64String(AccountsReceivableInvoice.Version);
			this.AccountsReceivableInvoiceId = AccountsReceivableInvoice.AccountsReceivableInvoiceId;
		} 
		public override TDto MapFromDomainModel<TDomain, TDto>(TDomain domainModel)
		{ 
			Domain.AccountsReceivableInvoice AccountsReceivableInvoiceModel = domainModel as Domain.AccountsReceivableInvoice;
			if(AccountsReceivableInvoiceModel != null)
			{ 
				MapToDtoWithoutCollections(AccountsReceivableInvoiceModel);
				foreach(Domain.AccountsReceivableAdjustment AccountsReceivableAdjustment in AccountsReceivableInvoiceModel.AccountsReceivableAdjustments)
				{ 
					  AccountsReceivableAdjustment AccountsReceivableAdjustmentDto = new AccountsReceivableAdjustment();
					  AccountsReceivableAdjustmentDto = AccountsReceivableAdjustmentDto.MapFromDomainModel<Domain.AccountsReceivableAdjustment, AccountsReceivableAdjustment>(AccountsReceivableAdjustment);
					  this.AccountsReceivableAdjustments.Add(AccountsReceivableAdjustmentDto);
				} 
			} 
				return this as TDto;
		} 
		private void MapAccountsReceivableAdjustments(Domain.AccountsReceivableInvoice destObj)
		{ 
			if (AccountsReceivableAdjustments != null)
			{ 
				foreach(AccountsReceivableAdjustment AccountsReceivableAdjustment in AccountsReceivableAdjustments)
				{ 
					Domain.AccountsReceivableAdjustment AccountsReceivableAdjustmentModel;
				   if(AccountsReceivableAdjustment.AccountsReceivableAdjustmentId == 0)
				   { 
						AccountsReceivableAdjustmentModel = new Domain.AccountsReceivableAdjustment();
						AccountsReceivableAdjustmentModel = AccountsReceivableAdjustment.MapToDomainModel<Domain.AccountsReceivableAdjustment>(AccountsReceivableAdjustmentModel) as Domain.AccountsReceivableAdjustment;
					    destObj.AccountsReceivableAdjustments.Add(AccountsReceivableAdjustmentModel);
				   } 
				   else 
				   { 
						AccountsReceivableAdjustmentModel = destObj.AccountsReceivableAdjustments.FirstOrDefault(a => a.AccountsReceivableAdjustmentId == AccountsReceivableAdjustment.AccountsReceivableAdjustmentId);
					   if (AccountsReceivableAdjustmentModel != null)
					   {
							if (AccountsReceivableAdjustment.HardDelete)
							{ 
								destObj.AccountsReceivableAdjustments.Remove(AccountsReceivableAdjustmentModel);
							} 
							else 
							{ 
								AccountsReceivableAdjustmentModel = AccountsReceivableAdjustment.MapToDomainModel<Domain.AccountsReceivableAdjustment>(AccountsReceivableAdjustmentModel) as Domain.AccountsReceivableAdjustment;
							} 
					   } 
					} 
				} 
			} 
		} 
		public override TDomain MapToDomainModel<TDomain>(TDomain domainModel)
		{ 
			Domain.AccountsReceivableInvoice AccountsReceivableInvoiceModel = domainModel as Domain.AccountsReceivableInvoice;
			Domain.AccountsReceivableInvoice destObj = MapToDomainModelWithoutCollections(AccountsReceivableInvoiceModel);
		    MapAccountsReceivableAdjustments(destObj);
		    return destObj as TDomain;
		} 
	} 
} 

