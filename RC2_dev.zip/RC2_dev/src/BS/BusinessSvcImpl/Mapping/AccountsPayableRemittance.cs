using System;
using CommonLib.DataObjects;
using Domain = DomainModel.Accounting;
namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{
    [System.CodeDom.Compiler.GeneratedCode("EF", "6.1.0")]
	public partial class AccountsPayableRemittance : BaseDto
	{ 
		public Domain.AccountsPayableRemittance MapToDomainModelWithoutCollections(Domain.AccountsPayableRemittance AccountsPayableRemittance)
		{ 
			AccountsPayableRemittance.ApplicationId = this.ApplicationId;
			AccountsPayableRemittance.AccountsPayableInvoiceId = this.AccountsPayableInvoiceId;
			AccountsPayableRemittance.InvoiceNumber = this.InvoiceNumber;
			AccountsPayableRemittance.InvoiceDate = this.InvoiceDate;
			AccountsPayableRemittance.InvoiceTypeGroup = this.InvoiceTypeGroup;
			AccountsPayableRemittance.InvoiceType = this.InvoiceType;
			AccountsPayableRemittance.InvoiceAmount = this.InvoiceAmount;
			AccountsPayableRemittance.CheckNumber = this.CheckNumber;
			AccountsPayableRemittance.CheckDate = this.CheckDate;
			AccountsPayableRemittance.CheckTypeGroup = this.CheckTypeGroup;
			AccountsPayableRemittance.CheckType = this.CheckType;
			AccountsPayableRemittance.PaidAmount = this.PaidAmount;
			AccountsPayableRemittance.PayeeCode = this.PayeeCode;
			AccountsPayableRemittance.Comments = this.Comments;
			AccountsPayableRemittance.CreatedById = this.CreatedById;
			if(this.CreatedDate!=null)
			{
				if(this.CreatedDate.Kind == DateTimeKind.Utc)
					AccountsPayableRemittance.CreatedDate = this.CreatedDate;
				else if(this.CreatedDate.Kind == DateTimeKind.Local)
					AccountsPayableRemittance.CreatedDate = TimeZoneInfo.ConvertTimeToUtc(this.CreatedDate);
				else
					AccountsPayableRemittance.CreatedDate = TimeZoneInfo.ConvertTimeToUtc(this.CreatedDate, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
			}
			else
			{
				AccountsPayableRemittance.CreatedDate = this.CreatedDate;
			}
			AccountsPayableRemittance.LastUpdatedById = this.LastUpdatedById;
			if(this.LastUpdatedDate.HasValue)
			{
				if(this.LastUpdatedDate.Value.Kind == DateTimeKind.Utc)
					AccountsPayableRemittance.LastUpdatedDate = this.LastUpdatedDate;
				else if(this.LastUpdatedDate.Value.Kind == DateTimeKind.Local)
					AccountsPayableRemittance.LastUpdatedDate = TimeZoneInfo.ConvertTimeToUtc(this.LastUpdatedDate.Value);
				else
					AccountsPayableRemittance.LastUpdatedDate = TimeZoneInfo.ConvertTimeToUtc(this.LastUpdatedDate.Value, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
			}
			else
			{
				AccountsPayableRemittance.LastUpdatedDate = this.LastUpdatedDate;
			}
            AccountsPayableRemittance.Version = string.IsNullOrEmpty(this.Version) ? null: Convert.FromBase64String(this.Version);
			AccountsPayableRemittance.AccountsPayableRemittanceId = this.AccountsPayableRemittanceId;
			return AccountsPayableRemittance;
		} 
		public void MapToDtoWithoutCollections(Domain.AccountsPayableRemittance AccountsPayableRemittance)
		{ 
			this.ApplicationId = AccountsPayableRemittance.ApplicationId;
			this.AccountsPayableInvoiceId = AccountsPayableRemittance.AccountsPayableInvoiceId;
			this.InvoiceNumber = AccountsPayableRemittance.InvoiceNumber;
			this.InvoiceDate = AccountsPayableRemittance.InvoiceDate;
			this.InvoiceTypeGroup = AccountsPayableRemittance.InvoiceTypeGroup;
			this.InvoiceType = AccountsPayableRemittance.InvoiceType;
			this.InvoiceAmount = AccountsPayableRemittance.InvoiceAmount;
			this.CheckNumber = AccountsPayableRemittance.CheckNumber;
			this.CheckDate = AccountsPayableRemittance.CheckDate;
			this.CheckTypeGroup = AccountsPayableRemittance.CheckTypeGroup;
			this.CheckType = AccountsPayableRemittance.CheckType;
			this.PaidAmount = AccountsPayableRemittance.PaidAmount;
			this.PayeeCode = AccountsPayableRemittance.PayeeCode;
			this.Comments = AccountsPayableRemittance.Comments;
			this.CreatedById = AccountsPayableRemittance.CreatedById;
			if(AccountsPayableRemittance.CreatedDate!=null)
			{
				if(AccountsPayableRemittance.CreatedDate.Kind == DateTimeKind.Utc || AccountsPayableRemittance.CreatedDate.Kind == DateTimeKind.Unspecified)
					this.CreatedDate = TimeZoneInfo.ConvertTimeFromUtc(AccountsPayableRemittance.CreatedDate, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
				else
					this.CreatedDate = TimeZoneInfo.ConvertTime(AccountsPayableRemittance.CreatedDate, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
			}
			else
			{
				this.CreatedDate = AccountsPayableRemittance.CreatedDate;
			}
			this.LastUpdatedById = AccountsPayableRemittance.LastUpdatedById;
			if(AccountsPayableRemittance.LastUpdatedDate.HasValue)
			{
				if(AccountsPayableRemittance.LastUpdatedDate.Value.Kind == DateTimeKind.Utc || AccountsPayableRemittance.LastUpdatedDate.Value.Kind == DateTimeKind.Unspecified)
					this.LastUpdatedDate = TimeZoneInfo.ConvertTimeFromUtc(AccountsPayableRemittance.LastUpdatedDate.Value, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
				else
					this.LastUpdatedDate = TimeZoneInfo.ConvertTime(AccountsPayableRemittance.LastUpdatedDate.Value, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
			}
			else
			{
				this.LastUpdatedDate = AccountsPayableRemittance.LastUpdatedDate;
			}
            this.Version = AccountsPayableRemittance.Version == null ? null:Convert.ToBase64String(AccountsPayableRemittance.Version);
			this.AccountsPayableRemittanceId = AccountsPayableRemittance.AccountsPayableRemittanceId;
		} 
		public override TDto MapFromDomainModel<TDomain, TDto>(TDomain domainModel)
		{ 
			Domain.AccountsPayableRemittance AccountsPayableRemittanceModel = domainModel as Domain.AccountsPayableRemittance;
			if(AccountsPayableRemittanceModel != null)
			{ 
				MapToDtoWithoutCollections(AccountsPayableRemittanceModel);
			} 
				return this as TDto;
		} 
		public override TDomain MapToDomainModel<TDomain>(TDomain domainModel)
		{ 
			Domain.AccountsPayableRemittance AccountsPayableRemittanceModel = domainModel as Domain.AccountsPayableRemittance;
			Domain.AccountsPayableRemittance destObj = MapToDomainModelWithoutCollections(AccountsPayableRemittanceModel);
		    return destObj as TDomain;
		} 
	} 
} 

