using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using CommonLib.DataObjects;
using CommonLib.ModelAttrib;
using Domain = DomainModel.Accounting;
namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{ 
[System.CodeDom.Compiler.GeneratedCode("EF", "6.1.0")]
	public partial class AccountingWorkOrder : BaseDto
	{ 
		public Domain.AccountingWorkOrder MapToDomainModelWithoutCollections(Domain.AccountingWorkOrder AccountingWorkOrder)
		{ 
			if (this.AccountingWorkOrderAPInvoice != null)
			{ 
				AccountingWorkOrder.AccountingWorkOrderAPInvoice = new Domain.AccountingWorkOrderAPInvoice();
				AccountingWorkOrder.AccountingWorkOrderAPInvoice = this.AccountingWorkOrderAPInvoice.MapToDomainModelWithoutCollections(AccountingWorkOrder.AccountingWorkOrderAPInvoice);
			} 
			if (this.AccountingWorkOrderARInvoice != null)
			{ 
				AccountingWorkOrder.AccountingWorkOrderARInvoice = new Domain.AccountingWorkOrderARInvoice();
				AccountingWorkOrder.AccountingWorkOrderARInvoice = this.AccountingWorkOrderARInvoice.MapToDomainModelWithoutCollections(AccountingWorkOrder.AccountingWorkOrderARInvoice);
			} 
			AccountingWorkOrder.WorkOrderId = this.WorkOrderId;
			return AccountingWorkOrder;
		} 
		public void MapToDtoWithoutCollections(Domain.AccountingWorkOrder AccountingWorkOrder)
		{ 
			if (AccountingWorkOrder.AccountingWorkOrderAPInvoice != null)
			{ 
				this.AccountingWorkOrderAPInvoice = new AccountingWorkOrderAPInvoice();
				this.AccountingWorkOrderAPInvoice.MapToDtoWithoutCollections(AccountingWorkOrder.AccountingWorkOrderAPInvoice);
			} 
			if (AccountingWorkOrder.AccountingWorkOrderARInvoice != null)
			{ 
				this.AccountingWorkOrderARInvoice = new AccountingWorkOrderARInvoice();
				this.AccountingWorkOrderARInvoice.MapToDtoWithoutCollections(AccountingWorkOrder.AccountingWorkOrderARInvoice);
			} 
			this.WorkOrderId = AccountingWorkOrder.WorkOrderId;
		} 
		public override TDto MapFromDomainModel<TDomain, TDto>(TDomain domainModel)
		{ 
			Domain.AccountingWorkOrder AccountingWorkOrderModel = domainModel as Domain.AccountingWorkOrder;
			if(AccountingWorkOrderModel != null)
			{ 
				MapToDtoWithoutCollections(AccountingWorkOrderModel);
			} 
				return this as TDto;
		} 
		public override TDomain MapToDomainModel<TDomain>(TDomain domainModel)
		{ 
			Domain.AccountingWorkOrder AccountingWorkOrderModel = domainModel as Domain.AccountingWorkOrder;
			Domain.AccountingWorkOrder destObj = MapToDomainModelWithoutCollections(AccountingWorkOrderModel);
		    return destObj as TDomain;
		} 
	} 
} 

