using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using CommonLib.DataObjects;
using CommonLib.ModelAttrib;
using Domain = DomainModel.Accounting;
namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{
    [System.CodeDom.Compiler.GeneratedCode("EF", "6.1.0")]
    public partial class AccountingDispute : BaseDto
    {
        public Domain.AccountingDispute MapToDomainModelWithoutCollections(Domain.AccountingDispute AccountingDispute)
        {
            AccountingDispute.BulkID = this.BulkID;
            AccountingDispute.AssignToFirstName = this.AssignToFirstName;
            AccountingDispute.AssignToLastName = this.AssignToLastName;
            AccountingDispute.DisputeStatusGroup = this.DisputeStatusGroup;
            AccountingDispute.DisputeStatusType = this.DisputeStatusType;
            AccountingDispute.DisputeTypeGroup = string.IsNullOrEmpty(this.DisputeType) ? null : GroupCodeEnum.DISTYP.ToString();
            AccountingDispute.DisputeType = this.DisputeType;
            AccountingDispute.DisComments = this.DisComments;
            AccountingDispute.SLFSResponseToClient = this.SLFSResponseToClient;
            AccountingDispute.DisInternalComments = this.DisInternalComments;
            AccountingDispute.DisResolutionGroup = string.IsNullOrEmpty(this.DisResolutionType) ? null : GroupCodeEnum.DISRES.ToString();
            AccountingDispute.DisResolutionType = this.DisResolutionType;
            AccountingDispute.DisResDepartGroup = string.IsNullOrEmpty(this.DisResDepartType) ? null : GroupCodeEnum.DISRESD.ToString();
            AccountingDispute.DisResDepartType = this.DisResDepartType;
            AccountingDispute.DisErrorGroup = string.IsNullOrEmpty(this.DisErrorType) ? null : GroupCodeEnum.DISERR.ToString();
            AccountingDispute.DisErrorType = this.DisErrorType;
            AccountingDispute.DisputeErrorCausedById = this.DisputeErrorCausedById;
            AccountingDispute.CreditClientAmount = this.CreditClientAmount;
            AccountingDispute.DebitClientAmount = this.DebitClientAmount;
            AccountingDispute.RebillNumber = this.RebillNumber;
            AccountingDispute.DisputeAmount = this.DisputeAmount;
            AccountingDispute.ClientId = this.ClientId;
            AccountingDispute.LoanNumber = this.LoanNumber;
            AccountingDispute.VendorId = this.VendorId;
            AccountingDispute.VendorWorkOrderId = this.VendorWorkOrderId;
            AccountingDispute.InspWorkOrderId = this.InspWorkOrderId;
            AccountingDispute.InvoiceNumber = this.InvoiceNumber;
            AccountingDispute.InvoiceDate = this.InvoiceDate;
            AccountingDispute.InvoiceAmount = this.InvoiceAmount;
            AccountingDispute.ApprovedById = this.ApprovedById;
            AccountingDispute.HardLoss = this.HardLoss;
            AccountingDispute.DisputeDate = this.DisputeDate;
            AccountingDispute.DisputeDueDate = this.DisputeDueDate;
            AccountingDispute.WorkOrderCompleteDate = this.WorkOrderCompleteDate;
            AccountingDispute.DocumentId = this.DocumentId;
            AccountingDispute.CreatedById = this.CreatedById;
            AccountingDispute.CreatedDate = this.CreatedDate;
            AccountingDispute.LastUpdatedById = this.LastUpdatedById;
            AccountingDispute.LastUpdatedDate = this.LastUpdatedDate;
            AccountingDispute.Version = string.IsNullOrEmpty(this.Version) ? null : Convert.FromBase64String(this.Version);
            AccountingDispute.AccountingDisputeId = this.AccountingDisputeId;
            return AccountingDispute;
        }
        public void MapToDtoWithoutCollections(Domain.AccountingDispute AccountingDispute)
        {
            this.BulkID = AccountingDispute.BulkID;
            this.AssignToFirstName = AccountingDispute.AssignToFirstName;
            this.AssignToLastName = AccountingDispute.AssignToLastName;
            this.DisputeStatusGroup = AccountingDispute.DisputeStatusGroup;
            this.DisputeStatusType = AccountingDispute.DisputeStatusType;
            this.DisputeType = AccountingDispute.DisputeType;
            this.DisComments = AccountingDispute.DisComments;
            this.SLFSResponseToClient = AccountingDispute.SLFSResponseToClient;
            this.DisInternalComments = AccountingDispute.DisInternalComments;
            this.DisResolutionType = AccountingDispute.DisResolutionType;
            this.DisResDepartType = AccountingDispute.DisResDepartType;
            this.DisErrorType = AccountingDispute.DisErrorType;
            this.DisputeErrorCausedById = AccountingDispute.DisputeErrorCausedById;
            this.CreditClientAmount = AccountingDispute.CreditClientAmount;
            this.DebitClientAmount = AccountingDispute.DebitClientAmount;
            this.RebillNumber = AccountingDispute.RebillNumber;
            this.DisputeAmount = AccountingDispute.DisputeAmount;
            this.HardLoss = AccountingDispute.HardLoss;
            this.ApprovedById = AccountingDispute.ApprovedById;
            this.ClientId = AccountingDispute.ClientId;
            this.LoanNumber = AccountingDispute.LoanNumber;
            this.VendorId = AccountingDispute.VendorId;
            this.VendorWorkOrderId = AccountingDispute.VendorWorkOrderId;
            this.InspWorkOrderId = AccountingDispute.InspWorkOrderId;
            this.InvoiceNumber = AccountingDispute.InvoiceNumber;
            this.InvoiceDate = AccountingDispute.InvoiceDate;
            this.InvoiceAmount = AccountingDispute.InvoiceAmount;
            this.DisputeDate = AccountingDispute.DisputeDate;
            this.DisputeDueDate = AccountingDispute.DisputeDueDate;
            this.WorkOrderCompleteDate = AccountingDispute.WorkOrderCompleteDate;
            this.DocumentId = AccountingDispute.DocumentId;
            this.CreatedById = AccountingDispute.CreatedById;
            this.CreatedDate = AccountingDispute.CreatedDate;
            this.LastUpdatedById = AccountingDispute.LastUpdatedById;
            this.LastUpdatedDate = AccountingDispute.LastUpdatedDate;
            this.Version = AccountingDispute.Version == null ? null : Convert.ToBase64String(AccountingDispute.Version);
            this.AccountingDisputeId = AccountingDispute.AccountingDisputeId;
        }
        public override TDto MapFromDomainModel<TDomain, TDto>(TDomain domainModel)
        {
            Domain.AccountingDispute AccountingDisputeModel = domainModel as Domain.AccountingDispute;
            if (AccountingDisputeModel != null)
            {
                MapToDtoWithoutCollections(AccountingDisputeModel);
                foreach (Domain.DisputeDocument DisputeDocument in AccountingDisputeModel.disputeDocuments)
                {
                    DisputeDocument DisputeDocumentDto = new DisputeDocument();
                    DisputeDocumentDto = DisputeDocumentDto.MapFromDomainModel<Domain.DisputeDocument, DisputeDocument>(DisputeDocument);
                    this.disputeDocuments.Add(DisputeDocumentDto);
                }
                foreach (Domain.DisputeFollowup DisputeFollowup in AccountingDisputeModel.disputeFollowups)
                {
                    DisputeFollowup DisputeFollowupDto = new DisputeFollowup();
                    DisputeFollowupDto = DisputeFollowupDto.MapFromDomainModel<Domain.DisputeFollowup, DisputeFollowup>(DisputeFollowup);
                    this.disputeFollowups.Add(DisputeFollowupDto);
                }
                foreach (Domain.VendorDisputeComment VendorDisputeComment in AccountingDisputeModel.VendorDisputeComments)
                {
                    VendorDisputeComment VendorDisputeCommentDto = new VendorDisputeComment();
                    VendorDisputeCommentDto = VendorDisputeCommentDto.MapFromDomainModel<Domain.VendorDisputeComment, VendorDisputeComment>(VendorDisputeComment);
                    this.VendorDisputeComments.Add(VendorDisputeCommentDto);
                }
            }
            return this as TDto;
        }
        private void MapdisputeDocuments(Domain.AccountingDispute destObj)
        {
            if (disputeDocuments != null)
            {
                foreach (DisputeDocument DisputeDocument in disputeDocuments)
                {
                    Domain.DisputeDocument DisputeDocumentModel;
                    if (DisputeDocument.DisputeDocumentId == 0)
                    {
                        DisputeDocumentModel = new Domain.DisputeDocument();
                        DisputeDocumentModel = DisputeDocument.MapToDomainModel<Domain.DisputeDocument>(DisputeDocumentModel) as Domain.DisputeDocument;
                        destObj.disputeDocuments.Add(DisputeDocumentModel);
                    }
                    else
                    {
                        DisputeDocumentModel = destObj.disputeDocuments.FirstOrDefault(a => a.DisputeDocumentId == DisputeDocument.DisputeDocumentId);
                        if (DisputeDocumentModel != null)
                        {
                            if (DisputeDocument.HardDelete)
                            {
                                destObj.disputeDocuments.Remove(DisputeDocumentModel);
                            }
                            else
                            {
                                DisputeDocumentModel = DisputeDocument.MapToDomainModel<Domain.DisputeDocument>(DisputeDocumentModel) as Domain.DisputeDocument;
                            }
                        }
                    }
                }
            }
        }
        private void MapdisputeFollowups(Domain.AccountingDispute destObj)
        {
            if (disputeFollowups != null)
            {
                foreach (DisputeFollowup DisputeFollowup in disputeFollowups)
                {
                    Domain.DisputeFollowup DisputeFollowupModel;
                    if (DisputeFollowup.DisputeFollowupId == 0)
                    {
                        DisputeFollowupModel = new Domain.DisputeFollowup();
                        DisputeFollowupModel = DisputeFollowup.MapToDomainModel<Domain.DisputeFollowup>(DisputeFollowupModel) as Domain.DisputeFollowup;
                        destObj.disputeFollowups.Add(DisputeFollowupModel);
                    }
                    else
                    {
                        DisputeFollowupModel = destObj.disputeFollowups.FirstOrDefault(a => a.DisputeFollowupId == DisputeFollowup.DisputeFollowupId);
                        if (DisputeFollowupModel != null)
                        {
                            if (DisputeFollowup.HardDelete)
                            {
                                destObj.disputeFollowups.Remove(DisputeFollowupModel);
                            }
                            else
                            {
                                DisputeFollowupModel = DisputeFollowup.MapToDomainModel<Domain.DisputeFollowup>(DisputeFollowupModel) as Domain.DisputeFollowup;
                            }
                        }
                    }
                }
            }
        }
        private void MapVendorDisputeComments(Domain.AccountingDispute destObj)
        {
            if (VendorDisputeComments != null)
            {
                foreach (VendorDisputeComment VendorDisputeComment in VendorDisputeComments)
                {
                    Domain.VendorDisputeComment VendorDisputeCommentModel;
                    if (VendorDisputeComment.vendorId == 0)
                    {
                        VendorDisputeCommentModel = new Domain.VendorDisputeComment();
                        VendorDisputeCommentModel = VendorDisputeComment.MapToDomainModel<Domain.VendorDisputeComment>(VendorDisputeCommentModel) as Domain.VendorDisputeComment;
                        destObj.VendorDisputeComments.Add(VendorDisputeCommentModel);
                    }
                    else
                    {
                        VendorDisputeCommentModel = destObj.VendorDisputeComments.FirstOrDefault(a => a.vendorId == VendorDisputeComment.vendorId);
                        if (VendorDisputeCommentModel != null)
                        {
                            if (VendorDisputeComment.HardDelete)
                            {
                                destObj.VendorDisputeComments.Remove(VendorDisputeCommentModel);
                            }
                            else
                            {
                                VendorDisputeCommentModel = VendorDisputeComment.MapToDomainModel<Domain.VendorDisputeComment>(VendorDisputeCommentModel) as Domain.VendorDisputeComment;
                            }
                        }
                    }
                }
            }
        }
        public override TDomain MapToDomainModel<TDomain>(TDomain domainModel)
        {
            Domain.AccountingDispute AccountingDisputeModel = domainModel as Domain.AccountingDispute;
            Domain.AccountingDispute destObj = MapToDomainModelWithoutCollections(AccountingDisputeModel);
            MapdisputeDocuments(destObj);
            MapdisputeFollowups(destObj);
            MapVendorDisputeComments(destObj);
            return destObj as TDomain;
        }
    }
}

