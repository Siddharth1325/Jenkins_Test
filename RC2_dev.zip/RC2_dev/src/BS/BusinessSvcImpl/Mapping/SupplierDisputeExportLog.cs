using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using CommonLib.DataObjects;
using CommonLib.ModelAttrib;
using Domain = DomainModel.Accounting;
namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{ 
[System.CodeDom.Compiler.GeneratedCode("EF", "6.1.0")]
	public partial class SupplierDisputeExportLog : BaseDto
	{ 
		public Domain.SupplierDisputeExportLog MapToDomainModelWithoutCollections(Domain.SupplierDisputeExportLog SupplierDisputeExportLog)
		{ 
			SupplierDisputeExportLog.AssetShieldInspectionWO = this.AssetShieldInspectionWO;
            SupplierDisputeExportLog.PreservationVendorWO = this.AssetShieldPreservationVendorWO;
			SupplierDisputeExportLog.DisputedAmount = this.DisputedAmount;
			SupplierDisputeExportLog.DisputeReason = this.DisputeReason;
			SupplierDisputeExportLog.DisputeComments = this.DisputeComments;
            SupplierDisputeExportLog.RecordStatus = this.Result;
            SupplierDisputeExportLog.StatusMessage = this.Message;
			SupplierDisputeExportLog.FieldScapeWO = this.FieldScapeWO;
			return SupplierDisputeExportLog;
		} 
		public void MapToDtoWithoutCollections(Domain.SupplierDisputeExportLog SupplierDisputeExportLog)
		{ 
			this.AssetShieldInspectionWO = SupplierDisputeExportLog.AssetShieldInspectionWO;
            this.AssetShieldPreservationVendorWO = SupplierDisputeExportLog.PreservationVendorWO;
			this.DisputedAmount = SupplierDisputeExportLog.DisputedAmount;
			this.DisputeReason = SupplierDisputeExportLog.DisputeReason;
			this.DisputeComments = SupplierDisputeExportLog.DisputeComments;
            this.Result = SupplierDisputeExportLog.RecordStatus;
            this.Message = SupplierDisputeExportLog.StatusMessage;
			this.FieldScapeWO = SupplierDisputeExportLog.FieldScapeWO;
		} 
		public override TDto MapFromDomainModel<TDomain, TDto>(TDomain domainModel)
		{ 
			Domain.SupplierDisputeExportLog SupplierDisputeExportLogModel = domainModel as Domain.SupplierDisputeExportLog;
			if(SupplierDisputeExportLogModel != null)
			{ 
				MapToDtoWithoutCollections(SupplierDisputeExportLogModel);
			} 
				return this as TDto;
		} 
		public override TDomain MapToDomainModel<TDomain>(TDomain domainModel)
		{ 
			Domain.SupplierDisputeExportLog SupplierDisputeExportLogModel = domainModel as Domain.SupplierDisputeExportLog;
			Domain.SupplierDisputeExportLog destObj = MapToDomainModelWithoutCollections(SupplierDisputeExportLogModel);
		    return destObj as TDomain;
		} 
	} 
} 

