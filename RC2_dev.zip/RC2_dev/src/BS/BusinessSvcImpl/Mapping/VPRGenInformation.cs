using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using CommonLib.DataObjects;
using CommonLib.ModelAttrib;
using Domain = DomainModel.Accounting;
namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{ 
[System.CodeDom.Compiler.GeneratedCode("EF", "6.1.0")]
	public partial class VPRGenInformation : BaseDto
	{ 
		public Domain.VPRGenInformation MapToDomainModelWithoutCollections(Domain.VPRGenInformation VPRGenInformation)
		{ 
			VPRGenInformation.VPRGenInformationId = this.VPRGenInformationId;
			VPRGenInformation.WorkOrderId = this.WorkOrderId;
            VPRGenInformation.OrdinanceProfileId = this.OrdinanceProfileId;
            //VPRGenInformation.Municipality = this.Municipality;
            //VPRGenInformation.MunicipalityZipCode = this.MunicipalityZipCode;
			VPRGenInformation.InitialRegistrationDue = this.InitialRegistrationDue;
			VPRGenInformation.OnlineRegistration = this.OnlineRegistration;
			VPRGenInformation.OccupancyStatusGroup = this.OccupancyStatusGroup;
			VPRGenInformation.OccupancyStatusType = this.OccupancyStatusType;
            VPRGenInformation.IscreditCardPayment = this.IscreditCardPayment;
            VPRGenInformation.ConfirmationNo = this.ConfirmationNo;
            VPRGenInformation.MunicipalityAddress1 = this.MunicipalityAddress1;
            VPRGenInformation.MunicipalityAddress2 = this.MunicipalityAddress2;
            VPRGenInformation.MunicipalityCity = this.MunicipalityCity;
            VPRGenInformation.MunicipalityState = this.MunicipalityState;
            VPRGenInformation.ChargeOffDate = this.ChargeOffDate;
			VPRGenInformation.CreatedById = this.CreatedById;
			VPRGenInformation.CreatedDate = this.CreatedDate;
			VPRGenInformation.LastUpdatedById = this.LastUpdatedById;
			VPRGenInformation.LastUpdatedDate = this.LastUpdatedDate;
            VPRGenInformation.Version = string.IsNullOrEmpty(this.Version) ? null: Convert.FromBase64String(this.Version);
			return VPRGenInformation;
		} 
		public void MapToDtoWithoutCollections(Domain.VPRGenInformation VPRGenInformation)
		{ 
			this.VPRGenInformationId = VPRGenInformation.VPRGenInformationId;
			this.WorkOrderId = VPRGenInformation.WorkOrderId;
            this.OrdinanceProfileId = VPRGenInformation.OrdinanceProfileId;
            //this.Municipality = VPRGenInformation.Municipality;
            //this.MunicipalityZipCode = VPRGenInformation.MunicipalityZipCode;
			this.InitialRegistrationDue = VPRGenInformation.InitialRegistrationDue;
			this.OnlineRegistration = VPRGenInformation.OnlineRegistration;
			this.OccupancyStatusGroup = VPRGenInformation.OccupancyStatusGroup;
			this.OccupancyStatusType = VPRGenInformation.OccupancyStatusType;
            this.IscreditCardPayment = VPRGenInformation.IscreditCardPayment;
            this.ConfirmationNo = VPRGenInformation.ConfirmationNo;
            this.MunicipalityAddress1 = VPRGenInformation.MunicipalityAddress1;
            this.MunicipalityAddress2 = VPRGenInformation.MunicipalityAddress2;
            this.MunicipalityCity = VPRGenInformation.MunicipalityCity;
            this.MunicipalityState = VPRGenInformation.MunicipalityState;
            this.ChargeOffDate = VPRGenInformation.ChargeOffDate;
			this.CreatedById = VPRGenInformation.CreatedById;
			this.CreatedDate = VPRGenInformation.CreatedDate;
			this.LastUpdatedById = VPRGenInformation.LastUpdatedById;
			this.LastUpdatedDate = VPRGenInformation.LastUpdatedDate;
            this.Version = VPRGenInformation.Version == null ? null:Convert.ToBase64String(VPRGenInformation.Version);
		} 
		public override TDto MapFromDomainModel<TDomain, TDto>(TDomain domainModel)
		{ 
			Domain.VPRGenInformation VPRGenInformationModel = domainModel as Domain.VPRGenInformation;
			if(VPRGenInformationModel != null)
			{ 
				MapToDtoWithoutCollections(VPRGenInformationModel);
				foreach(Domain.PaymentDetail PaymentDetail in VPRGenInformationModel.PaymentDetails)
				{ 
					  PaymentDetail PaymentDetailDto = new PaymentDetail();
					  PaymentDetailDto = PaymentDetailDto.MapFromDomainModel<Domain.PaymentDetail, PaymentDetail>(PaymentDetail);
					  this.PaymentDetails.Add(PaymentDetailDto);
				} 
			} 
				return this as TDto;
		} 
		private void MapPaymentDetails(Domain.VPRGenInformation destObj)
		{ 
			if (PaymentDetails != null)
			{ 
				foreach(PaymentDetail PaymentDetail in PaymentDetails)
				{ 
					Domain.PaymentDetail PaymentDetailModel;
				   if(PaymentDetail.PaymentDetailsId == 0)
				   { 
						PaymentDetailModel = new Domain.PaymentDetail();
						PaymentDetailModel = PaymentDetail.MapToDomainModel<Domain.PaymentDetail>(PaymentDetailModel) as Domain.PaymentDetail;
					    destObj.PaymentDetails.Add(PaymentDetailModel);
				   } 
				   else 
				   { 
						PaymentDetailModel = destObj.PaymentDetails.FirstOrDefault(a => a.PaymentDetailsId == PaymentDetail.PaymentDetailsId);
					   if (PaymentDetailModel != null)
					   {
							if (PaymentDetail.HardDelete)
							{ 
								destObj.PaymentDetails.Remove(PaymentDetailModel);
							} 
							else 
							{ 
								PaymentDetailModel = PaymentDetail.MapToDomainModel<Domain.PaymentDetail>(PaymentDetailModel) as Domain.PaymentDetail;
							} 
					   } 
					} 
				} 
			} 
		} 
		public override TDomain MapToDomainModel<TDomain>(TDomain domainModel)
		{ 
			Domain.VPRGenInformation VPRGenInformationModel = domainModel as Domain.VPRGenInformation;
			Domain.VPRGenInformation destObj = MapToDomainModelWithoutCollections(VPRGenInformationModel);
		    MapPaymentDetails(destObj);
		    return destObj as TDomain;
		} 
	} 
} 

