﻿using System.ServiceModel;
using BusinessSvcImpl.DataObjects.DocGen;

namespace BusinessSvcImpl.SvcImpl.DocGen
{
  [ServiceContract(ConfigurationName = "DocumentService.IDocumentGeneratorService", 
                   Namespace = "http://www.bkfs.com/FS/services/IDocumentGeneratorService/1.00")]
  public interface IDocumentGeneratorService
  {
    [OperationContract]
    GenerateDocumentResponse GenerateDocument(GenerateDocumentRequest generateDocumentRequest);
    [OperationContract]
    DocumentStatusResponse IsAvaliable(IsDocumentReadyRequest request);
  }
}