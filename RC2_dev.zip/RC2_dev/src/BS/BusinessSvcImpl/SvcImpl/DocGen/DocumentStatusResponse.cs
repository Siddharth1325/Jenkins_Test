﻿using System.Runtime.Serialization;
using BusinessSvcImpl.DataObjects;

namespace BusinessSvcImpl.SvcImpl.DocGen
{
  [DataContract(Namespace = "http://www.bkfs.com/FS/DataContract/DocumentStatusResponse/1.00")]
  public class DocumentStatusResponse: GenericResponse<bool>
  {
    [DataMember] public int DocumentId { get; set; }
  }

}