using BusinessSvcImpl.DataObjects.DocGen;
using BusinessSvcImpl.SvcImpl.DocGen.Builders;
using BusinessSvcImpl.SvcImpl.DocGen.Builders.APAdjustments;
using BusinessSvcImpl.SvcImpl.DocGen.Builders.APDetail;
using BusinessSvcImpl.SvcImpl.DocGen.Builders.APInvoice;
using BusinessSvcImpl.SvcImpl.DocGen.Builders.ARAdjustments;
using BusinessSvcImpl.SvcImpl.DocGen.Builders.ARDetail;
using BusinessSvcImpl.SvcImpl.DocGen.Builders.ARInvoice;
using BusinessSvcImpl.SvcImpl.DocGen.Builders.DisputeSearch;
using BusinessSvcImpl.SvcImpl.DocGen.Builders.IClearMapping;
using BusinessSvcImpl.SvcImpl.DocGen.Builders.IMChaseMapping;
using BusinessSvcImpl.SvcImpl.DocGen.Builders.IMStandardMapping;
using BusinessSvcImpl.SvcImpl.DocGen.Builders.MaintainAdjustmentCode;
using BusinessSvcImpl.SvcImpl.DocGen.Builders.MaintainGLCode;
using BusinessSvcImpl.SvcImpl.DocGen.Builders.Order;
using BusinessSvcImpl.SvcImpl.DocGen.Builders.ReviewImportException;
using BusinessSvcImpl.SvcImpl.DocGen.Builders.VendorRemittance;
using CommonLib.Context;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.ServiceModel;
using BusinessSvcImpl.SvcImpl.DocGen.Builders.PresAdjustment;
using BusinessSvcImpl.SvcImpl.DocGen.Builders.SupplierDisputeSearch;
using BusinessSvcImpl.SvcImpl.DocGen.Builders.SupplierDisputeExportLog;
using BusinessSvcImpl.SvcImpl.DocGen.Builders.RRRInvoiceDecision;

namespace BusinessSvcImpl.SvcImpl.DocGen
{
    [ServiceBehavior(AddressFilterMode = AddressFilterMode.Any)]
    public class DocumentGeneratorService : IDocumentGeneratorService
    {
        public const string ExportTypeKey = "ExportType";

        // TODO Pass in from configuration
        public static readonly string StandardOutputPath = Path.GetTempPath();

        public DocumentGeneratorService()
        {
            _documentDirector = new DocumentBuildingDirector();

        }

        private static readonly IDictionary<string, IDocumentBuilder> DocumentBuilderConfiguration =
          new Dictionary<string, IDocumentBuilder>
      {
       {DisputeSearchBuilder.DisputeSearchValue,new DisputeSearchBuilder()},
        {ARAdjustmentsBuilder.ARAdjustmentValue, new ARAdjustmentsBuilder()} ,
        {OrderBuilder.OrderSearchValue, new OrderBuilder()} ,
        {MaintainGLCodeBuilder.AccountingGLCodeValue, new MaintainGLCodeBuilder()} ,
        {ReviewImportExceptionBuilder.ReviewImportExceptionValue, new ReviewImportExceptionBuilder()} ,
        {MaintainAdjustmentCodeBuilder.AccountingAdjustmentCodeValue, new MaintainAdjustmentCodeBuilder()} ,
        {APAdjustmentsInternalBuilder.APAdjustmentValue, new APAdjustmentsInternalBuilder()} ,
        {APAdjustmentsExternalBuilder.APAdjustmentValue, new APAdjustmentsExternalBuilder()},
        {VendorRemittanceCheckBuilder.VendorRemittanceSearchValue, new VendorRemittanceCheckBuilder()}, 
        {VendorRemittanceCheckInternalUserBuilder.VendorRemittanceInternalUserSearchValue, new VendorRemittanceCheckInternalUserBuilder()},
        {VendorRemittanceInvoiceBuilder.VendorRemittanceInvoiceSearchValue, new VendorRemittanceInvoiceBuilder()}, 
        {VendorRemittanceInvoiceInternUsersBuilder.VendorRemittanceInternUserInvoiceSearchValue, new VendorRemittanceInvoiceInternUsersBuilder()},      
        {IMChaseMappingBuilder.IMChaseMappingValue, new IMChaseMappingBuilder()},
        {IMStandardMappingBuilder.IMStandardMappingValue, new IMStandardMappingBuilder()},
        {IClearMappingBuilder.IClearMappingValue, new IClearMappingBuilder()},
        {APInvoiceBuilder.APInvoiceValue, new APInvoiceBuilder()},
        {ARInvoiceBuilder.ARInvoiceValue, new ARInvoiceBuilder()},
        {ARDetailBuilder.ARDetailValue, new ARDetailBuilder()},
        {APDetailBuilder.APDetailValue, new APDetailBuilder()},
        {CronologicalBuilder.CronologicalAdjustmentProcedure, new CronologicalBuilder()},
        {SupplierDisputeSearchBuilder.SupplierDisputeSearchValue, new SupplierDisputeSearchBuilder()},
        {SupplierDisputeExportLogBuilder.SupplierDisputeExportLog, new SupplierDisputeExportLogBuilder()},
        {DRTExportBuilder.DRTExportValue, new DRTExportBuilder()}
      };

        private readonly DocumentBuildingDirector _documentDirector;

        public GenerateDocumentResponse GenerateDocument(GenerateDocumentRequest generateDocumentRequest)
        {
            if (generateDocumentRequest == null) throw new ArgumentNullException("generateDocumentRequest");
            if (generateDocumentRequest.Metadata == null) throw new ArgumentException("Request Metadata can not be null", "generateDocumentRequest");
            IDocumentBuilder currentBuilder;

            var exportTypeData = generateDocumentRequest.Metadata.SingleOrDefault(x => x.Key.Equals(ExportTypeKey, StringComparison.OrdinalIgnoreCase));
            if (exportTypeData == null)
            {
                // Throw???
                // Kendo Builder???
                currentBuilder = new DefaultBuilder();
            }
            else
            {
                var contextValue = exportTypeData.Value.ToString();
                currentBuilder = DocumentBuilderConfiguration.ContainsKey(contextValue)
                  ? DocumentBuilderConfiguration[contextValue]
                  : new DefaultBuilder();
            }

            var requestId = Guid.NewGuid();
            _documentDirector.userContext = ApplicationContext.Instance.UserContext;
            _documentDirector.Construct(currentBuilder, generateDocumentRequest, requestId);

            var response = new GenerateDocumentResponse
            {
                Data = requestId,
                Success = true
            };

            return response;
        }


        public DocumentStatusResponse IsAvaliable(IsDocumentReadyRequest request)
        {
            if (request == null) throw new ArgumentNullException("request");

            var requestId = request.Data;

            if (_documentDirector.DocumentAvailable(requestId))
            {
                var documentInfo = _documentDirector.GetDocumentInfo(requestId);
                return new DocumentStatusResponse
                {
                    Success = true,
                    DocumentId = documentInfo.DocumentId.Value
                };
            }

            return new DocumentStatusResponse { Success = false };
        }
    }
}