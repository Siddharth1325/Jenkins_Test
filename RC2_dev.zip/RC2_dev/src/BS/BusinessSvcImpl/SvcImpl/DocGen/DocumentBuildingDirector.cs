using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using BusinessSvcImpl.DataObjects.DocGen;
using BusinessSvcImpl.SvcImpl.DocGen.Builders;
using DocumentServiceLib.Service;
using CommonLib.Context;
namespace BusinessSvcImpl.SvcImpl.DocGen
{
    public class DocumentBuildingDirector
    {
        public UserContext userContext
        {
            get;
            set;
        }
        public void Construct(IDocumentBuilder builder, GenerateDocumentRequest generateDocumentRequest, Guid requestId)
        {
            if (builder == null) throw new ArgumentNullException("builder");
            s_pendingRequests.Add(requestId, generateDocumentRequest);         
            var request = new AsyncBuilderRequest(builder, generateDocumentRequest, requestId, userContext);

            ThreadPool.QueueUserWorkItem(AsyncGenerateReport, request);
        }

        private void AsyncGenerateReport(object asyncBuilderRequest)
        {
            var builderRequest = (AsyncBuilderRequest)asyncBuilderRequest;
          ApplicationContext.Instance.UserContext = userContext;

            var docInfo = builderRequest.Builder.GenerateDocument(builderRequest.GenerateDocumentRequest);

            UploadDocumentResponse response;
            using (var stream = new MemoryStream(docInfo.Data))
            {

                var uploadDocumentRequest = new UploadDocumentRequest
                {
                    DocumentDescription = docInfo.DocumentDesc,
                    DocumentName = docInfo.DocumentName,
                    MimeType = docInfo.MimeType,
                    DocumentStream = stream,
                    DocumentType = docInfo.DocumentType,
                    IsTemporary = true,
                    ApplicationId = userContext.ApplicationId
                };

                var docService = new DocumentService();
                response = docService.SaveDocument(uploadDocumentRequest);
            }

            if (response.DocumentId <= 0)
            {
                throw new ApplicationException(string.Format("Doc Service Failed to save {0}", response.DocumentName));
            }

            docInfo.DocumentId = response.DocumentId;           
            s_completedRequests.Add(builderRequest.RequestId, docInfo);
            s_pendingRequests.Remove(builderRequest.RequestId);
        }

        private static readonly Dictionary<Guid, GenerateDocumentRequest> s_pendingRequests = new Dictionary<Guid, GenerateDocumentRequest>();
        private static readonly Dictionary<Guid, GeneratedDocumentInfo> s_completedRequests = new Dictionary<Guid, GeneratedDocumentInfo>();


        private class AsyncBuilderRequest
        {
            internal IDocumentBuilder Builder { get; private set; }
            internal GenerateDocumentRequest GenerateDocumentRequest { get; private set; }
            internal Guid RequestId { get; private set; }
            internal UserContext uContext { get; private set; }

            public AsyncBuilderRequest(IDocumentBuilder builder, GenerateDocumentRequest generateDocumentRequest, Guid requestId, UserContext uC)
            {
                GenerateDocumentRequest = generateDocumentRequest;
                RequestId = requestId;
                Builder = builder;
                uContext = uC;
            }
        }

        public bool DocumentAvailable(Guid requestId)
        {
            return s_completedRequests.ContainsKey(requestId);
        }

        public GeneratedDocumentInfo GetDocumentInfo(Guid requestId)
        {
            if (s_completedRequests.ContainsKey(requestId) == false) throw new ArgumentException("This is not a completed request", "requestId");

            var docInfo = s_completedRequests[requestId];

            s_completedRequests.Remove(requestId);

            return docInfo;
        }
    }
}