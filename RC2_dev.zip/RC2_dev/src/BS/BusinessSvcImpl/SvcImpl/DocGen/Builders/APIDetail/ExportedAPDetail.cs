﻿using BusinessSvcImpl.DataObjects.SpaAccounting.Dto;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessSvcImpl.SvcImpl.DocGen.Builders.APDetail
{
    public class ExportedAPDetail
    {
        //public int? VendorId { get; set; }
        //public string VendorName { get; set; }
        [Description("Service")]
        public string ProductName { get; set; }
        
        [Description("Trans Date")]
        public string APDate { get; set; }

        [Description("Starting Price")]
        public string BaseAmount { get; set; }

        [Description("Total Price")]
        public string EligibleAmount { get; set; }

        [Description("Pre-Billing Cost Adj reason")]
        public string CostAdjReason { get; set; }
        
        [Description("Invoice #")]
        public string InvoiceNumber { get; set; }
        
        [Description("Invoice Date")]
        public string InvoiceDate { get; set; }
        
        [Description("Check Date")]
        public string CheckDate { get; set; }
        
        [Description("Check #")]
        public string CheckNumber { get; set; }
        
        [Description("Paid Amount")]
        public string PaidAmount { get; set; }
        
        [Description("Status")]
        public string Status { get; set; }
        //  public string SourceWorkOrderId { get; set; }
        //public int WorkOrderId { get; set; }

        //public DateTime? Date { get; set; }












    }
}
