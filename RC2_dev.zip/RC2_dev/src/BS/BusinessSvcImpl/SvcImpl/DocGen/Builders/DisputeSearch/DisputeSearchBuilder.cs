﻿
using Delegate.SpaAcc;
//using DomCommon = DomainModel.Accounting;
using BusinessSvcImpl.SvcImpl.DocGen.Builders.DisputeSearch;
using System.IO;
using System.Web.Script.Serialization;
using BusinessSvcImpl.DataObjects.DocGen;
using BusinessSvcImpl.SvcImpl.SpaAcc;
using CommonLib.Context;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DisputeDto = BusinessSvcImpl.DataObjects.SpaAccounting.Dto;
using DisputeServiceDto = BusinessSvcImpl.DataObjects.SpaAccountingService.Dto;
using BusinessSvcImpl.DataObjects.SpaAccountingService.Dto;


namespace BusinessSvcImpl.SvcImpl.DocGen.Builders.DisputeSearch
{
    public class DisputeSearchBuilder : CommonBuilder<DisputeDto.DisputeSearchResult, ExportDisputeSearch>
    {
        public const string DisputeSearchValue = "DisputeSearch";
        public const string AppliedFilterIdsKey = "DisputeSearchCriterion";

        private bool IsValid(GenerateDocumentRequest generateDocumentRequest)
        {
            if (generateDocumentRequest == null) throw new NullReferenceException("Document Info");

            var values = generateDocumentRequest.Metadata
              .Where(x => x.Value != null)
              .Select(x => x.Value.ToString())
              .ToArray();
            return values.Any(x => x.Equals(DisputeSearchValue, StringComparison.Ordinal));
        }

        public override IEnumerable<DisputeDto.DisputeSearchResult> GetData(GenerateDocumentRequest generateDocumentRequest)
        {
            DocumentMetadata filterTypeData = generateDocumentRequest.Metadata.SingleOrDefault(x => x.Key.Equals(AppliedFilterIdsKey, StringComparison.OrdinalIgnoreCase));
            var context = JsonConvert.DeserializeObject<UserContext>(generateDocumentRequest.UserContext);
            if (filterTypeData == null || filterTypeData.Value == null) return new List<DisputeDto.DisputeSearchResult>();

            var selectedIdsValue = filterTypeData.Value.ToString();
            var dispute = JsonConvert.DeserializeObject<DisputeSearchCriterion>(selectedIdsValue);

            DisputeDto.DisputeSearchInput DisputeDto = new DisputeDto.DisputeSearchInput();
            DisputeServiceDto.GetDisputeSearchRequest request = new DisputeServiceDto.GetDisputeSearchRequest();


            DisputeDto.AssignedTo = dispute.AssignedTo;//.Split(new char[] { ',' }).ToList();
            DisputeDto.ClientName = dispute.ClientName;
            DisputeDto.InvoiceNumber = dispute.InvoiceNumber;
           // DisputeDto.ClientName = string.IsNullOrWhiteSpace(order.ClientNumber) ? null : order.ClientNumber;
          
           // orderDto.InvoiceAmount = (order.InvoiceAmount.HasValue) ? order.InvoiceAmount.Value : orderDto.InvoiceAmount;
            DisputeDto.DisputeAmount = dispute.DisputeAmount;
            DisputeDto.DisputeStatusType = dispute.DisputeStatusType;
            DisputeDto.DisputeType = dispute.DisputeType;
            DisputeDto.DisputeResolution = dispute.DisputeResolution;
            DisputeDto.DisputeDueDateFrom = dispute.DisputeDueDateFrom;
            DisputeDto.DisputeDueDateTo = dispute.DisputeDueDateTo;
            DisputeDto.VendorId = dispute.VendorId;
            DisputeDto.VendorWorkOrderId = dispute.VendorWorkOrderId;
            DisputeDto.InspWorkOrderId = dispute.InspWorkOrderId;
            DisputeDto.DisputeResolution = dispute.DisputeResolution;


            if(string.IsNullOrEmpty(DisputeDto.InvoiceNumber))
            {
                DisputeDto.InvoiceNumber = null;
            }

            //if (string.IsNullOrWhiteSpace(DisputeDto.ApplicationId))
            //{
            //    DisputeDto.AssignedTo = null;
            //}



            request.SearchInput = DisputeDto;
            request.PageSize = 10000;
            request.SkipCount = 0;
            request.PageNumber = 1;
            var service = new SpaAcc.SpaAccountingService();
            GetDisputeSearchResponse response= service.GetDisputeSearchResults(request);

            return response.SearchResults;
           // List<DisputeDto.DisputeSearch> result = new List<DisputeDto.DisputeSearch>();

            //return result;
        }

        public override string ExportIdentifier
        {
            get { return DisputeSearchValue; }
            set { value = DisputeSearchValue; }
        }

        public override ExportDisputeSearch MapTToTE(DisputeDto.DisputeSearchResult dispute)
        {
            if (dispute == null) throw new ArgumentNullException("databaseChangeLog");


            var exportedLoan = new ExportDisputeSearch
            {
              //  ApplicationId = dispute.ApplicationId,
                DisputeId=dispute.DisputeId,
                AssignedTo = dispute.AssignedTo,//string.Join(",", dispute.AssignedTo ?? new List<string>()),

                ClientName = dispute.ClientName,//string.Join(",", dispute.ClientName ?? new List<string>()),
                DisputeAmount = dispute.DisputeAmount,
                DisputeDueDateFrom = (dispute.DisputeDueDateFrom.HasValue) ? dispute.DisputeDueDateFrom.Value.ToString("MM/dd/yyyy hh:mm tt") : string.Empty,
                DisputeDueDateTo = (dispute.DisputeDueDateTo.HasValue) ? dispute.DisputeDueDateTo.Value.ToString("MM/dd/yyyy hh:mm tt") : string.Empty,
                DisputeStatusType = dispute.DisputeStatusType,
                InspWorkOrder = dispute.InspWorkOrderId,
                InvoiceNumber = dispute.InvoiceNumber,
                VendorId = dispute.VendorId,
                VendorWorkOrderId = dispute.VendorWorkOrderId,
                LoanNumber = dispute.LoanNumber,
                DisputeType=dispute.DisputeType,
                Resolution=dispute.DisputeResolution

            };
            return exportedLoan;


        }

       

        class DisputeSearchCriterion
        {


            public List<string> DisputeStatusType { get; set; }
            public List<string> AssignedTo { get; set; }
            public List<string> ClientName { get; set; }
            public string LoanNumber { get; set; }
            public Nullable<int> VendorId { get; set; }
            public Nullable<int> VendorWorkOrderId { get; set; }
            public Nullable<int> InspWorkOrderId { get; set; }
            public string InvoiceNumber { get; set; }
            public Nullable<DateTime> DisputeDueDateFrom { get; set; }
            public Nullable<DateTime> DisputeDueDateTo { get; set; }
            public Nullable<int> ApplicationId { get; set; }

            public decimal? DisputeAmount { get; set; }

            public List<string> DisputeType { get; set; }

            public List<string> DisputeResolution { get; set; }
            




          
        }

      /*  public override ExportDisputeSearch MapTToTE(DisputeDto.DisputeSearchInput t)
        {
            throw new NotImplementedException();
        }*/
    }

}
