using System;
using BusinessSvcImpl.DataObjects.DocGen;

namespace BusinessSvcImpl.SvcImpl.DocGen.Builders
{
  public class DefaultBuilder : IDocumentBuilder
  {
    public GeneratedDocumentInfo GenerateDocument(GenerateDocumentRequest request)
    {
      throw new NotImplementedException();
    }
  }
}