﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Authentication;
using BusinessSvcImpl.DataObjects.DocGen;
using BusinessSvcImpl.SvcImpl.SpaAcc;
//using IbmBpmRestApi.ServiceProxy.Reference;
using Newtonsoft.Json;
using User.ServiceProxy.UserRepository;
using UserContext = CommonLib.Context.UserContext;
using BusinessSvcImpl.DataObjects.SpaAccountingService.Dto;
using BusinessSvcImpl.DataObjects.SpaAccounting.Dto;
using System.Diagnostics;

namespace BusinessSvcImpl.SvcImpl.DocGen.Builders.ReviewImportException
{

    public class ReviewImportExceptionBuilder : CommonBuilder<BulkException, ExportedReviewImportException>
    {
        public const string ReviewImportExceptionValue = "ReviewImportException";
        public const string AppliedFilterIdsKey = "ReviewImportExceptionCriterion";


        private bool IsValid(GenerateDocumentRequest generateDocumentRequest)
        {
            if (generateDocumentRequest == null) throw new NullReferenceException("Document Info");

            var values = generateDocumentRequest.Metadata
              .Where(x => x.Value != null)
              .Select(x => x.Value.ToString())
              .ToArray();
            return values.Any(x => x.Equals(ReviewImportExceptionValue, StringComparison.Ordinal));
        }

        public override IEnumerable<BulkException> GetData(GenerateDocumentRequest generateDocumentRequest)
        {
            DocumentMetadata filterTypeData = generateDocumentRequest.Metadata.SingleOrDefault(x => x.Key.Equals(AppliedFilterIdsKey, StringComparison.OrdinalIgnoreCase));
            if (filterTypeData == null || filterTypeData.Value == null) return new List<BulkException>();

            var context = JsonConvert.DeserializeObject<UserContext>(generateDocumentRequest.UserContext);
            var selectedIdsValue = filterTypeData.Value.ToString();
            var reviewException = JsonConvert.DeserializeObject<ReviewImportExceptionCriterion>(selectedIdsValue);

            GetImportBulkExceptionRequest request = new GetImportBulkExceptionRequest() { FileImportDateFrom = reviewException.FileImportDateFrom, FileImportDateTo = reviewException.FileImportDateTo.Value.AddHours(23).AddMinutes(59).AddSeconds(59), FileType = reviewException.FileType };
            var service = new SpaAccountingService();
            if (request.FileType == null)
            { request.FileType = "All"; }

            GetBulkExceptionResponse response = service.GetImportBulkException(request);
            return response.BulkExceptions;
        }



        public override ExportedReviewImportException MapTToTE(BulkException bulkException)
        {
            if (bulkException == null) throw new ArgumentNullException("bulkException");

            var exportedReviewImportException = new ExportedReviewImportException
            {
                FileImportDate = bulkException.FileDate,
                FileName = bulkException.FileName,
                FileType = bulkException.FileTypeEleCde,
                LineNumber = bulkException.LineNumber,
                ExceptionDescription = bulkException.ErrorDescription

            };
            return exportedReviewImportException;
        }



        public override string ExportIdentifier
        {
            get { return ReviewImportExceptionValue; }
            set { value = ReviewImportExceptionValue; }
        }
        private static IList<int> GetSelectedIds(GenerateDocumentRequest generateDocumentRequest, string collectionKey)
        {
            if (generateDocumentRequest == null) throw new ArgumentNullException("generateDocumentRequest");
            if (string.IsNullOrEmpty(collectionKey)) throw new ArgumentNullException("collectionKey");

            DocumentMetadata filterTypeData = generateDocumentRequest.Metadata
              .SingleOrDefault(x => x.Key.Equals(collectionKey, StringComparison.OrdinalIgnoreCase));

            if (filterTypeData == null || filterTypeData.Value == null) return new int[0];

            var selectedIdsValue = filterTypeData.Value.ToString();
            var selectedIds = selectedIdsValue
              .Split(new[] { ',' })
              .Select(x => x.Trim());

            var numericIds = new List<int>();
            foreach (var selectedId in selectedIds)
            {
                int convertedId;
                if (int.TryParse(selectedId, out convertedId))
                {
                    numericIds.Add(convertedId);
                }
            }

            return numericIds;
        }

        public GenerateDocumentResponse GetDocumentRequest()
        {
            return new GenerateDocumentResponse();
        }
    }
    class ReviewImportExceptionCriterion
    {
        public DateTime? FileImportDateFrom { get; set; }
        public DateTime? FileImportDateTo { get; set; }
        public string FileType { get; set; }

    }
}