﻿using BusinessSvcImpl.DataObjects.DocGen;
using BusinessSvcImpl.SvcImpl.DocGen.Builders.ARAdjustments;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessSvcImpl.SvcImpl.DocGen.Builders
{
    public abstract class CommonBuilder<T, TE> : BuilderBase
        where T : class
        where TE : class
    {
        public abstract string ExportIdentifier { get; set; }
        private bool IsValid(GenerateDocumentRequest generateDocumentRequest)
        {
            if (generateDocumentRequest == null) throw new NullReferenceException("Document Info");
            var values = generateDocumentRequest.Metadata.Where(x => x.Value != null).Select(x => x.Value.ToString()).ToArray();
            return values.Any(x => x.Equals(ExportIdentifier, StringComparison.Ordinal));
        }
        public override GeneratedDocumentInfo GenerateDocument(DataObjects.DocGen.GenerateDocumentRequest request)
        {
            if (IsValid(request) == false) throw new ArgumentException("Request is not valid", "request");

            GeneratedDocumentInfo generatedDocumentInfo;

            try
            {
                var exportedLoans = new List<TE>();
                int createdById = GetCurrentUserId(request);
                var logData = GetData(request);
                exportedLoans.AddRange(logData.Select(MapTToTE));

                var csv = new CsvExport<TE>(exportedLoans);
                var fileData = csv.ExportToBytes();
                var success = (fileData.Length > 0);

                var data = fileData;
                var createdDate = DateTime.Now;
                var documentName = "export.csv";
                var mimeType = "text/csv";
                var description = "Database log output.";
                var documentType = "Other";

                generatedDocumentInfo = new GeneratedDocumentInfo(documentName, description, documentType, mimeType,
                    createdById, createdDate, success, data);
            }
            catch (IOException)
            {
                throw;
            }
            return generatedDocumentInfo;
        }
        public abstract IEnumerable<T> GetData(GenerateDocumentRequest generateDocumentRequest);
        public abstract TE MapTToTE(T t);

        public string GetMetadataValue(GenerateDocumentRequest generateDocumentRequest, string key)
        {
            DocumentMetadata filterTypeData = generateDocumentRequest.Metadata.SingleOrDefault(x => x.Key.Equals(key, StringComparison.OrdinalIgnoreCase));
            if (filterTypeData == null || filterTypeData.Value == null) return string.Empty;
            return filterTypeData.Value.ToString();
        }
    }
}
