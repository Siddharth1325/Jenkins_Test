﻿using BusinessSvcImpl.DataObjects;
using BusinessSvcImpl.DataObjects.DocGen;
using BusinessSvcImpl.SvcImpl.SpaAcc;
using BusinessSvcImpl.DataObjects.SpaAccounting.Dto;
using CommonLib.Context;
using DomainModel.Common.Dto;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessSvcImpl.SvcImpl.DocGen.Builders.PresAdjustment
{
    public class CronologicalBuilder : CommonBuilder<CronologicalAdjustmentListResponse, CronologicalAdjustmentExportResponse>
    {
        public const string CronologicalAdjustmentProcedure = "GetCronologicalAdjustments";
        public const string AppliedFilterIdsKey = "AdjustmentSearchCriterion";

        private bool IsValid(GenerateDocumentRequest generateDocumentRequest)
        {
            if (generateDocumentRequest == null) throw new NullReferenceException("Document Info");

            var values = generateDocumentRequest.Metadata
              .Where(x => x.Value != null)
              .Select(x => x.Value.ToString())
              .ToArray();
            return values.Any(x => x.Equals(CronologicalAdjustmentProcedure, StringComparison.Ordinal));
        }

        public override IEnumerable<CronologicalAdjustmentListResponse> GetData(GenerateDocumentRequest generateDocumentRequest)
        {
            DocumentMetadata filterTypeData = generateDocumentRequest.Metadata.SingleOrDefault(x => x.Key.Equals(AppliedFilterIdsKey, StringComparison.OrdinalIgnoreCase));
            var context = JsonConvert.DeserializeObject<UserContext>(generateDocumentRequest.UserContext);

            if (filterTypeData == null || filterTypeData.Value == null) 
                return new List<CronologicalAdjustmentListResponse>();

            var selectedIdsValue = filterTypeData.Value.ToString();            
            AdjustmentDetailRequest adjustmentSerahchDto = new AdjustmentDetailRequest();
            if(!String.IsNullOrEmpty(selectedIdsValue))
            adjustmentSerahchDto.OrderId =  Convert.ToInt32(selectedIdsValue);           
        
            var service = new SpaAccountingService();
            List<CronologicalAdjustmentListResponse> cronologicaladjustmentList = service.GetCronologicalAdjustmentList(adjustmentSerahchDto);

            return cronologicaladjustmentList;
        }

        public override string ExportIdentifier
        {
            get { return CronologicalAdjustmentProcedure; }
            set { value = CronologicalAdjustmentProcedure; }
        }

        public override CronologicalAdjustmentExportResponse MapTToTE(CronologicalAdjustmentListResponse adjustment)
        {
            if (adjustment == null) throw new ArgumentNullException("databaseChangeLog");

            var exportedCronologicalAdjustment = new CronologicalAdjustmentExportResponse
            {
                AdjustedBy = adjustment.AdjustedBy,
                AdjustedCategory = adjustment.AdjustedCategory,
                AdjustmentAmount = adjustment.AdjustmentAmount,
                AdjustmentDate = adjustment.AdjustmentDate,
                AdjustmentInvoiceNumber = adjustment.AdjustmentInvoiceNumber,
                EndingAmount = adjustment.EndingAmount,
                EndingTax=adjustment.EndingTax,
                Feetype = adjustment.Feetype,
                OderNumber = adjustment.OderNumber,
                Product = adjustment.Product,
                SentToOracleDate = adjustment.SentToOracleDate,
                Service = adjustment.Service,
                ServiceItem = adjustment.ServiceItem,
                StartingAmount = adjustment.StartingAmount,
                VendorId = adjustment.VendorId,
                VendorWorkOrderNumber = adjustment.VendorWorkOrderNumber,
                RecordNumber = "Adj " + adjustment.RecordNumber
            };
            return exportedCronologicalAdjustment;
        }
    }

    public class CronologicalAdjustmentExportResponse
    {
        
        public string AdjustedCategory { get; set; }
        
        public decimal? StartingAmount { get; set; }
        
        public decimal? AdjustmentAmount { get; set; }
        
        public decimal? EndingAmount { get; set; }

        public decimal? EndingTax { get; set; }
        
        public string AdjustmentInvoiceNumber { get; set; }
        
        public int? OderNumber { get; set; }
        
        public int? VendorWorkOrderNumber { get; set; }
        
        public int? VendorId { get; set; }
        
        public string Product { get; set; }
        
        public string Service { get; set; }
        
        public string ServiceItem { get; set; }
        
        public string Feetype { get; set; }
        
        public string AdjustedBy { get; set; }
        
        public DateTime? AdjustmentDate { get; set; }
        
        public DateTime? SentToOracleDate { get; set; }

        public string RecordNumber { get; set; }

    }
}
