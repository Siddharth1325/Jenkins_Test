﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Authentication;
using BusinessSvcImpl.DataObjects.DocGen;
using BusinessSvcImpl.SvcImpl.SpaAcc;
//using IbmBpmRestApi.ServiceProxy.Reference;
using Newtonsoft.Json;
using User.ServiceProxy.UserRepository;
using UserContext = CommonLib.Context.UserContext;
using APInvoiceDto = BusinessSvcImpl.DataObjects.SpaAccounting.Dto;
using BusinessSvcImpl.DataObjects.SpaAccountingService.Dto;
using BusinessSvcImpl.DataObjects.SpaAccounting.Dto;
using InspectionDto = Inspections.ServiceProxy.InspectionSvc;
using System.Diagnostics;
using ProductDto = Admin.ServiceProxy.ProductService;
using System.Globalization;

namespace BusinessSvcImpl.SvcImpl.DocGen.Builders.ARDetail
{
    public class ARDetailBuilder : CommonBuilder<APInvoiceDto.ARDetailView, ExportedARDetail>
    {
        public const string ARDetailValue = "ARDetail";
        public const string AppliedFilterIdsKey = "ARDetailCriterion";


        private bool IsValid(GenerateDocumentRequest generateDocumentRequest)
        {
            if (generateDocumentRequest == null) throw new NullReferenceException("Document Info");

            var values = generateDocumentRequest.Metadata
              .Where(x => x.Value != null)
              .Select(x => x.Value.ToString())
              .ToArray();
            return values.Any(x => x.Equals(ARDetailValue, StringComparison.Ordinal));
        }

        public override IEnumerable<APInvoiceDto.ARDetailView> GetData(GenerateDocumentRequest generateDocumentRequest)
        {
            var service = new SpaAccountingService();

            DocumentMetadata filterTypeData = generateDocumentRequest.Metadata.SingleOrDefault(x => x.Key.Equals(AppliedFilterIdsKey, StringComparison.OrdinalIgnoreCase));
            if (filterTypeData == null || filterTypeData.Value == null) return new List<APInvoiceDto.ARDetailView>();

            var context = JsonConvert.DeserializeObject<UserContext>(generateDocumentRequest.UserContext);

            var selectedIdsValue = filterTypeData.Value.ToString();
            var apInvoiceSearchFilter = JsonConvert.DeserializeObject<ARDetailCriterion>(selectedIdsValue);
            GetARDetailsRequest request = new GetARDetailsRequest() { WorkOrderId = int.Parse(apInvoiceSearchFilter.WorkOrderNumber), PageSize = 10000, SkipCount = 0 };
            GetARDetailsResponse serviceResponse = service.GetARDetails(request);
            return serviceResponse.AccRcvbleList;
        }



        public override ExportedARDetail MapTToTE(APInvoiceDto.ARDetailView apInvoice)
        {
            if (apInvoice == null) throw new ArgumentNullException("apInvoice");

            var exportedAccountingAdjustmentCode = new ExportedARDetail
            {                
                Service = apInvoice.ProductName,
                TransDate = apInvoice.ARDate == null ? "" : apInvoice.ARDate.Value.ToString("MM/dd/yyyy"),
                StartingPrice = apInvoice.BaseAmount.ToString("C", CultureInfo.GetCultureInfo("en-US")),
                TotalPrice = apInvoice.EligibleAmount.ToString("C", CultureInfo.GetCultureInfo("en-US")),
                TaxRate = apInvoice.TaxRate.ToString("C", CultureInfo.GetCultureInfo("en-US")),
                TaxAmount = apInvoice.TaxAmount.ToString("C", CultureInfo.GetCultureInfo("en-US")),
                TotalAmount = apInvoice.TotalAmount.Value.ToString("C", CultureInfo.GetCultureInfo("en-US")),
                PreBillingPriceAdjReason = apInvoice.PriceAdjReason,
                InvoiceNumber = apInvoice.InvoiceNumber,
                InvoiceDate = apInvoice.InvoiceDate == null ? "" : apInvoice.InvoiceDate.Value.ToString("MM/dd/yyyy"),
                Status = apInvoice.Status

            };
            return exportedAccountingAdjustmentCode;
        }



        public override string ExportIdentifier
        {
            get { return ARDetailValue; }
            set { value = ARDetailValue; }
        }
        private static IList<int> GetSelectedIds(GenerateDocumentRequest generateDocumentRequest, string collectionKey)
        {
            if (generateDocumentRequest == null) throw new ArgumentNullException("generateDocumentRequest");
            if (string.IsNullOrEmpty(collectionKey)) throw new ArgumentNullException("collectionKey");

            DocumentMetadata filterTypeData = generateDocumentRequest.Metadata
              .SingleOrDefault(x => x.Key.Equals(collectionKey, StringComparison.OrdinalIgnoreCase));

            if (filterTypeData == null || filterTypeData.Value == null) return new int[0];

            var selectedIdsValue = filterTypeData.Value.ToString();
            var selectedIds = selectedIdsValue
              .Split(new[] { ',' })
              .Select(x => x.Trim());

            var numericIds = new List<int>();
            foreach (var selectedId in selectedIds)
            {
                int convertedId;
                if (int.TryParse(selectedId, out convertedId))
                {
                    numericIds.Add(convertedId);
                }
            }

            return numericIds;
        }

        public GenerateDocumentResponse GetDocumentRequest()
        {
            return new GenerateDocumentResponse();
        }
    }
    class ARDetailCriterion
    {
        public string WorkOrderNumber { get; set; }
    }
}