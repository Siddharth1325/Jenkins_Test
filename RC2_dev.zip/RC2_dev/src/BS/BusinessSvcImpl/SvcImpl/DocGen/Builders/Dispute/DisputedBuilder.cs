﻿
using OrderDto = BusinessSvcImpl.DataObjects.SpaAccounting.Dto;
using BusinessSvcImpl.DataObjects.DocGen;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Delegate.SpaAcc;
using DomCommon = DomainModel.Accounting;
using Newtonsoft.Json;
using BusinessSvcImpl.SvcImpl.DocGen.Builders.Order;
using BusinessSvcImpl.SvcImpl.DocGen.Builders.ARAdjustments;
using System.IO;
using System.Web.Script.Serialization;
using OrderServiceDto = BusinessSvcImpl.DataObjects.SpaAccountingService.Dto;
using BusinessSvcImpl.SvcImpl.SpaAcc;
using UserContext = CommonLib.Context.UserContext;
using System.Diagnostics;

namespace BusinessSvcImpl.SvcImpl.DocGen.Builders.Order
{
    public class DisputedBuilder : CommonBuilder<OrderDto, ExportedOrder>
    {
        public const string OrderSearchValue = "OrderSearch";
        public const string AppliedFilterIdsKey = "OrderSearchCriterion";

        private bool IsValid(GenerateDocumentRequest generateDocumentRequest)
        {
            if (generateDocumentRequest == null) throw new NullReferenceException("Document Info");

            var values = generateDocumentRequest.Metadata
              .Where(x => x.Value != null)
              .Select(x => x.Value.ToString())
              .ToArray();
            return values.Any(x => x.Equals(OrderSearchValue, StringComparison.Ordinal));
        }

        public override IEnumerable<OrderDto.OrderSearchResult> GetData(GenerateDocumentRequest generateDocumentRequest)
        {
            DocumentMetadata filterTypeData = generateDocumentRequest.Metadata.SingleOrDefault(x => x.Key.Equals(AppliedFilterIdsKey, StringComparison.OrdinalIgnoreCase));
            var context = JsonConvert.DeserializeObject<UserContext>(generateDocumentRequest.UserContext);
            if (filterTypeData == null || filterTypeData.Value == null) return new List<OrderDto.OrderSearchResult>();

            var selectedIdsValue = filterTypeData.Value.ToString();
            var order = JsonConvert.DeserializeObject<OrderSearchCriterion>(selectedIdsValue);

            OrderDto.OrderSearchInput orderDto = new OrderDto.OrderSearchInput();
            OrderServiceDto.GetOrderSearchRequest request = new OrderServiceDto.GetOrderSearchRequest();


            orderDto.OrderNumber = order.OrderNumber;
            orderDto.WorkOrderNumber = order.WorkOrderNumber;
            orderDto.InvoiceNumber = order.InvoiceNumber;
            orderDto.ClientNumber = string.IsNullOrWhiteSpace(order.ClientNumber) ? null : order.ClientNumber;
            orderDto.LoanNumber = string.IsNullOrWhiteSpace(order.LoanNumber) ? null : order.LoanNumber;
            orderDto.VendorNumber = order.VendorNumber;
            orderDto.Invoiced = string.IsNullOrWhiteSpace(order.Invoiced) ? null : order.Invoiced;
            orderDto.ProductCode = string.IsNullOrWhiteSpace(order.ProductCode) ? null : order.ProductCode;
            orderDto.ProductCategory = string.IsNullOrWhiteSpace(order.ProductCategory) ? null : order.ProductCategory;
            orderDto.Address = string.IsNullOrWhiteSpace(order.Address) ? null : order.Address;
            orderDto.LineOfBusiness = string.IsNullOrWhiteSpace(order.LineOfBusiness) ? null : order.LineOfBusiness;
            orderDto.BillingFrequency = string.IsNullOrWhiteSpace(order.BillingFrequency) ? null : order.BillingFrequency;
            orderDto.CompletedDateFrom = order.CompletedDateFrom;
            orderDto.CompletedDateTo = order.CompletedDateTo;
            orderDto.InvoiceAmount = (order.InvoiceAmount.HasValue) ? order.InvoiceAmount.Value : orderDto.InvoiceAmount;
            orderDto.InvoiceDateFrom = order.InvoiceDateFrom;
            orderDto.InvoiceDateTo = order.InvoiceDateTo;

            request.SearchInput = orderDto;
            request.PageSize = 10000;
            request.SkipCount = 0;
            request.PageNumber = 1;
            var service = new SpaAccountingService();
            OrderServiceDto.GetOrderSearchResponse orderSearch = service.GetOrderSearchResults(request);

            return orderSearch.SearchResults;
        }

        public override string ExportIdentifier
        {
            get { return OrderSearchValue; }
            set { value = OrderSearchValue; }
        }

        public override ExportedOrder MapTToTE(OrderDto.OrderSearchResult order)
        {
            if (order == null) throw new ArgumentNullException("databaseChangeLog");


            var exportedLoan = new ExportedOrder
            {
                WorkOrderNumber = order.WorkOrderNumber,
                ClientNumber = order.ClientNumber,
                OrderNumber = order.OrderNumber,
                ARInvoiceNumber = order.InvoiceNumber,
                LoanNumber = order.LoanNumber,
                ProductCode = order.ProductCode,
                InvoiceAmount = order.InvoiceAmount,
                BillingFrequency = order.BillingFrequency,
                CompletedDate = (order.CompletedDate.HasValue) ? order.CompletedDate.Value.ToString("MM/dd/yyyy hh:mm tt") : string.Empty,
                InvoiceDate = (order.InvoiceDate.HasValue) ? order.InvoiceDate.Value.ToString("MM/dd/yyyy hh:mm tt") : string.Empty
            };
            return exportedLoan;


        }

        //public override GeneratedDocumentInfo GenerateDocument(DataObjects.DocGen.GenerateDocumentRequest request)
        //{
        //    if (IsValid(request) == false) throw new ArgumentException("Request is not valid", "request");

        //    GeneratedDocumentInfo generatedDocumentInfo;

        //    try
        //    {
        //        var exportedOrders = new List<ExportedOrder>();
        //        int createdById = GetCurrentUserId(request);
        //        var logData = GetData(request);
        //        exportedOrders.AddRange(logData.Select(ExportedOrder.Build));

        //        var csv = new CsvExport<ExportedOrder>(exportedOrders);
        //        var fileData = csv.ExportToBytes();
        //        var success = (fileData.Length > 0);

        //        var data = fileData;
        //        var createdDate = DateTime.Now;
        //        var documentName = "export.csv";
        //        var mimeType = "text/csv";
        //        var description = "Order Export.";
        //        var documentType = "Other";

        //        generatedDocumentInfo = new GeneratedDocumentInfo(documentName, description, documentType, mimeType,
        //                                                          createdById, createdDate, success, data);
        //    }
        //    catch (IOException ex)
        //    {
        //        Debug.WriteLine("Error Generating document {0}", ex);
        //        throw;
        //    }


        //    return generatedDocumentInfo;
        //}

        class OrderSearchCriterion
        {
            public Nullable<int> OrderNumber { get; set; }

            public Nullable<int> InvoiceNumber { get; set; }

            public Nullable<int> WorkOrderNumber { get; set; }

            public string LoanNumber { get; set; }

            public String ClientNumber { get; set; }

            public Nullable<int> VendorNumber { get; set; }

            public string Invoiced { get; set; }

            public string ProductCategory { get; set; }

            public string ProductCode { get; set; }

            public string Address { get; set; }

            public string LineOfBusiness { get; set; }

            public string BillingFrequency { get; set; }

            public Nullable<System.DateTime> CompletedDateTo { get; set; }

            public Nullable<System.DateTime> CompletedDateFrom { get; set; }

            public double? InvoiceAmount { get; set; }

            public Nullable<System.DateTime> InvoiceDateTo { get; set; }

            public Nullable<System.DateTime> InvoiceDateFrom { get; set; }
        }
    }
}



