﻿using BusinessSvcImpl.DataObjects.SpaAccounting.Dto;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessSvcImpl.SvcImpl.DocGen.Builders.APInvoice
{
    public class ExportedAPInvoice
    {
        
        public string WorkOrderNumber { get; set; }       
        public string InspectorUniqueID { get; set; }

        [Description("WO Inv Amt")]
        public string InvoiceAmount { get; set; } 
      
        public string AssignedDate { get; set; }       
        public string CompletedDate { get; set; }

        [Description("Product")]
        public string ProductCode { get; set; }     
  
        public string PriceAdjReason { get; set; }

        //public string Occupancy { get; set; }    
         [Description("QC Supplier Adjustment Comments")]
        public string QCSupplierComment { get; set; }       
        public string PropertyAddress { get; set; }       

    }
}
