﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Authentication;
using BusinessSvcImpl.DataObjects.DocGen;
using BusinessSvcImpl.SvcImpl.SpaAcc;
using Newtonsoft.Json;
using User.ServiceProxy.UserRepository;
using UserContext = CommonLib.Context.UserContext;
using AccountingGLCodeDto = BusinessSvcImpl.DataObjects.SpaAccounting.Dto;
using BusinessSvcImpl.DataObjects.SpaAccountingService.Dto;
using BusinessSvcImpl.DataObjects.SpaAccounting.Dto;
using System.Diagnostics;

namespace BusinessSvcImpl.SvcImpl.DocGen.Builders.MaintainGLCode
{
    public class MaintainGLCodeBuilder : CommonBuilder<AccountingGLCodeDto.AccountingGLCode, ExportedMaintainGLCode>
    {
        public const string AccountingGLCodeValue = "AccountingGLCode";
        public const string AppliedFilterIdsKey = "AccountingGLCodeCriterion";


        private bool IsValid(GenerateDocumentRequest generateDocumentRequest)
        {
            if (generateDocumentRequest == null) throw new NullReferenceException("Document Info");

            var values = generateDocumentRequest.Metadata
              .Where(x => x.Value != null)
              .Select(x => x.Value.ToString())
              .ToArray();
            return values.Any(x => x.Equals(AccountingGLCodeValue, StringComparison.Ordinal));
        }

        public override IEnumerable<AccountingGLCodeDto.AccountingGLCode> GetData(GenerateDocumentRequest generateDocumentRequest)
        {
            var service = new SpaAccountingService();

            DocumentMetadata filterTypeData = generateDocumentRequest.Metadata.SingleOrDefault(x => x.Key.Equals(AppliedFilterIdsKey, StringComparison.OrdinalIgnoreCase));
            if (filterTypeData == null || filterTypeData.Value == null) return new List<AccountingGLCodeDto.AccountingGLCode>();

            var context = JsonConvert.DeserializeObject<UserContext>(generateDocumentRequest.UserContext);

            var selectedIdsValue = filterTypeData.Value.ToString();
            var accountingGLCode = JsonConvert.DeserializeObject<AccountingGLCodeCriterion>(selectedIdsValue);
            IList<AccountingGLCodeDto.AccountingGLCode> adjustmentDetail = new List<AccountingGLCodeDto.AccountingGLCode>();
            SearchAccountingGLCodeRequest request = new SearchAccountingGLCodeRequest();


            int? masterClientProfileId = null;

            if (accountingGLCode.ClientNumber.HasValue)
            {

                using (Admin.ServiceProxy.ClientService.ClientServiceClient client = new Admin.ServiceProxy.ClientService.ClientServiceClient())
                {

                    var masterResponse = client.GetMasterProfileForClientNumber(new Admin.ServiceProxy.ClientService.GetMasterProfileClientNumberRequest() { ClientNumber = accountingGLCode.ClientNumber.Value });
                    if (masterResponse != null && masterResponse.MasterClientProfile != null)
                        masterClientProfileId = masterResponse.MasterClientProfile.MasterClientProfileId;
                }
            }

            request.GLCodeSearchParameters = new AccountingGLCode()
            {
                ProductCategory = accountingGLCode.ProductCategory,
                Active = accountingGLCode.Active,
                ProductCodes = accountingGLCode.ProductCodes,
                MasterClientProfileId = masterClientProfileId
            };
            request.PageSize = 10000;
            request.SkipCount = 0;
            SearchAccountingGLCodeResponse glCodeSearch = service.SearchAccountingGLCode(request);

            return glCodeSearch.SearchResult;
        }



        public override ExportedMaintainGLCode MapTToTE(AccountingGLCodeDto.AccountingGLCode accountingGLCodeDetail)
        {
            if (accountingGLCodeDetail == null) throw new ArgumentNullException("arAdjustmentDetail");
            string serviceName = "";
            string feeType = "";
            string productCode = "";
            string clientNumber = "";
            string lineItemName = "";

            if (accountingGLCodeDetail.Service != null)
            {
                serviceName = accountingGLCodeDetail.Service.ServiceName;
            }
            if (accountingGLCodeDetail.LineItem != null)
            {
                lineItemName = accountingGLCodeDetail.LineItem.LineItemName;
            }
            if (accountingGLCodeDetail.FeeType != null)
            {
                feeType = accountingGLCodeDetail.FeeType.FeeTypeName;
            }
            if (accountingGLCodeDetail.Product != null)
            {
                productCode = accountingGLCodeDetail.Product.ProductCode + "-" + accountingGLCodeDetail.Product.ProductName;

            }

            if (accountingGLCodeDetail.MasterClientProfile != null)
            {
                clientNumber = accountingGLCodeDetail.MasterClientProfile.ClientNumber != null ? accountingGLCodeDetail.MasterClientProfile.ClientNumber.ToString() : "";
            }

            var exportedAccountingGLCode = new ExportedMaintainGLCode
            {
                ProductCategory = accountingGLCodeDetail.ProductCategory,
                GLTransType = accountingGLCodeDetail.GLTransType,
                ClientNumber = clientNumber,
                ServiceType = serviceName,
                LineItem = lineItemName,
                FeeType = feeType,
                Product = productCode,
                GLCompany = accountingGLCodeDetail.GLCompany,
                Intercompany = accountingGLCodeDetail.Intercompany,
                Location = accountingGLCodeDetail.LocationCode,
                Operation = accountingGLCodeDetail.Operation,
                Function = accountingGLCodeDetail.Functions,
                NaturalAccount = accountingGLCodeDetail.NaturalAccount,
                EnterpriseClientId = accountingGLCodeDetail.FRU1,
                FRU = accountingGLCodeDetail.FRU2,
                Active = (accountingGLCodeDetail.IsActive) ? "Y" : "N"

            };
            return exportedAccountingGLCode;
        }



        public override string ExportIdentifier
        {
            get { return AccountingGLCodeValue; }
            set { value = AccountingGLCodeValue; }
        }
        private static IList<int> GetSelectedIds(GenerateDocumentRequest generateDocumentRequest, string collectionKey)
        {
            if (generateDocumentRequest == null) throw new ArgumentNullException("generateDocumentRequest");
            if (string.IsNullOrEmpty(collectionKey)) throw new ArgumentNullException("collectionKey");

            DocumentMetadata filterTypeData = generateDocumentRequest.Metadata
              .SingleOrDefault(x => x.Key.Equals(collectionKey, StringComparison.OrdinalIgnoreCase));

            if (filterTypeData == null || filterTypeData.Value == null) return new int[0];

            var selectedIdsValue = filterTypeData.Value.ToString();
            var selectedIds = selectedIdsValue
              .Split(new[] { ',' })
              .Select(x => x.Trim());

            var numericIds = new List<int>();
            foreach (var selectedId in selectedIds)
            {
                int convertedId;
                if (int.TryParse(selectedId, out convertedId))
                {
                    numericIds.Add(convertedId);
                }
            }

            return numericIds;
        }

        public GenerateDocumentResponse GetDocumentRequest()
        {
            return new GenerateDocumentResponse();
        }
    }
    class AccountingGLCodeCriterion
    {
        public string Active { get; set; }
        public string ProductCategory { get; set; }

        public List<int?> ProductCodes { get; set; }

        public int MasterClientProfileId { get; set; }

        public int? ClientNumber { get; set; }
    }
}