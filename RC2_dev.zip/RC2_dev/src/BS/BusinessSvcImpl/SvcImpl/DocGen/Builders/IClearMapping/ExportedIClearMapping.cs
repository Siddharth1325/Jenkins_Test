﻿using BusinessSvcImpl.DataObjects.SpaAccounting.Dto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessSvcImpl.SvcImpl.DocGen.Builders.IClearMapping
{
    public class ExportedIClearMapping
    {
        public string Lob { get; set; }
        public string Category { get; set; }

        public int ClientNumber { get; set; }

        public string LSCINumber { get; set; }

        public string IClearClientCode { get; set; }

        public string Product { get; set; }

        public string ServiceType { get; set; }

        public string ServiceItem { get; set; }

        public string FeeType { get; set; }

        public string Rush { get; set; }
        public string Tax { get; set; }
        public string InspectionResult { get; set; }

        public string MBACode { get; set; }

        public string IClearLineItemCode { get; set; }
       
        
       

    }
}
