﻿using BusinessSvcImpl.DataObjects.SpaAccounting.Dto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessSvcImpl.SvcImpl.DocGen.Builders.MaintainGLCode
{
    public class ExportedMaintainGLCode
    {

        public string ProductCategory { get; set; }

        public string GLTransType { get; set; }

        public string ClientNumber { get; set; }

        public string Product { get; set; }
      
        public string ServiceType { get; set; }

        public string LineItem { get; set; }

        public string FeeType { get; set; }       

        public string GLCompany { get; set; }

        public string Operation { get; set; }

        public string Function { get; set; }

        public string NaturalAccount { get; set; }

        public string Location { get; set; }
        public string Intercompany { get; set; }

        public string EnterpriseClientId { get; set; }

        public string FRU { get; set; }

        public string Active { get; set; }       
        

    }
}
