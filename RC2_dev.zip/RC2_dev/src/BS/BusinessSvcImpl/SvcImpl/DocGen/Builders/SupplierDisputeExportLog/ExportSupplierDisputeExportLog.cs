﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessSvcImpl.SvcImpl.DocGen.Builders.SupplierDisputeExportLog
{
    public class ExportSupplierDisputeExportLog
    {
        public string FieldScapeWO { get; set; }
        public string AssetShieldInspectionWO { get; set; }
        public string AssetShieldPreservationVendorWO { get; set; }
        public string DisputedAmount { get; set; }
        public string DisputeReason { get; set; }
        public string DisputeComments { get; set; }
        public string Result { get; set; }
        public string Message { get; set; }
    }
}
