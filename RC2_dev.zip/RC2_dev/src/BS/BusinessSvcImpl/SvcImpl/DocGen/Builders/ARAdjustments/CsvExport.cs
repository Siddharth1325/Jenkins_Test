﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.SqlTypes;
using System.Reflection;
using System.Text;

namespace BusinessSvcImpl.SvcImpl.DocGen.Builders.ARAdjustments
{
    public class CsvExport<T> where T : class
    {
        private List<T> Objects;

        public CsvExport(IEnumerable<T> objects)
        {
            Objects = new List<T>(objects);
        }

        public string Export()
        {
            return Export(true);
        }

        public string Export(bool includeHeaderLine)
        {

            StringBuilder sb = new StringBuilder();
            //Get properties using reflection.
            IList<PropertyInfo> propertyInfos = typeof(T).GetProperties();

            if (includeHeaderLine)
            {
                //add header line.
                foreach (PropertyInfo propertyInfo in propertyInfos)
                {
                    var tempDescriptionAttribute =
                        ((DescriptionAttribute)
                            Attribute.GetCustomAttribute(propertyInfo, typeof(DescriptionAttribute)));
                    if (null != tempDescriptionAttribute && !String.IsNullOrEmpty(tempDescriptionAttribute.Description))
                        sb.Append(MakeValueCsvFriendly(tempDescriptionAttribute.Description)).Append(",");
                    else
                        sb.Append(propertyInfo.Name).Append(",");
                }
                sb.Remove(sb.Length - 1, 1).AppendLine();
            }

            //add value for each property.
            foreach (T obj in Objects)
            {
                foreach (PropertyInfo propertyInfo in propertyInfos)
                {
                    sb.Append(MakeValueCsvFriendly(propertyInfo.GetValue(obj, null))).Append(",");
                }
                sb.Remove(sb.Length - 1, 1).AppendLine();
            }

            return sb.ToString();
        }

        public byte[] ExportToBytes()
        {
            return Encoding.UTF8.GetBytes(Export());
        }

        private static string MakeValueCsvFriendly(object value)
        {
            if (value == null) return "";
            if (value is Nullable && ((INullable)value).IsNull) return "";

            if (value is DateTime)
            {
                return
                  ((DateTime)value).ToString(((DateTime)value).TimeOfDay.TotalSeconds == 0
                    ? "yyyy-MM-dd"
                    : "yyyy-MM-dd HH:mm:ss");
            }
            var output = value.ToString();

            if (output.Contains(",") || output.Contains("\""))
                output = '"' + output.Replace("\"", "\"\"") + '"';

            return output;

        }
    }
}