﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessSvcImpl.SvcImpl.DocGen.Builders.SupplierDisputeSearch
{
    public class ExportSupplierDisputeSearch
    {
        [Description("Bulk Id")]
        public int BulkId { get; set; }
        [Description("Dispute Id")]
        public int SupplierDisputeId { get; set; }
        [Description("Dispute Date")]
        public string DisputeDate { get; set; }
        [Description("Vendor Id")]
        public int VendorId { get; set; }

        [Description("Vendor Name")]
        public string VendorName{ get; set; }
        [Description("Property Address1")]
        public string PropertyAddress1{ get; set; }
        [Description("Property Address2")]
        public string PropertyAddress2{ get; set; }
        [Description("Property City")]
        public string PropertyCity{ get; set; }
        [Description("Property State")]
        public string PropertyState{ get; set; }
        [Description("Property Zip")]
        public string PropertyZip { get; set; }

        [Description("FieldScape WO#")]
        public int? FieldScapeWorkOrderId { get; set; }
        [Description("AssetShield Inspection WO#")]
        public int? InspWorkOrderId { get; set; }
        [Description("AssetShield Preservation VWO#")]
        public int? VendorWorkOrderId { get; set; }

        [Description("Product Name")]
        public string ProductName { get; set; }
        [Description("Client #")]
        public string ClientNumber { get; set; }
        [Description("Dispute Amount")]
        public decimal? DisputeAmount { get; set; }

        [Description("Dispute Comments")]
        public string VendorDisputeComments { get; set; }
        [Description("SLFS Response to Vendor")]
        public string SLFSResponseToVendor { get; set; }
        [Description("Vendor Escalation Comments")]
        public string EscalationComments { get; set; }
        [Description("SLFS Escalation Response to Vendor")]
        public string SLFSResponseToEscalation { get; set; }

        public string Decision { get; set; }
        public string Resolution { get; set; }

        [Description("Dispute Completed Date")]
        public string DisputeCompletedDate { get; set; }

        [Description("Escalation Decision")]
        public string EscalationDecision { get; set; }

        [Description("Escalation Resolution")]
        public string EscalationResolutionStatus { get; set; }
        [Description("Escalation Completed Date")]
        public string EscalationCompleteDate { get; set; }
        [Description("Additional Amount Approved")]
        public decimal? AdditionalAmtApproved { get; set; }

        //public string DisputeDueDate { get; set; }
        //public string DisputeStatus { get; set; }
        //public string DisputeStatusType { get; set; }
        //public string EscalationResolutionStatusType { get; set; }
        //public string EscalationDueDate { get; set; }
        //public string DisputeReason { get; set; }
        //public string DisputeResolutionType { get; set; }
        //public string DisputeResolution { get; set; }
        //public string EscalationDate { get; set; }

    }
}
