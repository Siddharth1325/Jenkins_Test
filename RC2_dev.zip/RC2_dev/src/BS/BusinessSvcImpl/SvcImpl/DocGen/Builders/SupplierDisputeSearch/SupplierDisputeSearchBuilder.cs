﻿using BusinessSvcImpl.DataObjects.DocGen;
using BusinessSvcImpl.SvcImpl.SpaAcc;
using CommonLib.Context;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DisputeDto = BusinessSvcImpl.DataObjects.SpaAccounting.Dto;
using DisputeServiceDto = BusinessSvcImpl.DataObjects.SpaAccountingService.Dto;
using BusinessSvcImpl.DataObjects.SpaAccountingService.Dto;
using System.IO;
using CommonLib;

namespace BusinessSvcImpl.SvcImpl.DocGen.Builders.SupplierDisputeSearch
{
    public class SupplierDisputeSearchBuilder : CommonBuilder<DisputeDto.SupplierDisputeSearchResult, ExportSupplierDisputeSearch>
    {
        public const string SupplierDisputeSearchValue = "SupplierDisputeSearch";
        public const string AppliedFilterIdsKey = "SupplierDisputeSearchCriterion";

        private bool IsValid(GenerateDocumentRequest generateDocumentRequest)
        {
            if (generateDocumentRequest == null) throw new NullReferenceException("Document Info");

            var values = generateDocumentRequest.Metadata
              .Where(x => x.Value != null)
              .Select(x => x.Value.ToString())
              .ToArray();
            return values.Any(x => x.Equals(SupplierDisputeSearchValue, StringComparison.Ordinal));
        }
        public override IEnumerable<DisputeDto.SupplierDisputeSearchResult> GetData(GenerateDocumentRequest generateDocumentRequest)
        {
            DocumentMetadata filterTypeData = generateDocumentRequest.Metadata.SingleOrDefault(x => x.Key.Equals(AppliedFilterIdsKey, StringComparison.OrdinalIgnoreCase));
            var context = JsonConvert.DeserializeObject<UserContext>(generateDocumentRequest.UserContext);
            if (filterTypeData == null || filterTypeData.Value == null) return new List<DisputeDto.SupplierDisputeSearchResult>();

            var selectedIdsValue = filterTypeData.Value.ToString();
            var dispute = JsonConvert.DeserializeObject<DisputeDto.SupplierDisputeSearchInput>(selectedIdsValue);
                       
            DisputeServiceDto.GetSupplierDisputeSearchRequest request = new DisputeServiceDto.GetSupplierDisputeSearchRequest();
            
            request.SearchInput = dispute; // DisputeDto;
            request.PageSize = 10000;
            request.SkipCount = 0;
            request.PageNumber = 1;
            var service = new SpaAcc.SpaAccountingService();
            GetSupplierDisputeSearchResponse response = service.GetSupplierDisputeSearchResults(request);
            return response.SearchResults;
        }

        public override string ExportIdentifier
        {
            get { return SupplierDisputeSearchValue; }
            set { value = SupplierDisputeSearchValue; }
        }

        public override ExportSupplierDisputeSearch MapTToTE(DisputeDto.SupplierDisputeSearchResult dispute)
        {
            if (dispute == null) throw new ArgumentNullException("databaseChangeLog");


            var exportedLoan = new ExportSupplierDisputeSearch
            {
                SupplierDisputeId = dispute.SupplierDisputeId,
                BulkId = dispute.BulkId,
                VendorId = dispute.VendorId,
                FieldScapeWorkOrderId = dispute.FieldScapeWorkOrderId,
                InspWorkOrderId = dispute.InspWorkOrderId,
                VendorWorkOrderId = dispute.VendorWorkOrderId,
                DisputeDate = dispute.DisputeDate.HasValue ? dispute.DisputeDate.Value.ToString("MM/dd/yyyy") : string.Empty,
                //DisputeDueDate = dispute.DisputeDueDate.HasValue ? dispute.DisputeDueDate.Value.ToString("MM/dd/yyyy hh:mm tt") : string.Empty,
                //DisputeStatus = dispute.DisputeStatus,
                //DisputeStatusType = dispute.DisputeStatusType,
                //EscalationResolutionStatusType = dispute.EscalationResolutionStatusType,
                EscalationResolutionStatus = dispute.EscalationResolutionStatus,
                //EscalationDueDate = dispute.EscalationDueDate.HasValue ? dispute.EscalationDueDate.Value.ToString("MM/dd/yyyy hh:mm tt") : string.Empty,
                AdditionalAmtApproved = dispute.AdditionalAmtApproved,
                //DisputeReason = dispute.DisputeReason,
                VendorDisputeComments = dispute.VendorDisputeComments,
                //DisputeResolutionType = dispute.DisputeResolutionType,
                //DisputeResolution = dispute.DisputeResolution,
                DisputeCompletedDate = dispute.DisputeCompletedDate.HasValue ? dispute.DisputeCompletedDate.Value.ToString("MM/dd/yyyy") : string.Empty,
                SLFSResponseToVendor = dispute.SLFSResponseToVendor,
                EscalationCompleteDate = dispute.EscalationCompleteDate.HasValue ? dispute.EscalationCompleteDate.Value.ToString("MM/dd/yyyy") : string.Empty,
                EscalationComments = dispute.EscalationComments,
                //EscalationDate = dispute.EscalationDate.HasValue ? dispute.EscalationDate.Value.ToString("MM/dd/yyyy hh:mm tt") : string.Empty,
                SLFSResponseToEscalation = dispute.SLFSEscalationComments,

                VendorName = dispute.VendorName,
                PropertyAddress1 = dispute.PropertyAddress1,
                PropertyAddress2 = dispute.PropertyAddress2,
                PropertyCity = dispute.PropertyCity,
                PropertyState = dispute.PropertyState,
                PropertyZip = dispute.PropertyZip,
                ProductName = dispute.ProductName,
                ClientNumber = dispute.ClientNumber,
                DisputeAmount = dispute.DisputeAmount,
                Decision = dispute.Decision,
                Resolution = dispute.Resolution,
                EscalationDecision = dispute.EscalationDecision
            };
            return exportedLoan;
        }
        public override GeneratedDocumentInfo GenerateDocument(DataObjects.DocGen.GenerateDocumentRequest request)
        {
            if (IsValid(request) == false) throw new ArgumentException("Request is not valid", "request");

            GeneratedDocumentInfo generatedDocumentInfo;
            try
            {
                int createdById = GetCurrentUserId(request);
                var createdDate = DateTime.Now;
                var documentName = string.Format("{0}_{1:yyyy_MM_dd_hh_mm_ss_tt}.xlsx", SupplierDisputeSearchValue, DateTime.Now);
                var mimeType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                var description = "Supplier dispute export log data.";
                var documentType = "Other";

                var searchResult = GetData(request);
                List<ExportSupplierDisputeSearch> exportResults = new List<ExportSupplierDisputeSearch>();
                foreach(var res in searchResult)
                {
                    var exportResult = MapTToTE(res);
                    exportResults.Add(exportResult);
                }
                var excel = new ExcelExport<ExportSupplierDisputeSearch>(exportResults);
                var fileData = excel.ExportToBytes();
                var success = (fileData.Length > 0);
                generatedDocumentInfo = new GeneratedDocumentInfo(documentName, description, documentType, mimeType, createdById, createdDate, success, fileData);

            }

            catch (IOException ex)
            {
                Logging.LogError(ex);
                throw;
            }
            return generatedDocumentInfo;
        }
    }
}
