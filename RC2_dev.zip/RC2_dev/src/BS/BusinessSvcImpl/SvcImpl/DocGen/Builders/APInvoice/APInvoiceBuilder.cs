﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Authentication;
using BusinessSvcImpl.DataObjects.DocGen;
using BusinessSvcImpl.SvcImpl.SpaAcc;
//using IbmBpmRestApi.ServiceProxy.Reference;
using Newtonsoft.Json;
using User.ServiceProxy.UserRepository;
using UserContext = CommonLib.Context.UserContext;
using APInvoiceDto = BusinessSvcImpl.DataObjects.SpaAccounting.Dto;
using BusinessSvcImpl.DataObjects.SpaAccountingService.Dto;
using BusinessSvcImpl.DataObjects.SpaAccounting.Dto;
using InspectionDto = Inspections.ServiceProxy.InspectionSvc;
using System.Diagnostics;
using ProductDto = Admin.ServiceProxy.ProductService;
using System.Globalization;

namespace BusinessSvcImpl.SvcImpl.DocGen.Builders.APInvoice
{
    public class APInvoiceBuilder : CommonBuilder<APInvoiceDto.APInvoice, ExportedAPInvoice>
    {
        public const string APInvoiceValue = "APInvoice";
        public const string AppliedFilterIdsKey = "APInvoiceCriterion";


        private bool IsValid(GenerateDocumentRequest generateDocumentRequest)
        {
            if (generateDocumentRequest == null) throw new NullReferenceException("Document Info");

            var values = generateDocumentRequest.Metadata
              .Where(x => x.Value != null)
              .Select(x => x.Value.ToString())
              .ToArray();
            return values.Any(x => x.Equals(APInvoiceValue, StringComparison.Ordinal));
        }

        public override IEnumerable<APInvoiceDto.APInvoice> GetData(GenerateDocumentRequest generateDocumentRequest)
        {
            var service = new SpaAccountingService();

            DocumentMetadata filterTypeData = generateDocumentRequest.Metadata.SingleOrDefault(x => x.Key.Equals(AppliedFilterIdsKey, StringComparison.OrdinalIgnoreCase));
            if (filterTypeData == null || filterTypeData.Value == null) return new List<APInvoiceDto.APInvoice>();

            var context = JsonConvert.DeserializeObject<UserContext>(generateDocumentRequest.UserContext);

            var selectedIdsValue = filterTypeData.Value.ToString();
            var apInvoiceSearchFilter = JsonConvert.DeserializeObject<APInvoiceCriterion>(selectedIdsValue);
            IList<APInvoiceDto.APInvoice> payableInvoiceDetailList = new List<APInvoiceDto.APInvoice>();
            GetAPInvoiceDetailsRequest request = new GetAPInvoiceDetailsRequest() { InvoiceNumber = apInvoiceSearchFilter.InvoiceNumber, vendorProfile = int.Parse(apInvoiceSearchFilter.VendorNumber) ,PageSize=10000,SkipCount=0};
            GetAPInvoiceDetailsResponse serviceResponse = service.GetAPInvoiceDetails(request);

            foreach (var payableDetail in serviceResponse.PayableList)
            {
                payableInvoiceDetailList.Add(new APInvoiceDto.APInvoice()
                {
                    WorkOrderNumber = payableDetail.WorkOrderId.ToString(),
                    AssignedDate = payableDetail.AssignedDate == null ? "" : payableDetail.AssignedDate.Value.ToString("MM/dd/yyyy"),
                    CompletedDate = payableDetail.CompletedDate == null ? "" : payableDetail.CompletedDate.Value.ToString("MM/dd/yyyy"),
                    InspectorUniqueId = payableDetail.InspectorUniqueId,
                    ProductCode = payableDetail.ProductName,
                    PropertyAddress = payableDetail.PropertyAddress,
                    PriceAdjReason = payableDetail.PriceAdjReason,
                    InvoiceAmount = payableDetail.InvoiceAmount.ToString(),
                    QCSupplierComment = payableDetail.QCSupplierComment
                });
            }
            payableInvoiceDetailList = payableInvoiceDetailList.OrderBy(x => x.WorkOrderNumber).ToList();
            return payableInvoiceDetailList;
        }



        public override ExportedAPInvoice MapTToTE(APInvoiceDto.APInvoice apInvoice)
        {
            if (apInvoice == null) throw new ArgumentNullException("apInvoice");

            var exportedAccountingAdjustmentCode = new ExportedAPInvoice
            {
                WorkOrderNumber = apInvoice.WorkOrderNumber,
                InspectorUniqueID = apInvoice.InspectorUniqueId,
                InvoiceAmount = apInvoice.InvoiceAmount,
                AssignedDate = apInvoice.AssignedDate,
                CompletedDate = apInvoice.CompletedDate,
                ProductCode = apInvoice.ProductCode,
                PriceAdjReason = apInvoice.PriceAdjReason,
                //Occupancy = apInvoice.Occupancy,
                PropertyAddress = apInvoice.PropertyAddress,
                QCSupplierComment=apInvoice.QCSupplierComment

            };
            return exportedAccountingAdjustmentCode;
        }



        public override string ExportIdentifier
        {
            get { return APInvoiceValue; }
            set { value = APInvoiceValue; }
        }
        private static IList<int> GetSelectedIds(GenerateDocumentRequest generateDocumentRequest, string collectionKey)
        {
            if (generateDocumentRequest == null) throw new ArgumentNullException("generateDocumentRequest");
            if (string.IsNullOrEmpty(collectionKey)) throw new ArgumentNullException("collectionKey");

            DocumentMetadata filterTypeData = generateDocumentRequest.Metadata
              .SingleOrDefault(x => x.Key.Equals(collectionKey, StringComparison.OrdinalIgnoreCase));

            if (filterTypeData == null || filterTypeData.Value == null) return new int[0];

            var selectedIdsValue = filterTypeData.Value.ToString();
            var selectedIds = selectedIdsValue
              .Split(new[] { ',' })
              .Select(x => x.Trim());

            var numericIds = new List<int>();
            foreach (var selectedId in selectedIds)
            {
                int convertedId;
                if (int.TryParse(selectedId, out convertedId))
                {
                    numericIds.Add(convertedId);
                }
            }

            return numericIds;
        }

        public GenerateDocumentResponse GetDocumentRequest()
        {
            return new GenerateDocumentResponse();
        }
    }
    class APInvoiceCriterion
    {
        public string InvoiceNumber { get; set; }
        public string VendorNumber { get; set; }
    }
}