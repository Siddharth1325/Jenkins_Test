﻿using RemittanceDto = DomainModel.Common.Dto;
using BusinessSvcImpl.DataObjects.DocGen;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Delegate.SpaAcc;
using DomCommon = DomainModel.Accounting;
using Newtonsoft.Json;
using BusinessSvcImpl.SvcImpl.DocGen.Builders.Order;
using BusinessSvcImpl.SvcImpl.DocGen.Builders.ARAdjustments;
using System.IO;
using System.Web.Script.Serialization;
using RemittanceServiceDto = BusinessSvcImpl.DataObjects.SpaAccountingService.Dto;
using BusinessSvcImpl.SvcImpl.SpaAcc;
using UserContext = CommonLib.Context.UserContext;
using System.Diagnostics;

namespace BusinessSvcImpl.SvcImpl.DocGen.Builders.VendorRemittance
{
    class VendorRemittanceInvoiceInternUsersBuilder : CommonBuilder<RemittanceDto.RemittanceSearchResponse, ExportedVendorRemittanceInternUserInvoiceView>
    {
        public const string VendorRemittanceInternUserInvoiceSearchValue = "act.GetVendorPaymentRemittanceInternUser";
        public const string AppliedFilterIdsKey = "VendorRemittanceSearchCriterion";

        private bool IsValid(GenerateDocumentRequest generateDocumentRequest)
        {
            if (generateDocumentRequest == null) throw new NullReferenceException("Document Info");

            var values = generateDocumentRequest.Metadata
              .Where(x => x.Value != null)
              .Select(x => x.Value.ToString())
              .ToArray();
            return values.Any(x => x.Equals(VendorRemittanceInternUserInvoiceSearchValue, StringComparison.Ordinal));
        }

        public override IEnumerable<RemittanceDto.RemittanceSearchResponse> GetData(GenerateDocumentRequest generateDocumentRequest)
        {
            DocumentMetadata filterTypeData = generateDocumentRequest.Metadata.SingleOrDefault(x => x.Key.Equals(AppliedFilterIdsKey, StringComparison.OrdinalIgnoreCase));
            var context = JsonConvert.DeserializeObject<UserContext>(generateDocumentRequest.UserContext);
            if (filterTypeData == null || filterTypeData.Value == null) return new List<RemittanceDto.RemittanceSearchResponse>();

            var selectedIdsValue = filterTypeData.Value.ToString();
            var remittance = JsonConvert.DeserializeObject<VendorRemittanceSearchCriterion>(selectedIdsValue);

            RemittanceDto.RemittanceSearchRequest remittanceDto = new RemittanceDto.RemittanceSearchRequest();
            RemittanceServiceDto.GetRemittanceSearchRequest request = new RemittanceServiceDto.GetRemittanceSearchRequest();

            remittanceDto.Check = string.IsNullOrWhiteSpace(remittance.Check) ? null : remittance.Check;
            remittanceDto.InspWorkOrderId = string.IsNullOrWhiteSpace(remittance.InspWorkOrderId) ? null : remittance.InspWorkOrderId;
            remittanceDto.PresWorkOrderId = string.IsNullOrWhiteSpace(remittance.PresWorkOrderId) ? null : remittance.PresWorkOrderId;
            remittanceDto.VendorProfileId = remittance.VendorProfileId;
            remittanceDto.VendorName = string.IsNullOrWhiteSpace(remittance.VendorName) ? null : remittance.VendorName;
            remittanceDto.Loan = string.IsNullOrWhiteSpace(remittance.Loan) ? null : remittance.Loan;
            remittanceDto.InvoiceDateTo = remittance.InvoiceDateTo;
            remittanceDto.InvoiceDateFrom = remittance.InvoiceDateFrom;
            remittanceDto.ChkDateTo = remittance.ChkDateTo;
            remittanceDto.ChkDateFrom = remittance.ChkDateFrom;
            remittanceDto.Lobs = string.IsNullOrWhiteSpace(remittance.Lobs) ? null : remittance.Lobs;
            remittanceDto.SubmissionFromDate = remittance.SubmissionFromDate;
            remittanceDto.SubmissionToDate = remittance.SubmissionToDate;
            remittanceDto.ViewType = remittance.ViewType;
            remittanceDto.InvoiceNumber = remittance.ApInvoiceNumber;
            remittance.OracleId = remittance.OracleId;
            request.VendorRemittanceSearchRequest = remittanceDto;
            request.PageNumber = 0;
            request.PageSize = 10000;
            request.SkipCount = 0;
            var service = new SpaAccountingService();
            RemittanceServiceDto.GetRemittanceSearchResponse orderSearch = service.GetRemittanceSearchResults(request);

            return orderSearch.VendorRemittanceSearchResponse;
        }

        public override string ExportIdentifier
        {
            get { return VendorRemittanceInternUserInvoiceSearchValue; }
            set { value = VendorRemittanceInternUserInvoiceSearchValue; }
        }

        public override ExportedVendorRemittanceInternUserInvoiceView MapTToTE(RemittanceDto.RemittanceSearchResponse remittance)
        {
            if (remittance == null) throw new ArgumentNullException("databaseChangeLog");


            var exportedInvoiceRemittance = new ExportedVendorRemittanceInternUserInvoiceView
            {
                VendorNumber = remittance.VendorProfileId,
                InvoiceNumber = remittance.InvoiceNumber,
                InvoiceDate = (remittance.InvoiceDate.HasValue) ? remittance.InvoiceDate.Value.ToString("MM/dd/yyyy") : string.Empty,
                InvoiceAmount = remittance.InvoiceAmountStr,
                CheckNumber = remittance.CheckNumber,
                CheckDate = (remittance.CheckDate.HasValue) ? remittance.CheckDate.Value.ToString("MM/dd/yyyy") : string.Empty,
                CheckComment = remittance.CheckComments,
                OracleId = remittance.OracleId,
                OracleSiteCode = remittance.OracleSiteCode
            };
            return exportedInvoiceRemittance;
        }

    }
}
