﻿using BusinessSvcImpl.DataObjects.SpaAccounting.Dto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessSvcImpl.SvcImpl.DocGen.Builders.IMChaseMapping
{
    public class ExportedIMChaseMapping
    {
        public string Lob { get; set; }
        public int ClientNumber { get; set; }

        public string LSCINumber { get; set; }

        public string RequestorCode { get; set; }

        public string MBACode { get; set; }
        public string Tax { get; set; }

        public string Rush { get; set; }

        public string Product { get; set; }
        public string ServiceType { get; set; }
        public string ServiceItem { get; set; }

        public string FeeType { get; set; }

        public string IMInvoiceType { get; set; }

        public string IMOrderType { get; set; }

        public string IMLineItemNumber { get; set; }

     
        
      
    }
}
