﻿using BusinessSvcImpl.DataObjects.DocGen;
using BusinessSvcImpl.SvcImpl.SpaAcc;
using CommonLib.Context;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DisputeDto = BusinessSvcImpl.DataObjects.SpaAccounting.Dto;
using DisputeServiceDto = BusinessSvcImpl.DataObjects.SpaAccountingService.Dto;
using BusinessSvcImpl.DataObjects.SpaAccountingService.Dto;
using System.IO;
using CommonLib;

namespace BusinessSvcImpl.SvcImpl.DocGen.Builders.SupplierDisputeExportLog
{
    public class SupplierDisputeExportLogBuilder : BuilderBase
    {
        public const string SupplierDisputeExportLog = "SupplierDisputeExportLog";
        public const string AppliedFilterIdsKey = "SupplierDisputeExportLogCriterion";

        private bool IsValid(GenerateDocumentRequest generateDocumentRequest)
        {
            if (generateDocumentRequest == null) throw new NullReferenceException("Document Info");

            var values = generateDocumentRequest.Metadata
              .Where(x => x.Value != null)
              .Select(x => x.Value.ToString())
              .ToArray();
            return values.Any(x => x.Equals(SupplierDisputeExportLog, StringComparison.Ordinal));
        }

        public override GeneratedDocumentInfo GenerateDocument(DataObjects.DocGen.GenerateDocumentRequest request)
        {
            if (IsValid(request) == false) throw new ArgumentException("Request is not valid", "request");

            GeneratedDocumentInfo generatedDocumentInfo;
            try
            {
                int createdById = GetCurrentUserId(request);
                var createdDate = DateTime.Now;
                var documentName = string.Format("{0}_{1:yyyy_MM_dd_hh_mm_ss_tt}.xlsx", SupplierDisputeExportLog, DateTime.Now);
                var mimeType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                var description = "Supplier dispute export log data.";
                var documentType = "Other";

                var LogsToExport = GetDataToExport(request);
                var excel = new ExcelExport<ExportSupplierDisputeExportLog>(LogsToExport);
                var fileData = excel.ExportToBytes();
                var success = (fileData.Length > 0);
                generatedDocumentInfo = new GeneratedDocumentInfo(documentName, description, documentType, mimeType, createdById, createdDate, success, fileData);

            }

            catch (IOException ex)
            {
                Logging.LogError(ex);
                throw;
            }
            return generatedDocumentInfo;
        }

        public IEnumerable<ExportSupplierDisputeExportLog> GetDataToExport(GenerateDocumentRequest generateDocumentRequest)
        {
            DocumentMetadata filterTypeData = generateDocumentRequest.Metadata.SingleOrDefault(x => x.Key.Equals(AppliedFilterIdsKey, StringComparison.OrdinalIgnoreCase));
            var context = JsonConvert.DeserializeObject<UserContext>(generateDocumentRequest.UserContext);
            if (filterTypeData == null || filterTypeData.Value == null) return new List<ExportSupplierDisputeExportLog>();

            var selectedIdsValue = filterTypeData.Value.ToString();
            var dispute = JsonConvert.DeserializeObject<SupplierDisputeExportLogInput>(selectedIdsValue);

            DisputeServiceDto.GetSupplierDisputeExportLogRequest request = new DisputeServiceDto.GetSupplierDisputeExportLogRequest();

            request.SearchInput = dispute; 
            request.PageSize = 10000;
            request.SkipCount = 0;
            request.PageNumber = 1;
            var service = new SpaAcc.SpaAccountingService();
            GetSupplierDisputeExportLogResponse response = service.GetSupplierDisputeExportLogResults(request);
            List<ExportSupplierDisputeExportLog> responseList = new List<ExportSupplierDisputeExportLog>();
            foreach(var item in response.SearchResults)
            {
                var exportedLoan = new ExportSupplierDisputeExportLog
                {
                    FieldScapeWO = item.FieldScapeWO,
                    AssetShieldInspectionWO = item.AssetShieldInspectionWO,
                    AssetShieldPreservationVendorWO = item.AssetShieldPreservationVendorWO,
                    DisputedAmount = item.DisputedAmount,
                    DisputeReason = item.DisputeReason,
                    DisputeComments = item.DisputeComments,
                    Result = item.Result,
                    Message = item.Message,
                };
                responseList.Add(exportedLoan);
            }

            return responseList;
        }
    }
}
