﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Authentication;
using BusinessSvcImpl.DataObjects.DocGen;
using BusinessSvcImpl.SvcImpl.SpaAcc;
//using IbmBpmRestApi.ServiceProxy.Reference;
using Newtonsoft.Json;
using User.ServiceProxy.UserRepository;
using UserContext = CommonLib.Context.UserContext;
using IMChaseMappingDto = BusinessSvcImpl.DataObjects.SpaAccounting.Dto;
using BusinessSvcImpl.DataObjects.SpaAccountingService.Dto;
using BusinessSvcImpl.DataObjects.SpaAccounting.Dto;
using System.Diagnostics;

namespace BusinessSvcImpl.SvcImpl.DocGen.Builders.IMChaseMapping
{
    public class IMChaseMappingBuilder : CommonBuilder<IMChaseMappingDto.IMChaseMappingView, ExportedIMChaseMapping>
    {
        public const string IMChaseMappingValue = "IMChaseMapping";
        public const string AppliedFilterIdsKey = "IMChaseMappingCriterion";


        private bool IsValid(GenerateDocumentRequest generateDocumentRequest)
        {
            if (generateDocumentRequest == null) throw new NullReferenceException("Document Info");

            var values = generateDocumentRequest.Metadata
              .Where(x => x.Value != null)
              .Select(x => x.Value.ToString())
              .ToArray();
            return values.Any(x => x.Equals(IMChaseMappingValue, StringComparison.Ordinal));
        }

        public override IEnumerable<IMChaseMappingDto.IMChaseMappingView> GetData(GenerateDocumentRequest generateDocumentRequest)
        {
            var service = new SpaAccountingService();

            DocumentMetadata filterTypeData = generateDocumentRequest.Metadata.SingleOrDefault(x => x.Key.Equals(AppliedFilterIdsKey, StringComparison.OrdinalIgnoreCase));
            if (filterTypeData == null || filterTypeData.Value == null) return new List<IMChaseMappingDto.IMChaseMappingView>();

            var context = JsonConvert.DeserializeObject<UserContext>(generateDocumentRequest.UserContext);

            var selectedIdsValue = filterTypeData.Value.ToString();
            var chaseMapping = JsonConvert.DeserializeObject<IMChaseMappingCriterion>(selectedIdsValue);
            IList<IMChaseMappingDto.IMChaseMappingView> adjustmentDetail = new List<IMChaseMappingDto.IMChaseMappingView>();
            GetIMChaseMappingRequest request = new GetIMChaseMappingRequest() { ClientId = chaseMapping.ClientId, LSCINumber = chaseMapping.LSCINumber };
            request.PageSize = 10000;
            request.SkipCount=0;
            GetIMChaseMappingResponse glCodeSearch = service.SearchIMChaseMapping(request);

            return glCodeSearch.Result;
        }



        public override ExportedIMChaseMapping MapTToTE(IMChaseMappingDto.IMChaseMappingView iMChaseMappingDetail)
        {
            if (iMChaseMappingDetail == null) throw new ArgumentNullException("iMChaseMappingDetail");

            var exportedAccountingGLCode = new ExportedIMChaseMapping
            {
                Lob = iMChaseMappingDetail.LOBType,
                ClientNumber = iMChaseMappingDetail.ClientNumber,
                LSCINumber = iMChaseMappingDetail.ClientLSCI,
                RequestorCode = iMChaseMappingDetail.RequestorCode,
                MBACode = iMChaseMappingDetail.MBACodeType,
                Tax = Convert.ToBoolean(iMChaseMappingDetail.IsTax) ? "Yes" : "",
                Rush = Convert.ToBoolean(iMChaseMappingDetail.IsRush) ? "Yes" : "",
                Product = iMChaseMappingDetail.Product,
                ServiceType = iMChaseMappingDetail.ServiceName,
                ServiceItem = iMChaseMappingDetail.ServiceItem,
                FeeType = iMChaseMappingDetail.FeeTypeName,
                IMInvoiceType = iMChaseMappingDetail.IMInvoiceType,
                IMOrderType = iMChaseMappingDetail.IMOrderType,
                IMLineItemNumber = iMChaseMappingDetail.IMLineItem                

            };
            return exportedAccountingGLCode;
        }



        public override string ExportIdentifier
        {
            get { return IMChaseMappingValue; }
            set { value = IMChaseMappingValue; }
        }
        private static IList<int> GetSelectedIds(GenerateDocumentRequest generateDocumentRequest, string collectionKey)
        {
            if (generateDocumentRequest == null) throw new ArgumentNullException("generateDocumentRequest");
            if (string.IsNullOrEmpty(collectionKey)) throw new ArgumentNullException("collectionKey");

            DocumentMetadata filterTypeData = generateDocumentRequest.Metadata
              .SingleOrDefault(x => x.Key.Equals(collectionKey, StringComparison.OrdinalIgnoreCase));

            if (filterTypeData == null || filterTypeData.Value == null) return new int[0];

            var selectedIdsValue = filterTypeData.Value.ToString();
            var selectedIds = selectedIdsValue
              .Split(new[] { ',' })
              .Select(x => x.Trim());

            var numericIds = new List<int>();
            foreach (var selectedId in selectedIds)
            {
                int convertedId;
                if (int.TryParse(selectedId, out convertedId))
                {
                    numericIds.Add(convertedId);
                }
            }

            return numericIds;
        }

        public GenerateDocumentResponse GetDocumentRequest()
        {
            return new GenerateDocumentResponse();
        }
    }
    class IMChaseMappingCriterion
    {
        public string ClientId { get; set; }
        public string LSCINumber { get; set; }
    }
}