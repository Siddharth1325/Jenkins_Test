﻿using BusinessSvcImpl.DataObjects.DocGen;
using BusinessSvcImpl.SvcImpl.SpaAcc;
using CommonLib.Context;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DisputeDto = BusinessSvcImpl.DataObjects.SpaAccounting.Dto;
using DisputeServiceDto = BusinessSvcImpl.DataObjects.SpaAccountingService.Dto;
using BusinessSvcImpl.DataObjects.SpaAccountingService.Dto;
using System.IO;
using CommonLib;

namespace BusinessSvcImpl.SvcImpl.DocGen.Builders.RRRInvoiceDecision
{
    public class DRTExportBuilder : CommonBuilder<DisputeDto.InvoiceDecisionSearchResult, DRTEPOXRT>
    {
        public const string DRTExportValue = "DRTExport";
        public const string AppliedFilterIdsKey = "InvoiceDecisionSearchCriterion";

        private bool IsValid(GenerateDocumentRequest generateDocumentRequest)
        {
            if (generateDocumentRequest == null) throw new NullReferenceException("Document Info");

            var values = generateDocumentRequest.Metadata
              .Where(x => x.Value != null)
              .Select(x => x.Value.ToString())
              .ToArray();
            return values.Any(x => x.Equals(DRTExportValue, StringComparison.Ordinal));
        }
        public override IEnumerable<DisputeDto.InvoiceDecisionSearchResult> GetData(GenerateDocumentRequest generateDocumentRequest)
        {
            DocumentMetadata filterTypeData = generateDocumentRequest.Metadata.SingleOrDefault(x => x.Key.Equals(AppliedFilterIdsKey, StringComparison.OrdinalIgnoreCase));
            var context = JsonConvert.DeserializeObject<UserContext>(generateDocumentRequest.UserContext);
            if (filterTypeData == null || filterTypeData.Value == null) return new List<DisputeDto.InvoiceDecisionSearchResult>();

            var selectedIdsValue = filterTypeData.Value.ToString();
            var invDecision = JsonConvert.DeserializeObject<DisputeDto.InvoiceDecisionSearchInput>(selectedIdsValue);

            DisputeServiceDto.GetInvoiceDecisionSearchRequest request = new DisputeServiceDto.GetInvoiceDecisionSearchRequest();

            request.SearchInput = invDecision; 
            request.PageSize = 10000;
            request.SkipCount = 0;
            request.PageNumber = 1;
            var service = new SpaAcc.SpaAccountingService();
            GetInvoiceDecisionSearchResponse response = service.GetInvoiceDecisionSearchResults(request);
            return response.SearchResults;
        }

        public override string ExportIdentifier
        {
            get { return DRTExportValue; }
            set { value = DRTExportValue; }
        }

        public override DRTEPOXRT MapTToTE(DisputeDto.InvoiceDecisionSearchResult invDecisionResult)
        {
            if (invDecisionResult == null) throw new ArgumentNullException("invDecisionResult");


            var exportedData = new DRTEPOXRT
            {
                AssignedToFirstName="",
                AssignedToLastName="",
                ClientNumber="801", //As mentioned in FRD
                VendorId="",
                VendorOrderNumber=invDecisionResult.OrderNumber,
                WorkOrderId = invDecisionResult.ClientInvoiceNumber != invDecisionResult.InvoiceNumber ? invDecisionResult.ClientInvoiceNumber : "",
                DisputeDueDate = invDecisionResult.InvoiceDecisionDate.HasValue ? invDecisionResult.InvoiceDecisionDate.Value.Date.AddDays(5).ToString("MM/dd/yyyy") : string.Empty,
                DisputeType = "Dispute",
                InvoiceDecisionComments = invDecisionResult.InvoiceDecisionComments,
                InvoiceDate = invDecisionResult.InvoiceDate.HasValue ? invDecisionResult.InvoiceDate.Value.Date.ToString("MM/dd/yyyy") : string.Empty,
                InvoiceDecisionDate = invDecisionResult.InvoiceDecisionDate.HasValue ? invDecisionResult.InvoiceDecisionDate.Value.Date.ToString("MM/dd/yyyy") : string.Empty,
                InvoiceNumber = invDecisionResult.InvoiceNumber,
                InvoiceTotal = invDecisionResult.InitialInvoiceSubtotal + invDecisionResult.InitialInvoiceTax,
                LoanNumber = invDecisionResult.LoanNumber,
                DisputeAmount = ((invDecisionResult.InitialInvoiceSubtotal + invDecisionResult.InitialInvoiceTax) - (invDecisionResult.ApprovedAmount + invDecisionResult.InvoiceTax)),
            };
            return exportedData;
        }
        public override GeneratedDocumentInfo GenerateDocument(DataObjects.DocGen.GenerateDocumentRequest request)
        {
            if (IsValid(request) == false) throw new ArgumentException("Request is not valid", "request");

            GeneratedDocumentInfo generatedDocumentInfo;
            try
            {
                int createdById = GetCurrentUserId(request);
                var createdDate = DateTime.Now;
                var documentName = string.Format("{0}_{1:yyyy_MM_dd_hh_mm_ss_tt}.xlsx", DRTExportValue, DateTime.Now);
                var mimeType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                var description = "DRT export data.";
                var documentType = "Other";

                var searchResult = GetData(request).Where(x=>x.InvoiceDecision!="Approved").ToList();
                List<DRTEPOXRT> exportResults = new List<DRTEPOXRT>();
                foreach(var res in searchResult)
                {
                    var exportResult = MapTToTE(res);
                    exportResults.Add(exportResult);
                }
                var excel = new ExcelExport<DRTEPOXRT>(exportResults);
                var fileData = excel.ExportToBytes();
                var success = (fileData.Length > 0);
                generatedDocumentInfo = new GeneratedDocumentInfo(documentName, description, documentType, mimeType, createdById, createdDate, success, fileData);

            }

            catch (IOException ex)
            {
                Logging.LogError(ex);
                throw;
            }
            return generatedDocumentInfo;
        }
    }
}
