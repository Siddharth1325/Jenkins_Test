﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Authentication;
using BusinessSvcImpl.DataObjects.DocGen;
using BusinessSvcImpl.SvcImpl.SpaAcc;
//using IbmBpmRestApi.ServiceProxy.Reference;
using Newtonsoft.Json;
using User.ServiceProxy.UserRepository;
using UserContext = CommonLib.Context.UserContext;
using ARInvoiceDto = BusinessSvcImpl.DataObjects.SpaAccounting.Dto;
using BusinessSvcImpl.DataObjects.SpaAccountingService.Dto;
using BusinessSvcImpl.DataObjects.SpaAccounting.Dto;
using InspectionDto = Inspections.ServiceProxy.InspectionSvc;
using System.Diagnostics;
using ProductDto = Admin.ServiceProxy.ProductService;
using System.Globalization;

namespace BusinessSvcImpl.SvcImpl.DocGen.Builders.ARInvoice
{
    public class ARInvoiceBuilder : CommonBuilder<ARInvoiceDto.ARInvoice, ExportedARInvoice>
    {
        public const string ARInvoiceValue = "ARInvoice";
        public const string AppliedFilterIdsKey = "ARInvoiceCriterion";


        private bool IsValid(GenerateDocumentRequest generateDocumentRequest)
        {
            if (generateDocumentRequest == null) throw new NullReferenceException("Document Info");

            var values = generateDocumentRequest.Metadata
              .Where(x => x.Value != null)
              .Select(x => x.Value.ToString())
              .ToArray();
            return values.Any(x => x.Equals(ARInvoiceValue, StringComparison.Ordinal));
        }

        public override IEnumerable<ARInvoiceDto.ARInvoice> GetData(GenerateDocumentRequest generateDocumentRequest)
        {
            var service = new SpaAccountingService();

            DocumentMetadata filterTypeData = generateDocumentRequest.Metadata.SingleOrDefault(x => x.Key.Equals(AppliedFilterIdsKey, StringComparison.OrdinalIgnoreCase));
            if (filterTypeData == null || filterTypeData.Value == null) return new List<ARInvoiceDto.ARInvoice>();

            var context = JsonConvert.DeserializeObject<UserContext>(generateDocumentRequest.UserContext);

            var selectedIdsValue = filterTypeData.Value.ToString();
            var arInvoiceSearchFilter = JsonConvert.DeserializeObject<ARInvoiceCriterion>(selectedIdsValue);
            IList<ARInvoiceDto.ARInvoice> receivableInvoiceDetailList = new List<ARInvoiceDto.ARInvoice>();
            GetARInvoiceDetailsRequest request = new GetARInvoiceDetailsRequest() { InvoiceNumber = arInvoiceSearchFilter.InvoiceNumber,PageSize=10000,SkipCount=0 };
            GetARInvoiceDetailsResponse serviceResponse = service.GetARInvoiceDetails(request);

            foreach (var receivableDetail in serviceResponse.ReceivableList)
            {
                ARInvoiceDto.ARInvoice invoiceEntry = new ARInvoiceDto.ARInvoice()
                {
                    InvoiceNumber = arInvoiceSearchFilter.InvoiceNumber,
                    InvoiceDate = arInvoiceSearchFilter.InvoiceDate == null || arInvoiceSearchFilter.InvoiceDate == "" ? "" : DateTime.Parse(arInvoiceSearchFilter.InvoiceDate).ToString("MM/dd/yyyy"),
                    TotalInvoiceAmount = arInvoiceSearchFilter.TotalInvoiceAmount == null || arInvoiceSearchFilter.TotalInvoiceAmount == "" ? "" : Decimal.Parse(arInvoiceSearchFilter.TotalInvoiceAmount).ToString("C", CultureInfo.GetCultureInfo("en-US")),
                    ClientNumber = arInvoiceSearchFilter.ClientNumber,
                    Department = arInvoiceSearchFilter.Department,
                    LineOfBusiness = arInvoiceSearchFilter.BusinessLine,
                    BillingFrequency = arInvoiceSearchFilter.BillingFrequency,
                    InvoiceType = arInvoiceSearchFilter.InvoiceType,
                    OrderNumber = receivableDetail.OrderId.ToString(),
                    WorkOrderNumber = receivableDetail.WorkOrderId.ToString(),
                    OrderedDate = receivableDetail.OrderDate.ToString("MM/dd/yyyy"),
                    CompletedDate = receivableDetail.CompletedDate == null ? "" : receivableDetail.CompletedDate.Value.ToString("MM/dd/yyyy"),
                    LoanNumber = receivableDetail.LoanNumber,
                    LoanType = receivableDetail.LoanType,                
                    MortgagorName = receivableDetail.MortgagorName,
                    ProductCode = receivableDetail.ProductCode,
                    InvoiceAmount = (receivableDetail.ClientPrice + receivableDetail.TaxAmount).ToString(),
                    ClientPrice = receivableDetail.ClientPrice.ToString(),
                    TaxAmount = receivableDetail.TaxAmount.ToString() ,
                    ProductCategory = receivableDetail.ProductCategory
                };
                receivableInvoiceDetailList.Add(invoiceEntry);
            }
            return receivableInvoiceDetailList;
        }



        public override ExportedARInvoice MapTToTE(ARInvoiceDto.ARInvoice arInvoice)
        {
            if (arInvoice == null) throw new ArgumentNullException("arInvoice");

            var exportedAccountingAdjustmentCode = new ExportedARInvoice
            {
                InvoiceNumber = arInvoice.InvoiceNumber,
                InvoiceDate = arInvoice.InvoiceDate,
                TotalInvoiceAmount = arInvoice.TotalInvoiceAmount,
                ClientNumber = arInvoice.ClientNumber,
                Department = arInvoice.Department,
                LineofBusiness = arInvoice.LineOfBusiness,
                BillingFrequency = arInvoice.BillingFrequency,
                InvoiceType = arInvoice.InvoiceType,
                WorkOrderNumber = arInvoice.WorkOrderNumber,
                LoanNumber = arInvoice.LoanNumber,
                WOInvAmt = arInvoice.InvoiceAmount,
                OrderDate = arInvoice.OrderedDate,
                CompletedDate = arInvoice.CompletedDate,
                Product = arInvoice.ProductCode,
                LoanType = arInvoice.LoanType,
                OrderNumber = arInvoice.OrderNumber,
                ClientPrice = arInvoice.ClientPrice,
                TaxAmount = arInvoice.TaxAmount
                //Occupancy = arInvoice.Occupancy,
                //MBACode = arInvoice.MBACode,
                //MortgagorName = arInvoice.MortgagorName
            };
            return exportedAccountingAdjustmentCode;
        }



        public override string ExportIdentifier
        {
            get { return ARInvoiceValue; }
            set { value = ARInvoiceValue; }
        }
        private static IList<int> GetSelectedIds(GenerateDocumentRequest generateDocumentRequest, string collectionKey)
        {
            if (generateDocumentRequest == null) throw new ArgumentNullException("generateDocumentRequest");
            if (string.IsNullOrEmpty(collectionKey)) throw new ArgumentNullException("collectionKey");

            DocumentMetadata filterTypeData = generateDocumentRequest.Metadata
              .SingleOrDefault(x => x.Key.Equals(collectionKey, StringComparison.OrdinalIgnoreCase));

            if (filterTypeData == null || filterTypeData.Value == null) return new int[0];

            var selectedIdsValue = filterTypeData.Value.ToString();
            var selectedIds = selectedIdsValue
              .Split(new[] { ',' })
              .Select(x => x.Trim());

            var numericIds = new List<int>();
            foreach (var selectedId in selectedIds)
            {
                int convertedId;
                if (int.TryParse(selectedId, out convertedId))
                {
                    numericIds.Add(convertedId);
                }
            }

            return numericIds;
        }

        public GenerateDocumentResponse GetDocumentRequest()
        {
            return new GenerateDocumentResponse();
        }
    }
    class ARInvoiceCriterion
    {
        public string InvoiceNumber { get; set; }
        public string InvoiceDate { get; set; }
        public string TotalInvoiceAmount { get; set; }
        public string ClientNumber { get; set; }
        public string Department { get; set; }
        public string BusinessLine { get; set; }
        public string BillingFrequency { get; set; }
        public string InvoiceType { get; set; }
    }
}