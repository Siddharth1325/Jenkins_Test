﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessSvcImpl.SvcImpl.DocGen.Builders.VertexErrorLog
{
    public class ExportedVertexErrorLog
    {
        public int workOrderId { get; set; }
        public int? clientNumber { get; set; }
        public string ProductName { get; set; }
        public string Address { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Zip { get; set; }
        public string Zip4 { get; set; }
        public DateTime? ErrorDate { get; set; }
        public string ErrorMessage { get; set; }
        public decimal EligibleAmount { get; set; }
    }
}
