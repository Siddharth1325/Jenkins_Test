﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessSvcImpl.SvcImpl.DocGen.Builders.DisputeSearch
{
    public class ExportDisputeSearch
    {
       // public int? ApplicationId { get; set; }

        public int? DisputeId { get; set; }


        public string DisputeStatusType { get; set; }

        public string Resolution { get; set; }

        public string AssignedTo { get; set; }

        public string DisputeDueDateFrom { get; set; }

        public string DisputeDueDateTo { get; set; }

        public string InvoiceNumber { get; set; }


        public string DisputeType { get; set; }


        public string ClientName { get; set; }

        public string LoanNumber { get; set; }


        public int? VendorId { get; set; }

        public int? VendorWorkOrderId { get; set; }

        public int? InspWorkOrder { get; set; }

       
        public decimal DisputeAmount { get; set; }
      
     
       
       
      
       
      
    }
}
