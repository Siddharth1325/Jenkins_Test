﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OrderDto = BusinessSvcImpl.DataObjects.SpaAccounting.Dto;


namespace BusinessSvcImpl.SvcImpl.DocGen.Builders.Order
{
    public class ExportedOrder
    {
        [Description("Prod Cat")]
        public string ProductCategory { get; set; }
        [Description("Order #")]
        public int OrderNumber { get; set; }

        [Description("WO #")]
        public int? WorkOrderNumber { get; set; }

        [Description("AR Invoice #")]
        public string ARInvoiceNumber { get; set; }

        [Description("Loan #")]
        public string LoanNumber { get; set; }

        [Description("Product")]
        public string Product { get; set; }

        [Description("Client #")]
        public string ClientNumber { get; set; }

        [Description("WO Inv Amt")]
        public decimal WorkOrderInvoiceAmount { get; set; }

        //public string BillingFrequency { get; set; }

        [Description("Completed Date")]
        public string CompletedDate { get; set; }

        [Description("Invoice Date")]
        public string InvoiceDate { get; set; }




    }
}
