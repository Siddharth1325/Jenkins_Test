﻿using BusinessSvcImpl.DataObjects.SpaAccounting.Dto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessSvcImpl.SvcImpl.DocGen.Builders.ARDetail
{
    public class ExportedARDetail
    {

        public string Service { get; set; }

        public string TransDate { get; set; }

        public string StartingPrice { get; set; }

        public string TotalPrice { get; set; }

        public string TaxRate { get; set; }

        public string TaxAmount { get; set; }

        public string TotalAmount { get; set; }

        public string PreBillingPriceAdjReason { get; set; }

        public string InvoiceNumber { get; set; }

        public string InvoiceDate { get; set; }

        public string Status { get; set; }

        //public int WorkOrderId { get; set; }

        //public int SourceWorkOrderId { get; set; }

        //public DateTime? Date { get; set; }

        //public int ApplicationId { get; set; }

    }
}
