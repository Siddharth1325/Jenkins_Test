﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Authentication;
using BusinessSvcImpl.DataObjects.DocGen;
using BusinessSvcImpl.SvcImpl.SpaAcc;
//using IbmBpmRestApi.ServiceProxy.Reference;
using Newtonsoft.Json;
using User.ServiceProxy.UserRepository;
using UserContext = CommonLib.Context.UserContext;
using ClearMappingDto = BusinessSvcImpl.DataObjects.SpaAccounting.Dto;
using BusinessSvcImpl.DataObjects.SpaAccountingService.Dto;
using BusinessSvcImpl.DataObjects.SpaAccounting.Dto;
using System.Diagnostics;

namespace BusinessSvcImpl.SvcImpl.DocGen.Builders.IClearMapping
{
    public class IClearMappingBuilder : CommonBuilder<ClearMappingDto.IClearMappingSummaryView, ExportedIClearMapping>
    {
        public const string IClearMappingValue = "IClearMapping";
        public const string AppliedFilterIdsKey = "IClearMappingCriterion";


        private bool IsValid(GenerateDocumentRequest generateDocumentRequest)
        {
            if (generateDocumentRequest == null) throw new NullReferenceException("Document Info");

            var values = generateDocumentRequest.Metadata
              .Where(x => x.Value != null)
              .Select(x => x.Value.ToString())
              .ToArray();
            return values.Any(x => x.Equals(IClearMappingValue, StringComparison.Ordinal));
        }

        public override IEnumerable<ClearMappingDto.IClearMappingSummaryView> GetData(GenerateDocumentRequest generateDocumentRequest)
        {
            var service = new SpaAccountingService();

            DocumentMetadata filterTypeData = generateDocumentRequest.Metadata.SingleOrDefault(x => x.Key.Equals(AppliedFilterIdsKey, StringComparison.OrdinalIgnoreCase));
            if (filterTypeData == null || filterTypeData.Value == null) return new List<ClearMappingDto.IClearMappingSummaryView>();

            var context = JsonConvert.DeserializeObject<UserContext>(generateDocumentRequest.UserContext);

            var selectedIdsValue = filterTypeData.Value.ToString();
            var iClearMapping = JsonConvert.DeserializeObject<IClearMappingCriterion>(selectedIdsValue);
            IList<ClearMappingDto.IClearMappingSummaryView> adjustmentDetail = new List<ClearMappingDto.IClearMappingSummaryView>();
            //Map Request Data 
            GetIMClearMappingRequest request = new GetIMClearMappingRequest() { Category = iClearMapping.Category, ClientId = iClearMapping.ClientId };
            request.PageSize = 10000;
            request.SkipCount = 0;
            GetIMClearMappingResponse iClearMappingSearch = service.SearchIMClearMapping(request);
            return iClearMappingSearch.Result;
        }



        public override ExportedIClearMapping MapTToTE(ClearMappingDto.IClearMappingSummaryView iClearMappingDetail)
        {
            if (iClearMappingDetail == null) throw new ArgumentNullException("iClearMappingDetail");

            var exportedAccountingGLCode = new ExportedIClearMapping
            {
                Lob = iClearMappingDetail.LobType,
                LSCINumber = iClearMappingDetail.ClientLSCI,
                ClientNumber = iClearMappingDetail.ClientNumber,
                IClearClientCode = iClearMappingDetail.IClearClientCode,
                IClearLineItemCode = iClearMappingDetail.IClearLineItem,
                Product = iClearMappingDetail.InspectionType,
                ServiceType = iClearMappingDetail.ServiceName,
                ServiceItem = iClearMappingDetail.ServiceItem,
                FeeType = iClearMappingDetail.FeeTypeName,
                InspectionResult = iClearMappingDetail.InspectionResultType,
                
                
                Rush = Convert.ToBoolean(iClearMappingDetail.IsRush)  ?  "Yes" : "",
                Tax = Convert.ToBoolean(iClearMappingDetail.IsTax) ? "Yes" : "",
                Category = iClearMappingDetail.MappingTypeDescription,
                MBACode = iClearMappingDetail.MBACodeType
                
            };
            return exportedAccountingGLCode;
        }



        public override string ExportIdentifier
        {
            get { return IClearMappingValue; }
            set { value = IClearMappingValue; }
        }
        private static IList<int> GetSelectedIds(GenerateDocumentRequest generateDocumentRequest, string collectionKey)
        {
            if (generateDocumentRequest == null) throw new ArgumentNullException("generateDocumentRequest");
            if (string.IsNullOrEmpty(collectionKey)) throw new ArgumentNullException("collectionKey");

            DocumentMetadata filterTypeData = generateDocumentRequest.Metadata
              .SingleOrDefault(x => x.Key.Equals(collectionKey, StringComparison.OrdinalIgnoreCase));

            if (filterTypeData == null || filterTypeData.Value == null) return new int[0];

            var selectedIdsValue = filterTypeData.Value.ToString();
            var selectedIds = selectedIdsValue
              .Split(new[] { ',' })
              .Select(x => x.Trim());

            var numericIds = new List<int>();
            foreach (var selectedId in selectedIds)
            {
                int convertedId;
                if (int.TryParse(selectedId, out convertedId))
                {
                    numericIds.Add(convertedId);
                }
            }

            return numericIds;
        }

        public GenerateDocumentResponse GetDocumentRequest()
        {
            return new GenerateDocumentResponse();
        }
    }
    class IClearMappingCriterion
    {
        public string ClientId { get; set; }
        public string Category { get; set; }
    }
}