﻿using BusinessSvcImpl.DataObjects.SpaAccounting.Dto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessSvcImpl.SvcImpl.DocGen.Builders.ReviewImportException
{
    public class ExportedReviewImportException
    {
        public DateTime? FileImportDate { get; set; }

        public string FileName { get; set; }

        public string FileType { get; set; }

        //public string ExceptionType { get; set; }

        public string LineNumber { get; set; }

        public string ExceptionDescription { get; set; }

    }
}
