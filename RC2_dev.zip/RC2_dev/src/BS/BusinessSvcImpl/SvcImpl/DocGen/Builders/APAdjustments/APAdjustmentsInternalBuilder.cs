using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Authentication;
using BusinessSvcImpl.DataObjects.DocGen;
using BusinessSvcImpl.SvcImpl.SpaAcc;
//using IbmBpmRestApi.ServiceProxy.Reference;
using Newtonsoft.Json;
using User.ServiceProxy.UserRepository;
using UserContext = CommonLib.Context.UserContext;
using APAdjustmentsDto = BusinessSvcImpl.DataObjects.SpaAccounting.Dto;
using BusinessSvcImpl.DataObjects.SpaAccountingService.Dto;
using BusinessSvcImpl.DataObjects.SpaAccounting.Dto;
using System.Diagnostics;
using DomainModel.Common;
using System.Globalization;

namespace BusinessSvcImpl.SvcImpl.DocGen.Builders.APAdjustments
{
    public class APAdjustmentsInternalBuilder : CommonBuilder<APAdjustmentsDto.APAdjustment, ExportedAPAdjustmentInternal>
    {
        public const string APAdjustmentValue = "AccountingAdjustmentInternal";
        public const string AppliedFilterIdsKey = "AccountingAdjustmentInternalCriterion";


        private bool IsValid(GenerateDocumentRequest generateDocumentRequest)
        {
            if (generateDocumentRequest == null) throw new NullReferenceException("Document Info");

            var values = generateDocumentRequest.Metadata
              .Where(x => x.Value != null)
              .Select(x => x.Value.ToString())
              .ToArray();
            return values.Any(x => x.Equals(APAdjustmentValue, StringComparison.Ordinal));
        }

        public override IEnumerable<APAdjustmentsDto.APAdjustment> GetData(GenerateDocumentRequest generateDocumentRequest)
        {
            var service = new SpaAccountingService();

            DocumentMetadata filterTypeData = generateDocumentRequest.Metadata.SingleOrDefault(x => x.Key.Equals(AppliedFilterIdsKey, StringComparison.OrdinalIgnoreCase));
            if (filterTypeData == null || filterTypeData.Value == null) return new List<APAdjustmentsDto.APAdjustment>();

            var context = JsonConvert.DeserializeObject<UserContext>(generateDocumentRequest.UserContext);

            var selectedIdsValue = filterTypeData.Value.ToString();
            var apAdjustment = JsonConvert.DeserializeObject<AccountingAdjustmentInternalCriterion>(selectedIdsValue);
            List<APAdjustmentsDto.APAdjustment> adjustmentDetail = new List<APAdjustmentsDto.APAdjustment>();
            //GetWorkOrderResponse respon = service.GetWorkOrderBySrcId(new GetSourceWorkOrderRequest() { SourceWorkOrderId = int.Parse(apAdjustment.WorkOrderNumber) });

            int woId;
            int vwoId;
            int.TryParse(apAdjustment.WorkOrderNumber, out woId);
            int.TryParse(apAdjustment.VendorWorkOrderId, out vwoId);


            GetAPAdjustmentDetailViewRequest request = new GetAPAdjustmentDetailViewRequest()
            {
                WorkOrderId =woId,//(respon != null && respon.WorkOrder != null) ? respon.WorkOrder.WorkOrderId : int.Parse(apAdjustment.WorkOrderNumber),
                VendorWorkOrderId = vwoId //(respon != null && respon.WorkOrder != null && respon.WorkOrder.VendorWorkOrder != null) ? respon.WorkOrder.VendorWorkOrder.SourceVendorWorkOrderId : int.Parse(apAdjustment.VendorNumber)
                
            };

     

            GetAPAdjustmentDetailViewResponse ApAdjustment = new GetAPAdjustmentDetailViewResponse();

             ApAdjustment = service.GetApAdjustmentDetailViewById(request);

            if (ApAdjustment != null && ApAdjustment.APAdjustmentDetailList != null && ApAdjustment.APAdjustmentDetailList.Count() > 0)
            {                
                foreach (var adjustment in ApAdjustment.APAdjustmentDetailList)
                {
                    adjustmentDetail.Add(new APAdjustmentsDto.APAdjustment()
                    {
                        AdjustmentCode = adjustment.AdjustmentCode,
                        AdjustmentDate = adjustment.AdjustmentDate.ToString("MM/dd/yyyy"),
                        AdjustmentType = adjustment.AdjustmentType,
                        Amount = adjustment.Amount.ToString("C", CultureInfo.GetCultureInfo("en-US")),
                        Comments = adjustment.Comments,
                        Function = adjustment.FunctionValue,
                        NaturalAccount = adjustment.NaturalAccount,
                        Operation = adjustment.Operation,
                        WorkOrderNumber = adjustment.SourceWorkOrderId.ToString(),
                        AdjInvoiceNumber = adjustment.AdjInvoiceNumber,
                        ProductCategory = adjustment.ProductCategory,
                        VendorNumber = adjustment.VendorProfileId.HasValue ? adjustment.VendorProfileId.Value.ToString() : "",
                        SupplierComments=adjustment.SupplierComment,
                        InvoiceNumber=apAdjustment.InvoiceNumber,
                        OrderNumber=apAdjustment.OrderNumber

                    });
                }

                adjustmentDetail = adjustmentDetail.OrderBy(x => x.AdjustmentDate).ToList();
            }

            return adjustmentDetail;
        }


        public override string ExportIdentifier
        {
            get { return APAdjustmentValue; }
            set { value = APAdjustmentValue; }
        }

        public override ExportedAPAdjustmentInternal MapTToTE(APAdjustmentsDto.APAdjustment apAdjustmentDetail)
        {
            if (apAdjustmentDetail == null) throw new ArgumentNullException("apAdjustmentDetail");

            var exportedAPAdjustment = new ExportedAPAdjustmentInternal
            {
                WorkOrderNumber = apAdjustmentDetail.WorkOrderNumber,
                OrderNumber = apAdjustmentDetail.OrderNumber,
                InvoiceNumber = apAdjustmentDetail.InvoiceNumber,
                VendorNumber = apAdjustmentDetail.VendorNumber,
                InspectorUniqueID = apAdjustmentDetail.InspectorUniqueID,
                AdjustmentCode = apAdjustmentDetail.AdjustmentCode,
                AdjustmentDate = apAdjustmentDetail.AdjustmentDate,
                AdjustmentType = apAdjustmentDetail.AdjustmentType,
                Amount = apAdjustmentDetail.Amount,
                AdjInternalComments = apAdjustmentDetail.Comments,
                Function = apAdjustmentDetail.Function,
                NaturalAccount = apAdjustmentDetail.NaturalAccount,
                Operation = apAdjustmentDetail.Operation,
                ReserveType = apAdjustmentDetail.ReserveType,
                SupplierComments = apAdjustmentDetail.SupplierComments,
                AdjInvoiceNumber=apAdjustmentDetail.AdjInvoiceNumber
            };
            return exportedAPAdjustment;
        }

        private static IList<int> GetSelectedIds(GenerateDocumentRequest generateDocumentRequest, string collectionKey)
        {
            if (generateDocumentRequest == null) throw new ArgumentNullException("generateDocumentRequest");
            if (string.IsNullOrEmpty(collectionKey)) throw new ArgumentNullException("collectionKey");

            DocumentMetadata filterTypeData = generateDocumentRequest.Metadata
              .SingleOrDefault(x => x.Key.Equals(collectionKey, StringComparison.OrdinalIgnoreCase));

            if (filterTypeData == null || filterTypeData.Value == null) return new int[0];

            var selectedIdsValue = filterTypeData.Value.ToString();
            var selectedIds = selectedIdsValue
              .Split(new[] { ',' })
              .Select(x => x.Trim());

            var numericIds = new List<int>();
            foreach (var selectedId in selectedIds)
            {
                int convertedId;
                if (int.TryParse(selectedId, out convertedId))
                {
                    numericIds.Add(convertedId);
                }
            }

            return numericIds;
        }

        public GenerateDocumentResponse GetDocumentRequest()
        {
            return new GenerateDocumentResponse();
        }
    }
    class AccountingAdjustmentInternalCriterion
    {
        public string WorkOrderNumber { get; set; }
        public string OrderNumber { get; set; }
        public string InvoiceNumber { get; set; }
        public string VendorNumber { get; set; }
        public string InspectorUniqueID { get; set; }

        public string VendorWorkOrderId { get; set; }
    }
}