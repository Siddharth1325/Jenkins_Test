using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Authentication;
using BusinessSvcImpl.DataObjects.DocGen;
using BusinessSvcImpl.SvcImpl.SpaAcc;
//using IbmBpmRestApi.ServiceProxy.Reference;
using Newtonsoft.Json;
using User.ServiceProxy.UserRepository;
using UserContext = CommonLib.Context.UserContext;
using APAdjustmentsDto = BusinessSvcImpl.DataObjects.SpaAccounting.Dto;
using BusinessSvcImpl.DataObjects.SpaAccountingService.Dto;
using BusinessSvcImpl.DataObjects.SpaAccounting.Dto;
using System.Diagnostics;
using DomainModel.Common;
using System.Globalization;

namespace BusinessSvcImpl.SvcImpl.DocGen.Builders.APAdjustments
{
    public class APAdjustmentsExternalBuilder : CommonBuilder<APAdjustmentsDto.APAdjustment, ExportedAPAdjustmentExternal>
    {
        public const string APAdjustmentValue = "AccountingAdjustmentExternal";
        public const string AppliedFilterIdsKey = "AccountingAdjustmentExternalCriterion";


        private bool IsValid(GenerateDocumentRequest generateDocumentRequest)
        {
            if (generateDocumentRequest == null) throw new NullReferenceException("Document Info");

            var values = generateDocumentRequest.Metadata
              .Where(x => x.Value != null)
              .Select(x => x.Value.ToString())
              .ToArray();
            return values.Any(x => x.Equals(APAdjustmentValue, StringComparison.Ordinal));
        }

        public override IEnumerable<APAdjustmentsDto.APAdjustment> GetData(GenerateDocumentRequest generateDocumentRequest)
        {
            var service = new SpaAccountingService();

            DocumentMetadata filterTypeData = generateDocumentRequest.Metadata.SingleOrDefault(x => x.Key.Equals(AppliedFilterIdsKey, StringComparison.OrdinalIgnoreCase));
            if (filterTypeData == null || filterTypeData.Value == null) return new List<APAdjustmentsDto.APAdjustment>();

            var context = JsonConvert.DeserializeObject<UserContext>(generateDocumentRequest.UserContext);

            var selectedIdsValue = filterTypeData.Value.ToString();
            var apAdjustment = JsonConvert.DeserializeObject<AccountingAdjustmentExternalCriterion>(selectedIdsValue);
            List<APAdjustmentsDto.APAdjustment> adjustmentDetail = new List<APAdjustmentsDto.APAdjustment>();

            int woId = int.Parse(apAdjustment.WorkOrderNumber);
            int vwoId;
            int.TryParse(apAdjustment.VendorWorkOrderId, out vwoId);

            GetAPAdjustmentDetailViewRequest request = new GetAPAdjustmentDetailViewRequest()
            {
                WorkOrderId = woId,//(respon != null && respon.WorkOrder != null) ? respon.WorkOrder.WorkOrderId : int.Parse(apAdjustment.WorkOrderNumber),
                VendorWorkOrderId = vwoId //(respon != null && respon.WorkOrder != null && respon.WorkOrder.VendorWorkOrder != null) ? respon.WorkOrder.VendorWorkOrder.SourceVendorWorkOrderId : int.Parse(apAdjustment.VendorNumber)

            };

            GetAPAdjustmentDetailViewResponse daoResponse = service.GetApAdjustmentDetailViewById(request);


            //GetWorkOrderResponse respon = service.GetWorkOrderBySrcId(new GetSourceWorkOrderRequest() { SourceWorkOrderId = int.Parse(apAdjustment.WorkOrderNumber) });
            //GetAccountsPayableByWorkOrderIdRequest request = new GetAccountsPayableByWorkOrderIdRequest()
            //{
            //    WorkOrderId = (respon != null && respon.WorkOrder != null) ? respon.WorkOrder.WorkOrderId : int.Parse(apAdjustment.WorkOrderNumber),
            //    ChildEnum = CommonEnums.AccountsPayableChild.PayableAdjustment

            //};

            //AccountsPayable payable = service.GetAccountsPayableByWorkOrderId(request).AccountsPayable;

            //if (payable != null && payable.AccountingAPInvoicePayables != null && payable.AccountingAPInvoicePayables.Count > 0)
            //{

            if (daoResponse != null)
            {


                var apAdjDetails = daoResponse.APAdjustmentDetailList;//.AccountingAPInvoicePayables.Cast<AccountingAPInvoicePayable>().ToList()[0].AccountsPayableInvoice;

                var accountsPayableAdjustmentList = new List<AccountsPayableAdjustment>(); //payableInvoice.AccountsPayableAdjustments.Where(x => x.WorkOrderId == request.WorkOrderId).ToList();

                foreach (var adjustment in apAdjDetails)
                {
                    adjustmentDetail.Add(new APAdjustmentsDto.APAdjustment()
                    {
                        WorkOrderNumber = apAdjustment.WorkOrderNumber,
                        OrderNumber = apAdjustment.OrderNumber,
                        InvoiceNumber = apAdjustment.InvoiceNumber,
                        VendorNumber = apAdjustment.VendorNumber,
                        InspectorUniqueID = apAdjustment.InspectorUniqueID,
                        AdjustmentCode = adjustment.AdjustmentCode,
                        AdjustmentDate = adjustment.AdjustmentDate.ToString("MM/dd/yyyy"),
                        AdjustmentType = adjustment.AdjustmentType,
                        Amount = (adjustment.AdjustmentType == "CREDIT" && adjustment.Amount > 0 ? (-1 * adjustment.Amount).ToString("C", CultureInfo.GetCultureInfo("en-US")) : adjustment.Amount.ToString("C", CultureInfo.GetCultureInfo("en-US"))),
                        Comments = adjustment.Comments,
                        Function = adjustment.FunctionValue,
                        NaturalAccount = adjustment.NaturalAccount,
                        Operation = adjustment.Operation,
                        ReserveType = "",
                        AdjInvoiceNumber=adjustment.AdjInvoiceNumber,
                        SupplierComments=adjustment.SupplierComment
                    });
                }

                adjustmentDetail = adjustmentDetail.OrderBy(x => x.AdjustmentDate).ToList();
            }
            //}

            return adjustmentDetail;
        }


        public override string ExportIdentifier
        {
            get { return APAdjustmentValue; }
            set { value = APAdjustmentValue; }
        }

        public override ExportedAPAdjustmentExternal MapTToTE(APAdjustmentsDto.APAdjustment apAdjustmentDetail)
        {
            if (apAdjustmentDetail == null) throw new ArgumentNullException("apAdjustmentDetail");

            var exportedAPAdjustment = new ExportedAPAdjustmentExternal
            {
                WorkOrderNumber = apAdjustmentDetail.WorkOrderNumber,
                OrderNumber = apAdjustmentDetail.OrderNumber,
                InvoiceNumber = apAdjustmentDetail.InvoiceNumber,
                VendorNumber = apAdjustmentDetail.VendorNumber,
                InspectorUniqueID = apAdjustmentDetail.InspectorUniqueID,
                AdjustmentCode = apAdjustmentDetail.AdjustmentCode,
                AdjustmentDate = apAdjustmentDetail.AdjustmentDate,
                AdjustmentType = apAdjustmentDetail.AdjustmentType,
                Amount = apAdjustmentDetail.Amount,
                Comments = apAdjustmentDetail.Comments,
                AdjInvoiceNumber=apAdjustmentDetail.AdjInvoiceNumber,
                SupplierComment=apAdjustmentDetail.SupplierComments
            };
            return exportedAPAdjustment;
        }

        private static IList<int> GetSelectedIds(GenerateDocumentRequest generateDocumentRequest, string collectionKey)
        {
            if (generateDocumentRequest == null) throw new ArgumentNullException("generateDocumentRequest");
            if (string.IsNullOrEmpty(collectionKey)) throw new ArgumentNullException("collectionKey");

            DocumentMetadata filterTypeData = generateDocumentRequest.Metadata
              .SingleOrDefault(x => x.Key.Equals(collectionKey, StringComparison.OrdinalIgnoreCase));

            if (filterTypeData == null || filterTypeData.Value == null) return new int[0];

            var selectedIdsValue = filterTypeData.Value.ToString();
            var selectedIds = selectedIdsValue
              .Split(new[] { ',' })
              .Select(x => x.Trim());

            var numericIds = new List<int>();
            foreach (var selectedId in selectedIds)
            {
                int convertedId;
                if (int.TryParse(selectedId, out convertedId))
                {
                    numericIds.Add(convertedId);
                }
            }

            return numericIds;
        }

        public GenerateDocumentResponse GetDocumentRequest()
        {
            return new GenerateDocumentResponse();
        }
    }
    class AccountingAdjustmentExternalCriterion
    {
        public string WorkOrderNumber { get; set; }
        public string OrderNumber { get; set; }
        public string InvoiceNumber { get; set; }
        public string VendorNumber { get; set; }
        public string InspectorUniqueID { get; set; }

        public string VendorWorkOrderId { get; set; }
    }
}