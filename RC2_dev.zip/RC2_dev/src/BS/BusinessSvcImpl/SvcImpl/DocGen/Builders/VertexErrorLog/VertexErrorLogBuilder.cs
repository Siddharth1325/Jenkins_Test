﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Authentication;
using BusinessSvcImpl.DataObjects.DocGen;
using BusinessSvcImpl.SvcImpl.SpaAcc;
//using IbmBpmRestApi.ServiceProxy.Reference;
using Newtonsoft.Json;
using User.ServiceProxy.UserRepository;
using UserContext = CommonLib.Context.UserContext;
using VertexErrorLogDto = BusinessSvcImpl.DataObjects.SpaAccounting.Dto;
using BusinessSvcImpl.DataObjects.SpaAccountingService.Dto;
using BusinessSvcImpl.DataObjects.SpaAccounting.Dto;
using System.Diagnostics;

namespace BusinessSvcImpl.SvcImpl.DocGen.Builders.VertexErrorLog
{
    public class VertexErrorLogBuilder : CommonBuilder<VertexErrorLogDto.VertexErrorLog, ExportedVertexErrorLog>
    {
        public const string VertexErrorLogValue = "VertexErrorLog";
        public const string AppliedFilterIdsKey = "VertexErrorLogCriterion";

        private bool IsValid(GenerateDocumentRequest generateDocumentRequest)
        {
            if (generateDocumentRequest == null) throw new NullReferenceException("Document Info");

            var values = generateDocumentRequest.Metadata
              .Where(x => x.Value != null)
              .Select(x => x.Value.ToString())
              .ToArray();
            return values.Any(x => x.Equals(VertexErrorLogValue, StringComparison.Ordinal));
        }

        public override IEnumerable<VertexErrorLogDto.VertexErrorLog> GetData(GenerateDocumentRequest generateDocumentRequest)
        {
            var service = new SpaAccountingService();

            DocumentMetadata filterTypeData = generateDocumentRequest.Metadata.SingleOrDefault(x => x.Key.Equals(AppliedFilterIdsKey, StringComparison.OrdinalIgnoreCase));
            if (filterTypeData == null || filterTypeData.Value == null) return new List<VertexErrorLogDto.VertexErrorLog>();

            var context = JsonConvert.DeserializeObject<UserContext>(generateDocumentRequest.UserContext);

            var selectedIdsValue = filterTypeData.Value.ToString();
            var vertexErrorLog = JsonConvert.DeserializeObject<VertexErrorLogCriterion>(selectedIdsValue);
            IList<VertexErrorLogDto.VertexErrorLog> vertexErrorLogList = new List<VertexErrorLogDto.VertexErrorLog>();
            GetAccountsTaxRequest request = new GetAccountsTaxRequest();
            request.WorkOrderId = vertexErrorLog.WorkOrderId;
            request.state = vertexErrorLog.state;
            request.errorDateFrom = vertexErrorLog.errorDateFrom;
            request.errorDateTo = vertexErrorLog.errorDateTo;
            request.PageSize = 10000;
            request.SkipCount = 0;
            GetAccountsTaxResponse vertexSearch = service.GetAccountsTax(request);

            foreach (var vertexError in vertexSearch.AccountsReceivableList)
            {
                VertexErrorLogDto.VertexErrorLog vertexErrorProcessing = new VertexErrorLogDto.VertexErrorLog();
                if (vertexError.AccountsReceivableDetail != null && vertexError.AccountsReceivableDetail.AccountsReceivable != null && vertexError.AccountsReceivableDetail.AccountsReceivable.WorkOrders != null)
                {
                    vertexErrorProcessing.workOrderId = vertexError.AccountsReceivableDetail.AccountsReceivable.WorkOrders.WorkOrderId;
                    if (vertexError.AccountsReceivableDetail.AccountsReceivable.WorkOrders.Order != null)
                    {
                        vertexErrorProcessing.ErrorDate = vertexError.ErrorDate;
                        vertexErrorProcessing.ErrorMessage = vertexError.ErrorMsg;
                        vertexErrorProcessing.EligibleAmount = vertexError.AccountsReceivableDetail.FinalTotalPrice;
                        if (vertexError.AccountsReceivableDetail.AccountsReceivable.WorkOrders.Order.Loan != null)
                        {
                            vertexErrorProcessing.clientNumber = vertexError.AccountsReceivableDetail.AccountsReceivable.WorkOrders.Order.Loan.SubClientProfileId;
                            vertexErrorProcessing.Address = vertexError.AccountsReceivableDetail.AccountsReceivable.WorkOrders.Order.Loan.PropAddress1 + "  " + vertexError.AccountsReceivableDetail.AccountsReceivable.WorkOrders.Order.Loan.PropAddress2;
                            vertexErrorProcessing.City = vertexError.AccountsReceivableDetail.AccountsReceivable.WorkOrders.Order.Loan.MailCityName;
                            vertexErrorProcessing.State = vertexError.AccountsReceivableDetail.AccountsReceivable.WorkOrders.Order.Loan.MailStateCode;
                            vertexErrorProcessing.Zip = vertexError.AccountsReceivableDetail.AccountsReceivable.WorkOrders.Order.Loan.MailZipCode;
                            vertexErrorProcessing.Zip4 = vertexError.AccountsReceivableDetail.AccountsReceivable.WorkOrders.Order.Loan.MailZipPlusFour;
                        }
                    }
                    if (vertexError.AccountsReceivableDetail.AccountsReceivable.WorkOrders.Product != null)
                    {
                        string[] vprCodes = { "INITIAL", "RENEWAL", "DEREG", "AMEND", "MUNLTR", "REGINSP", "VIOLNPAY" };
                        if (vprCodes.Contains(vertexError.AccountsReceivableDetail.AccountsReceivable.WorkOrders.Product.ProductCode))
                            if (vertexError.AccountsReceivableDetail.AccountsReceivable.WorkOrders.Product.IsFeeBased)
                                vertexErrorProcessing.ProductName = vertexError.AccountsReceivableDetail.FeeType.FeeTypeName;
                            else
                                vertexErrorProcessing.ProductName = vertexError.AccountsReceivableDetail.AccountsReceivable.WorkOrders.Product.ProductName;
                        else if (vertexError.AccountsReceivableDetail.AccountsReceivable.WorkOrders.Product.ProductServices.Count != 0)
                            vertexErrorProcessing.ProductName = vertexError.AccountsReceivableDetail.AccountsReceivable.WorkOrders.Product.ProductServices.FirstOrDefault().Service.ServiceName;
                    }
                }
                vertexErrorLogList.Add(vertexErrorProcessing);
            }



            return vertexErrorLogList;
        }
        public override ExportedVertexErrorLog MapTToTE(VertexErrorLogDto.VertexErrorLog vertexLog)
        {
            if (vertexLog == null) throw new ArgumentNullException("vertexLog");

            var exportedVertexErrorLog = new ExportedVertexErrorLog
            {
                workOrderId = vertexLog.workOrderId,
                clientNumber = vertexLog.clientNumber,
                ProductName = vertexLog.ProductName,
                Address = vertexLog.Address,
                City = vertexLog.City,
                State = vertexLog.State,
                Zip = vertexLog.Zip,
                Zip4 = vertexLog.Zip4,
                ErrorMessage = vertexLog.ErrorMessage,
                ErrorDate = vertexLog.ErrorDate,
                EligibleAmount = vertexLog.EligibleAmount
            };
            return exportedVertexErrorLog;
        }

        public override string ExportIdentifier
        {
            get { return VertexErrorLogValue; }
            set { value = VertexErrorLogValue; }
        }
        private static IList<int> GetSelectedIds(GenerateDocumentRequest generateDocumentRequest, string collectionKey)
        {
            if (generateDocumentRequest == null) throw new ArgumentNullException("generateDocumentRequest");
            if (string.IsNullOrEmpty(collectionKey)) throw new ArgumentNullException("collectionKey");

            DocumentMetadata filterTypeData = generateDocumentRequest.Metadata
              .SingleOrDefault(x => x.Key.Equals(collectionKey, StringComparison.OrdinalIgnoreCase));

            if (filterTypeData == null || filterTypeData.Value == null) return new int[0];

            var selectedIdsValue = filterTypeData.Value.ToString();
            var selectedIds = selectedIdsValue
              .Split(new[] { ',' })
              .Select(x => x.Trim());

            var numericIds = new List<int>();
            foreach (var selectedId in selectedIds)
            {
                int convertedId;
                if (int.TryParse(selectedId, out convertedId))
                {
                    numericIds.Add(convertedId);
                }
            }

            return numericIds;
        }

        public GenerateDocumentResponse GetDocumentRequest()
        {
            return new GenerateDocumentResponse();
        }

    }

    class VertexErrorLogCriterion
    {
        public int? WorkOrderId { get; set; }


        public string state { get; set; }


        public DateTime? errorDateFrom { get; set; }


        public DateTime? errorDateTo { get; set; }

    }
}
