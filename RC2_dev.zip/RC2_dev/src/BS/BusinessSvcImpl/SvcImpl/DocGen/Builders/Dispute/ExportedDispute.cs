﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OrderDto = BusinessSvcImpl.DataObjects.SpaAccounting.Dto;


namespace BusinessSvcImpl.SvcImpl.DocGen.Builders.Order
{
    public class ExportedDisputed
    {

        public int DisputeId { get; set; }

       
        public string AssignedTo { get; set; }

        public string DisputeDate { get; set; }

        public string DisputeDueDate { get; set; }

        public string InvoiceNumber { get; set; }

        public decimal DisputeStatusType { get; set; }

        public string ClientName { get; set; }

        public string LoanNumber { get; set; }


        public string VendorId { get; set; }
        public string VendorWorkOrderId { get; set; }
        public string InspWorkOrderId { get; set; }
        public decimal DisputeAmount { get; set; }
    }
}
