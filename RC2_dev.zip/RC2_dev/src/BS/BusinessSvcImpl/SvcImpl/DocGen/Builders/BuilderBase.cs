using System;
using BusinessSvcImpl.DataObjects.DocGen;
using Newtonsoft.Json;
using UserContext = CommonLib.Context.UserContext;
using System.Security.Authentication;

namespace BusinessSvcImpl.SvcImpl.DocGen.Builders
{
    public abstract class BuilderBase : IDocumentBuilder
    {
        public abstract GeneratedDocumentInfo GenerateDocument(GenerateDocumentRequest request);

        protected int GetCurrentUserId(GenerateDocumentRequest request)
        {
            var userContext = JsonConvert.DeserializeObject<UserContext>(request.UserContext);
            //since UserId does not mapped to appUserId
            if (userContext == null)
            {
                throw new AuthenticationException("Could not determine user context.");
            }

            return userContext.UserId;
        }

    }
}