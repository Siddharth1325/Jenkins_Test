﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.SqlTypes;
using System.Reflection;
using System.Text;
using NPOI.XSSF.UserModel;
using System.IO; // XSSFWorkbook, XSSFSheet
using NPOI.SS.UserModel; 

namespace BusinessSvcImpl.SvcImpl.DocGen.Builders
{
    public class ExcelExport<T> where T : class
    {
        private List<T> Objects;
        public ExcelExport(IEnumerable<T> objects)
        {
            Objects = new List<T>(objects);
        }
        public string ExportSheetName { get; set; }
        int headerRowIndex = 0;
        private XSSFWorkbook Export()
        {
            XSSFWorkbook workBook = new XSSFWorkbook();
            XSSFSheet workSheet = (XSSFSheet)workBook.CreateSheet(ExportSheetName ?? "Sheet1");
            GenerateHeader(workSheet);
            GenerateExportData(workSheet);
            return workBook;

        }

        public byte[] ExportToBytes()
        {
            using (MemoryStream ms = new MemoryStream())
            {
                Export().Write(ms);
                return ms.ToArray();
            }

        }

        private static string MakeValueExcelFriendly(object value)
        {
            if (value == null) return "";
            if (value is Nullable && ((INullable)value).IsNull) return "";

            if (value is DateTime)
            {
                return
                    ((DateTime)value).ToString(((DateTime)value).TimeOfDay.TotalSeconds == 0
                        ? "yyyy-MM-dd"
                        : "yyyy-MM-dd HH:mm:ss");
            }
            var output = value.ToString();

            return output;

        }

        /// <summary>
        /// Make a value to excel formatted number.
        /// </summary>
        /// <param name="val"></param>
        /// <returns></returns>
        private string MakeValueExcelNumber(object val)
        {
            if (val == null) return "";
            if (val is Nullable && ((INullable)val).IsNull) return "";

            string retval = "";

            if (val is Nullable<Decimal>)
            {
                retval = ((Nullable<Decimal>)val).Value.ToString("n2"); // 2dp Number
            }
            else if (val is Decimal )
            {
                retval = ((Decimal)val).ToString("n2"); // 2dp Number
            }
            //else if (val is String && Decimal.TryParse((string)val, out valDecimal) && valDecimal > 0)
            //{
            //    retval = valDecimal.ToString("n2"); // 2dp Number
            //}

            return retval;
        }

        /// <summary>
        /// This Method is used to generate header for Sheet.
        /// </summary>
        /// <param name="requestedWorkSheet"></param>
        private void GenerateHeader(XSSFSheet requestedWorkSheet)
        {
            IList<PropertyInfo> propertyInfos = typeof(T).GetProperties();

            var headerRow = requestedWorkSheet.CreateRow(headerRowIndex);

            //add header line.
            int currentItemIndex = 0;
            foreach (var propertyInfo in propertyInfos)
            {
                var cell = headerRow.CreateCell(currentItemIndex);
                var tempDescriptionAttribute =
                    ((DescriptionAttribute)
                        Attribute.GetCustomAttribute(propertyInfo, typeof(DescriptionAttribute)));
                if (null != tempDescriptionAttribute && !String.IsNullOrEmpty(tempDescriptionAttribute.Description))
                {
                    // To Create WorkSheetHeader excel fetch the Name from the attribute
                    cell.SetCellValue(MakeValueExcelFriendly(tempDescriptionAttribute.Description));

                }
                else
                {
                    // This will only work if no Description Attribute is set.
                    cell.SetCellValue(propertyInfo.Name);
                }
                currentItemIndex++;
            }
        }
        /// <summary>
        /// This Code is used to export data in excel 
        /// </summary>
        /// <param name="requestedWorkSheet"></param>
        private void GenerateExportData(XSSFSheet requestedWorkSheet)
        {
            IList<PropertyInfo> propertyInfos = typeof(T).GetProperties();
            // This GetHashCode wiil fetch the Data from requested type list.
            foreach (var obj in Objects)
            {
                headerRowIndex++;
                var headerRow = requestedWorkSheet.CreateRow(headerRowIndex);
                int currentItemIndex = 0;
                foreach (var propertyInfo in propertyInfos)
                {
                    var cell = headerRow.CreateCell(currentItemIndex);
                    var val = propertyInfo.GetValue(obj, null);

                    //for numaric values format cell type to numeric.
                    string excelNumber = MakeValueExcelNumber(val);
                    if (!string.IsNullOrEmpty(excelNumber))
                    {
                        cell.SetCellValue(excelNumber);
                        cell.SetCellType(CellType.String);
                    }
                    else
                    {
                        cell.SetCellValue(MakeValueExcelFriendly(val));
                    }
                    currentItemIndex++;
                }

            }
        }

    }
}
