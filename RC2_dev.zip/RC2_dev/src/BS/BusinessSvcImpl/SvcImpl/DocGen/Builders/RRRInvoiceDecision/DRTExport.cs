﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessSvcImpl.SvcImpl.DocGen.Builders.RRRInvoiceDecision
{
    public class DRTEPOXRT
    {
        [Description("Assigned To FirstName")]
        public string AssignedToFirstName { get; set; }

        [Description("Assigned To LastName")]
        public string AssignedToLastName { get; set; }

        [Description("Client #")]
        public string ClientNumber { get; set; }

        [Description("Loan #")]
        public string LoanNumber { get; set; }

        [Description("Invoice #")]
        public string InvoiceNumber { get; set; }

        [Description("Invoice Date")]
        public string InvoiceDate { get; set; }

        [Description("Invoice Amount")]
        public decimal? InvoiceTotal { get; set; }

        [Description("Vendor #")]
        public string VendorId { get; set; }

        [Description("Vendor Work Order #")]
        public int VendorOrderNumber { get; set; }

        [Description("Inspections Work Order #")]
        public string WorkOrderId{ get; set; }

        [Description("Dispute Date")]
        public string InvoiceDecisionDate { get; set; }

        [Description("Dispute Due Date")]
        public string DisputeDueDate{ get; set; }

        [Description("Dispute Type")]
        public string DisputeType{ get; set; }

        [Description("Dispute Comments")]
        public string InvoiceDecisionComments { get; set; }

        [Description("Dispute Amount")]
        public decimal? DisputeAmount { get; set; }
        

    }
}
