﻿using ARAdjustmentsDto = BusinessSvcImpl.DataObjects.SpaAccounting.Dto;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace BusinessSvcImpl.SvcImpl.DocGen.Builders.APAdjustments
{
    public class ExportedAPAdjustmentInternal
    {

        public string WorkOrderNumber { get; set; }
        public string OrderNumber { get; set; }
        public string InvoiceNumber { get; set; }
        public string VendorNumber { get; set; }
        public string InspectorUniqueID { get; set; }
        public string AdjInvoiceNumber { get; set; }
        public string AdjustmentType { get; set; }
        public string AdjustmentDate { get; set; }
        public string AdjustmentCode { get; set; }
        public string ReserveType { get; set; }
        public string Amount { get; set; }
        public string Operation { get; set; }
        public string Function { get; set; }
        public string NaturalAccount { get; set; }
        public string AdjInternalComments { get; set; }
        public string SupplierComments { get; set; }


    }
}