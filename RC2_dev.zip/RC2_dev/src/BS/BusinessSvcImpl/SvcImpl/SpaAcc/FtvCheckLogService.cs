﻿using FtvDel = Delegate.SpaAcc;

namespace BusinessSvcImpl.SvcImpl.SpaAcc
{
    using BusinessSvcImpl.DataObjects.SpaAccounting.Dto;
    using CommonLib;
    using Reference.ServiceProxy.ReferenceService;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.ServiceModel;
    using System.Text;
    using System.Threading.Tasks;
    using System.Transactions;

    public partial class SpaAccountingService : ISpaAccountingService
    {

        [OperationBehavior(TransactionScopeRequired = true)]
        public SaveNewCheckResponse SaveNewCheck(SaveNewCheckRequest request)
        {
            if (ValidateNewCheckRequest(request))
                throw new Exception("Invalid Arguements to Save Check");

            var response = new SaveNewCheckResponse();
            var applicationId = CommonLib.Context.ApplicationContext.Instance.UserContext.ApplicationId;
            var del = new FtvDel.FtvCheckLogDelegate();
            var billDel = new FtvDel.BillingAdjustmentDelegate();

            foreach (var checkReq in request.NewCheckList)
            {
                var payable = new SavePayableInfo()
                {
                    CheckAmount = checkReq.CheckAmount,
                    Comments = checkReq.Comments,
                    FeeTypeId = checkReq.FeeTypeId,
                    OrderHierarchyId = checkReq.OrderHierarchyId,
                    PayeeName = checkReq.PayeeName
                };
                var apd = SavePayableData(payable, applicationId, del, billDel, "NEWCHK");

                var feeType = del.GetFeeType(checkReq.FeeTypeId);
                var isRevenue = false;
                if (feeType != null)
                    isRevenue = feeType.IsRevenue.GetValueOrDefault();

                if (isRevenue)
                {
                    var receivable = new SaveReceivableInfo()
                    {
                        CheckAmount = checkReq.CheckAmount,
                        Comments = checkReq.Comments,
                        FeeTypeId = checkReq.FeeTypeId,
                        OrderHierarchyId = checkReq.OrderHierarchyId,
                        PayeeName = checkReq.PayeeName,
                        AdjustmentCode = "NWCHK",
                        //ARAdjStatusType = "RDY2BILL",
                        ARAdjStatusType = "NEW",
                        AdjustmentType = "DEBIT",
                        FeeTypeRefId = apd.AccountsPayableDetailId

                    };
                    SaveNewReceivableData(receivable, del, billDel);

                }
            }

            response.IsSuccess = true;
            return response;
        }

        //[OperationBehavior(TransactionScopeRequired = true)]
        public RejectCheckResponse RejectCheck(RejectCheckRequest request)
        {
            if (request == null || request.TrackingLogSource == null || request.TrackingLogSource.OrderHierarchyId <= 0 || request.RejectPayeeList == null || request.RejectPayeeList.Count <= 0)
                throw new Exception("Invalid Arguements to Reject Check");

            var applicationId = CommonLib.Context.ApplicationContext.Instance.UserContext.ApplicationId;

            var del = new FtvDel.FtvCheckLogDelegate();
            var billDel = new FtvDel.BillingAdjustmentDelegate();
            var emailData = new List<DomainModel.FtvCheckLog.ChecksLogEmail>();
            string checkNumber = request.AccountsPayableInvoiceId.HasValue ? new FtvDel.FtvCheckLogDelegate().GetCheckNumberByInvoiceId(request.AccountsPayableInvoiceId.Value) : string.Empty;
            string rejectionReason = GetReferenceElementName("REJREA", request.RejectionReason);

            using (var scope = new TransactionScope(TransactionScopeOption.RequiresNew, new TransactionOptions { IsolationLevel = IsolationLevel.ReadCommitted }))
            {
                foreach (var reject in request.RejectPayeeList)
                {
                    DomainModel.Accounting.AccountsPayableDetail rejectDetail = null;
                    if (!request.IsReOrderOnly)
                        rejectDetail = VoidPayableDetail(del, reject, billDel, request.TrackingLogSource.OrderHierarchyId, request.RejectionComments);
                    else
                        rejectDetail = del.GetAccountsPayableDetailByKey(reject.AccountsPayableDetailId);

                    int newAccountsPayableDetailId = 0;
                    if (request.IsRejectAndReOrder || request.IsReOrderOnly)
                    {
                        var payable = new SavePayableInfo()
                        {
                            CheckAmount = reject.Amount,
                            Comments = request.RejectionComments,
                            FeeTypeId = reject.FeeTypeId,
                            OrderHierarchyId = request.TrackingLogSource.OrderHierarchyId,
                            PayeeName = rejectDetail.PayeeName,
                            FeeTypeRefId = rejectDetail.FeeTypePaymentRefId
                        };
                        var apdd = SavePayableData(payable, applicationId, del, billDel, "CHKREORD"); // Save New Trans
                        newAccountsPayableDetailId = apdd.AccountsPayableDetailId;
                    }

                    var feeType = del.GetFeeType(reject.FeeTypeId);
                    var isRevenue = false;
                    if (feeType != null)
                        isRevenue = feeType.IsRevenue.GetValueOrDefault();

                    if (isRevenue)
                    {
                        SaveReceivableInfo info = null;
                        if (request.IsRejectAndReOrder && reject.DiffAmount != 0)
                        {
                            info = new SaveReceivableInfo()
                            {
                                CheckAmount = reject.DiffAmount,
                                Comments = request.RejectionComments,
                                FeeTypeId = reject.FeeTypeId,
                                PayeeName = reject.PayeeName,
                                OrderHierarchyId = request.TrackingLogSource.OrderHierarchyId,
                                AdjustmentCode = reject.DiffAmount < 0 ? "ARCR1" : "ARDR1",
                                ARAdjStatusType = "NEW",
                                AdjustmentType = reject.DiffAmount < 0 ? "CREDIT" : "DEBIT",
                                FeeTypeRefId = newAccountsPayableDetailId,
                                RejectPaymentRefId = rejectDetail.FeeTypePaymentRefId
                            };
                        }
                        else if (request.IsReOrderOnly)
                        {
                            info = new SaveReceivableInfo()
                            {
                                CheckAmount = reject.Amount,
                                Comments = request.RejectionComments,
                                FeeTypeId = reject.FeeTypeId,
                                PayeeName = reject.PayeeName,
                                AdjustmentCode = "REORD",
                                OrderHierarchyId = request.TrackingLogSource.OrderHierarchyId,
                                ARAdjStatusType = "NEW",
                                AdjustmentType = "DEBIT",
                                FeeTypeRefId = newAccountsPayableDetailId,
                                RejectPaymentRefId = rejectDetail.FeeTypePaymentRefId
                            };
                        }
                        else if (!request.IsRejectAndReOrder && !request.IsReOrderOnly) // REJECT ONLY
                        {
                            info = new SaveReceivableInfo()
                            {
                                CheckAmount = reject.Amount * -1,
                                Comments = request.RejectionComments,
                                FeeTypeId = reject.FeeTypeId,
                                PayeeName = reject.PayeeName,
                                AdjustmentCode = "VOID",
                                OrderHierarchyId = request.TrackingLogSource.OrderHierarchyId,
                                ARAdjStatusType = "NEW",
                                AdjustmentType = "CREDIT",
                                RejectPaymentRefId = rejectDetail.FeeTypePaymentRefId
                            };
                        }
                        if (info != null)
                        {
                            if (request.IsReOrderOnly)
                                SaveNewReceivableData(info, del, billDel);
                            else
                            {
                                var isARData = SaveRejectReceivableData(info, del, billDel);
                                if (!isARData)
                                {
                                    int workOrderId = new FtvDel.FtvCheckLogDelegate().GetSourceWorkOrderIdByOrderHierarchy(request.TrackingLogSource.OrderHierarchyId);
                                    var data = new DomainModel.FtvCheckLog.ChecksLogEmail
                                    {
                                        FeeAmount = reject.Amount,
                                        RejectionComments = request.RejectionComments,
                                        RejectionDate = DateTime.Now,
                                        RejectionReason = rejectionReason,
                                        FeeTypeName = feeType.FeeTypeName,
                                        WorkOrderId = workOrderId,
                                        CheckNumber = checkNumber
                                    };
                                    emailData.Add(data);
                                }
                            }
                        }
                    }

                    SaveRejectionTrackingLog(request, del);
                    
                }
                scope.Complete();
            }

            if (emailData.Count > 0)
            {
                SendEmailNotification(emailData);
            }

            var response = new RejectCheckResponse();
            response.IsSuccess = true;
            return response;
        }

        private string GetReferenceElementName(string groupCode, string elementCode)
        {
            try
            {
                if (string.IsNullOrEmpty(groupCode))
                    throw new ArgumentNullException(groupCode);
                else if (string.IsNullOrEmpty(elementCode))
                    throw new ArgumentNullException(elementCode);

                ReferenceData rdata = null;
                using (var proxy = new ReferenceDataServiceClient())
                {
                    var response = proxy.GetReferenceDataElementByCode(new GetReferenceDataElementByCodeRequest() { GroupCode = groupCode, ElementCode = elementCode });
                    rdata = response != null && response.ReferenceDataElement != null ? response.ReferenceDataElement : null;
                }

                return rdata != null ? rdata.ElementName : string.Empty;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public CheckDeliveryConfirmationResponse SaveCheckDeliveryConfirmation(CheckDeliveryConfirmationRequest request)
        {
            if (request == null)
                throw new Exception("Invalid Arguements to Save Check Delivery Info");
            var response = new CheckDeliveryConfirmationResponse();
            var del = new FtvDel.FtvCheckLogDelegate();
            var trackingLog = GetTrackingLogForDeliveryConfirmation(request, del);
            del.SaveAccountsPayableTrackingLog(trackingLog);
            response.IsSuccess = true;
            return response;
        }

        public CheckLogSearchResponse FtvCheckLogSearch(CheckLogSearchRequest searchRequest)
        {
            if (searchRequest == null)
                throw new Exception("Cannot do Search");

            var response = new CheckLogSearchResponse();
            var searchInput = BuildSearchInputDao(searchRequest);

            var searchResponse = new FtvDel.FtvCheckLogDelegate().CheckLogSearch(searchInput);
            if (searchResponse != null && searchResponse.Count > 0)
            {
                foreach (var daoResp in searchResponse)
                    BuildCheckLogDto(response, daoResp);
            }
            return response;
        }

        public CheckLogSearchExportResponse FtvCheckLogSearchExport(CheckLogSearchRequest searchRequest)
        {
            if (searchRequest == null)
                throw new Exception("Cannot do Search");

            var response = new CheckLogSearchExportResponse();
            var searchInput = BuildSearchInputDao(searchRequest);
            var searchResponse = new FtvDel.FtvCheckLogDelegate().CheckLogSearchExport(searchInput);
            if (searchResponse != null && searchResponse.Count > 0)
            {
                foreach (var daoResp in searchResponse)
                    BuildCheckLogExportDto(response, daoResp);
            }

            return response;
        }

        public SaveCheckInformationResponse SaveBasicCheckInfo(SaveCheckInformationRequest request)
        {
            if (request == null || request.TrackingLogInfo == null || request.TrackingLogInfo.Count <= 0)// || request.TrackingLogInfo.Any(p => p.TrackingLogSource.AccountsPayableInvoiceId.GetValueOrDefault() <= 0))
                throw new Exception("Invalid Information to Save Info");

            var response = new SaveCheckInformationResponse();
            var del = new FtvDel.FtvCheckLogDelegate();
            foreach (var trackingInfo in request.TrackingLogInfo)
            {
                if (CanSavePayableTrackingLog(trackingInfo))
                    SaveTrackingLog(del, trackingInfo);

                if (CanSavePayableDetail(trackingInfo))
                    SavePayableRemittance(del, trackingInfo);

            }


            response.IsSuccess = true;
            return response;
        }

        public PayeeDetailResponse GetPayeeList(PayeeDetailsRequest request)
        {
            if (request == null || request.OrderHierarchyId <= 0)
                throw new Exception("Invalid Arguements");
            var response = new PayeeDetailResponse();
            var del = new FtvDel.FtvCheckLogDelegate();
            var daoResponse = del.GetPayeeList(request.OrderHierarchyId, request.PayableInvoiceId);
            if (daoResponse != null && daoResponse.Count > 0)
            {
                foreach (var resp in daoResponse)
                {
                    response.PayeeDetails.Add(new PayeeDetail()
                    {
                        Amount = resp.Amount,
                        PayableDetailId = resp.PayableDetailId,
                        PayeeName = resp.PayeeName,
                        FeeTypeId = resp.FeeTypeId,
                        FeeType = resp.FeeType

                    });
                }
            }
            return response;
        }

        #region Private Region

        private static bool ValidateNewCheckRequest(SaveNewCheckRequest request)
        {
            return request == null
                 || request.NewCheckList == null
                 || request.NewCheckList.Count <= 0
                 || request.NewCheckList.Any(p => p.OrderHierarchyId <= 0 || p.FeeTypeId <= 0);
        }

        private static void SaveRejectionTrackingLog(RejectCheckRequest request, FtvDel.FtvCheckLogDelegate del)
        {
            var trackingLog = del.GetAccountsPayableTrackingLogByOrderHierarchyId(request.TrackingLogSource.OrderHierarchyId, request.TrackingLogSource.AccountsPayableInvoiceId);
            if (trackingLog == null || trackingLog.AccountsPayableTrackingLogId <= 0)
            {
                trackingLog = new DomainModel.Accounting.AccountsPayableTrackingLog();
                trackingLog.WorkOrderId = del.GetWorkOrderIdByOrderHierarchy(request.TrackingLogSource.OrderHierarchyId);
                trackingLog.RejectedDate = DateTime.Now;
                trackingLog.RejectionReason = request.RejectionReason;
                trackingLog.RejectionReasonGroup = "REJREA";
                trackingLog.RejectionReasonComments = request.RejectionComments;
            }
            else
            {
                if (!trackingLog.RejectedDate.HasValue || trackingLog.RejectedDate == default(DateTime))
                    trackingLog.RejectedDate = DateTime.Now;

                if (!string.IsNullOrEmpty(request.RejectionReason) && string.IsNullOrEmpty(trackingLog.RejectionReason))
                {
                    trackingLog.RejectionReason = request.RejectionReason;
                    trackingLog.RejectionReasonGroup = "REJREA";
                }
                if (!string.IsNullOrEmpty(request.RejectionComments) && string.IsNullOrEmpty(trackingLog.RejectionReasonComments))
                    trackingLog.RejectionReasonComments = request.RejectionComments;
            }

            trackingLog.AccountsPayableInvoiceId = request.TrackingLogSource.AccountsPayableInvoiceId;
            trackingLog.IsReorderCheck = request.IsReOrderOnly || request.IsRejectAndReOrder;
            trackingLog.ReOrderDate = trackingLog.IsReorderCheck ? (DateTime?)DateTime.Now : null;
            del.SaveAccountsPayableTrackingLog(trackingLog);
        }

        private static DomainModel.Accounting.DisputePayableAdjustmentHistory BuildSaveDispPayableHist(SaveDisputeInfo info)
        {
            return new DomainModel.Accounting.DisputePayableAdjustmentHistory()
            {
                ApplicationId = info.ApplicationId,
                OrderHierarchyId = info.SavePayableInfo.OrderHierarchyId,
                Quantity = 1,
                QuantityAdjusted = 0,
                VendorFee = info.FinalAmount,
                VendorFeeAdjstdAmt = info.AdjustedAmount,
                VendorFinalFee = info.FinalAmount,
                VendorFinalFeeAdjstdAmt = info.AdjustedAmount,
                HistoryDate = DateTime.Now,
                VendorAdjComments = info.SavePayableInfo.Comments,
                RecordNumber = info.RecordNumber,
                AdjustmentHistoryRecordGroup = "ADJHIST",
                AdjustmentHistoryRecordType = info.RecordType,
                AdjustmentType = "MiscProd",
                FeeTypeId = info.SavePayableInfo.FeeTypeId,
                FeeTypePaymentRefId = info.PaymentRefId,
                //SupplierComment = info.SavePayableInfo.Comments
            };
        }

        private static DomainModel.Accounting.AccountsPayableDetail VoidPayableDetail(FtvDel.FtvCheckLogDelegate del, RejectPayee reject, FtvDel.BillingAdjustmentDelegate billDel, int orderHierarchyId, string comments)
        {
            var apd = del.GetAccountsPayableDetailByKey(reject.AccountsPayableDetailId);
            apd.APStatusType = "VOID";
            del.SaveAccountsPayableDetail(apd);

            var dpah = billDel.GetLatestDisputePayableAdjustmentHistory(orderHierarchyId, apd.FeeTypeId, apd.FeeTypePaymentRefId);
            if (dpah != null && dpah.DisputePayableAdjustmentHistoryId > 0)
            {
                if (dpah.VendorFee >= apd.FinalTotalCost)
                {
                    var dpajAdj = BuildSaveDispPayableHist(new SaveDisputeInfo()
                    {
                        SavePayableInfo = new SavePayableInfo()
                        {
                            OrderHierarchyId = orderHierarchyId,
                            CheckAmount = reject.Amount,
                            PayeeName = reject.PayeeName,
                            FeeTypeId = reject.FeeTypeId,
                            FeeTypeRefId = apd.FeeTypePaymentRefId,
                            Comments = comments,
                        },

                        ApplicationId = dpah.ApplicationId,
                        RecordNumber = dpah.AdjustmentHistoryRecordType == "ORIG" ? 2 : dpah.RecordNumber + 1,
                        RecordType = "ADJED",
                        PaymentRefId = dpah.FeeTypePaymentRefId,
                        AdjustedAmount = apd.FinalTotalCost.GetValueOrDefault() * -1,
                        FinalAmount = Math.Round(dpah.VendorFee.GetValueOrDefault() - apd.FinalTotalCost.GetValueOrDefault(), 2)
                    });

                    dpajAdj = billDel.SaveDisputePayableAdjustmentHistory(dpajAdj);
                    int adjHistId = dpajAdj.DisputePayableAdjustmentHistoryId;

                    decimal vendFee = Math.Round(dpah.VendorFee.GetValueOrDefault() - apd.FinalTotalCost.GetValueOrDefault(), 2);


                    if (dpah.AdjustmentHistoryRecordType == "ORIG")
                    {
                        dpah.DisputePayableAdjustmentHistoryId = -1;
                        dpah.HistoryDate = DateTime.Now;
                        dpah.VendorFee = vendFee;
                        dpah.VendorFinalFee = vendFee;
                        dpah.AdjustmentHistoryRecordType = "FINAL";
                        dpah.RecordNumber = 3;
                        dpah.Version = null;
                        dpah.VendorAdjComments = comments;
                        dpah.SourceDisputePayableAdjustmentHistoryId = null;
                        billDel.SaveDisputePayableAdjustmentHistory(dpah);
                    }


                    var invoiceID = reject.AccountsPayableInvoiceId;
                    var feeTypeId = reject.FeeTypeId;
                    var amount = apd.FinalTotalCost.GetValueOrDefault() * -1;
                    var acpAdj = BuildPayableAdjustment(
                        new SaveAdjustment()
                        {
                            applicationId = dpajAdj.ApplicationId,
                            orderHierarchyId = orderHierarchyId,
                            comments = comments,
                            adjHistId = adjHistId,
                            invoiceID = invoiceID,
                            feeTypeId = feeTypeId,
                            amount = amount,
                            PayableDetailId = reject.AccountsPayableDetailId
                        }, del);

                    billDel.SaveAccountsPayableAdjustment(acpAdj);
                }
            }
            else
            {
                // WE SHOULD NOT GET HERE
                Logging.LogError(string.Format("Not able to Find Dispute Record For Order HierarchyId: {0}, FeeTypeId: {1} , RefId {2}", orderHierarchyId, apd.FeeTypeId, apd.FeeTypePaymentRefId));
                throw new Exception("Exception in Rejecting Check, Not Able to create Adjustment");
            }
            return apd;
        }

        private static DomainModel.Accounting.AccountsPayableAdjustment BuildPayableAdjustment(SaveAdjustment adj, FtvDel.FtvCheckLogDelegate del)
        {
            var apGlCode = del.GetApGlCode(adj.orderHierarchyId, adj.feeTypeId);

            var acpAdj = new DomainModel.Accounting.AccountsPayableAdjustment()
            {
                AccountsPayableInvoiceId = adj.invoiceID,
                AdjustmentDate = DateTime.Now,
                AdjustmentType = "CREDIT",
                AdjustmentCode = "APVOD",
                ApplicationId = adj.applicationId,
                GLTransTypeGroup = "GLTRN",
                APAdjStatusGroup = "APADJSG",
                APAdjStatusType = "RDY2BILL",
                GLTransType = "APADJUST",
                Operation = apGlCode.Operation,
                Function = apGlCode.Function,
                NaturalAccount = apGlCode.NaturalAccount,
                Comments = adj.comments,
                // SupplierComment = adj.comments,
                DisputePayableAdjustmentHistoryId = adj.adjHistId,
                Amount = Math.Abs(Math.Round(adj.amount.GetValueOrDefault(), 2)),
                AccountsPayableDetailId = adj.PayableDetailId

            };
            //acpAdj.AdjustmentCode = GetAccountingAdjustmentCode("AP", acpAdj.AdjustmentType, adj.applicationId);
            return acpAdj;
        }

        private static void SaveNewReceivableData(SaveReceivableInfo request, FtvDel.FtvCheckLogDelegate del, FtvDel.BillingAdjustmentDelegate billDel)
        {
            var newArd = BuildNewReceivableObj(request);
            var disp = new DomainModel.Accounting.DisputeReceivableAdjustmentHistory()
            {
                ApplicationId = CommonLib.Context.ApplicationContext.Instance.UserContext.ApplicationId,
                OrderHierarchyId = request.OrderHierarchyId,
                Quantity = 1,
                //AgreedClientUnitPrice = request.CheckAmount,
                ClientPrice = request.CheckAmount,
                HistoryDate = DateTime.Now,
                RecordNumber = 1,
                AdjustmentHistoryRecordGroup = "ADJHIST",
                AdjustmentHistoryRecordType = "ORIG",
                FeeTypeId = request.FeeTypeId,
                FeeTypePaymentRefId = request.FeeTypeRefId
            };
            del.SaveNewAccountsReceivable(newArd, disp);
        }

        private static bool SaveRejectReceivableData(SaveReceivableInfo request, FtvDel.FtvCheckLogDelegate del, FtvDel.BillingAdjustmentDelegate billDel)
        {
            var recInvData = del.GetReceivableInvoice(request.OrderHierarchyId, request.FeeTypeId, request.RejectPaymentRefId);
            if (recInvData != null && recInvData.AccountsReceivableDetailId > 0)
            {
                var drah = billDel.GetLatestDisputeReceivableAdjustmentHistory(request.OrderHierarchyId, recInvData.FeeTypeId, recInvData.FeeTypeRefId);
                int disputeAdjId = 0;
                if (drah != null && drah.ClientPrice > 0 && drah.ClientPrice >= request.CheckAmount)
                {

                    var dispRecAdj = BuildReceivableAdjustmentRecord(request, drah.ApplicationId, drah);
                    dispRecAdj = billDel.SaveDisputeReceivableAdjustmentHistory(dispRecAdj);
                    disputeAdjId = dispRecAdj.DisputeReceivableAdjustmentHistoryId;
                    if (drah.AdjustmentHistoryRecordType == "ORIG")
                    {
                        var dispRecFinal = BuidReceivableFinalRecord(request, drah.ApplicationId, drah);
                        billDel.SaveDisputeReceivableAdjustmentHistory(dispRecFinal);
                    }
                    if (drah.AdjustmentHistoryRecordType == "FINAL")
                    {
                        var dispRecFinal = UpdateReceivableFinalRecord(request, drah.ApplicationId, drah);
                        billDel.SaveDisputeReceivableAdjustmentHistory(dispRecFinal);
                    }


                    var ard = new DomainModel.Accounting.AccountsReceivableAdjustment()
                    {
                        ApplicationId = drah.ApplicationId,
                        AccountsReceivableDetailId = recInvData.AccountsReceivableDetailId > 0 ? (int?)recInvData.AccountsReceivableDetailId : null,
                        AccountsReceivableInvoiceId = recInvData.AccountsReceivableInvoiceId > 0 ? (int?)recInvData.AccountsReceivableInvoiceId : null,
                        AdjustmentType = request.AdjustmentType,
                        //AdjustmentCode = GetAccountingAdjustmentCode("AP", request.AdjustmentType, applicationId),
                        AdjustmentCode = request.AdjustmentCode,// "NWCHK",
                        AdjustmentDate = DateTime.Now,
                        Amount = Math.Abs(request.CheckAmount.GetValueOrDefault()),
                        Comments = request.Comments,
                        ARAdjStatusGroup = "ARADJSG",
                        ARAdjStatusType = request.ARAdjStatusType,
                        DisputeReceivableAdjustmentHistoryId = disputeAdjId
                    };

                    var glCode = del.GetGlCode(request.OrderHierarchyId, request.FeeTypeId);
                    if (glCode != null)
                    {
                        ard.GLTransTypeGroup = "GLTRN";
                        ard.GLTransType = "ARADJUST";
                        ard.Operation = glCode.Operation;
                        ard.Function = glCode.Function;
                        ard.NaturalAccount = glCode.NaturalAccount;
                    }
                    billDel.SaveAccountsReceivableAdjustment(ard);

                }
                return true;
            }
            else
            {
                return false;
            }
        }

        public void SendEmailNotification(List<DomainModel.FtvCheckLog.ChecksLogEmail> emailData)
        {
            //get Communication Template for email                           
            var req = new Admin.ServiceProxy.ClientService.GetCommunicationTemplateRequest();

            req.CommType = "CHKRJCT";
            req.CommMethod = "COMMMTD3";
            req.ProductCategory = "PRESERV";

            var svc = new Admin.ServiceProxy.ClientServiceProxy();
            var communicationTemp = svc.GetCommunicationTemplate(0, req.ProductCategory, req.CommType, req.CommMethod);

            if (communicationTemp == null)
                CommonLib.Logging.LogError("Communication template not defined for Check Rejection.");
            else
            {
                var noti = new BusinessSvcImpl.Utilities.Notification();
                noti.SendCheckRejectionEmail(emailData, communicationTemp);
            }
        }

        private static DomainModel.Accounting.AccountsReceivableDetail BuildNewReceivableObj(SaveReceivableInfo request)
        {
            var newArd = new DomainModel.Accounting.AccountsReceivableDetail()
            {
                ApplicationId = CommonLib.Context.ApplicationContext.Instance.UserContext.ApplicationId,
                OrderHierarchyId = request.OrderHierarchyId,
                Quantity = 1,
                UnitsGroup = "ARUN",
                UnitsType = "ARUN1",
                BasePricePerUnit = request.CheckAmount.GetValueOrDefault(),
                BaseTotalPrice = request.CheckAmount.GetValueOrDefault(),
                FinalTotalPrice = request.CheckAmount.GetValueOrDefault(),
                FeeTypeId = request.FeeTypeId,
                ARStatusGroup = "ARSG",
                ARStatusType = "NEW",
                AcctProcessedDate = DateTime.Now,
                FeeTypePaymentRefId = request.FeeTypeRefId
            };
            var trace = new DomainModel.Accounting.AccountsReceivableTrace()
            {
                ApplicationId = CommonLib.Context.ApplicationContext.Instance.UserContext.ApplicationId,
                AccountsReceivableDetailId = newArd.AccountsReceivableDetailId,
                StartingPrice = request.CheckAmount,
                PriceSelectionReason = request.Comments
            };
            newArd.AccountsReceivableTraces = new List<DomainModel.Accounting.AccountsReceivableTrace>();
            newArd.AccountsReceivableTraces.Add(trace);
            return newArd;
        }

        private static DomainModel.Accounting.DisputeReceivableAdjustmentHistory BuidReceivableFinalRecord(SaveReceivableInfo request, int applicationId, DomainModel.Accounting.DisputeReceivableAdjustmentHistory drah)
        {
            return new DomainModel.Accounting.DisputeReceivableAdjustmentHistory()
            {
                ApplicationId = applicationId,
                OrderHierarchyId = request.OrderHierarchyId,
                Quantity = 1,
                ClientPrice = Math.Round(drah.ClientPrice.GetValueOrDefault() + request.CheckAmount.GetValueOrDefault(), 2),
                ClientPriceTax = drah.ClientPriceTax,
                HistoryDate = DateTime.Now,
                ClientAdjComments = request.Comments,
                RecordNumber = 3,
                AdjustmentHistoryRecordGroup = "ADJHIST",
                AdjustmentHistoryRecordType = "FINAL",
                AdjustmentType = "MiscProd",
                FeeTypeId = request.FeeTypeId,
                FeeTypePaymentRefId = drah.FeeTypePaymentRefId,
                InvoiceDate = drah.InvoiceDate,
                InvoiceNumber = drah.InvoiceNumber,

            };
        }
        private static DomainModel.Accounting.DisputeReceivableAdjustmentHistory UpdateReceivableFinalRecord(SaveReceivableInfo request, int applicationId, DomainModel.Accounting.DisputeReceivableAdjustmentHistory drah)
        {
            drah.ClientPrice = Math.Round(drah.ClientPrice.GetValueOrDefault() + request.CheckAmount.GetValueOrDefault(),2);
            drah.ClientAdjComments = request.Comments;
            drah.HistoryDate = DateTime.Now;
            return drah;
        }

        private static DomainModel.Accounting.DisputeReceivableAdjustmentHistory BuildReceivableAdjustmentRecord(SaveReceivableInfo request, int applicationId, DomainModel.Accounting.DisputeReceivableAdjustmentHistory drah)
        {
            return new DomainModel.Accounting.DisputeReceivableAdjustmentHistory()
            {
                ApplicationId = applicationId,
                OrderHierarchyId = request.OrderHierarchyId,
                Quantity = 1,
                ClientPrice = Math.Round(request.CheckAmount.GetValueOrDefault() + drah.ClientPrice.GetValueOrDefault(), 2),
                ClientPriceAdjstdAmt = request.CheckAmount,
                HistoryDate = DateTime.Now,
                ClientAdjComments = request.Comments,
                RecordNumber = drah.AdjustmentHistoryRecordType == "ORIG" ? 2 : drah.RecordNumber + 1,
                AdjustmentHistoryRecordGroup = "ADJHIST",
                AdjustmentHistoryRecordType = "ADJED",
                AdjustmentType = "MiscProd",
                FeeTypeId = request.FeeTypeId,
                FeeTypePaymentRefId = drah.FeeTypePaymentRefId,
            };
        }

        private static DomainModel.Accounting.AccountsPayableDetail SavePayableData(SavePayableInfo request, int applicationId, FtvDel.FtvCheckLogDelegate del, FtvDel.BillingAdjustmentDelegate billDel, string apCode)
        {
            var apd = new DomainModel.Accounting.AccountsPayableDetail()
            {
                ApplicationId = applicationId,
                OrderHierarchyId = request.OrderHierarchyId,
                Quantity = 1,
                UnitsGroup = "APUN",
                UnitsType = "APUN1",
                BaseCostPerUnit = request.CheckAmount,
                BaseTotalCost = request.CheckAmount.GetValueOrDefault(),
                FinalTotalCost = request.CheckAmount,
                FeeTypeId = request.FeeTypeId,
                PayeeName = request.PayeeName,
                APStatusGroup = "APSG",
                APStatusType = "RDY2BILL",
                AcctProcessedDate = DateTime.Now
            };


            var reason = GetApTraceReason(apCode);

            apd.AccountsPayableTraces.Add(new DomainModel.Accounting.AccountsPayableTrace()
            {
                ApplicationId = applicationId,
                AccountsPayableDetailId = apd.AccountsPayableDetailId,
                StartingCost = request.CheckAmount,
                CostSelectionReason = reason
            });

            apd = del.SaveAccountsPayableDetailWithTrace(apd);
            var apdd = del.GetAccountsPayableDetailByKey(apd.AccountsPayableDetailId);
            apdd.FeeTypePaymentRefId = apdd.AccountsPayableDetailId;
            del.SaveAccountsPayableDetail(apdd);

            var dpah = new DomainModel.Accounting.DisputePayableAdjustmentHistory()
            {
                ApplicationId = applicationId,
                OrderHierarchyId = request.OrderHierarchyId,
                FeeTypeId = request.FeeTypeId,
                Quantity = 1,
                AgreedUnitCost = request.CheckAmount,
                VendorFee = request.CheckAmount,
                RecordNumber = 1,
                AdjustmentHistoryRecordGroup = "ADJHIST",
                AdjustmentHistoryRecordType = "ORIG",
                FeeTypePaymentRefId = apd.AccountsPayableDetailId,
                HistoryDate = DateTime.Now,
                VendorFinalFee = request.CheckAmount,
                //SupplierComment = request.Comments
            };
            billDel.SaveDisputePayableAdjustmentHistory(dpah);
            return apdd;
        }

        private static string GetApTraceReason(string apCode)
        {
            var reason = string.Empty;
            switch (apCode)
            {
                case "NEWCHK":
                    reason = "Additional fee requested by municipality";
                    break;
                case "CHKREORD":
                    reason = "New Check is re-ordered for municipality fees";
                    break;
                case "CHKREJ":
                    reason = "Municipality check is rejected";
                    break;
            }
            return reason;
        }

        private static DomainModel.Accounting.AccountsPayableTrackingLog GetTrackingLogForDeliveryConfirmation(CheckDeliveryConfirmationRequest request, FtvDel.FtvCheckLogDelegate del)
        {
            DomainModel.Accounting.AccountsPayableTrackingLog trackingLog = null;
            var source = request.TrackingLogSource;
            if (source.AccountsPayableTrackingLogId > 0)
                trackingLog = del.GetAccountsPayableTrackingLogById(source.AccountsPayableTrackingLogId.Value);
            else if (source.OrderHierarchyId > 0)
                trackingLog = del.GetAccountsPayableTrackingLogByOrderHierarchyId(source.OrderHierarchyId, source.AccountsPayableInvoiceId);
            //else if (source.PlatFormWorkOrderId > 0)
            //    trackingLog = del.GetAccountsPayableTrackingLogByWorkOrderId(source.PlatFormWorkOrderId);
            else if (source.AccountsPayableRemittanceId.GetValueOrDefault() > 0)
                trackingLog = del.GetAccountsPayableTrackingLogByRemittanceId(source.AccountsPayableRemittanceId.Value);

            if (trackingLog == null || trackingLog.AccountsPayableTrackingLogId <= 0)
                trackingLog = new DomainModel.Accounting.AccountsPayableTrackingLog();

            if (trackingLog.AccountsPayableRemittanceId <= 0)
                trackingLog.AccountsPayableRemittanceId = source.AccountsPayableRemittanceId;
            trackingLog.AccountsPayableInvoiceId = source.AccountsPayableInvoiceId;

            trackingLog.WorkOrderId = source.PlatFormWorkOrderId;
            trackingLog.DeliveryConfirmStatus = request.ConfirmationStatus;
            trackingLog.DeliveryConfirmStatusGroup = "DCS";
            trackingLog.DeliveryConfirmDate = request.ConfirmationReceiptDate;
            trackingLog.DeliveryConfirmComments = request.ConfirmationComments;

            return trackingLog;
        }

        private static DomainModel.FtvCheckLog.CheckLogSearchInput BuildSearchInputDao(CheckLogSearchRequest searchRequest)
        {
            var dtoSearchInput = searchRequest.SearchInput;
            var searchInput = new DomainModel.FtvCheckLog.CheckLogSearchInput()
            {
                CheckedDateFrom = dtoSearchInput.CheckedDateFrom,
                CheckedDateTo = dtoSearchInput.CheckedDateTo,
                CheckNumber = dtoSearchInput.Check,
                ClientNumber = dtoSearchInput.ClientNumber,
                CompletedDateFrom = dtoSearchInput.CompletedDateFrom,
                CompletedDateTo = dtoSearchInput.CompletedDateTo,
                InvoiceNumber = dtoSearchInput.Invoice,
                IsDelieveryConfirmation = dtoSearchInput.IsDelieveryConfirmation,
                IsPosted = dtoSearchInput.IsPosted,
                LoanNumber = dtoSearchInput.LoanNumber,
                PageSize = searchRequest.PageSize,
                PayableName = dtoSearchInput.PayableName,
                SkipCount = searchRequest.SkipCount,
                TrackingNumber = dtoSearchInput.Tracking,
                WorkOrderId = dtoSearchInput.WorkOrderId

            };
            return searchInput;
        }

        private static void BuildCheckLogDto(CheckLogSearchResponse response, DomainModel.FtvCheckLog.CheckLogSearchResult daoResp)
        {
            response.SearchResults.Add(new CheckLogSearchResult()
            {
                AccountsPayableInvoiceId = daoResp.AccountsPayableInvoiceId,
                AccountsPayableRemittanceId = daoResp.AccountsPayableRemittanceId,
                AccountsPayableTrackingLogId = daoResp.AccountsPayableTrackingLogId,
                ClientNumber = daoResp.ClientNumber,
                ConfirmationNo = daoResp.ConfirmationNo,
                DeliveryConfirmDate = daoResp.DeliveryConfirmDate,
                FeeAmount = daoResp.TotalAmountDue,
                InvoiceNumber = daoResp.InvoiceNumber,
                LoanNumber = daoResp.LoanNumber,
                OrderHierarchyId = daoResp.OrderHierarchyId,
                PayableName = daoResp.PayableName,
                PaymentDate = daoResp.ConfirmationDate,
                PaymentType = daoResp.PaymentType,
                PlatformWorkOrderId = daoResp.WorkOrderId,
                PostedDate = daoResp.PostedDate,
                SourceWorkOrderId = daoResp.SourceWorkOrderId,
                TrackingNumber = daoResp.TrackingNumber,
                WorkOrderStatus = daoResp.WorkOrderStatusType,
                DeliveryConfirmComments = daoResp.DeliveryConfirmComments,
                DeliveryConfirmStatusCode = daoResp.DeliveryConfirmStatusCode,
                IsReorderCheck = daoResp.IsReorderCheck,
                RejectionReasonCode = daoResp.RejectionReasonCode,
                RejectionReasonComments = daoResp.RejectionReasonComments,
                ApStatus = daoResp.ApStatus,
                ApStatusType = daoResp.ApStatusType,
                FeeTypePaymentRefId = daoResp.FeeTypePaymentRefId

            });
        }

        private static void BuildCheckLogExportDto(CheckLogSearchExportResponse response, DomainModel.FtvCheckLog.CheckLogSearchResultExport daoResp)
        {
            response.SearchExportResults.Add(new CheckLogExport()
            {


                ClientNumber = daoResp.ClientNumber.ToString(),
                CommentPrintedCheck = daoResp.DeliveryConfirmComments,
                ConfirmationNo = daoResp.ConfirmationNo,
                DeliveryConfirmComments = daoResp.DeliveryConfirmComments,
                DeliveryConfirmDate = daoResp.DeliveryConfirmDate.HasValue ? daoResp.DeliveryConfirmDate.GetValueOrDefault().ToShortDateString() : "",
                DeliveryConfirmStatus = daoResp.DeliveryConfirmStatus,
                FeeAmount = daoResp.TotalAmountDue,
                FeeTypeName = daoResp.FeeTypeName,
                InvoiceNumber = daoResp.InvoiceNumber,
                LoanNumber = daoResp.LoanNumber,
                PaymentDate = daoResp.ConfirmationDate.HasValue ? daoResp.ConfirmationDate.GetValueOrDefault().ToShortDateString() : "",
                PaymentType = daoResp.PaymentType,
                PostedDate = daoResp.PostedDate.HasValue ? daoResp.PostedDate.GetValueOrDefault().ToShortDateString() : "",
                RejectedDate = daoResp.RejectedDate.HasValue ? daoResp.RejectedDate.GetValueOrDefault().ToShortDateString() : "",
                RejectionReason = daoResp.RejectionReason,
                RejectionReasonComments = daoResp.RejectionReasonComments,
                ReOrderDate = daoResp.ReOrderDate.HasValue ? daoResp.ReOrderDate.GetValueOrDefault().ToShortDateString() : "",

                TrackingNumber = daoResp.TrackingNumber,
                WorkOrderId = daoResp.SourceWorkOrderId,
                WorkOrderStatus = daoResp.WorkOrderStatusType,

                PayableName = daoResp.PayableName,
                PayableAddress = daoResp.PayableAddress,
                State = daoResp.PayableStateCode,
                City = daoResp.PayableCity,
                Zip = daoResp.PayableZipCode,
                ApStatus = daoResp.ApStatus,
                AssetAddress = daoResp.AssetAddress,
                AssetCity = daoResp.AssetCity,
                AssetStateCode = daoResp.AssetStateCode,
                AssetZipCode = daoResp.AssetZipCode,
                AssetZipPlusFour = daoResp.AssetZipPlusFour,
                RegCompletedDate = daoResp.AcctProcessedDate.HasValue ? daoResp.AcctProcessedDate.GetValueOrDefault().ToShortDateString() : ""

            });
        }

        private static void SavePayableRemittance(FtvDel.FtvCheckLogDelegate del, TrackingLogInfo trackingInfo)
        {
            var apd = del.GetAccountsPayableDetailByHierarchyId(trackingInfo.TrackingLogSource.OrderHierarchyId);
            var accInvoice = del.GetAccountsPayableInvoice(trackingInfo.TrackingLogSource.AccountsPayableInvoiceId.Value);

            if (accInvoice != null)
            {
                var apr = del.GetRemittanceByInvoiceId(accInvoice.AccountsPayableInvoiceId);
                if (apr == null || apr.AccountsPayableRemittanceId <= 0)
                {
                    apr = new DomainModel.Accounting.AccountsPayableRemittance()
                    {
                        AccountsPayableInvoiceId = accInvoice.AccountsPayableInvoiceId,
                        ApplicationId = accInvoice.ApplicationId,
                        CheckDate = trackingInfo.PaymentDate.GetValueOrDefault(),
                        CheckNumber = trackingInfo.ConfirmationNumber,
                        InvoiceAmount = accInvoice.InvoiceAmount,
                        InvoiceNumber = accInvoice.InvoiceNumber,
                        InvoiceDate = accInvoice.InvoiceDate,
                        PayeeCode = trackingInfo.OracleId,
                        Comments = "Municipality check",
                        PaidAmount = accInvoice.InvoiceAmount
                    };
                }
                else
                {
                    apr.CheckDate = trackingInfo.PaymentDate.GetValueOrDefault();
                    apr.CheckNumber = trackingInfo.ConfirmationNumber;
                    apr.InvoiceAmount = accInvoice.InvoiceAmount;
                    apr.InvoiceNumber = accInvoice.InvoiceNumber;
                    apr.InvoiceDate = accInvoice.InvoiceDate;
                    apr.PayeeCode = trackingInfo.OracleId;
                    apr.Comments = "Municipality check";
                    apr.PaidAmount = accInvoice.InvoiceAmount;
                }


                apr = del.SavePayableRemittance(apr);

                var trackingLog = del.GetAccountsPayableTrackingLogByWorkOrderId(trackingInfo.TrackingLogSource.PlatFormWorkOrderId);
                var isTrackingModified = false;
                if (trackingLog != null && trackingLog.AccountsPayableTrackingLogId > 0)
                {
                    if (!trackingLog.AccountsPayableRemittanceId.HasValue)
                    {
                        trackingLog.AccountsPayableRemittanceId = apr.AccountsPayableRemittanceId;
                        isTrackingModified = true;
                    }
                    if (!trackingLog.AccountsPayableInvoiceId.HasValue)
                    {
                        trackingLog.AccountsPayableInvoiceId = accInvoice.AccountsPayableInvoiceId;
                        isTrackingModified = true;
                    }
                    if (isTrackingModified)
                        del.SaveAccountsPayableTrackingLog(trackingLog);
                }
            }
        }

        private static void SaveTrackingLog(FtvDel.FtvCheckLogDelegate del, TrackingLogInfo trackingInfo)
        {
            var existingTrackingLog = GetTrackingLog(trackingInfo, del);
            if (existingTrackingLog == null || existingTrackingLog.AccountsPayableTrackingLogId <= 0)
            {
                var source = trackingInfo.TrackingLogSource;
                existingTrackingLog = new DomainModel.Accounting.AccountsPayableTrackingLog();
                existingTrackingLog.AccountsPayableRemittanceId = source.AccountsPayableRemittanceId;
                existingTrackingLog.WorkOrderId = source.PlatFormWorkOrderId;
            }
            existingTrackingLog.AccountsPayableInvoiceId = trackingInfo.TrackingLogSource.AccountsPayableInvoiceId;
            existingTrackingLog.TrackingNumber = trackingInfo.TrackingNumber;
            existingTrackingLog.PostedDate = trackingInfo.PostedDate;
            existingTrackingLog.DeliveryConfirmDate = trackingInfo.DeliveryConfirmationDate;

            if (string.IsNullOrEmpty(existingTrackingLog.DeliveryConfirmStatus) && trackingInfo.DeliveryConfirmationDate.HasValue && trackingInfo.DeliveryConfirmationDate != default(DateTime))
            {
                existingTrackingLog.DeliveryConfirmStatusGroup = "DCS";
                existingTrackingLog.DeliveryConfirmStatus = "DCS1";
            }

            del.SaveAccountsPayableTrackingLog(existingTrackingLog);
        }

        private static bool CanSavePayableDetail(TrackingLogInfo trackingInfo)
        {
            return !string.IsNullOrEmpty(trackingInfo.ConfirmationNumber) || (trackingInfo.PaymentDate.HasValue && trackingInfo.PaymentDate != default(DateTime));
        }

        private static bool CanSavePayableTrackingLog(TrackingLogInfo trackingInfo)
        {
            return !string.IsNullOrEmpty(trackingInfo.TrackingNumber) || (trackingInfo.PostedDate.HasValue && trackingInfo.PostedDate != default(DateTime)) || (trackingInfo.DeliveryConfirmationDate.HasValue && trackingInfo.DeliveryConfirmationDate != default(DateTime));
        }

        private static DomainModel.Accounting.AccountsPayableTrackingLog GetTrackingLog(TrackingLogInfo request, FtvDel.FtvCheckLogDelegate del)
        {
            DomainModel.Accounting.AccountsPayableTrackingLog trackingLog = null;
            var source = request.TrackingLogSource;
            if (source.AccountsPayableTrackingLogId.GetValueOrDefault() > 0)
                trackingLog = del.GetAccountsPayableTrackingLogById(source.AccountsPayableTrackingLogId.Value);
            else if (source.OrderHierarchyId > 0)
                trackingLog = del.GetAccountsPayableTrackingLogByOrderHierarchyId(source.OrderHierarchyId, request.TrackingLogSource.AccountsPayableInvoiceId);
            else if (source.AccountsPayableRemittanceId.GetValueOrDefault() > 0)
                trackingLog = del.GetAccountsPayableTrackingLogByRemittanceId(source.AccountsPayableRemittanceId.Value);

            return trackingLog;
        }

        #endregion
    }

    class SavePayableInfo
    {
        public int OrderHierarchyId { get; set; }

        public decimal? CheckAmount { get; set; }

        public int? FeeTypeId { get; set; }

        public string PayeeName { get; set; }

        public string Comments { get; set; }

        public int? FeeTypeRefId { get; set; }
    }

    class SaveReceivableInfo
    {
        public int OrderHierarchyId { get; set; }

        public decimal? CheckAmount { get; set; }

        public int? FeeTypeId { get; set; }

        public string PayeeName { get; set; }

        public string Comments { get; set; }

        public string AdjustmentCode { get; set; }

        public string ARAdjStatusType { get; set; }

        public string AdjustmentType { get; set; }

        public int? FeeTypeRefId { get; set; }

        public int? RejectPaymentRefId { get; set; }
    }

    class SaveDisputeInfo
    {
        public SavePayableInfo SavePayableInfo { get; set; }

        public decimal? AdjustedAmount { get; set; }

        public decimal FinalAmount { get; set; }

        public int RecordNumber { get; set; }

        public int ApplicationId { get; set; }

        public int? PaymentRefId { get; set; }

        public string RecordType { get; set; }
    }

    class SaveAdjustment
    {
        public int applicationId { get; set; }
        public int orderHierarchyId { get; set; }
        public string comments { get; set; }
        public int adjHistId { get; set; }
        public int? invoiceID { get; set; }
        public int? feeTypeId { get; set; }
        public decimal? amount { get; set; }

        public int PayableDetailId { get; set; }
    }
}
