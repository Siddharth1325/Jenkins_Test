﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Dom = DomainModel.Accounting;
using DataAccess;
//using Delegate.SpaAcc;
using System.ServiceModel;
//using CommonLib.ServiceProxy;
using BusinessSvcImpl.DataObjects.SpaAccountingService.Dto;
using BusinessSvcImpl.DataObjects.SpaAccounting.Dto;
using Delegate;

namespace BusinessSvcImpl.SvcImpl.SpaAcc
{
    //TODO: set transaction level when we to commit to database
    //[ServiceBehavior(TransactionIsolationLevel = System.Transactions.IsolationLevel.ReadCommitted)]
    [ServiceBehavior]
    public partial class SpaAccService : ISpaAccService
    {
        public SpaAccService()
            : base()
        {
        }

        public GetOrderSearchResponse GetOrderSearchResults(GetOrderSearchRequest request)
        {
            OrderSearchInput orderDto = request.SearchInput;

            List<Dom.OrderSearchResult> searchResult = null;
            GetOrderSearchResponse response = new GetOrderSearchResponse();

            OrderDelegate accountingDelegate = new OrderDelegate();

            Dom.OrderSearchInput searchInput = new Dom.OrderSearchInput()
            {
                OrderId = orderDto.OrderNumber,
                WorkOrderId = orderDto.WorkOrderNumber,
                InvoiceId = orderDto.InvoiceNumber,
                ClientNumber = orderDto.ClientNumber,
                LoanNumber = orderDto.LoanNumber,
                VendorId = orderDto.VendorNumber,
                Invoiced = orderDto.Invoiced,
                ProductCode = orderDto.ProductCode,
                ProductCategory = orderDto.ProductCategory,
                AddressLine1 = orderDto.Address,
                LineOfBusiness = orderDto.LineOfBusiness,
                BillingFrequency = billingInput(orderDto.BillingFrequency),
                CompletedDateFrom = orderDto.CompletedDateFrom,
                CompletedDateTo = orderDto.CompletedDateTo,
                InvoiceAmount = orderDto.InvoiceAmount,
                InvoiceDateFrom = orderDto.InvoiceDateFrom,
                InvoiceDateTo = orderDto.InvoiceDateTo

            };

            var lstOrderSearch = accountingDelegate.SearchOrders(searchInput);

            List<OrderSearchResult> lstResultDto = new List<OrderSearchResult>();
            foreach (Dom.OrderSearchResult lSearch in lstOrderSearch)
            {
                lstResultDto.Add(new OrderSearchResult()
                {
                    OrderNumber = lSearch.OrderId,
                    WorkOrderNumber = lSearch.WorkOrderId,
                    ClientNumber = lSearch.ClientNumber,
                    InvoiceNumber = orderDto.InvoiceNumber,
                    LoanNumber = lSearch.LoanNumber,
                    ProductCode = lSearch.ProductCode,
                    InvoiceAmount = lSearch.InvoiceAmount,
                    BillingFrequency = billingResult(lSearch.BillingFrequency),
                    CompletedDate = lSearch.CompletedDate,
                    InvoiceDate = lSearch.InvoiceDate
                });
            }
            response.SearchResults = lstResultDto;

            return response;
        }

        private DomainModel.Enums.AllEnums.BillingType billingInput(OrderSearchInput.BillingType billingType)
        {
            DomainModel.Enums.AllEnums.BillingType BillingType;
            switch (billingType)
            {
                case OrderSearchInput.BillingType.All:
                    BillingType = DomainModel.Enums.AllEnums.BillingType.All;
                    return BillingType;
                case OrderSearchInput.BillingType.Daily:
                    BillingType = DomainModel.Enums.AllEnums.BillingType.Daily;
                    return BillingType;
                case OrderSearchInput.BillingType.Weekly:
                    BillingType = DomainModel.Enums.AllEnums.BillingType.Weekly;
                    return BillingType;
                case OrderSearchInput.BillingType.Monthly:
                    BillingType = DomainModel.Enums.AllEnums.BillingType.Monthly;
                    return BillingType;
                default:
                    throw new Exception("No Such Billing Type");
            }
        }
        private OrderSearchResult.BillingType billingResult(DomainModel.Enums.AllEnums.BillingType billingType)
        {
            OrderSearchResult.BillingType BillingType;
            switch (billingType)
            {
                case DomainModel.Enums.AllEnums.BillingType.All:
                    BillingType = OrderSearchResult.BillingType.All;
                    return BillingType;
                case DomainModel.Enums.AllEnums.BillingType.Daily:
                    BillingType = OrderSearchResult.BillingType.Daily;
                    return BillingType;
                case DomainModel.Enums.AllEnums.BillingType.Weekly:
                    BillingType = OrderSearchResult.BillingType.Weekly;
                    return BillingType;
                case DomainModel.Enums.AllEnums.BillingType.Monthly:
                    BillingType = OrderSearchResult.BillingType.Monthly;
                    return BillingType;
                default:
                    throw new Exception("No Such Billing Type");
            }

        }


    }
}