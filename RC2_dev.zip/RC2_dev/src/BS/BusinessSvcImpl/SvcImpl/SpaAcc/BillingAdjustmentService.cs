﻿using Delegate;
using Delegate.SpaAcc;
using CommonLib.FSException;
namespace BusinessSvcImpl.SvcImpl.SpaAcc
{
    using Dom = DomainModel.Accounting;
    using BusinessSvcImpl.DataObjects.SpaAccounting.Dto;
    using BusinessSvcImpl.DataObjects;

    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    using DomainModel;
    using CommonLib.Context;
    using System.ServiceModel;
    using DomainModel.Enums;
    using BusinessSvcImpl.DataObjects.SpaAccountingService.Dto;
    using Reference.ServiceProxy.ReferenceService;
    using CommonLib;
    using System.Data.Entity.Infrastructure;
    public partial class SpaAccountingService
    {

        private const string PRESS_AR_ADJUST_GLTRAN_TYPE = "ARADJUST";
        private const string PRESS_AP_ADJUST_GLTRAN_TYPE = "APADJUST";


        public bool IsAdjustmentExists(int sourceOrderId)
        {
            return new BillingAdjustmentDelegate().IsAdjustmentExists(sourceOrderId);
        }

        public AdjustmentDetailResponse GetBillingAdjustmentLists(AdjustmentDetailRequest request)
        {
            if (request == null || request.OrderId <= 0) return null;

            Dom.AdjustmentDetailResponseDAO mainDataDAO = new BillingAdjustmentDelegate().GetAdjustmentMainData(request.OrderId, request.UpdateGridType);
            AdjustmentDetailResponse adjustmentResponseMainData = MapAllListToDTO(mainDataDAO);
            return adjustmentResponseMainData;
        }


        public PenaltyDataResponse GetPenaltyAdjustmentLists(int orderId)
        {
            if (orderId <= 0) return null;
            PenaltyDataResponse returnResponse = new PenaltyDataResponse();
            var daoResponse = new BillingAdjustmentDelegate().GetPenaltyAdjustmentMainData(orderId);
            if (daoResponse != null)
            {
                if (daoResponse.PenaltyAdjustmentDetailList != null)
                {
                    foreach (var penDao in daoResponse.PenaltyAdjustmentDetailList)
                    {
                        PenaltyAdjustmentDetail penaltyAdjustmentDetail = new PenaltyAdjustmentDetail();
                        MapPenaltyDaoToDto(penDao, penaltyAdjustmentDetail);
                        returnResponse.PenaltyAdjustmentDetailList.Add(penaltyAdjustmentDetail);
                    }
                }

                if (daoResponse.PenaltyVwoDetailsList != null)
                {
                    foreach (var vwoDet in daoResponse.PenaltyVwoDetailsList)
                    {
                        returnResponse.PenaltyVwoDetailsList.Add(
                            new PenaltyVendorWorkOrderDetailDto()
                            {
                                VendorId = vwoDet.VendorId,
                                VendorWorkOrderId = vwoDet.VendorWorkOrderId
                            });
                    }
                }
            }
            returnResponse.IsScoreCardVisible = returnResponse.PenaltyAdjustmentDetailList.Count > 0;

            return returnResponse;
        }

        public List<AdjustmentScoreCard> GetPenaltyAdjustmentsDataForScoreCard(int vendorWorkOrderId)
        {
            var penaltyAdjDetailsDao = new BillingAdjustmentDelegate().GetPenaltyAdjustmentsDataForScoreCard(vendorWorkOrderId);
            var data = new List<AdjustmentScoreCard>();
            foreach (var penDao in penaltyAdjDetailsDao)
            {
                var calDetail = new AdjustmentScoreCard();
                calDetail.AchievementName = penDao.AchievementName;
                calDetail.AdjustmentAmount = penDao.AdjustmentAmount;
                calDetail.WorkOrderId = penDao.WorkOrderId;
                calDetail.WorkOrderItemId = penDao.WorkOrderItemId;
                calDetail.GoalName = penDao.GoalName;
                data.Add(calDetail);
            }

            return data;
        }

        public PrdSrvMainDataResponse GetPrdSrvMainData(PrdSrvMainDataRequest request)
        {
            if (request == null || request.OrderhierachyID <= 0) return null;

            Dom.PrdSrvMainResponseDAO mainDataDAO = new BillingAdjustmentDelegate().GetPrdSrvMainData(request.OrderhierachyID, request.FeeType);
            if (mainDataDAO == null)
                return null;
            PrdSrvMainDataResponse response = MapPrdSrvListsToDTO(mainDataDAO);
            return response;
        }

        public List<CronologicalAdjustmentListResponse> GetCronologicalAdjustmentList(AdjustmentDetailRequest request)
        {
            if (request == null || request.OrderId <= 0) return null;

            List<Dom.CronologicalAdjustmentListResponseDAO> cronologicalResponseDAO = new BillingAdjustmentDelegate().GetCronologicalAdjustments(request.OrderId);
            List<CronologicalAdjustmentListResponse> cronologicalAdjustmentListResponseDTOs = MapCronologicalDaoToDTO(cronologicalResponseDAO);
            if (cronologicalAdjustmentListResponseDTOs == null) cronologicalAdjustmentListResponseDTOs = new List<CronologicalAdjustmentListResponse>();
            return cronologicalAdjustmentListResponseDTOs;
        }

        public FeeAdjustmentDetailResponse GetFeeAdjustmentDetails(FeeAdjustmentDetailRequest request)
        {
            FeeAdjustmentDetailResponse response = new FeeAdjustmentDetailResponse();
            if (request == null || request.ARAdjustmentHistoryId <= 0)
                throw new CommonLib.FSException.FSBusinessException("Invalid ARAdjustmentHistoryId");
            switch (request.DetailType.ToString())
            {
                case "Order":
                    response.ClientFeeAdjustmentDetailList = new List<ClientFeeAdjustmentDetail>();
                    response.ClientFeeAdjustmentDetailList = GetClientFeeDetails(request.ARAdjustmentHistoryId, request.OrderHierarchyId);
                    break;
                case "VendorWorkOrder":
                    response.VendorFeeAdjustmentDetailList = new List<VendorFeeAdjustmentDetail>();
                    response.VendorFeeAdjustmentDetailList = GetVendorFeeDetailsList(request.ARAdjustmentHistoryId, request.OrderHierarchyId);
                    break;
                case "FlatFee":
                    response.FlatFeeAdjustmentDetailList = new List<FlatFeeAdjustmentDetail>();
                    response.FlatFeeAdjustmentDetailList = GetFlatFeeDetailsList(request.ARAdjustmentHistoryId, request.OrderHierarchyId);
                    break;
                case "Discount":
                    response.DiscountAdjustmentDetailList = new List<DiscountAdjustmentDetail>();
                    response.DiscountAdjustmentDetailList = GetDiscountDetailsList(request.ARAdjustmentHistoryId, request.OrderHierarchyId);
                    break;
                case "LineItem":
                    response.LineItemAdjustmentDetailList = new List<LineItemAdjustmentDetail>();
                    response.LineItemAdjustmentDetailList = GetLineItemDetailsList(request.ARAdjustmentHistoryId, request.OrderHierarchyId);
                    break;
                case "MiscProduct":
                    response.MiscAdjustmentDetailList = new List<MiscAdjustmentDetail>();
                    response.MiscAdjustmentDetailList = GetMiscDetailsList(request.ARAdjustmentHistoryId, request.OrderHierarchyId, request.Type, request.feeTypeId, request.FeeTypeRefId);
                    break;
                case "Penalty":
                    response.PenaltyAdjustmentDetailList = new List<PenaltyAdjustmentDetail>();
                    response.PenaltyAdjustmentDetailList = GetPenaltyDetailList(request.AchievementName, request.OrderHierarchyId);
                    break;
                default:
                    response = null;
                    break;
            }
            return response;
        }

        [System.ServiceModel.OperationBehavior(TransactionScopeRequired = true)]
        public bool SaveDisputeEntities(SaveDisputeEntitiesRequest request)
        {
            bool IsSaved = false;
            if (request == null) throw new ArgumentNullException("request");

            if (request.DisputePayableAdjustmentHistory != null)
            {
                DisputePayableAdjustmentHistory disPayAdjHistResponse = new DisputePayableAdjustmentHistory();
                disPayAdjHistResponse = SaveDisputePayableAdjustmentHistory(request.DisputePayableAdjustmentHistory);
                if (disPayAdjHistResponse != null)
                    IsSaved = true;
            }
            else
                IsSaved = false;

            if (request.DisputeReceivableAdjustmentHistory != null)
            {
                DisputeReceivableAdjustmentHistory disRecAdjHistResponse = new DisputeReceivableAdjustmentHistory();
                disRecAdjHistResponse = SaveDisputeReceivableAdjustmentHistory(request.DisputeReceivableAdjustmentHistory);
                if (disRecAdjHistResponse != null)
                    IsSaved = true;
            }
            else
                IsSaved = false;

            return IsSaved;
        }

        [OperationBehavior(TransactionScopeRequired = true)]
        public DisputePayableAdjustmentHistory SaveDisputePayableAdjustmentHistory(DisputePayableAdjustmentHistory request)
        {
            if (request == null) return null;
            try
            {
                var response = SaveDisputePayableAdjustmentAdjRecord(request, false);
                CreateApAdjustment(response, request.AdjustmentType);
                return response;
            }
            catch (DbUpdateConcurrencyException concExc)
            {
                ThrowConcurrencyExc(concExc);
                return null;
            }

        }

        private static void ThrowConcurrencyExc(DbUpdateConcurrencyException concExc)
        {
            Logging.LogError(concExc);
            throw new FSBusinessException("Data is modified by some other user. Please refresh the screen and try again.");
        }

        [OperationBehavior(TransactionScopeRequired = true)]
        public DisputeReceivableAdjustmentHistory SaveDisputeReceivableAdjustmentHistory(DisputeReceivableAdjustmentHistory request)
        {
            if (request == null) return null;
            try
            {

                DisputeReceivableAdjustmentHistory response = SaveDisputeReceivableAdjustmentAdjRecord(request); //SaveReceivableAdjustment(request, true);

                CreateArAdjustment(response, request.AdjustmentType);
                return response;
            }
            catch (DbUpdateConcurrencyException concExc)
            {
                ThrowConcurrencyExc(concExc);
                return null;
            }
        }

        [OperationBehavior(TransactionScopeRequired = true)]
        public DisputePenaltyAdjustmentHistory SaveDisputePenaltyAdjustmentHistory(DisputePenaltyAdjustmentHistory request)
        {

            if (request == null) return null;
            try
            {
                DisputePenaltyAdjustmentHistory response = SaveDisputePenaltyAdjustmentAdjRecord(request); //SaveReceivableAdjustment(request, true);

                CreateApPenaltyAdjustment(response);
                return response;
            }
            catch (DbUpdateConcurrencyException concExc)
            {
                ThrowConcurrencyExc(concExc);
                return null;
            }
        }

        private void CreateApPenaltyAdjustment(DisputePenaltyAdjustmentHistory request)
        {
            var del = new BillingAdjustmentDelegate();
            if (request == null || request.OrderHierarchyId <= 0)
                throw new NullReferenceException("Invalid Request. Check the request");

            var glCode = SpaAccountingService.GetGLCodeDetails(PRESS_AP_ADJUST_GLTRAN_TYPE, request.OrderHierarchyId, GetFeeTypeCode(request.FeeTypeId));
            if (glCode == null || glCode.AccountingGLCodeId <= 0)
                throw new FSBusinessException("GI Code Not Configured for Penalty/Incentive Fee Types");

            if (request.PenaltyAdjustmentAmount.HasValue && request.PenaltyAdjustmentAmount.Value != 0)
            {
                var accountsPayableAdj = new Dom.AccountsPayableAdjustment();
                accountsPayableAdj.AccountsPayableDetailId = del.GetAccountsPayableByFeeTypeId(request.FeeTypeId, request.OrderHierarchyId);
                accountsPayableAdj.DisputePenaltyAdjustmentHistoryId = request.DisputePenaltyAdjustmentHistoryId;
                accountsPayableAdj.AccountsPayableInvoiceId = del.GetAccountPayableInvoiceId(request.InvoiceNumber);
                accountsPayableAdj.AdjustmentDate = DateTime.Now;
                accountsPayableAdj.AdjustmentType = request.PenaltyAdjustmentAmount.Value < 0 ? "CREDIT" : "DEBIT";
                accountsPayableAdj.AdjustmentCode = GetAccountingAdjustmentCode("AP", accountsPayableAdj.AdjustmentType, request.ApplicationId.GetValueOrDefault());
                accountsPayableAdj.ApplicationId = request.ApplicationId.GetValueOrDefault();
                accountsPayableAdj.GLTransTypeGroup = "GLTRN";
                accountsPayableAdj.APAdjStatusGroup = "APADJSG";
                accountsPayableAdj.APAdjStatusType = "RDY2BILL";
                accountsPayableAdj.GLTransType = PRESS_AP_ADJUST_GLTRAN_TYPE;
                accountsPayableAdj.Operation = glCode.Operation;
                accountsPayableAdj.Function = glCode.Function;
                accountsPayableAdj.NaturalAccount = glCode.NaturalAccount;
                accountsPayableAdj.Comments = request.Comments;
                accountsPayableAdj.SupplierComment = request.SupplierComment;
                accountsPayableAdj.Amount = Math.Abs(Math.Round(request.PenaltyAdjustmentAmount.Value, 2));

                del.SaveAccountsPayableAdjustment(accountsPayableAdj);
            }


        }

        public DisputePenaltyAdjustmentHistory SaveDisputePenaltyAdjustmentAdjRecord(DisputePenaltyAdjustmentHistory request)
        {
            var billingDel = new BillingAdjustmentDelegate();
            Dom.DisputePenaltyAdjustmentHistory disRecOrig = billingDel.GetDisputePenaltyAdjustmentHistory(request.OrderHierarchyId, request.AchievementName);
            int maxRecNumber = billingDel.GetPenaltyLastRecordNumber(request.OrderHierarchyId, request.AchievementName);

            if (disRecOrig == null || disRecOrig.DisputePenaltyAdjustmentHistoryId <= 0)
                throw new Exception("No Original Record Found.");

            Dom.DisputePenaltyAdjustmentHistory disRecAdj = new Dom.DisputePenaltyAdjustmentHistory(); //SaveReceivableAdjustment(request, true);
            disRecAdj.AchievementName = disRecOrig.AchievementName;
            disRecAdj.ApplicationId = (int)request.ApplicationId;
            disRecAdj.FeeTypeId = request.FeeTypeId;
            disRecAdj.GoalName = disRecOrig.GoalName;
            disRecAdj.AdjustmentDate = DateTime.Now;
            disRecAdj.OrderHierarchyId = request.OrderHierarchyId;
            disRecAdj.Comments = request.Comments;
            disRecAdj.PenaltyAmount = GetRoundedValue(request.PenaltyAmount);
            disRecAdj.AdjustmentAmount = GetRoundedValue(request.PenaltyAdjustmentAmount);
            disRecAdj.RecordNumber = GetNewRecordNumber(maxRecNumber);
            disRecAdj.RecordGroup = "ADJHIST";
            disRecAdj.RecordType = "ADJED";
            disRecAdj.SupplierComment = request.SupplierComment;
            disRecAdj = billingDel.SaveDisputePenaltyAdjustmentHistory(disRecAdj);

            //update original object.
            if (disRecOrig.RecordType == "ORIG")
            {
                disRecOrig.DisputePenaltyAdjustmentHistoryId = -1;
                disRecOrig.Version = null;
                disRecOrig.RecordNumber = 3;
                //disRecOrig.InvoiceDate = null;
                //disRecOrig.InvoiceNumber = null;
                disRecOrig.RecordType = "FINAL";
                disRecOrig.SourceDisputePenaltyAdjustmentHistoryId = null;
                disRecOrig.AdjustmentDate = DateTime.Now;
            }
            else
            {
                disRecOrig.Version = string.IsNullOrEmpty(request.Version) ? null : Convert.FromBase64String(request.Version);
            }
            disRecOrig.PenaltyAmount = Math.Round(request.PenaltyAmount.GetValueOrDefault(), 2);
            //disRecOrig.FinalPenaltyAmount = request.FinalPenaltyAmount;//TODO
            disRecOrig.Comments = request.Comments;
            billingDel.SaveDisputePenaltyAdjustmentHistory(disRecOrig);
            MapPenaltyDomainDaoToDto(disRecAdj, request);
            return request;
        }

        #region Private Region

        private static void MapPenaltyDomainDaoToDto(Dom.DisputePenaltyAdjustmentHistory penDao, DisputePenaltyAdjustmentHistory penaltyAdjustmentDetail)
        {
            penaltyAdjustmentDetail.DisputePenaltyAdjustmentHistoryId = penDao.DisputePenaltyAdjustmentHistoryId;
            penaltyAdjustmentDetail.GoalName = penDao.GoalName;
            penaltyAdjustmentDetail.AchievementName = penDao.AchievementName;
            penaltyAdjustmentDetail.AdjustmentDate = penDao.AdjustmentDate;
            penaltyAdjustmentDetail.Comments = penDao.Comments;
            penaltyAdjustmentDetail.InvoiceNumber = penDao.InvoiceNumber;
            penaltyAdjustmentDetail.InvoiceDate = penDao.InvoiceDate;
            penaltyAdjustmentDetail.PenaltyAmount = penDao.PenaltyAmount;
            penaltyAdjustmentDetail.Version = penDao.Version == null ? null : Convert.ToBase64String(penDao.Version); ;
            penaltyAdjustmentDetail.RecordNumber = penDao.RecordNumber;
            penaltyAdjustmentDetail.RecType = penDao.RecordType;
            penaltyAdjustmentDetail.OrderHierarchyId = penDao.OrderHierarchyId;
            penaltyAdjustmentDetail.PenaltyAdjustmentAmount = penDao.AdjustmentAmount;
            penaltyAdjustmentDetail.FeeTypeId = penDao.FeeTypeId;
            penaltyAdjustmentDetail.ApplicationId = penDao.ApplicationId;
            penaltyAdjustmentDetail.DisputePenaltyAdjustmentHistoryId = penDao.DisputePenaltyAdjustmentHistoryId;
            penaltyAdjustmentDetail.Version = Convert.ToBase64String(penDao.Version);
        }

        private DisputeReceivableAdjustmentHistory SaveDisputeReceivableAdjustmentAdjRecord(DisputeReceivableAdjustmentHistory request)
        {
            var billingDel = new BillingAdjustmentDelegate();
            var response = new DisputeReceivableAdjustmentHistory();
            var disRecAdj = new Dom.DisputeReceivableAdjustmentHistory();
            Dom.DisputeReceivableAdjustmentHistory disRecOrig;
            int maxRecNumber;

            if (request.AdjustmentType != "MiscProd")
            {
                disRecOrig = billingDel.GetLatestDisputeReceivableAdjustmentHistory(request.OrderHierarchyId);
                maxRecNumber = billingDel.GetReceivableLastRecordNumber(request.OrderHierarchyId);
            }
            else
            {
                disRecOrig = billingDel.GetLatestDisputeReceivableAdjustmentHistory(request.OrderHierarchyId, request.FeeTypeId, request.FeeTypePaymentRefId);
                maxRecNumber = billingDel.GetReceivableLastRecordNumber(request.OrderHierarchyId, request.FeeTypeId, request.FeeTypePaymentRefId);
            }

            if (disRecOrig == null || disRecOrig.DisputeReceivableAdjustmentHistoryId <= 0)
                throw new Exception("No Original Record Found.");

            disRecAdj.OrderHierarchyId = request.OrderHierarchyId;
            disRecAdj.ApplicationId = disRecOrig.ApplicationId;
            disRecAdj.AdjustmentHistoryRecordGroup = "ADJHIST";
            disRecAdj.AdjustmentHistoryRecordType = "ADJED";
            disRecAdj.RecordNumber = GetNewRecordNumber(maxRecNumber);
            disRecAdj.FeeTypeId = request.FeeTypeId;
            disRecAdj.HistoryDate = DateTime.UtcNow;
            disRecAdj.ServiceDescription = disRecOrig.ServiceDescription;
            disRecAdj.LineItemDescription = disRecOrig.LineItemDescription;
            disRecAdj.ClientAdjComments = disRecOrig.ClientAdjComments = request.ClientAdjComments;
            disRecAdj.AdjustmentType = request.AdjustmentType;
            disRecAdj.FeeTypePaymentRefId = disRecOrig.FeeTypePaymentRefId;
            switch (request.AdjustmentType)
            {
                case "Client":
                    disRecAdj.Quantity = 1;
                    disRecAdj.QuantityAdjusted = 0;
                    disRecAdj.ClientRushFee = disRecOrig.ClientRushFee = GetRoundedValue(request.ClientRushFee);
                    disRecAdj.ClientRushFeeAdjstdAmt = GetRoundedValue(request.ClientRushFeeAdjstdAmt);
                    disRecAdj.ClientTripFee = disRecOrig.ClientTripFee = GetRoundedValue(request.ClientTripFee);
                    disRecAdj.ClientTripFeeAdjstdAmt = GetRoundedValue(request.ClientTripFeeAdjstdAmt);
                    break;
                case "FlatFee":
                    disRecAdj.Quantity = disRecOrig.Quantity;
                    disRecAdj.QuantityAdjusted = disRecOrig.QuantityAdjusted;
                    disRecAdj.ClientPrice = disRecOrig.ClientPrice = GetRoundedValue(request.ClientPrice);
                    disRecAdj.ClientPriceAdjstdAmt = GetRoundedValue(request.ClientPriceAdjstdAmt);
                    break;
                case "LineItem":
                    var isUpdatePrice = request.RecordsToBeSaved == "all" || request.RecordsToBeSaved == "Price";
                    var isUpdateQuantity = request.RecordsToBeSaved == "all" || request.QuantityAdjusted.GetValueOrDefault() > 0;
                    disRecOrig.Quantity = request.Quantity;
                    if (isUpdateQuantity)
                    {
                        disRecAdj.Quantity = request.Quantity;
                        disRecAdj.QuantityAdjusted = disRecOrig.QuantityAdjusted = request.QuantityAdjusted;
                    }
                    else
                    {
                        disRecAdj.Quantity = disRecOrig.Quantity;
                        disRecAdj.QuantityAdjusted = null;
                    }

                    disRecAdj.UnitOfMeasure = disRecOrig.UnitOfMeasure = request.UnitOfMeasure;
                    disRecAdj.UnitOfMeasureAdjusted = request.UnitOfMeasureAdjusted;

                    if (isUpdatePrice)
                    {
                        disRecAdj.AgreedClientUnitPrice = disRecOrig.AgreedClientUnitPrice = GetRoundedValue(request.AgreedClientUnitPrice);
                        disRecAdj.AgreedUnitPriceAdjstdAmt = GetRoundedValue(request.AgreedUnitPriceAdjstdAmt);
                        disRecAdj.ClientPrice = disRecOrig.ClientPrice = GetRoundedValue(request.ClientPrice);
                        disRecAdj.ClientPriceAdjstdAmt = GetRoundedValue(request.ClientPriceAdjstdAmt);
                    }
                    else
                    {
                        disRecAdj.AgreedClientUnitPrice = disRecOrig.AgreedClientUnitPrice;
                        disRecAdj.AgreedUnitPriceAdjstdAmt = null;
                        disRecAdj.ClientPrice = disRecOrig.ClientPrice;
                        disRecAdj.ClientPriceAdjstdAmt = null;
                    }

                    var latestItem = billingDel.GetWorkItemLatestReceivableAdjustmentHistory(disRecAdj.OrderHierarchyId);
                    if (isUpdatePrice)
                        latestItem.ClientPrice = latestItem.ClientPrice.GetValueOrDefault() + disRecAdj.ClientPriceAdjstdAmt.GetValueOrDefault();
                    latestItem.HistoryDate = DateTime.Now;
                    billingDel.SaveDisputeReceivableAdjustmentHistory(latestItem);
                    break;
                case "MiscProd":
                    disRecAdj.Quantity = disRecOrig.Quantity;
                    disRecAdj.FeeTypeId = disRecOrig.FeeTypeId;
                    disRecAdj.ClientPrice = disRecOrig.ClientPrice = GetRoundedValue(request.ClientPrice);
                    disRecAdj.ClientPriceAdjstdAmt = GetRoundedValue(request.ClientPriceAdjstdAmt);
                    break;
            }
            disRecAdj = billingDel.SaveDisputeReceivableAdjustmentHistory(disRecAdj);

            if (disRecOrig.AdjustmentHistoryRecordType == "ORIG")
            {
                disRecOrig.DisputeReceivableAdjustmentHistoryId = -1;
                disRecOrig.Version = null;
                disRecOrig.RecordNumber = 3;
                disRecOrig.AdjustmentHistoryRecordType = "FINAL";
                disRecOrig.SourceDisputeReceivableAdjustmentHistoryId = null;
                if (disRecAdj.Quantity > 0)
                    disRecOrig.Quantity = disRecAdj.Quantity;
                disRecOrig.HistoryDate = DateTime.Now;
            }
            else
                disRecOrig.Version = string.IsNullOrEmpty(request.Version) ? null : Convert.FromBase64String(request.Version);
            billingDel.SaveDisputeReceivableAdjustmentHistory(disRecOrig);
            response.MapToDtoWithoutCollections(disRecAdj);
            response.InvoiceNumber = disRecOrig.InvoiceNumber;
            return response;
        }

        private int GetNewRecordNumber(int oldRecordNumber)
        {
            var recNum = oldRecordNumber;
            if (recNum == 1)
                recNum = 2;
            else
                recNum = recNum + 1;

            return recNum;
        }

        private decimal? GetRoundedValue(decimal? value)
        {
            if (value.HasValue)
                return Math.Round(value.GetValueOrDefault(), 2);

            return null;
        }

        private DisputePayableAdjustmentHistory SaveDisputePayableAdjustmentAdjRecord(DisputePayableAdjustmentHistory request, bool isFromDisc)
        {
            var billingDel = new BillingAdjustmentDelegate();
            var response = new DisputePayableAdjustmentHistory();
            var historyAdj = new Dom.DisputePayableAdjustmentHistory();

            Dom.DisputePayableAdjustmentHistory historyOrig;
            int maxRecNumber;
            if (request.AdjustmentType != "MiscProd")
            {
                historyOrig = billingDel.GetLatestDisputePayableAdjustmentHistory(request.OrderHierarchyId);
                maxRecNumber = billingDel.GetLastRecordNumber(request.OrderHierarchyId);
            }
            else
            {
                historyOrig = billingDel.GetLatestDisputePayableAdjustmentHistory(request.OrderHierarchyId, request.FeeTypeId, request.FeeTypePaymentRefId);
                maxRecNumber = billingDel.GetLastRecordNumber(request.OrderHierarchyId, request.FeeTypeId, request.FeeTypePaymentRefId);
            }

            //  var historyOrig = billingDel.GetLatestDisputePayableAdjustmentHistory(request.OrderHierarchyId);
            if (historyOrig == null || historyOrig.DisputePayableAdjustmentHistoryId <= 0)
                throw new Exception("No Original Record Found.");
            //var maxRecNumber = billingDel.GetLastRecordNumber(request.OrderHierarchyId);

            historyAdj.OrderHierarchyId = request.OrderHierarchyId;
            historyAdj.ApplicationId = historyOrig.ApplicationId;
            historyAdj.AdjustmentHistoryRecordGroup = "ADJHIST";
            historyAdj.AdjustmentHistoryRecordType = "ADJED";
            historyAdj.RecordNumber = GetNewRecordNumber(maxRecNumber);
            historyAdj.HistoryDate = DateTime.UtcNow;
            historyAdj.ServiceDescription = historyOrig.ServiceDescription;
            historyAdj.LineItemDescription = historyOrig.LineItemDescription;
            historyAdj.VendorAdjComments = request.VendorAdjComments;

            if (request.AdjustmentType != "FlatFee" && request.AdjustmentType != "Discount")
                historyOrig.VendorAdjComments = request.VendorAdjComments;

            historyAdj.SupplierComment = historyOrig.SupplierComment = request.SupplierComment;
            historyAdj.AdjustmentType = request.AdjustmentType;
            historyAdj.FeeTypeId = request.FeeTypeId;
            historyAdj.FeeTypePaymentRefId = historyOrig.FeeTypePaymentRefId;

            switch (request.AdjustmentType)
            {
                case "VendorWorkOrder":
                    historyAdj.Quantity = 1;
                    historyAdj.QuantityAdjusted = 0;
                    historyAdj.VendorOneTimeFee = historyOrig.VendorOneTimeFee = GetRoundedValue(request.VendorOneTimeFee);
                    historyAdj.VendorOneTimeFeeAdjstdAmt = GetRoundedValue(request.VendorOneTimeFeeAdjstdAmt);
                    historyAdj.VendorTripFee = historyOrig.VendorTripFee = GetRoundedValue(request.VendorTripFee);
                    historyAdj.VendorTripFeeAdjstdAmt = GetRoundedValue( request.VendorTripFeeAdjstdAmt);
                    historyAdj.VendorMinServiceFee = historyOrig.VendorMinServiceFee = GetRoundedValue(request.VendorMinServiceFee);
                    historyAdj.VendorMinServiceFeeAdjstdAmt = GetRoundedValue( request.VendorMinServiceFeeAdjstdAmt);
                    break;

                case "FlatFee":
                    historyAdj.Quantity = 1;
                    historyAdj.QuantityAdjusted = 0;

                    if (!historyOrig.VendorDiscountPercentage.HasValue)
                    {
                        historyOrig.VendorDiscountPercentage = GetRoundedValue(request.VendorDiscountPercentage);
                        billingDel.SaveDisputePayableAdjustmentHistory(historyOrig); // Save Discount Percentage
                    }

                    historyOrig.VendorAdjComments = request.VendorAdjComments;
                    historyOrig.VendorFlatFee = GetRoundedValue(request.VendorFlatFee.GetValueOrDefault());
                    historyAdj.VendorFlatFee = GetRoundedValue(request.VendorFlatFee.GetValueOrDefault());
                    historyAdj.VendorFlatFeeAdjstdAmt = GetRoundedValue(request.VendorFlatFeeAdjstdAmt.GetValueOrDefault());
                    historyOrig.VendorFinalFee = GetRoundedValue(historyOrig.VendorFinalFee.GetValueOrDefault() + request.VendorFlatFeeAdjstdAmt.GetValueOrDefault());
                    historyAdj.VendorFinalFee = GetRoundedValue(historyOrig.VendorFinalFee);

                    historyAdj.VendorFinalFeeAdjstdAmt = GetRoundedValue(request.VendorFlatFeeAdjstdAmt.GetValueOrDefault());
                    historyOrig.VendorDiscountPercentage = GetRoundedValue(request.VendorDiscountPercentage);
                    if (historyOrig.VendorFee.HasValue)
                        historyOrig.VendorFee = historyOrig.VendorFee + GetRoundedValue(request.VendorFlatFeeAdjstdAmt.GetValueOrDefault());
                    else
                        historyOrig.VendorFee = historyOrig.VendorFinalFee;

                    break;
                case "Discount":
                    historyAdj.Quantity = 1;
                    historyAdj.QuantityAdjusted = 0;
                    bool isUpdateOrig1 = historyOrig.VendorDiscountPercentage.HasValue;
                    if (!isUpdateOrig1)
                    {
                        historyOrig.VendorDiscountPercentage = GetRoundedValue(request.VendorDiscountPercentage - request.VendorDiscountAdjPercentage);
                        billingDel.SaveDisputePayableAdjustmentHistory(historyOrig); // Save Discount Percentage
                    }
                    //historyOrig.VendorAdjComments = 
                    historyOrig.DiscountComment = request.VendorAdjComments;
                    historyAdj.VendorDiscountPercentage = historyOrig.VendorDiscountPercentage = GetRoundedValue(request.VendorDiscountPercentage);
                    historyAdj.VendorDiscountAdjPercentage = GetRoundedValue(request.VendorDiscountAdjPercentage);

                    var flatFee = historyOrig.VendorFlatFee.HasValue ? historyOrig.VendorFlatFee.Value : 0;
                    decimal originalFee;
                    if (historyOrig.VendorFee.HasValue)
                        originalFee = historyOrig.VendorFee.Value;
                    else
                        originalFee = historyOrig.VendorFinalFee.Value;

                    var origWithNoFlatFee = originalFee - flatFee;
                    var discount = historyAdj.VendorDiscountPercentage.HasValue ? historyAdj.VendorDiscountPercentage.Value : 0;
                    var finalFeeWithDiscount = (origWithNoFlatFee - (origWithNoFlatFee * (discount / 100)));

                    historyAdj.VendorFinalFee = historyOrig.VendorFinalFee = flatFee + Math.Round(finalFeeWithDiscount, 2);
                    if (!historyOrig.VendorFee.HasValue)
                        historyOrig.VendorFee = origWithNoFlatFee;

                    //  historyAdj.VendorFee = historyOrig.VendorFee = originalFee;
                    historyAdj.VendorFinalFeeAdjstdAmt = historyOrig.VendorFinalFeeAdjstdAmt = GetRoundedValue(originalFee - historyOrig.VendorFinalFee);
                    break;

                case "LineItem":

                    var isSaveItem = request.VendorFeeAdjstdAmt.HasValue;
                    var latestItem = billingDel.GetWorkItemPayableAdjustmentHistory(historyAdj.OrderHierarchyId);

                    var isUpdateQuantity = request.RecordsToBeSaved == "all" || request.QuantityAdjusted.GetValueOrDefault() > 0;
                    var isUpdateCost = request.RecordsToBeSaved == "all" || request.RecordsToBeSaved == "Cost";
                    var disc = GetRoundedValue(request.VendorDiscountPercentage.GetValueOrDefault());

                    if (isUpdateQuantity)
                    {
                        historyAdj.Quantity = request.Quantity;
                        historyAdj.QuantityAdjusted = historyOrig.QuantityAdjusted = request.QuantityAdjusted;
                    }
                    else
                    {
                        historyAdj.Quantity = historyOrig.Quantity;
                        historyOrig.QuantityAdjusted = 0;
                    }

                    historyAdj.UnitOfMeasure = historyOrig.UnitOfMeasure = request.UnitOfMeasure;
                    historyAdj.UnitOfMeasureAdjusted = request.UnitOfMeasureAdjusted;

                    if (isUpdateCost)
                    {
                        historyAdj.AgreedUnitCost = historyOrig.AgreedUnitCost = GetRoundedValue(request.AgreedUnitCost);
                        historyAdj.AgreedUnitCostAdjstdAmt = GetRoundedValue(request.AgreedUnitCostAdjstdAmt);
                        decimal? discountedAdjustment = 0;
                        if (disc > 0)
                        {
                            discountedAdjustment = request.VendorFee * (disc / 100);
                            if (discountedAdjustment.HasValue)
                                discountedAdjustment = Math.Round(discountedAdjustment.Value, 2);
                        }
                        historyAdj.VendorFeeAdjstdAmt = GetRoundedValue(request.VendorFee) - historyOrig.VendorFee;
                        historyAdj.VendorFee = historyOrig.VendorFee = GetRoundedValue(request.VendorFee);

                        historyOrig.VendorDiscountPercentage = request.VendorDiscountPercentage;

                        historyAdj.VendorFinalFee = GetRoundedValue(request.VendorFee.GetValueOrDefault()) - discountedAdjustment.GetValueOrDefault();
                        historyAdj.VendorFinalFeeAdjstdAmt = GetRoundedValue(historyAdj.VendorFinalFee.GetValueOrDefault() - historyOrig.VendorFinalFee.GetValueOrDefault());
                        historyOrig.VendorFinalFee = historyAdj.VendorFinalFee.GetValueOrDefault();
                        historyAdj.VendorFeeAfterDiscount = historyAdj.VendorFinalFee.GetValueOrDefault();
                    }
                    else
                    {
                        historyAdj.AgreedUnitCost = historyOrig.AgreedUnitCost;
                        historyAdj.VendorFee = historyOrig.VendorFee;
                        historyAdj.VendorFinalFee = historyOrig.VendorFinalFee.GetValueOrDefault();

                        historyAdj.AgreedUnitCostAdjstdAmt = null;
                        historyAdj.VendorFeeAdjstdAmt = null;
                        historyAdj.VendorFinalFeeAdjstdAmt = null;
                    }



                    if (!isFromDisc)
                    {
                        var itemFlatFee = latestItem.VendorFlatFee.HasValue ? latestItem.VendorFlatFee : 0;
                        var discountedAdj = historyAdj.VendorFeeAdjstdAmt - (historyAdj.VendorFeeAdjstdAmt * (disc / 100));
                        if (discountedAdj.HasValue)
                            discountedAdj = Math.Round(discountedAdj.Value, 2);

                        var finalFee = latestItem.VendorFinalFee + discountedAdj;

                        if (isUpdateCost)
                        {
                            latestItem.VendorFinalFee = finalFee.HasValue ? finalFee : itemFlatFee;
                            latestItem.VendorFee = latestItem.VendorFee.GetValueOrDefault() + historyAdj.VendorFeeAdjstdAmt.GetValueOrDefault();
                        }

                        var adjType = latestItem.AdjustmentHistoryRecordType;
                        if (adjType == "ORIG")
                        {
                            latestItem.Version = null;
                            latestItem.RecordNumber = 3;
                            latestItem.DisputePayableAdjustmentHistoryId = -1;
                            latestItem.AdjustmentHistoryRecordType = "FINAL";
                            latestItem.VendorDiscountPercentage = GetRoundedValue(request.VendorDiscountPercentage);
                            latestItem.SourceDisputePayableAdjustmentHistoryId = null;
                            latestItem.HistoryDate = DateTime.Now;
                        }


                        billingDel.SaveDisputePayableAdjustmentHistory(latestItem);

                        if (adjType == "ORIG")
                        {
                            var adjItem = latestItem;
                            adjItem.Version = null;
                            adjItem.RecordNumber = 2;
                            adjItem.VendorFlatFee = null;
                            adjItem.AdjustmentHistoryRecordType = "ADJED";
                            adjItem.DisputePayableAdjustmentHistoryId = -1;
                            adjItem.HistoryDate = DateTime.Now;
                            billingDel.SaveDisputePayableAdjustmentHistory(adjItem);
                        }
                    }
                    else
                    {
                        latestItem.VendorFee = latestItem.VendorFee.GetValueOrDefault() + historyAdj.VendorFeeAdjstdAmt.GetValueOrDefault();// Vendor Final Fee is Updated in Disc
                        billingDel.SaveDisputePayableAdjustmentHistory(latestItem);
                    }
                    break;
                case "MiscProd":
                    historyAdj.Quantity = 1;
                    historyAdj.QuantityAdjusted = 0;
                    historyAdj.FeeTypeId = historyOrig.FeeTypeId;
                    historyAdj.VendorFee = historyOrig.VendorFee = GetRoundedValue(request.VendorFee);
                    historyAdj.VendorFeeAdjstdAmt = GetRoundedValue(request.VendorFeeAdjstdAmt);
                    historyAdj.VendorFinalFee = historyOrig.VendorFinalFee = GetRoundedValue(request.VendorFee);
                    historyAdj.VendorFinalFeeAdjstdAmt = GetRoundedValue(historyOrig.VendorFinalFeeAdjstdAmt = request.VendorFeeAdjstdAmt);
                    break;
            }
            historyAdj.HistoryDate = DateTime.Now;
            historyAdj = billingDel.SaveDisputePayableAdjustmentHistory(historyAdj);

            if (historyOrig.AdjustmentHistoryRecordType == "ORIG")
            {
                historyOrig.DisputePayableAdjustmentHistoryId = -1;
                historyOrig.Version = null;
                historyOrig.RecordNumber = 3;
                historyOrig.HistoryDate = DateTime.Now;
                historyOrig.SourceDisputePayableAdjustmentHistoryId = null;
                historyOrig.AdjustmentHistoryRecordType = "FINAL";
            }
            else
            {
                historyOrig.Version = string.IsNullOrEmpty(request.Version) ? null : Convert.FromBase64String(request.Version);
            }

            billingDel.SaveDisputePayableAdjustmentHistory(historyOrig);

            if (request.AdjustmentType == "Discount" && historyAdj.VendorDiscountPercentage.HasValue)
            {

                UpdateDiscountChangesForLineItems(historyAdj.OrderHierarchyId, historyAdj.VendorAdjComments, historyAdj.VendorDiscountPercentage.Value, historyAdj.SupplierComment, request.orderHierarchyVersions);
            }

            response.MapToDtoWithoutCollections(historyAdj);
            response.InvoiceNumber = historyOrig.InvoiceNumber;
            return response;
        }

        private void UpdateDiscountChangesForLineItems(int orderHierarchyId, string comments, decimal discount, string supplierComment, IList<OrderHierarchyVersions> orderHierarchyVersions = null)
        {
            var del = new BillingAdjustmentDelegate();
            var lineItemList = del.GetLineItemsForWoItem(orderHierarchyId);



            foreach (var lineItem in lineItemList)
            {
                DisputePayableAdjustmentHistory adjtPayable = new DisputePayableAdjustmentHistory();
                var recNum = del.GetLastRecordNumber(lineItem.Payable.OrderHierarchyId);

                if (lineItem.Payable != null && lineItem.Payable.VendorFinalFee.GetValueOrDefault() > 0)
                {
                    if (orderHierarchyVersions != null)
                    {
                        string version = orderHierarchyVersions.Where(x => x.OrderHierarchyId == lineItem.Payable.OrderHierarchyId).Select(x => x.ApVersion).FirstOrDefault();
                        adjtPayable.Version = version;
                    }

                    adjtPayable.OrderHierarchyId = lineItem.Payable.OrderHierarchyId;
                    adjtPayable.VendorAdjComments = comments;
                    adjtPayable.SupplierComment = supplierComment;
                    adjtPayable.AdjustmentType = "LineItem";
                    adjtPayable.Quantity = lineItem.Payable.Quantity;
                    adjtPayable.AgreedUnitCost = lineItem.Payable.AgreedUnitCost;
                    adjtPayable.VendorFee = lineItem.Payable.VendorFee;
                    adjtPayable.VendorFinalFee = lineItem.Payable.VendorFinalFee;
                    adjtPayable.RecordNumber = recNum;
                    adjtPayable.VendorDiscountPercentage = discount;
                    adjtPayable.VendorFeeAdjstdAmt = null;//lineItem.Payable.VendorFee * (discount / 100);
                    adjtPayable.RecordsToBeSaved = "Cost";
                    //var originalFinalFee = lineItem.Payable.VendorFinalFee;
                    //adjtPayable.VendorFinalFee = lineItem.Payable.VendorFee - (lineItem.Payable.VendorFee * (discount / 100));
                    //adjtPayable.VendorFinalFeeAdjstdAmt = originalFinalFee - adjtPayable.VendorFinalFee;
                }
                DisputeReceivableAdjustmentHistory adjstReceivable = new DisputeReceivableAdjustmentHistory();
                if (lineItem.Receivable != null && lineItem.Payable != null && lineItem.Payable.VendorFinalFee.GetValueOrDefault() > 0)
                {
                    adjstReceivable.OrderHierarchyId = lineItem.Receivable.OrderHierarchyId;
                    adjstReceivable.AdjustmentType = "LineItem";
                    adjstReceivable.ClientAdjComments = comments;
                    adjstReceivable.Quantity = lineItem.Receivable.Quantity;
                    adjstReceivable.AgreedClientUnitPrice = lineItem.Receivable.AgreedClientUnitPrice;
                    adjstReceivable.ClientPrice = lineItem.Receivable.ClientPrice;
                    adjstReceivable.ClientPriceAdjstdAmt = 0;
                    adjstReceivable.RecordNumber = recNum;
                    adjstReceivable.RecordsToBeSaved = "Price";
                    if (orderHierarchyVersions != null)
                    {
                        string version = orderHierarchyVersions.Where(x => x.OrderHierarchyId == lineItem.Receivable.OrderHierarchyId).Select(x => x.ArVersion).FirstOrDefault();
                        adjstReceivable.Version = version;
                    }
                }

                if (lineItem.Payable != null && lineItem.Payable.VendorFinalFee.GetValueOrDefault() > 0)
                {
                    var resp = SaveDisputePayableAdjustmentAdjRecord(adjtPayable, isFromDisc: true);
                    CreateApAdjustment(resp, "LineItem");
                    SaveDisputeReceivableAdjustmentAdjRecord(adjstReceivable);
                }
            }
        }

        private string GetApFeeType(DisputePayableAdjustmentHistory request, string adjustmentType)
        {
            switch (adjustmentType)
            {
                case "VendorWorkOrder":
                    if (request.VendorOneTimeFeeAdjstdAmt.HasValue && request.VendorOneTimeFeeAdjstdAmt.Value != 0)
                        return "VENOTF";
                    if (request.VendorTripFeeAdjstdAmt.HasValue && request.VendorTripFeeAdjstdAmt.Value != 0)
                        return "VENTF";
                    if (request.VendorMinServiceFeeAdjstdAmt.HasValue && request.VendorMinServiceFeeAdjstdAmt.Value != 0)
                        return "VENMSF";
                    break;
                case "MiscProd":
                    return GetFeeTypeCode(request.FeeTypeId);
                //if (request.FeeTypeId.HasValue)
                //{
                //    var feeType = new DataAccess.Accounting.AccountingBillingDao().GetFeeTypeById(request.FeeTypeId.Value);
                //    return feeType.FeeTypeCode;
                //}
                //return null;

                default:
                    return null;
            }
            return null;
        }

        private string GetFeeTypeCode(int? feeTypeId)
        {
            if (feeTypeId.HasValue)
            {
                var feeType = new DataAccess.Accounting.AccountingBillingDao().GetFeeTypeById(feeTypeId.Value);
                return feeType.FeeTypeCode;
            }
            else
                return null;
        }


        private string GetArFeeType(DisputeReceivableAdjustmentHistory request, string adjustmentType)
        {
            switch (adjustmentType)
            {
                case "Client":
                    if (request.ClientRushFeeAdjstdAmt.HasValue && request.ClientRushFeeAdjstdAmt.Value != 0)
                        return "CLTRF";
                    if (request.ClientTripFeeAdjstdAmt.HasValue && request.ClientTripFeeAdjstdAmt.Value != 0)
                        return "CLTTF";

                    break;
                case "MiscProd":
                    return GetFeeTypeCode(request.FeeTypeId);
                //if (request.FeeTypeId.HasValue)
                //{
                //    var feeType = new DataAccess.Accounting.AccountingBillingDao().GetFeeTypeById(request.FeeTypeId.Value);
                //    return feeType.FeeTypeCode;
                //}
                //return null;
                default:
                    return null;
            }
            return null;
        }

        private void CreateApAdjustment(DisputePayableAdjustmentHistory request, string adjustmentType)
        {
            var del = new BillingAdjustmentDelegate();
            if (request == null || request.OrderHierarchyId <= 0)
                throw new NullReferenceException("Invalid Request. Check the request");

            var glCode = SpaAccountingService.GetGLCodeDetails(PRESS_AP_ADJUST_GLTRAN_TYPE, request.OrderHierarchyId, GetApFeeType(request, adjustmentType));
            if (glCode == null || glCode.AccountingGLCodeId <= 0)
                throw new NullReferenceException("GI Code Not Configured for AP");


            var payableAdjustmentList = new List<Dom.AccountsPayableAdjustment>();
            BuildApAdjustments(request, payableAdjustmentList, del, adjustmentType);

            payableAdjustmentList.ForEach(item =>
            {

                item.AccountsPayableInvoiceId = del.GetAccountPayableInvoiceId(request.InvoiceNumber);
                item.AdjustmentDate = DateTime.Now;
                item.AdjustmentType = item.Amount < 0 ? "CREDIT" : "DEBIT"; //if we are paying to vendor (CREDIT)
                item.AdjustmentCode = GetAccountingAdjustmentCode("AP", item.AdjustmentType, request.ApplicationId);
                item.ApplicationId = request.ApplicationId;
                item.GLTransTypeGroup = "GLTRN";
                item.APAdjStatusGroup = "APADJSG";
                item.APAdjStatusType = "RDY2BILL";
                item.GLTransType = PRESS_AP_ADJUST_GLTRAN_TYPE;
                item.Operation = glCode.Operation;
                item.Function = glCode.Function;
                item.NaturalAccount = glCode.NaturalAccount;
                item.Comments = request.VendorAdjComments;
                item.SupplierComment = request.SupplierComment;
                item.DisputePayableAdjustmentHistoryId = request.DisputePayableAdjustmentHistoryId;
                item.Amount = Math.Abs(Math.Round(item.Amount, 2));
                del.SaveAccountsPayableAdjustment(item);
            });

        }

        private static void BuildApAdjustments(DisputePayableAdjustmentHistory request, List<Dom.AccountsPayableAdjustment> payableAdjustmentList, BillingAdjustmentDelegate del, string adjustmentType)
        {
            switch (adjustmentType)
            {
                case "VendorWorkOrder":
                    if (request.VendorOneTimeFeeAdjstdAmt.HasValue && request.VendorOneTimeFeeAdjstdAmt.Value != 0)
                    {
                        var oneTimeFeeAdj = new Dom.AccountsPayableAdjustment
                        {
                            Amount = request.VendorOneTimeFeeAdjstdAmt.Value,
                            AccountsPayableDetailId = del.GetAccountsPayableId("VENOTF", request.OrderHierarchyId)
                        };
                        payableAdjustmentList.Add(oneTimeFeeAdj);
                    }

                    if (request.VendorTripFeeAdjstdAmt.HasValue && request.VendorTripFeeAdjstdAmt.Value != 0)
                    {
                        var tripFeeAdj = new Dom.AccountsPayableAdjustment
                        {
                            Amount = request.VendorTripFeeAdjstdAmt.Value,
                            AccountsPayableDetailId = del.GetAccountsPayableId("VENTF", request.OrderHierarchyId)
                        };
                        payableAdjustmentList.Add(tripFeeAdj);
                    }

                    if (request.VendorMinServiceFeeAdjstdAmt.HasValue && request.VendorMinServiceFeeAdjstdAmt.Value != 0)
                    {
                        var minSvcFeeAdj = new Dom.AccountsPayableAdjustment
                        {
                            Amount = request.VendorMinServiceFeeAdjstdAmt.Value,
                            AccountsPayableDetailId = del.GetAccountsPayableId("VENMSF", request.OrderHierarchyId)

                        };
                        payableAdjustmentList.Add(minSvcFeeAdj);
                    }

                    break;
                case "FlatFee":
                    if (request.VendorFlatFeeAdjstdAmt.HasValue && request.VendorFlatFeeAdjstdAmt.Value != 0)
                    {
                        var flatFeeAdj = new Dom.AccountsPayableAdjustment
                        {
                            Amount = request.VendorFlatFeeAdjstdAmt.Value,
                            AccountsPayableDetailId = del.GetAccountsPayableId(null, request.OrderHierarchyId)
                        };
                        payableAdjustmentList.Add(flatFeeAdj);
                    }
                    break;
                case "Discount":
                    break;
                case "LineItem":
                    if (request.VendorFinalFeeAdjstdAmt.HasValue && request.VendorFinalFeeAdjstdAmt.Value != 0)
                    {
                        var finalCostAdj = new Dom.AccountsPayableAdjustment
                        {
                            Amount = request.VendorFinalFeeAdjstdAmt.Value,
                            AccountsPayableDetailId = del.GetAccountsPayableId(null, request.OrderHierarchyId)

                        };
                        payableAdjustmentList.Add(finalCostAdj);
                    }

                    break;
                case "MiscProd":
                    if (request.VendorFeeAdjstdAmt.HasValue && request.VendorFeeAdjstdAmt.Value != 0)
                    {
                        var vendFeeAdj = new Dom.AccountsPayableAdjustment();
                        vendFeeAdj.Amount = request.VendorFeeAdjstdAmt.Value;
                        vendFeeAdj.AccountsPayableDetailId = del.GetAccountsPayableByFeeTypeId(request.FeeTypeId, request.OrderHierarchyId);
                        payableAdjustmentList.Add(vendFeeAdj);
                    }
                    break;
            }
        }

        private void CreateArAdjustment(DisputeReceivableAdjustmentHistory request, string adjustmentType)
        {
            var glCode = SpaAccountingService.GetGLCodeDetails(PRESS_AR_ADJUST_GLTRAN_TYPE, request.OrderHierarchyId, GetArFeeType(request, adjustmentType));
            if (glCode == null)
                throw new NullReferenceException("GI Code Not Configured for AR ");
            var del = new BillingAdjustmentDelegate();
            var accDel = new AccountingBillingDelegate();
            var receivableAdjustmentList = new List<Dom.AccountsReceivableAdjustment>();
            BuildArAdjustments(request, receivableAdjustmentList, del, adjustmentType);

            var adjIds = new List<int>();
            for (var i = 0; i < receivableAdjustmentList.Count; i++)
            {
                var item = receivableAdjustmentList[i];
                item.AccountsReceivableInvoiceId = del.GetAccountReceivableInvoiceId(request.InvoiceNumber);
                item.AdjustmentDate = DateTime.Now;
                item.AdjustmentType = item.Amount > 0 ? "DEBIT" : "CREDIT";
                item.AdjustmentCode = GetAccountingAdjustmentCode("AR", item.AdjustmentType, request.ApplicationId);
                item.ARAdjStatusGroup = "ARADJSG";
                item.ARAdjStatusType = "NEW";
                item.ApplicationId = request.ApplicationId;
                item.GLTransTypeGroup = "GLTRN";
                item.GLTransType = PRESS_AR_ADJUST_GLTRAN_TYPE;
                item.Operation = glCode.Operation;
                item.Function = glCode.Function;
                item.NaturalAccount = glCode.NaturalAccount;
                item.Comments = request.ClientAdjComments;
                item.DisputeReceivableAdjustmentHistoryId = request.DisputeReceivableAdjustmentHistoryId;
                item.Amount = Math.Abs(Math.Round(item.Amount, 2));
                item = del.SaveAccountsReceivableAdjustment(item);
                adjIds.Add(item.AccountsReceivableAdjustmentId);
            }


            accDel.CalculateRealTimeVertexTax(adjIds);
        }

        private static void BuildArAdjustments(DisputeReceivableAdjustmentHistory request, List<Dom.AccountsReceivableAdjustment> receivableAdjustmentList, BillingAdjustmentDelegate del, string adjustmentType)
        {
            switch (adjustmentType)
            {
                case "Client":
                    if (request.ClientRushFeeAdjstdAmt.HasValue && request.ClientRushFeeAdjstdAmt.Value != 0)
                    {
                        var rushFeeAdj = new Dom.AccountsReceivableAdjustment();
                        rushFeeAdj.Amount = request.ClientRushFeeAdjstdAmt.Value;
                        rushFeeAdj.AccountsReceivableDetailId = del.GetAccountsReceivableId("CLTRF", request.OrderHierarchyId);
                        receivableAdjustmentList.Add(rushFeeAdj);
                    }

                    if (request.ClientTripFeeAdjstdAmt.HasValue && request.ClientTripFeeAdjstdAmt.Value != 0)
                    {
                        var tripFeeAdj = new Dom.AccountsReceivableAdjustment();
                        tripFeeAdj.Amount = request.ClientTripFeeAdjstdAmt.Value;
                        tripFeeAdj.AccountsReceivableDetailId = del.GetAccountsReceivableId("CLTTF", request.OrderHierarchyId);
                        receivableAdjustmentList.Add(tripFeeAdj);
                    }
                    break;
                case "FlatFee":
                    if (request.ClientPriceAdjstdAmt.HasValue && request.ClientPriceAdjstdAmt.Value != 0)
                    {
                        var flatFeeAdj = new Dom.AccountsReceivableAdjustment();
                        flatFeeAdj.Amount = request.ClientPriceAdjstdAmt.Value;
                        flatFeeAdj.AccountsReceivableDetailId = del.GetAccountsReceivableId(null, request.OrderHierarchyId);
                        receivableAdjustmentList.Add(flatFeeAdj);
                    }

                    break;
                case "LineItem":
                    if (request.ClientPriceAdjstdAmt.HasValue && request.ClientPriceAdjstdAmt.Value != 0)
                    {
                        var clientPriceAdj = new Dom.AccountsReceivableAdjustment();
                        clientPriceAdj.Amount = request.ClientPriceAdjstdAmt.Value;
                        clientPriceAdj.AccountsReceivableDetailId = del.GetAccountsReceivableId(null, request.OrderHierarchyId);
                        receivableAdjustmentList.Add(clientPriceAdj);
                    }
                    break;
                case "MiscProd":
                    if (request.ClientPriceAdjstdAmt.HasValue && request.ClientPriceAdjstdAmt.Value != 0)
                    {
                        var clientPriceAdj = new Dom.AccountsReceivableAdjustment();
                        clientPriceAdj.Amount = request.ClientPriceAdjstdAmt.Value;
                        clientPriceAdj.AccountsReceivableDetailId = del.GetAccountsReceivableByFeeTypeId(request.FeeTypeId, request.OrderHierarchyId, request.FeeTypePaymentRefId);
                        receivableAdjustmentList.Add(clientPriceAdj);
                    }
                    break;
            }
        }

        private List<ClientFeeAdjustmentDetail> GetClientFeeDetails(int AdjustmentHistoryId, int orderHierarchyId)
        {
            List<Dom.ClientFeeAdjustmentDetail> DomainDetailList = new List<Dom.ClientFeeAdjustmentDetail>();
            DomainDetailList = new BillingAdjustmentDelegate().GetClientFeeAdjustmentDetail(AdjustmentHistoryId, orderHierarchyId);
            List<ClientFeeAdjustmentDetail> ClientFeeAdjustmentDetailList = new List<ClientFeeAdjustmentDetail>();
            if (DomainDetailList != null)
            {
                foreach (Dom.ClientFeeAdjustmentDetail DomainDetail in DomainDetailList)
                {
                    ClientFeeAdjustmentDetail DtoDetail = new ClientFeeAdjustmentDetail();
                    DtoDetail = DtoDetail.MapFromDomainModel<Dom.ClientFeeAdjustmentDetail, ClientFeeAdjustmentDetail>(DomainDetail);
                    ClientFeeAdjustmentDetailList.Add(DtoDetail);
                }
            }

            return ClientFeeAdjustmentDetailList;
        }

        private List<VendorFeeAdjustmentDetail> GetVendorFeeDetailsList(int AdjustmentHistoryId, int orderHierarchyId)
        {
            List<Dom.VendorFeeAdjustmentDetail> DomainDetailList = new List<Dom.VendorFeeAdjustmentDetail>();
            DomainDetailList = new BillingAdjustmentDelegate().GetVendorFeeAdjustmentDetail(AdjustmentHistoryId, orderHierarchyId);
            if (DomainDetailList == null || DomainDetailList.Count <= 0)
                return null;
            List<VendorFeeAdjustmentDetail> VendorFeeAdjustmentDetailList = new List<VendorFeeAdjustmentDetail>();
            foreach (Dom.VendorFeeAdjustmentDetail DomainDetail in DomainDetailList)
            {
                VendorFeeAdjustmentDetail DtoDetail = new VendorFeeAdjustmentDetail();
                DtoDetail = DtoDetail.MapFromDomainModel<Dom.VendorFeeAdjustmentDetail, VendorFeeAdjustmentDetail>(DomainDetail);
                VendorFeeAdjustmentDetailList.Add(DtoDetail);
            }
            return VendorFeeAdjustmentDetailList;
        }

        private List<FlatFeeAdjustmentDetail> GetFlatFeeDetailsList(int AdjustmentHistoryId, int orderHierarchyId)
        {
            var DomainDetailList = new BillingAdjustmentDelegate().GetFlatFeeAdjustmentDetail(AdjustmentHistoryId, orderHierarchyId);
            List<FlatFeeAdjustmentDetail> FlatFeeAdjustmentDetailList = new List<FlatFeeAdjustmentDetail>();
            if (DomainDetailList != null)
                foreach (Dom.FlatFeeAdjustmentDetail DomainDetail in DomainDetailList)
                {
                    FlatFeeAdjustmentDetail DtoDetail = new FlatFeeAdjustmentDetail();
                    DtoDetail = DtoDetail.MapFromDomainModel<Dom.FlatFeeAdjustmentDetail, FlatFeeAdjustmentDetail>(DomainDetail);
                    FlatFeeAdjustmentDetailList.Add(DtoDetail);
                }
            return FlatFeeAdjustmentDetailList;
        }

        private List<DiscountAdjustmentDetail> GetDiscountDetailsList(int AdjustmentHistoryId, int orderHierarchyId)
        {
            var DomainDetailList = new BillingAdjustmentDelegate().GetDiscountAdjustmentDetail(AdjustmentHistoryId, orderHierarchyId);
            List<DiscountAdjustmentDetail> DiscountAdjustmentDetailList = new List<DiscountAdjustmentDetail>();
            if (DomainDetailList != null)
                foreach (Dom.DiscountAdjustmentDetail DomainDetail in DomainDetailList)
                {
                    DiscountAdjustmentDetail DtoDetail = new DiscountAdjustmentDetail();
                    DtoDetail = DtoDetail.MapFromDomainModel<Dom.DiscountAdjustmentDetail, DiscountAdjustmentDetail>(DomainDetail);
                    DiscountAdjustmentDetailList.Add(DtoDetail);
                }
            return DiscountAdjustmentDetailList;
        }

        private List<LineItemAdjustmentDetail> GetLineItemDetailsList(int AdjustmentHistoryId, int orderHierarchyId)
        {
            var DomainDetailList = new BillingAdjustmentDelegate().GetLineItemAdjustmentDetail(AdjustmentHistoryId, orderHierarchyId);
            List<LineItemAdjustmentDetail> LineItemAdjustmentDetailList = new List<LineItemAdjustmentDetail>();
            if (DomainDetailList != null)
                foreach (Dom.LineItemAdjustmentDetail DomainDetail in DomainDetailList)
                {
                    LineItemAdjustmentDetail DtoDetail = new LineItemAdjustmentDetail();
                    DtoDetail = DtoDetail.MapFromDomainModel<Dom.LineItemAdjustmentDetail, LineItemAdjustmentDetail>(DomainDetail);
                    DtoDetail.RecType = CalculateRecordType(DtoDetail);
                    DtoDetail.RecordNumber = CalculateRecordNumber(DtoDetail);
                    LineItemAdjustmentDetailList.Add(DtoDetail);
                }
            return LineItemAdjustmentDetailList;
        }

        private List<MiscAdjustmentDetail> GetMiscDetailsList(int historyId, int orderHierarchyId, string type, int? feeTypeId, int? feeTypeRefId)
        {
            var DomainDetailList = new BillingAdjustmentDelegate().GetMiscProductAdjustmentDetail(historyId, orderHierarchyId, type, feeTypeId, feeTypeRefId);
            List<MiscAdjustmentDetail> miscAdjustmentDetailList = new List<MiscAdjustmentDetail>();
            if (DomainDetailList != null)
                foreach (Dom.MiscAdjustmentDetail DomainDetail in DomainDetailList)
                {
                    MiscAdjustmentDetail DtoDetail = new MiscAdjustmentDetail();
                    DtoDetail = MiscProdMapDaoToDto(DomainDetail);
                    miscAdjustmentDetailList.Add(DtoDetail);
                }
            return miscAdjustmentDetailList;
        }

        private List<PenaltyAdjustmentDetail> GetPenaltyDetailList(string achievementName, int orderHierarchyId)
        {
            var penaltyAdjDetailsDao = new BillingAdjustmentDelegate().GetPenaltyAdjustmentDetails(achievementName, orderHierarchyId);
            List<PenaltyAdjustmentDetail> penaltyAdjDetails = new List<PenaltyAdjustmentDetail>();
            if (penaltyAdjDetailsDao != null)
            {
                foreach (var penDao in penaltyAdjDetailsDao)
                {
                    PenaltyAdjustmentDetail penaltyAdjustmentDetail = new PenaltyAdjustmentDetail();
                    MapPenaltyDaoToDto(penDao, penaltyAdjustmentDetail);
                    penaltyAdjDetails.Add(penaltyAdjustmentDetail);
                }

            }
            return penaltyAdjDetails;
        }

        private static void MapPenaltyDaoToDto(Dom.PenaltyAdjustmentDetail penDao, PenaltyAdjustmentDetail penaltyAdjustmentDetail)
        {
            penaltyAdjustmentDetail.DisputePenaltyAdjustmentHistoryId = penDao.DisputePenaltyAdjustmentHistoryId;
            penaltyAdjustmentDetail.VendorWorkOrderId = penDao.VendorWorkOrderId;
            penaltyAdjustmentDetail.AssignedVendorId = penDao.AssignedVendorId;
            penaltyAdjustmentDetail.GoalName = penDao.GoalName;
            penaltyAdjustmentDetail.AchievementName = penDao.AchievementName;
            penaltyAdjustmentDetail.AdjustmentDate = penDao.AdjustmentDate;
            penaltyAdjustmentDetail.Comments = penDao.Comments;
            penaltyAdjustmentDetail.InvoiceDate = penDao.InvoiceDate;
            penaltyAdjustmentDetail.InvoiceNumber = penDao.InvoiceNumber;
            penaltyAdjustmentDetail.PenaltyAmount = penDao.PenaltyAmount;
            penaltyAdjustmentDetail.PenaltyAdjustmentAmount = penDao.PenaltyAdjustmentAmount;
            penaltyAdjustmentDetail.ProductName = penDao.ProductName;
            penaltyAdjustmentDetail.ServiceName = penDao.ServiceName;
            penaltyAdjustmentDetail.Version = penDao.Version == null ? null : Convert.ToBase64String(penDao.Version); ;
            penaltyAdjustmentDetail.WorkOrderId = penDao.WorkOrderId;
            penaltyAdjustmentDetail.RecordNumber = penDao.RecordNumber;
            penaltyAdjustmentDetail.RecType = penDao.RecType;
            penaltyAdjustmentDetail.OrderHierarchyId = penDao.OrderHierarchyId;
            penaltyAdjustmentDetail.OrderId = penDao.OrderId;
            penaltyAdjustmentDetail.FeeTypeId = penDao.FeeTypeId;
            penaltyAdjustmentDetail.ApplicationId = penDao.ApplicationId;
            penaltyAdjustmentDetail.IsAPAdjusted = penDao.IsAPAdjusted;

        }

        private int CalculateRecordNumber(LineItemAdjustmentDetail detail)
        {
            int recordNumber = 0;
            if (detail != null)
            {
                if (detail.APRecordNumber != null && detail.ARRecordNumber != null && detail.APRecordNumber.GetValueOrDefault() > 0 && detail.APRecordNumber.GetValueOrDefault() > 0)
                {
                    recordNumber = (detail.APRecordNumber.Value >= detail.ARRecordNumber.Value) ? detail.APRecordNumber.Value : detail.ARRecordNumber.Value;
                }

                if (recordNumber == 0)
                {
                    if (detail.ARRecordNumber.GetValueOrDefault() > 0)
                        recordNumber = detail.ARRecordNumber.Value;
                    else if (detail.APRecordNumber.GetValueOrDefault() > 0)
                        recordNumber = detail.APRecordNumber.Value;
                }
            }

            if (recordNumber == 0)
                recordNumber = 1;

            return recordNumber;
        }

        private string CalculateRecordType(LineItemAdjustmentDetail detail)
        {
            string recType = string.Empty;

            if (!string.IsNullOrEmpty(detail.ApRecType) && !string.IsNullOrEmpty(detail.ArRecType))
            {
                if (detail.ApRecType.Equals("ADJED", StringComparison.CurrentCultureIgnoreCase) || detail.ArRecType.Equals("ADJED", StringComparison.CurrentCultureIgnoreCase))
                    recType = "ADJED";
                else if (detail.ApRecType.Equals("FINAL", StringComparison.CurrentCultureIgnoreCase) || detail.ArRecType.Equals("FINAL", StringComparison.CurrentCultureIgnoreCase))
                    recType = "FINAL";
                else
                    recType = "ORIG";
            }

            if (string.IsNullOrEmpty(recType))
            {
                if (!string.IsNullOrEmpty(detail.ApRecType))
                    recType = detail.ApRecType;
                else if (!string.IsNullOrEmpty(detail.ArRecType))
                    recType = detail.ArRecType;
            }

            return recType;
        }

        private List<CronologicalAdjustmentListResponse> MapCronologicalDaoToDTO(List<Dom.CronologicalAdjustmentListResponseDAO> cronologicalResponseDAO)
        {
            if (cronologicalResponseDAO == null || cronologicalResponseDAO.Count <= 0)
                return null;

            List<CronologicalAdjustmentListResponse> cronDTOResponseList = new List<CronologicalAdjustmentListResponse>();
            foreach (Dom.CronologicalAdjustmentListResponseDAO cronDAO in cronologicalResponseDAO)
            {
                CronologicalAdjustmentListResponse cronDTO = new CronologicalAdjustmentListResponse();

                cronDTO.AdjustedBy = cronDAO.AdjustedBy;
                cronDTO.AdjustedCategory = cronDAO.adjustmentcategory;
                cronDTO.AdjustmentAmount = cronDAO.AdjustedFee;
                cronDTO.AdjustmentDate = cronDAO.AdjustmentDate;
                cronDTO.AdjustmentInvoiceNumber = cronDAO.InvoiceNumber;
                cronDTO.EndingAmount = cronDAO.EndingFee;
                cronDTO.Feetype = cronDAO.Feetype;
                cronDTO.OderNumber = cronDAO.orderId;
                cronDTO.Product = cronDAO.ProductName;
                cronDTO.SentToOracleDate = cronDAO.SentToOracleDate;
                cronDTO.Service = cronDAO.ServiceName;
                cronDTO.ServiceItem = cronDAO.ServiceItem;
                cronDTO.StartingAmount = cronDAO.startingFee;
                cronDTO.VendorId = cronDAO.VendorId > 0 ? cronDAO.VendorId : null;
                cronDTO.VendorWorkOrderNumber = cronDAO.vendorworkOrderId;
                cronDTO.RecordNumber = "Adj " + cronDAO.RecordNumber;
                cronDTO.EndingTax = cronDAO.EndingTax;
                cronDTOResponseList.Add(cronDTO);
            }

            return cronDTOResponseList;
        }

        private static Dom.AccountingGLCode GetGLCodeDetails(string AP_AR_GLTransType, int orderHierarchyId, string feeType)
        {
            var del = new AccountingGLCodeDelegate();
            var glCode = del.GetPresAccountingGlCode(orderHierarchyId, feeType, AP_AR_GLTransType);
            return glCode;
        }

        private static string GetAccountingAdjustmentCode(string adjustmentCategoryType, string adjustmentType, int applicationID)
        {
            string returncode = string.Empty;
            SearchAdjustmentCodeResponse result =
                new SpaAccountingService().SearchAccountingAdjustmentsCode(
                    new SearchAdjustmentCodeRequest()
                    {
                        SearchInput = new AdjustmentCodeSearchInput()
                        {
                            AdjustmentCategoryType = adjustmentCategoryType,
                            AdjustmentType = adjustmentType,
                            IsActive = "Yes"
                        },
                        PageSize = 100,
                        SkipCount = 0
                    });
            if (result != null && result.SearchResults != null && result.SearchResults.Count > 0)
                returncode = result.SearchResults.FirstOrDefault().AdjustmentCode;
            return returncode;// should fileter with application Id but Entity and its repose DTO and DAO needs to change
        }

        private Dom.DisputePayableAdjustmentHistory APReValidateOriginalObjectForServiceLevelChanges(int historyOrderhierachyId, BillingAdjustmentDelegate billingDel)
        {
            return billingDel.GetLatestDisputePayableAdjustmentHistory(historyOrderhierachyId);
        }

        private Dom.DisputePayableAdjustmentHistory APGetWorkItemAdjustmentHistoryObjForItsLineItem(int lineitemOderHierachyId, BillingAdjustmentDelegate billingDel)
        {
            return billingDel.GetWorkItemPayableAdjustmentHistory(lineitemOderHierachyId);
        }

        private Dom.DisputeReceivableAdjustmentHistory ARReValidateOriginalObjectForServiceLevelChanges(int historyOrderhierachyId, BillingAdjustmentDelegate billingDel)
        {
            return billingDel.GetLatestDisputeReceivableAdjustmentHistory(historyOrderhierachyId);
        }

        private Dom.DisputeReceivableAdjustmentHistory ARGetWorkItemAdjustmentHistoryObjForItsLineItem(int lineitemOderHierachyId, BillingAdjustmentDelegate billingDel)
        {
            return billingDel.GetWorkItemLatestReceivableAdjustmentHistory(lineitemOderHierachyId);
        }

        #endregion

        #region MAPPERS
        private AdjustmentDetailResponse MapAllListToDTO(Dom.AdjustmentDetailResponseDAO mainDataDAO)
        {
            AdjustmentDetailResponse adjustmentResponseDTO = new AdjustmentDetailResponse();

            if (mainDataDAO.IsMiscProduct)
            {
                adjustmentResponseDTO.IsMiscProduct = mainDataDAO.IsMiscProduct;
                adjustmentResponseDTO.MiscAdjustmentDetailList = new List<MiscAdjustmentDetail>();
                if (mainDataDAO.MiscAdjustmentDetailList != null && mainDataDAO.MiscAdjustmentDetailList.Count > 0)
                {
                    mainDataDAO.MiscAdjustmentDetailList.ForEach(p =>
                    {
                        var det = MiscProdMapDaoToDto(p);
                        adjustmentResponseDTO.MiscAdjustmentDetailList.Add(det);
                    });
                }
            }
            else
            {
                if (mainDataDAO != null && mainDataDAO.clientAdjustMentResponseList != null && mainDataDAO.clientAdjustMentResponseList.Count > 0)
                {
                    adjustmentResponseDTO.clientAdjustMentResponseList = new List<ClientFeeAdjustmentDetail>();
                    foreach (Dom.ClientFeeAdjustmentDetail clntFeeDAO in mainDataDAO.clientAdjustMentResponseList)
                    {
                        ClientFeeAdjustmentDetail clntFeeDTO = new ClientFeeAdjustmentDetail();
                        clntFeeDTO.MapToDtoWithoutCollections(clntFeeDAO);
                        adjustmentResponseDTO.clientAdjustMentResponseList.Add(clntFeeDTO);
                    }
                }

                if (mainDataDAO != null && mainDataDAO.vendorFeeAdjustmentResponseList != null && mainDataDAO.vendorFeeAdjustmentResponseList.Count > 0)
                {
                    adjustmentResponseDTO.vendorFeeAdjustmentResponseList = new List<VendorFeeAdjustmentDetail>();
                    foreach (Dom.VendorFeeAdjustmentDetail vnrFeeDAO in mainDataDAO.vendorFeeAdjustmentResponseList)
                    {
                        VendorFeeAdjustmentDetail vdrFeeDTO = new VendorFeeAdjustmentDetail();
                        vdrFeeDTO.MapToDtoWithoutCollections(vnrFeeDAO);
                        adjustmentResponseDTO.vendorFeeAdjustmentResponseList.Add(vdrFeeDTO);
                    }
                }


                if (mainDataDAO != null && mainDataDAO.OrderTotals != null)
                {
                    adjustmentResponseDTO.OrderTotals = new OrderTotal()
                    {
                        ClientPrice = mainDataDAO.OrderTotals.ClientPrice,
                        VendorFee = mainDataDAO.OrderTotals.VendorFee,
                        VendorFinalFee = mainDataDAO.OrderTotals.VendorFinalFee,
                        Penalties = mainDataDAO.OrderTotals.Penalties

                    };
                }


                //product Service mapping, need to generate Mapping file and Uncomment below code
                if (mainDataDAO != null && mainDataDAO.productServiceAdjustmentResponseList != null && mainDataDAO.productServiceAdjustmentResponseList.Count > 0)
                {
                    adjustmentResponseDTO.productServiceAdjustmentResponseList = new List<ProductServiceAdjustmentResponse>();
                    foreach (Dom.ProductServiceAdjustmentResponse productservsAdjustDAO in mainDataDAO.productServiceAdjustmentResponseList)
                    {
                        var productServiceAdjustDTO = new ProductServiceAdjustmentResponse()
                        {
                            IsARAdjusted = Convert.ToBoolean(productservsAdjustDAO.IsARAdjusted),
                            IsAPAdjusted = Convert.ToBoolean(productservsAdjustDAO.IsAPAdjusted),
                            OrderId = productservsAdjustDAO.OrderId,
                            WorkOrderId = productservsAdjustDAO.WorkOrderId,
                            VendorWorkOrderId = productservsAdjustDAO.VendorWorkOrderId,
                            WorkOrderItemId = productservsAdjustDAO.WorkOrderItemId,
                            Product = productservsAdjustDAO.Product,
                            Service = productservsAdjustDAO.Service,
                            Cost = productservsAdjustDAO.Cost,
                            Discount = productservsAdjustDAO.Discount,
                            DiscountAmt = productservsAdjustDAO.DiscountAmt,
                            CostAfterDiscount = productservsAdjustDAO.CostAfterDiscount,
                            ClientBilling = productservsAdjustDAO.ClientBilling,
                            ClientPrice = productservsAdjustDAO.ClientPrice,
                            ArInvoiceNumber = productservsAdjustDAO.ArInvoiceNumber,
                            TaxAmount = productservsAdjustDAO.TaxAmount,
                            invoicedDate = productservsAdjustDAO.invoicedDate,
                            OrderHierarchyId = productservsAdjustDAO.OrderHierarchyId,
                            AdjustmentHistoryPayableId = productservsAdjustDAO.AdjustmentHistoryPayableId,
                            AdjustmentHistoryReceivableId = productservsAdjustDAO.AdjustmentHistoryReceivableId,
                            RecType = productservsAdjustDAO.RecType,
                            ProductCode = productservsAdjustDAO.ProductCode,
                            ApInvoiceNumber = productservsAdjustDAO.ApInvoiceNumber,
                            ApInvoiceDate = productservsAdjustDAO.ApInvoiceDate,
                            IsApInvoiced = productservsAdjustDAO.IsApInvoiced,
                            IsArInvoiced = productservsAdjustDAO.IsArInvoiced,
                            VendorId = productservsAdjustDAO.VendorId,
                            IsServiceLevelBilling = productservsAdjustDAO.IsServiceLevelBilling,
                            CostAfterPI = productservsAdjustDAO.CostAfterPI,
                            PenaltyIncentive = productservsAdjustDAO.PenaltyIncentive

                        };

                        adjustmentResponseDTO.productServiceAdjustmentResponseList.Add(productServiceAdjustDTO);
                    }
                }

            }
            return adjustmentResponseDTO;
        }

        private static MiscAdjustmentDetail MiscProdMapDaoToDto(Dom.MiscAdjustmentDetail p)
        {
            var det = new MiscAdjustmentDetail();
            det.Cost = p.Cost;
            det.CostAdjustment = p.CostAdjustment;
            det.FeeType = p.FeeType;
            det.Id = p.Id;
            det.IdType = p.IdType;
            det.RecType = p.RecType;
            det.InvoicedDate = p.InvoicedDate;
            det.InvoiceNumber = p.InvoiceNumber;
            det.OrderId = p.OrderId;
            det.WorkOrderId = p.WorkOrderId;
            det.Tax = p.Tax;
            det.Product = p.Product;
            det.RecordNumber = p.RecordNumber;
            det.OrderHierarchyId = p.OrderHierarchyId;
            det.Comments = p.Comments;
            det.FeeTypeId = p.FeeTypeId;
            det.AdjustmentDate = p.AdjustmentDate;
            det.FeeTypeRefId = p.FeeTypeRefId;
            det.VendorId = p.VendorId;
            det.ProductCode = p.ProductCode;
            det.Version = p.Version == null ? null : Convert.ToBase64String(p.Version);
            return det;
        }



        private PrdSrvMainDataResponse MapPrdSrvListsToDTO(Dom.PrdSrvMainResponseDAO mainDataDAO)
        {
            PrdSrvMainDataResponse prdSrvResponseDTO = new PrdSrvMainDataResponse();
            if (mainDataDAO != null && mainDataDAO.flatFeeResponseList != null && mainDataDAO.flatFeeResponseList.Count > 0)
            {
                prdSrvResponseDTO.FlatFeeAdjustmentResponseList = new List<FlatFeeAdjustmentDetail>();
                foreach (Dom.FlatFeeAdjustmentDetail flatFeeDAO in mainDataDAO.flatFeeResponseList)
                {
                    FlatFeeAdjustmentDetail flatFeeDTO = new FlatFeeAdjustmentDetail();
                    flatFeeDTO.MapToDtoWithoutCollections(flatFeeDAO);
                    prdSrvResponseDTO.FlatFeeAdjustmentResponseList.Add(flatFeeDTO);
                }
            }

            if (mainDataDAO != null && mainDataDAO.discountResponseList != null && mainDataDAO.discountResponseList.Count > 0)
            {
                prdSrvResponseDTO.DiscountAdjustmentResponseList = new List<DiscountAdjustmentDetail>();
                foreach (Dom.DiscountAdjustmentDetail discountDAO in mainDataDAO.discountResponseList)
                {
                    DiscountAdjustmentDetail discountDTO = new DiscountAdjustmentDetail();
                    discountDTO.MapToDtoWithoutCollections(discountDAO);
                    prdSrvResponseDTO.DiscountAdjustmentResponseList.Add(discountDTO);
                }
            }

            //LineItem
            if (mainDataDAO != null && mainDataDAO.lineItemResponseList != null && mainDataDAO.lineItemResponseList.Count > 0)
            {
                prdSrvResponseDTO.LineItemAdjustmentResponseList = new List<LineItemAdjustmentDetail>();
                foreach (Dom.LineItemAdjustmentDetail lineItemDAO in mainDataDAO.lineItemResponseList)
                {
                    LineItemAdjustmentDetail lineItemDTO = new LineItemAdjustmentDetail();
                    lineItemDTO.MapToDtoWithoutCollections(lineItemDAO);
                    lineItemDTO.RecType = CalculateRecordType(lineItemDTO);
                    lineItemDTO.RecordNumber = CalculateRecordNumber(lineItemDTO);
                    prdSrvResponseDTO.LineItemAdjustmentResponseList.Add(lineItemDTO);
                }
            }

            if (mainDataDAO != null && mainDataDAO.OrderTotals != null)
            {
                prdSrvResponseDTO.OrderTotals = new OrderTotal()
                {
                    ClientPrice = mainDataDAO.OrderTotals.ClientPrice,
                    VendorFee = mainDataDAO.OrderTotals.VendorFee,
                    VendorFinalFee = mainDataDAO.OrderTotals.VendorFinalFee,
                    Penalties = mainDataDAO.OrderTotals.Penalties

                };
            }

            return prdSrvResponseDTO;
        }
        #endregion


    }
}
