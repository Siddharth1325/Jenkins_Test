﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel;
using BusinessSvcImpl.DataObjects.SpaAccountingService.Dto;
using DynamicForms.Utilities;

namespace BusinessSvcImpl.SvcImpl.SpaAcc
{
    [ServiceContractAttribute(Namespace = "http://www.bkfs.com/FS/services/Vendor/1.00")]
    public partial interface ISpaAccService
    {
        [OperationContract]
        GetOrderSearchResponse GetOrderSearchResults(GetOrderSearchRequest request);
    }
}
