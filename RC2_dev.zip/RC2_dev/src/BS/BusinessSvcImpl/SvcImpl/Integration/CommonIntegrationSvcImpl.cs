﻿using DataAccess.Accounting.Subscriber;
using Delegate.TxnDelegate;
using DomainModel.Accounting;
using IntCommonSvcLib.Service.Impl;
using IntCommonSvcLib.Service.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;

namespace BusinessSvcImpl.SvcImpl.Integration
{

    // This is a pass through wrapper service over Common Integration Svc. This is done so that we load all the dependent dll's so that reflection doesn ot have issues finding them.
    [ServiceBehavior(TransactionIsolationLevel = IsolationLevel.ReadCommitted, InstanceContextMode = InstanceContextMode.PerCall)]
    public class CommonIntegrationSvcImpl : IntegrationCommonSvcImpl, IIntegrationCommonSvc
    {
        public CommonIntegrationSvcImpl()
        {
            // this is done to load referenced assemlies in AppDomain, so that when reflection tries to find specific Impl, its able to find them in any of these libraries.
            
            Asset assetDom = new Asset();
            AssetDao dao = new AssetDao();
            AssetDelegate assetDel = new AssetDelegate();

        }
    }
}
