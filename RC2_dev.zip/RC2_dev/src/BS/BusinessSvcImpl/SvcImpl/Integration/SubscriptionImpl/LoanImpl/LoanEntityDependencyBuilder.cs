﻿using CommonLib.FSException;
using CommonLib.Messaging.Ict;
using CommonLib.Util;
using Delegate.TxnDelegate;
using DomainModel.Accounting;
using IntCommonSvcLib.Constants;
using IntCommonSvcLib.Implementation.DataAccess;
using IntCommonSvcLib.Implementation.Domain;
using IntCommonSvcLib.Interfaces;
using Platform.Acct.IntegrationBusinessSvcImpl;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessSvcImpl.Integration.SubscriptionImpl.Loan
{
    public class LoanEntityDependencyBuilder : AcctEntityUpdateBase
    {
        public LoanEntityDependencyBuilder() { }
        private bool _canExit = false;
        public override bool CanExit()
        {
            return _canExit;
        }
        private IctSubscriptionMsg SaveHoldMsg(IContext MessageCtx, int applicationid, string MessageType, int SrcAssetId, string DateTimeStamp, string Status)
        {
            PlatformMqMessage msg = MessageCtx.Context.ContextInfo[LiteralConstants.PlatformMqMessage] as PlatformMqMessage;


            var Msg = new SubscriptionMsgDao().GetSubscriptionMsgWithKeys(applicationid, MessageType, LiteralConstants.AssetId, SrcAssetId, LiteralConstants.LastUpdatedDate, DateTimeStamp);
            if (Msg == null || Msg.Count == 0)
            {
                return new SubscriptionMsgDao().SaveSubscriptionMsg(new IctSubscriptionMsg() { Message = RelectionUtils.SerilizeToXml<PlatformMqMessage>(msg), MessageType = MessageType, ApplicationId = applicationid, Key1Name = LiteralConstants.AssetId, Key1Value = SrcAssetId.ToString(), Key2Name = LiteralConstants.LastUpdatedDate, Key2Value = DateTimeStamp, MessageProcStatus = Status });
            }
            else return Msg[0];
        }
        private void DeleteHoldMsg(IContext MessageCtx, int applicationid, string MessageType, int SrcAssetId, string DateTimeStamp, string Status)
        {
            PlatformMqMessage msg = MessageCtx.Context.ContextInfo[LiteralConstants.PlatformMqMessage] as PlatformMqMessage;

            EFdbHelper.OptConcurrencyHelper(() =>
                    {
                        var Msgs = new SubscriptionMsgDao().GetSubscriptionMsgWithKeys(applicationid, MessageType, LiteralConstants.AssetId, SrcAssetId, LiteralConstants.LastUpdatedDate, DateTimeStamp);

                        if (Msgs != null && Msgs.Count > 0)
                        {
                            foreach (var Msg in Msgs)  {   DeleteHeldMsg(Msg);};
                        }
                    }, 50);
        }
        public override void Execute(IContext MessageCtx)
        {
            EntityUpdate EntityUpdateDto = null;
            if (MessageCtx.Context.ContextInfo.ContainsKey(typeof(EntityUpdate).Name))
            {
                EntityUpdateDto = MessageCtx.Context.ContextInfo[typeof(EntityUpdate).Name] as EntityUpdate;
            }
            if (EntityUpdateDto == null)
            {
                EntityUpdateDto = RelectionUtils.GetObjectFromXml<CommonLib.Messaging.Ict.EntityUpdate>(MessageCtx.Context.PayLoad);
            }

            this.EnrichMessage(EntityUpdateDto, MessageCtx.Context.ContextInfo[LiteralConstants.PlatformMqMessage] as PlatformMqMessage);

            if (EntityUpdateDto.LatestValues.Find(item => item.Name == LiteralConstants.AssetId) == null) throw new FSBusinessException("AssetId is not present in the payload");

            Int32 AppId = (Int32)EntityUpdateDto.LatestValues.Find(item => item.Name == LiteralConstants.ApplicationId).Value;

            var sourceAsset = EntityUpdateDto.LatestValues.Find(item => item.Name == LiteralConstants.AssetId).Value;
            int SourceAssetId=0;
            if(sourceAsset!=null)
             SourceAssetId = (Int32)EntityUpdateDto.LatestValues.Find(item => item.Name == LiteralConstants.AssetId).Value;

            if (SourceAssetId > 0)
            {
                var PlatformAsset = GetPlatformAsset(AppId, SourceAssetId);

                System.DateTime dtStamp = (System.DateTime)EntityUpdateDto.LatestValues.Find(item => item.Name == LiteralConstants.LastUpdatedDate).Value;
                if (PlatformAsset != null && PlatformAsset.AssetId > 0)
                {
                    EntityUpdateDto.LatestValues.Find(item => item.Name == LiteralConstants.AssetId).Value = PlatformAsset.AssetId;

                    DeleteHoldMsg(MessageCtx, AppId, EntityUpdateDto.EntityName, SourceAssetId, dtStamp.ToString(), "QUEUED");
                    _canExit = false;
                }
                else
                {
                   

                    SaveHoldMsg(MessageCtx, AppId, EntityUpdateDto.EntityName, SourceAssetId, dtStamp.ToString(), "QUEUED");
                    _canExit = true;
                }
            }
            
        }
    }
}
