﻿using BusinessSvcImpl.SvcImpl.Integration;
using CommonLib.Messaging.Ict;
using CommonLib.Util;
using IntCommonSvcLib.Constants;
using IntCommonSvcLib.Implementation.Domain;
using IntCommonSvcLib.Interfaces;
using Platform.Acct.IntegrationBusinessSvcImpl;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessSvcImpl.Integration.SubscriptionImpl.WO
{
    public class PostWorkOrderCommitAction : AcctEntityUpdateBase
    {
        public override void Execute(IContext MessageCtx)
        {
            EntityUpdate EntityUpdateDto = null;
            CommonIntegrationSvcImpl svc = new CommonIntegrationSvcImpl();

            EntityUpdateDto = RelectionUtils.GetObjectFromXml<CommonLib.Messaging.Ict.EntityUpdate>(MessageCtx.Context.PayLoad);

            var sourceWorkOrderId = EntityUpdateDto.LatestValues.Find(item => item.Name == LiteralConstants.WorkOrderId).Value;
            Int32 AppId = (MessageCtx.Context.ContextInfo[LiteralConstants.PlatformMqMessage] as PlatformMqMessage).MqContext.UserContext.ApplicationId;

            List<IctSubscriptionMsg> WorkOrderItemMsgs = GetHeldMsgs(AppId, LiteralConstants.WorkOrderId, (int)sourceWorkOrderId);

            if (WorkOrderItemMsgs != null)
            {

                foreach (var wo in WorkOrderItemMsgs)
                {
                    svc.Process(RelectionUtils.GetObjectFromXml<PlatformMqMessage>(wo.Message));
                    
                }
            }
           

        }
    }
}
