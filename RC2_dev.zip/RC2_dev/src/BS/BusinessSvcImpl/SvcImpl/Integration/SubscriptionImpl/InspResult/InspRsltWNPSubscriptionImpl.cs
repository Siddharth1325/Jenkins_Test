﻿
using CommonLib.FSException;
using CommonLib.Messaging.Ict;
using CommonLib.Util;
using Delegate.TxnDelegate;
using DomainModel.Accounting;
using DomainModel.InspResult;

using IntCommonSvcLib.Constants;
using IntCommonSvcLib.Interfaces;
using Platform.Acct.IntegrationBusinessSvcImpl;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dto = BusinessSvcImpl.DataObjects.SpaAccounting.Dto;
using InspProxy= Inspections.ServiceProxy.InspectionSvc;
namespace BusinessSvcImpl.SvcImpl.Integration.SubscriptionImpl.InspResult
{
    public class InspResultGeneralDto
    {

    }
    public class InspRsltWNPSubscriptionImpl : AcctEntityUpdateBase
    {
        public InspRsltWNPSubscriptionImpl() { }


        private InspRsltWorkNotPerformed MapToInspRsltGeneralDto(EntityUpdate src)
        {
            var InspRsltWNPDto = new InspRsltWorkNotPerformed();

            base.Map<EntityUpdate, DomainModel.BaseDomainModel>(src, InspRsltWNPDto, null);

            return InspRsltWNPDto;

        }
        private int GetWorkorderId(InspRsltWorkNotPerformed Insp)
        {
            return new Inspections.ServiceProxy.InspectionServiceProxy().GetInspectionWorkOrderIdByInspectionId(new InspProxy.InspectinGetWorkOrderIdRequest() { InspectionId = Insp.InspectionResultId.Value, children = new List<InspProxy.InspResultEnumInspResultChild>() { InspProxy.InspResultEnumInspResultChild.WorkNotPerformed } }).WorkOrderId;
        }

        private WorkOrder MapToDomainModel(InspRsltWorkNotPerformed Insp, WorkOrder Wo)
        {
            Wo.BadAddrGroupCode = Insp.BadAddrGroupCode;
            Wo.AccessDeniedType = Insp.AccessDeniedType;
            return Wo;

        }
        public override void Execute(IContext MessageCtx)
        {
            EntityUpdate EntityUpdateDto = null;
            if (MessageCtx.Context.ContextInfo.ContainsKey(typeof(EntityUpdate).Name))
            {
                EntityUpdateDto = MessageCtx.Context.ContextInfo[typeof(EntityUpdate).Name] as EntityUpdate;
            }
            if (EntityUpdateDto == null)
            {
                EntityUpdateDto = RelectionUtils.GetObjectFromXml<CommonLib.Messaging.Ict.EntityUpdate>(MessageCtx.Context.PayLoad);
            }

            this.EnrichMessage(EntityUpdateDto, MessageCtx.Context.ContextInfo[LiteralConstants.PlatformMqMessage] as PlatformMqMessage);
            Int32 AppId = (Int32)EntityUpdateDto.LatestValues.Find(item => item.Name == LiteralConstants.ApplicationId).Value;

            var InspResultGeneral =  this.MapToInspRsltGeneralDto(EntityUpdateDto);

            int WorkOrderId = GetWorkorderId(InspResultGeneral);

            if (WorkOrderId > 0)
            {
                EFdbHelper.OptConcurrencyHelper(() =>
               {
                   //Get the WorkOrder
                   WorkOrderDelegate woDelegate = new WorkOrderDelegate();
                   var DomWorkOrder = woDelegate.GetWorkOrder(AppId, WorkOrderId);

                   if (DomWorkOrder != null)
                   {
                       //Map to Domain Model
                       this.MapToDomainModel(InspResultGeneral, DomWorkOrder);

                       //Save the Work Order
                       woDelegate.SaveWorkOrder(DomWorkOrder);
                   }
               }, 50);

            }
            else throw new FSBusinessException("Could not retrieve Work Order id in Platform from Source system to Save InspRsltWorkNotPerformed subscription.");


           

            
        }
    }
}
