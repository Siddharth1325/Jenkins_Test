﻿
using CommonLib.FSException;
using CommonLib.Messaging.Ict;
using CommonLib.Util;
using Delegate.TxnDelegate;
using DomainModel.Accounting;
using DomainModel.InspResult;

using IntCommonSvcLib.Constants;
using IntCommonSvcLib.Interfaces;
using Platform.Acct.IntegrationBusinessSvcImpl;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dto = BusinessSvcImpl.DataObjects.SpaAccounting.Dto;
using InspProxy = Inspections.ServiceProxy.InspectionSvc;

namespace BusinessSvcImpl.SvcImpl.Integration.SubscriptionImpl.InspResult
{
    
    public class InspRsltGeneralSubscriptionImpl : AcctEntityUpdateBase
    {
        public InspRsltGeneralSubscriptionImpl() { }


        private InspRsltGeneral MapToInspRsltGeneralDto(EntityUpdate src)
        {
            var InspRsltGeneralDto = new InspRsltGeneral();

            base.Map<EntityUpdate, DomainModel.BaseDomainModel>(src, InspRsltGeneralDto,null);

            return InspRsltGeneralDto;

        }
        private int GetWorkorderId(InspRsltGeneral Insp)
        {
            return new Inspections.ServiceProxy.InspectionServiceProxy().GetInspectionWorkOrderIdByInspectionId(new Inspections.ServiceProxy.InspectionSvc.InspectinGetWorkOrderIdRequest() { InspectionId = Insp.InspRsltGeneralId, children = new List<InspProxy.InspResultEnumInspResultChild>() { InspProxy.InspResultEnumInspResultChild.General } }).WorkOrderId;
        }

        private WorkOrder MapToDomainModel(InspRsltGeneral Insp, WorkOrder Wo)
        {
            Wo.InspectorUniqueId = Insp.InspectorUniqueId;
            Wo.InspectionDate1 = Insp.InspectionDate1;
            Wo.InspectionDate2 = Insp.InspectionDate2;
            Wo.InspectionDate3 = Insp.InspectionDate3;
            return Wo;

        }
        public override void Execute(IContext MessageCtx)
        {
            EntityUpdate EntityUpdateDto = null;
            if (MessageCtx.Context.ContextInfo.ContainsKey(typeof(EntityUpdate).Name))
            {
                EntityUpdateDto = MessageCtx.Context.ContextInfo[typeof(EntityUpdate).Name] as EntityUpdate;
            }
            if (EntityUpdateDto == null)
            {
                EntityUpdateDto = RelectionUtils.GetObjectFromXml<CommonLib.Messaging.Ict.EntityUpdate>(MessageCtx.Context.PayLoad);
            }

            this.EnrichMessage(EntityUpdateDto, MessageCtx.Context.ContextInfo[LiteralConstants.PlatformMqMessage] as PlatformMqMessage);
            Int32 AppId = (Int32)EntityUpdateDto.LatestValues.Find(item => item.Name == LiteralConstants.ApplicationId).Value;

            var InspResultGeneral =  this.MapToInspRsltGeneralDto(EntityUpdateDto);

            int WorkOrderId = GetWorkorderId(InspResultGeneral);

            if (WorkOrderId > 0)
            {
                EFdbHelper.OptConcurrencyHelper(() =>
               {
                   //Get the WorkOrder
                   WorkOrderDelegate woDelegate = new WorkOrderDelegate();
                   var DomWorkOrder = woDelegate.GetWorkOrder(AppId, WorkOrderId);

                   if (DomWorkOrder != null)
                   {
                       //Map to Domain Model
                       this.MapToDomainModel(InspResultGeneral, DomWorkOrder);

                       //Save the Work Order
                       woDelegate.SaveWorkOrder(DomWorkOrder);
                   }
               }, 50);

            }
            else throw new FSBusinessException("Could not retrieve Work Order id in Platform from Source system to Save InspRsltGeneral subscription.");


           

            
        }
    }
}
