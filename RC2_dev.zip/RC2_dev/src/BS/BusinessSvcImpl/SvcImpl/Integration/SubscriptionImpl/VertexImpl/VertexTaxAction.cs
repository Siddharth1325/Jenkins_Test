﻿using BusinessSvcImpl.DataObjects.SpaAccountingService.Dto;
using BusinessSvcImpl.SvcImpl.SpaAcc;
using CommonLib.FSException;
using IntCommonSvcLib.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessSvcImpl.SvcImpl.Integration.SubscriptionImpl.VertexImpl
{
    public static class LiteralConstants
    {
        public const string SubscriptionIdentifier = "AccountTaxBatchID";
        public const string TenantGuid = "TenantGuid";  

    }
   
    public class VertexTaxAction : ActionBase
    {
        public override void Execute(IContext MessageCtx)
        {
           
            CalculateVertexTaxRequest RequestPayLoad = CommonLib.Util.RelectionUtils.GetObjectFromXml<CalculateVertexTaxRequest>(MessageCtx.Context.PayLoad);
            if (RequestPayLoad ==null || RequestPayLoad.AccountTaxBatchID == 0 || string.IsNullOrEmpty(RequestPayLoad.TenantGuid)) throw new FSBusinessException("VertexTaxAction-> AccountTaxBatchID Or TenantGuid is null");

            new SpaAccountingService().CalculateVertexTaxUsingTaxBatchId(RequestPayLoad);

        }
    }
}
