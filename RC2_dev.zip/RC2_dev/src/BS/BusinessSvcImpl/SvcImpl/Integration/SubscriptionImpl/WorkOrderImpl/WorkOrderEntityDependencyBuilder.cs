﻿using CommonLib;
using CommonLib.FSException;
using CommonLib.Messaging.Ict;
using CommonLib.Util;
using DataAccess.Accounting.Subscriber;
using Delegate.TxnDelegate;
using DomainModel.Accounting;
using IntCommonSvcLib.Constants;
using IntCommonSvcLib.Implementation.DataAccess;
using IntCommonSvcLib.Implementation.Domain;
using IntCommonSvcLib.Interfaces;
using Platform.Acct.IntegrationBusinessSvcImpl;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessSvcImpl.Integration.SubscriptionImpl.Order
{
    public static class WoUtil
{
        public static bool IsBilledStatus(WorkOrder PlatformWorkOrder)
        {
            if (PlatformWorkOrder != null
                && PlatformWorkOrder.AcctProcessedDate != null
                && PlatformWorkOrder.AcctProcessedDate.HasValue
                &&
                (PlatformWorkOrder.WorkOrderStatusType == WorkOrderStatusEnum.BILLED.ToString() || PlatformWorkOrder.WorkOrderStatusType == WorkOrderStatusEnum.CANCEL.ToString())
                )
            {
                return true;
            }
            else
                return false;
        }
}
    public class WorkOrderEntityDependencyBuilder : AcctEntityUpdateBase
    {

       
        public WorkOrderEntityDependencyBuilder() { }
        private bool _canExit = false;
        public override bool CanExit()
        {
            return _canExit;
        }
        private IctSubscriptionMsg SaveHoldMsg(IContext MessageCtx, int applicationid, string MessageType, int SrcOrderId, string DateTimeStamp, string Status)
        {
            PlatformMqMessage msg = MessageCtx.Context.ContextInfo[LiteralConstants.PlatformMqMessage] as PlatformMqMessage;

            var Msg = new SubscriptionMsgDao().GetSubscriptionMsgWithKeys(applicationid, MessageType, LiteralConstants.OrderId, SrcOrderId, LiteralConstants.LastUpdatedDate, DateTimeStamp);
            if (Msg == null || Msg.Count == 0)
            {
                return new SubscriptionMsgDao().SaveSubscriptionMsg(new IctSubscriptionMsg() { Message = RelectionUtils.SerilizeToXml<PlatformMqMessage>(msg), MessageType = MessageType, ApplicationId = applicationid, Key1Name = LiteralConstants.OrderId, Key1Value = SrcOrderId.ToString(),Key2Name =  LiteralConstants.LastUpdatedDate, Key2Value = DateTimeStamp, MessageProcStatus = Status });
            }
            else return Msg[0];
        }
        private void DeleteHoldMsg(IContext MessageCtx, int applicationid, string MessageType, int SrcOrderId, string DateTimeStamp, string Status)
        {
            PlatformMqMessage msg = MessageCtx.Context.ContextInfo[LiteralConstants.PlatformMqMessage] as PlatformMqMessage;

            EFdbHelper.OptConcurrencyHelper(() =>
                    {
                        var Msgs = new SubscriptionMsgDao().GetSubscriptionMsgWithKeys(applicationid, MessageType, LiteralConstants.OrderId, SrcOrderId, LiteralConstants.LastUpdatedDate, DateTimeStamp);
                        if (Msgs != null && Msgs.Count > 0)
                        {
                            foreach (var Msg in Msgs)
                            {

                                DeleteHeldMsg(Msg);
                            };
                        }
                    }, 50);
            
        }
        public override void Execute(IContext MessageCtx)
        {
            EntityUpdate EntityUpdateDto = null;
            if (MessageCtx.Context.ContextInfo.ContainsKey(typeof(EntityUpdate).Name))
            {
                EntityUpdateDto = MessageCtx.Context.ContextInfo[typeof(EntityUpdate).Name] as EntityUpdate;
            }
            if (EntityUpdateDto == null)
            {
                EntityUpdateDto = RelectionUtils.GetObjectFromXml<CommonLib.Messaging.Ict.EntityUpdate>(MessageCtx.Context.PayLoad);
            }

            this.EnrichMessage(EntityUpdateDto, MessageCtx.Context.ContextInfo[LiteralConstants.PlatformMqMessage] as PlatformMqMessage);

            if (EntityUpdateDto.LatestValues.Find(item => item.Name == LiteralConstants.OrderId) == null) throw new FSBusinessException("OrderId is not present in the payload");

            Int32 AppId = (Int32)EntityUpdateDto.LatestValues.Find(item => item.Name == LiteralConstants.ApplicationId).Value;
            Int32 SourceOrderId = (Int32)EntityUpdateDto.LatestValues.Find(item => item.Name == LiteralConstants.OrderId).Value;
            Int32 SourceWorkOrderId = (Int32)EntityUpdateDto.LatestValues.Find(item => item.Name == LiteralConstants.WorkOrderId).Value;

            var PlatformWorkOrder = GetPlatformWorkOrder(AppId, SourceWorkOrderId);

            // If Billing has been run on the Work Order,we can not take any more updates.


            if (WoUtil.IsBilledStatus(PlatformWorkOrder))
            {
                Logging.LogError("Platform says=> Step1 Ignoring this update on Work Order = " + PlatformWorkOrder.SourceWorkOrderId.ToString() + " as Billing has already completed this Work order.");
                _canExit = true;
                return;
            }
            var PlatformOrder = GetPlatformOrder(AppId, SourceOrderId);

            System.DateTime dtStamp = (System.DateTime)EntityUpdateDto.LatestValues.Find(item => item.Name == LiteralConstants.LastUpdatedDate).Value;
            if (PlatformOrder != null && PlatformOrder.OrderId > 0)
            {
                EntityUpdateDto.LatestValues.Find(item => item.Name == LiteralConstants.OrderId).Value = PlatformOrder.OrderId;

                //we are here, means we will process this message, lets delete any held messages.
                DeleteHoldMsg(MessageCtx, AppId, EntityUpdateDto.EntityName, SourceOrderId, dtStamp.ToString(), "QUEUED");
                _canExit = false;
            }
            else
            {
                SaveHoldMsg(MessageCtx, AppId, EntityUpdateDto.EntityName, SourceOrderId,dtStamp.ToString() ,"QUEUED");
                _canExit = true;
            }
        }
    }
}
