﻿using BusinessSvcImpl.SvcImpl.Integration;
using CommonLib.Messaging.Ict;
using CommonLib.Util;
using IntCommonSvcLib.Constants;
using IntCommonSvcLib.Implementation.DataAccess;
using IntCommonSvcLib.Implementation.Domain;
using IntCommonSvcLib.Interfaces;
using Platform.Acct.IntegrationBusinessSvcImpl;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessSvcImpl.Integration.SubscriptionImpl.Asset
{
    public class PostAssetSaveAction : AcctEntityUpdateBase
    {
        
        public override void Execute(IContext MessageCtx)
        {
            EntityUpdate EntityUpdateDto = null;
            CommonIntegrationSvcImpl svc = new CommonIntegrationSvcImpl();
           
            EntityUpdateDto = RelectionUtils.GetObjectFromXml<CommonLib.Messaging.Ict.EntityUpdate>(MessageCtx.Context.PayLoad);
            
            var AssetLoanId = EntityUpdateDto.LatestValues.Find(item => item.Name == LiteralConstants.AssetId).Value;
            Int32 AppId = (MessageCtx.Context.ContextInfo[LiteralConstants.PlatformMqMessage] as PlatformMqMessage).MqContext.UserContext.ApplicationId;

            List<IctSubscriptionMsg> LoanMsgs = GetHeldMsgs(AppId, LiteralConstants.AssetId, (int)AssetLoanId);
            if (LoanMsgs != null)
            {
                foreach (IctSubscriptionMsg LoanMsg in LoanMsgs)
                {
                    svc.Process(RelectionUtils.GetObjectFromXml<PlatformMqMessage>(LoanMsg.Message));
                   
                }
                 
            }
           
        }
    }
}
