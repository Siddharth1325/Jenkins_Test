﻿using BusinessSvcImpl.SvcImpl.Integration;
using CommonLib.Messaging.Ict;
using CommonLib.Util;
using IntCommonSvcLib.Constants;
using IntCommonSvcLib.Implementation.Domain;
using IntCommonSvcLib.Interfaces;
using Platform.Acct.IntegrationBusinessSvcImpl;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessSvcImpl.Integration.SubscriptionImpl.Order
{
    public class PostOrderCommitAction : AcctEntityUpdateBase
    {
        public override void Execute(IContext MessageCtx)
        {
            EntityUpdate EntityUpdateDto = null;
            CommonIntegrationSvcImpl svc = new CommonIntegrationSvcImpl();

            EntityUpdateDto = RelectionUtils.GetObjectFromXml<CommonLib.Messaging.Ict.EntityUpdate>(MessageCtx.Context.PayLoad);

            var sourceOrderId = EntityUpdateDto.LatestValues.Find(item => item.Name == LiteralConstants.OrderId).Value;
            Int32 AppId = (MessageCtx.Context.ContextInfo[LiteralConstants.PlatformMqMessage] as PlatformMqMessage).MqContext.UserContext.ApplicationId;

            List<IctSubscriptionMsg> WorkOrderMsgs = GetHeldMsgs(AppId, LiteralConstants.OrderId, (int)sourceOrderId);

            if (WorkOrderMsgs!=null)
            {

                foreach(var wo in WorkOrderMsgs)
                {
                    svc.Process(RelectionUtils.GetObjectFromXml<PlatformMqMessage>(wo.Message));
                    
                  
                }
            }
           

        }
    }
}
