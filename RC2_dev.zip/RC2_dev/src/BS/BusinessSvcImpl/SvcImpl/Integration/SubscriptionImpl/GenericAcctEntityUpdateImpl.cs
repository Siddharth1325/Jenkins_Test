﻿using BusinessSvcImpl.Integration.SubscriptionImpl.Order;
using CommonLib;
using CommonLib.FSException;
using CommonLib.Messaging.Ict;
using CommonLib.Util;
using Delegate.TxnDelegate;
using DomainModel.Accounting;
using IntCommonSvcLib.Constants;
using IntCommonSvcLib.Implementation.DataAccess;
using IntCommonSvcLib.Implementation.Domain;
using IntCommonSvcLib.Interfaces;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Platform.Acct.IntegrationBusinessSvcImpl
{

    public class AcctEntityUpdateBase: ActionBase
    {
        public AcctEntityUpdateBase() { }

        protected void EnrichMessage(EntityUpdate entityupdate, PlatformMqMessage msg)
        {
            if (entityupdate != null && msg != null)
            {
                if (entityupdate.LatestValues.Where(item => item.Name ==LiteralConstants.ApplicationId).FirstOrDefault() == null)
                {
                    entityupdate.LatestValues.Add(new CommonLib.Messaging.NameValue() { Name = LiteralConstants.ApplicationId, Value = msg.MqContext.UserContext.ApplicationId });

                }
            }
        }
        protected int GetPlatformAssetId(int appId, int SourceAssetId)
        {
            Asset assetDom = new AssetDelegate().GetAsset(appId, SourceAssetId);

            if (assetDom == null) throw new FSBusinessException("Asset is not present in the system yet, pls retry");

            return assetDom.AssetId;
        }
        protected Asset GetPlatformAsset(int appId, int SourceAssetId)
        {
            return new AssetDelegate().GetAsset(appId, SourceAssetId);

            
        }
        protected int GetPlatformLoanId(int appId, int SourceLoanId)
        {
            var loanDom = new LoanDelegate().GetLoan(appId, SourceLoanId);

            if (loanDom == null) throw new FSBusinessException("Loan is not present in the system yet, pls retry");

            return loanDom.LoanId;
        }
        protected Loan GetPlatformLoan(int appId, int SourceLoanId)
        {
            return new LoanDelegate().GetLoan(appId, SourceLoanId);

        }
        protected int GetPlatformOrderId(int appId, int SourceOrderId)
        {
            var orderDom = new OrderDelegate().GetOrder(appId, SourceOrderId);

            if (orderDom == null) throw new FSBusinessException("Order is not present in the system yet, pls retry");

            return orderDom.OrderId;
        }
        protected Order GetPlatformOrder(int appId, int SourceOrderId)
        {
            return new OrderDelegate().GetOrder(appId, SourceOrderId);

            
        }
        protected int GetPlatformWorkOrderId(int appId, int SourceWorkOrderId)
        {
            var WorkOrderDom = new WorkOrderDelegate().GetWorkOrder(appId, SourceWorkOrderId);

            if (WorkOrderDom == null) throw new FSBusinessException("WorkOrder is not present in the system yet, pls retry");

            return WorkOrderDom.WorkOrderId;
        }
        protected WorkOrder GetPlatformWorkOrder(int appId, int SourceWorkOrderId)
        {
            return new WorkOrderDelegate().GetWorkOrder(appId, SourceWorkOrderId);

           
        }
        protected List<IctSubscriptionMsg> GetHeldMsgs(int applicationId, string Key1Name, int Key1Value)
        {
            return new SubscriptionMsgDao().GetSubscriptionMsgWithKeys(applicationId, Key1Name, Key1Value);
            
        }
        protected void DeleteHeldMsg(IctSubscriptionMsg msg)
        {
            new SubscriptionMsgDao().DeleteSubscriptionMsg(msg);
        }
        
    }
        
        
    // This is responsible to save all the Subscription Entities such as WorkOrder/Order/Aset/Loan.
    //We can write specific Impl also if we need to.
    public class GenericAcctEntityUpdateImpl :AcctEntityUpdateBase
    {
        
        public GenericAcctEntityUpdateImpl()
        { }
        
        private string _DestType;

        
        public override void Init(IContext ActionCtx)
        {
            _DestType = ActionCtx.Context.ContextInfo[LiteralConstants.DestType].ToString();


        }
        public override void PreExecute(IContext MessageCtx)
        {

            EntityUpdate EntityUpdateDto = null;
            if (MessageCtx.Context.ContextInfo.ContainsKey(typeof(EntityUpdate).Name))
            {
                EntityUpdateDto = MessageCtx.Context.ContextInfo[typeof(EntityUpdate).Name] as EntityUpdate;
            }
            if (EntityUpdateDto == null)
            {
                EntityUpdateDto = RelectionUtils.GetObjectFromXml<CommonLib.Messaging.Ict.EntityUpdate>(MessageCtx.Context.PayLoad);
            }
            this.EnrichMessage(EntityUpdateDto, MessageCtx.Context.ContextInfo[LiteralConstants.PlatformMqMessage] as PlatformMqMessage);
        }
        
        public override void Execute(IContext MessageCtx)
            {

                EFdbHelper.OptConcurrencyHelper(() =>
                {
                    Type DestType = RelectionUtils.GetClassType(this._DestType);

                    var DomInstance = InstanceHelper.GetInstance<DomainModel.BaseDomainModel>(DestType);

                    Delegate.Com.CommonDelegate comDelegate = new Delegate.Com.CommonDelegate();

                    EntityUpdate EntityUpdateDto = null;

                    if (MessageCtx.Context.ContextInfo.ContainsKey(typeof(EntityUpdate).Name))
                    {
                        EntityUpdateDto = MessageCtx.Context.ContextInfo[typeof(EntityUpdate).Name] as EntityUpdate;
                    }
                    if (EntityUpdateDto == null)
                    {
                        EntityUpdateDto = RelectionUtils.GetObjectFromXml<CommonLib.Messaging.Ict.EntityUpdate>(MessageCtx.Context.PayLoad);
                    }

                    
                    //map
                    base.Map<CommonLib.Messaging.Ict.EntityUpdate, DomainModel.BaseDomainModel>(EntityUpdateDto, DomInstance, MessageCtx);

                    //Try to look up the Record by Id.
                    var ExistingEntity = comDelegate.FetchEntityByKeys(DomInstance);

                    if (ExistingEntity != null)
                    {
                        if (base.IsLatestUpdated(ExistingEntity as DomainModel.BaseDomainModel, DomInstance as DomainModel.BaseDomainModel)) 
                        {
                            Logging.LogWarn("Platform says=>Ignoring this update, we already have a latest update.");
                            return; 
                        } // If latest updates are already applied, exit.

                        byte[] version = (byte[])ExistingEntity.GetType().GetProperty(LiteralConstants.Version).GetValue(ExistingEntity);

                        DomInstance.GetType().GetProperty(LiteralConstants.Version).SetValue(DomInstance, version);

                        DomainModel.BaseDomainModel exsitingEntity = ExistingEntity as DomainModel.BaseDomainModel;

                        // this should have been in sepearte Impl, will move it later. one more time, just to make sure Ming has not commited the data in between.
                        WorkOrder wo = ExistingEntity as WorkOrder;
                        if (wo!=null)
                        {
                            if(WoUtil.IsBilledStatus(wo))
                            {
                                Logging.LogError("Platform says=> Step2 Ignoring this update on Work Order = " + wo.SourceWorkOrderId.ToString() + " as Billing has already completed this Work order.");
                                return;

                            }
                        }
                        
                        base.SimpleMap<DomainModel.BaseDomainModel, DomainModel.BaseDomainModel>(DomInstance as DomainModel.BaseDomainModel, exsitingEntity, MessageCtx);

                        comDelegate.Save(ExistingEntity);

                    }
                    else
                    {
                        comDelegate.Save(DomInstance);

                    }
                    return;
                   },50);
                    
                   //Action x = () => {
                   // Type DestType = RelectionUtils.GetClassType(this._DestType);

                   // var DomInstance = InstanceHelper.GetInstance<DomainModel.BaseDomainModel>(DestType);

                   // Delegate.Com.CommonDelegate comDelegate = new Delegate.Com.CommonDelegate();

                   // EntityUpdate EntityUpdateDto = null;

                   // if (MessageCtx.Context.ContextInfo.ContainsKey(typeof(EntityUpdate).Name))
                   // {
                   //     EntityUpdateDto = MessageCtx.Context.ContextInfo[typeof(EntityUpdate).Name] as EntityUpdate;
                   // }
                   // if (EntityUpdateDto == null)
                   // {
                   //     EntityUpdateDto = RelectionUtils.GetObjectFromXml<CommonLib.Messaging.Ict.EntityUpdate>(MessageCtx.Context.PayLoad);
                   // }

                   
                   // //map
                   // base.Map<CommonLib.Messaging.Ict.EntityUpdate, DomainModel.BaseDomainModel>(EntityUpdateDto, DomInstance, MessageCtx);

                   // //Try to look up the Record by Id.
                   // var ExistingEntity = comDelegate.FetchEntityByKeys(DomInstance);

                   // if (ExistingEntity != null)
                   // {
                   //     if (base.IsLatestUpdated(ExistingEntity as DomainModel.BaseDomainModel, DomInstance as DomainModel.BaseDomainModel)) { return; } // If latest updates are already applied, exit.

                   //     byte[] version = (byte[])ExistingEntity.GetType().GetProperty(LiteralConstants.Version).GetValue(ExistingEntity);

                   //     DomInstance.GetType().GetProperty(LiteralConstants.Version).SetValue(DomInstance, version);

                   //     DomainModel.BaseDomainModel exsitingEntity = ExistingEntity as DomainModel.BaseDomainModel;

                   //     WorkOrder wo = ExistingEntity as WorkOrder;


                   //     base.SimpleMap<DomainModel.BaseDomainModel, DomainModel.BaseDomainModel>(DomInstance as DomainModel.BaseDomainModel, exsitingEntity, MessageCtx);

                   //     comDelegate.Save(ExistingEntity);

                   // }
                   // else
                   // {
                   //     comDelegate.Save(DomInstance);

                   // }
                   // return;
                   //};
                    
                    
                   


            //while(true){
            //    try
            //    {

                    
            //        Type DestType = RelectionUtils.GetClassType(this._DestType);

            //        var DomInstance = InstanceHelper.GetInstance<DomainModel.BaseDomainModel>(DestType);

            //        Delegate.Com.CommonDelegate comDelegate = new Delegate.Com.CommonDelegate();

            //        EntityUpdate EntityUpdateDto = null;

            //        if (MessageCtx.Context.ContextInfo.ContainsKey(typeof(EntityUpdate).Name))
            //        {
            //            EntityUpdateDto = MessageCtx.Context.ContextInfo[typeof(EntityUpdate).Name] as EntityUpdate;
            //        }
            //        if (EntityUpdateDto == null)
            //        {
            //            EntityUpdateDto = RelectionUtils.GetObjectFromXml<CommonLib.Messaging.Ict.EntityUpdate>(MessageCtx.Context.PayLoad);
            //        }

                   
            //        //map
            //        base.Map<CommonLib.Messaging.Ict.EntityUpdate, DomainModel.BaseDomainModel>(EntityUpdateDto, DomInstance, MessageCtx);

            //        //Try to look up the Record by Id.
            //        var ExistingEntity = comDelegate.FetchEntityByKeys(DomInstance);

            //        if (ExistingEntity != null)
            //        {
            //            if (base.IsLatestUpdated(ExistingEntity as DomainModel.BaseDomainModel, DomInstance as DomainModel.BaseDomainModel)) { return; } // If latest updates are already applied, exit.

            //            byte[] version = (byte[])ExistingEntity.GetType().GetProperty(LiteralConstants.Version).GetValue(ExistingEntity);

            //            DomInstance.GetType().GetProperty(LiteralConstants.Version).SetValue(DomInstance, version);

            //            DomainModel.BaseDomainModel exsitingEntity = ExistingEntity as DomainModel.BaseDomainModel;

            //            WorkOrder wo = ExistingEntity as WorkOrder;


            //            base.SimpleMap<DomainModel.BaseDomainModel, DomainModel.BaseDomainModel>(DomInstance as DomainModel.BaseDomainModel, exsitingEntity, MessageCtx);

            //            comDelegate.Save(ExistingEntity);

            //        }
            //        else
            //        {
            //            comDelegate.Save(DomInstance);

            //        }
            //        return;
            //    }
            //    //Type genericType = typeof(DataAccess.Common.GenericRepo<DataAccess.AdmDao.SubscriptionContext>);

            //    //MethodInfo mi = genericType.GetMethod(LiteralConstants.GenericInspRepoSaveEntity);
            //    //MethodInfo miConstructed = mi.MakeGenericMethod(DestType);
            //    //object[] args = { DomInstance };
            //    //try
            //    //{
            //    //    miConstructed.Invoke(new DataAccess.Common.GenericRepo<DataAccess.AdmDao.SubscriptionContext>(), args);
            //    //    return;
            //    //}
            //    catch (System.Data.Entity.Infrastructure.DbUpdateConcurrencyException e) { Logging.LogError("UpdateConcurrencyException Error in Execute method, moving on to save the data with retry ", e); }
               

               
            }
            
        }


    
}
