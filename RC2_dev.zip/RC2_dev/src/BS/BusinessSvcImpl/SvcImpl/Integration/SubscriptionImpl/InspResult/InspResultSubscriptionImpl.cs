﻿
using CommonLib.FSException;
using CommonLib.Messaging.Ict;
using CommonLib.Util;
using Delegate.TxnDelegate;
using DomainModel.Accounting;
using DomainModel.InspResult;

using IntCommonSvcLib.Constants;
using IntCommonSvcLib.Interfaces;
using Platform.Acct.IntegrationBusinessSvcImpl;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dto = BusinessSvcImpl.DataObjects.SpaAccounting.Dto;
namespace BusinessSvcImpl.SvcImpl.Integration.SubscriptionImpl.InspResult
{
    
    public class InspResultSubscriptionImpl : AcctEntityUpdateBase
    {
        public InspResultSubscriptionImpl() { }


        private InspectionResult MapToInspRsltGeneralDto(EntityUpdate src)
        {
            var InspRsltDto = new InspectionResult();

            base.Map<EntityUpdate, DomainModel.BaseDomainModel>(src, InspRsltDto, null);

            return InspRsltDto;

        }
        private int GetWorkorderId(InspectionResult Insp)
        {
            return Insp.WorkOrderId.Value;
        }

        private WorkOrder MapToDomainModel(InspectionResult Insp, WorkOrder Wo)
        {
            Wo.IsWorkPerformed = Insp.IsWorkPerformed;
            return Wo;

        }
        public override void Execute(IContext MessageCtx)
        {
            EntityUpdate EntityUpdateDto = null;
            if (MessageCtx.Context.ContextInfo.ContainsKey(typeof(EntityUpdate).Name))
            {
                EntityUpdateDto = MessageCtx.Context.ContextInfo[typeof(EntityUpdate).Name] as EntityUpdate;
            }
            if (EntityUpdateDto == null)
            {
                EntityUpdateDto = RelectionUtils.GetObjectFromXml<CommonLib.Messaging.Ict.EntityUpdate>(MessageCtx.Context.PayLoad);
            }

            this.EnrichMessage(EntityUpdateDto, MessageCtx.Context.ContextInfo[LiteralConstants.PlatformMqMessage] as PlatformMqMessage);
            Int32 AppId = (Int32)EntityUpdateDto.LatestValues.Find(item => item.Name == LiteralConstants.ApplicationId).Value;

            var InspResult =  this.MapToInspRsltGeneralDto(EntityUpdateDto);

            int WorkOrderId = GetWorkorderId(InspResult);

            if (WorkOrderId > 0)
            {
                EFdbHelper.OptConcurrencyHelper(() =>
              {
                  //Get the WorkOrder
                  WorkOrderDelegate woDelegate = new WorkOrderDelegate();
                  var DomWorkOrder = woDelegate.GetWorkOrder(AppId, WorkOrderId);

                  if (DomWorkOrder != null)
                  {
                      //Map to Domain Model
                      this.MapToDomainModel(InspResult, DomWorkOrder);

                      //Save the Work Order
                      woDelegate.SaveWorkOrder(DomWorkOrder);
                  }
              }, 50);

            }
            else throw new FSBusinessException("Could not retrieve Work Order id in Platform from Source system to Save InspectionResult subscription");


           

            
        }
    }
}
