﻿using CommonLib.FSException;
using CommonLib.Messaging.Ict;
using CommonLib.Util;
using Delegate.TxnDelegate;
using DomainModel.Accounting;
using IntCommonSvcLib.Constants;
using IntCommonSvcLib.Interfaces;
using Platform.Acct.IntegrationBusinessSvcImpl;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessSvcImpl.Integration.SubscriptionImpl.Cancel
{
    public class CancellationDependencyBuilder : AcctEntityUpdateBase
    {
        public CancellationDependencyBuilder() { }

       

        public override void Execute(IContext MessageCtx)
        {
            EntityUpdate EntityUpdateDto = null;
            if (MessageCtx.Context.ContextInfo.ContainsKey(typeof(EntityUpdate).Name))
            {
                EntityUpdateDto = MessageCtx.Context.ContextInfo[typeof(EntityUpdate).Name] as EntityUpdate;
            }
            if (EntityUpdateDto == null)
            {
                EntityUpdateDto = RelectionUtils.GetObjectFromXml<CommonLib.Messaging.Ict.EntityUpdate>(MessageCtx.Context.PayLoad);
            }

            this.EnrichMessage(EntityUpdateDto, MessageCtx.Context.ContextInfo[LiteralConstants.PlatformMqMessage] as PlatformMqMessage);

          

           
            Int32 AppId = (Int32)EntityUpdateDto.LatestValues.Find(item => item.Name == LiteralConstants.ApplicationId).Value;

            var SourceLoanId = EntityUpdateDto.LatestValues.Find(item => item.Name == "Cancelled"+ LiteralConstants.LoanId);

            if (SourceLoanId != null && SourceLoanId.Value!=null) 
            {
                SourceLoanId.Value =  GetPlatformLoanId(AppId, (int)SourceLoanId.Value);
            }
            else
            {
                SourceLoanId.Value = null;
            }
            var SourceOrderId = EntityUpdateDto.LatestValues.Find(item => item.Name == "Cancelled" + LiteralConstants.OrderId);

            if (SourceOrderId != null && SourceOrderId.Value!=null)
            {
                SourceOrderId.Value = GetPlatformOrderId(AppId, (int)SourceOrderId.Value);
            }
            else
            {
                SourceOrderId.Value = null;
            }
            var SourceWorkOrderId = EntityUpdateDto.LatestValues.Find(item => item.Name == "Cancelled" + LiteralConstants.WorkOrderId);

            if (SourceWorkOrderId != null && SourceWorkOrderId.Value!=null)
            {
                SourceWorkOrderId.Value = GetPlatformWorkOrderId(AppId, (int)SourceWorkOrderId.Value);
            }
            else
            {
                SourceWorkOrderId.Value = null;
            }

            if (SourceLoanId.Value == null && SourceOrderId.Value == null && SourceWorkOrderId.Value == null)
                throw new FSBusinessException("Cancellation Entity needs to have associated LoanId or OrderId or WorkOrderId");
        }
    }
}
