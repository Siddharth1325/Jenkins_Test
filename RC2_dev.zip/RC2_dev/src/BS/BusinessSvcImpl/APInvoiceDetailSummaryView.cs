﻿using System;
using System.Collections.Generic;
using System.Linq;
using CommonLib.DataObjects;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using CommonLib.ModelAttrib;

namespace BusinessSvcImpl.DataObjects.SpaAccounting.Dto
{
    [DataContract(Namespace = "http://www.bkfs.com/FS/DataContract/Accounting/1.00")]
    [Serializable]
    [AutoGenMap]
    [KnownTypeAttribute(typeof(BaseDto))]
    public partial class APInvoiceDetailSummaryView : BaseDto
    {
        [DataMember]
        public int? VendorId { get; set; }

        [DataMember]
        public string VendorName { get; set; }

        [DataMember]
        public string InvoiceNumber { get; set; }
        [DataMember]
        public DateTime InvoiceDate { get; set; }

        [DataMember]
        public decimal InvoiceAmount { get; set; }

        [DataMember]
        public DateTime? CheckDate { get; set; }

        [DataMember]
        public string CheckNumber { get; set; }

        [DataMember]
        public decimal PaidAmount { get; set; }

        [DataMember]
        public int? OrdinanceProfileId { get; set; }      

        [DataMember]
        public int? VendorWorkOrderId { get; set; }
    }
}
