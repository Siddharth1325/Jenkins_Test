﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Reflection;
using DomainModel.Accounting;
using BusinessSvcImpl.DataObjects.SpaAccountingService.Dto;

namespace BusinessSvcImpl.Utilities
{
    public static class MapToModel
    {
        //public static Type MapDictionaryToModel(Dictionary<string, string> mappingKeys, string formName, QuestionAnswers[] data,ref object instance)
        //{
        //    Type instanceType=null;
        //    if (instance == null)
        //    {
        //        instanceType = typeof(bool);
        //        instance = false;
        //    } else instanceType = instance.GetType();

        //    if (data != null && data.ToList().Count > 0)
        //    {
        //        var groupedAnswers = from ans in data
        //                              group ans by new { ans.QId }
        //                                  into g
        //                                  select new { Question = g.Key, Answers = g };


        //       //  = getMappingKeys(formName);

        //        if (instanceType == typeof(bool))
        //        {
        //            instanceType = getFormIntanceType(formName);
        //            if (instanceType != null)
        //                instance = Activator.CreateInstance(instanceType);
        //        }                   

        //        if (instanceType != null)
        //        {
        //            foreach (var item in groupedAnswers)
        //            {
        //                string[] question = item.Question.QId.Split(new Char[] { '_' });
        //                doMapping(mappingKeys, instance, question[0], item.Answers.ToList());
        //            }
        //        }

        //    }
        //    return instanceType;
        //}


        //private static void doMapping(Dictionary<string, string> mappingKeys, object instance, string key, List<QuestionAnswers> answers=null, string parentQId=null)
        //{
        //    if (mappingKeys.ContainsKey(key))
        //    {
        //        string mapVal = mappingKeys[key];
        //        string[] propTypeName = mapVal.Split(new Char[] { '/' });
        //        if (!String.IsNullOrWhiteSpace(propTypeName[0]))
        //        {
        //            if (propTypeName[0] == "QuestionIdToProperty") //Map QuestionID to Property
        //            {
        //                if (propTypeName.Length > 1 && !String.IsNullOrWhiteSpace(propTypeName[1]))
        //                    SetPropValue(instance, propTypeName[1], key);
        //                if (answers != null)
        //                    foreach (var ans in answers)
        //                    {
        //                        doMapping(mappingKeys, instance, ans.Ans, null, key); // do mapping of answers
        //                    }
        //            }
        //            if (propTypeName[0] == "AnswerToProperty")//Map Answer of QuestionID to Property
        //            {
        //                SetPropValue(instance, propTypeName[1], answers.First().Ans);
        //            }
        //            if (propTypeName[0] == "AnswerIdToProperty") //Map AnswerID to Property
        //            {
        //                SetPropValue(instance, propTypeName[1], key);
        //            }
        //            if (propTypeName[0] == "MemberOfProperty") //Map Answers to List<T> --> if multiple choises for same question
        //            {

        //                string[] columns = propTypeName[2].Split(new Char[] { '-' });

        //                PropertyInfo propertyInfo = instance.GetType().GetProperty(propTypeName[1]);

        //                object property = propertyInfo.GetValue(instance, null);
        //                Type elementType = propertyInfo.PropertyType.GetGenericArguments()[0];

        //                if (property == null)
        //                {
        //                    Type listType = typeof(List<>).MakeGenericType(new Type[] { elementType });
        //                    property = Activator.CreateInstance(listType);
        //                    propertyInfo.SetValue(instance, property, null);
        //                }


        //                object element = Activator.CreateInstance(elementType);

        //                SetPropValue(element, columns[0], parentQId);
        //                SetPropValue(element, columns[1], key);

        //                SetPropValue(element, "CreatedById", "7");
        //                SetPropValue(element, "CreatedDate", DateTime.Now.ToString());

        //                property.GetType().GetMethod("Add").Invoke(property, new[] { element });


        //            }

        //        }

        //    }
        //    else {
        //        if (answers != null)
        //            foreach (var ans in answers)
        //            {
        //                doMapping(mappingKeys, instance, ans.Ans); // do mapping of answers
        //            }
        //    }
        //}
        //private static void SetPropValue(object src, string propName, string value)
        //{

        //    try
        //    {
        //        PropertyInfo propertyInfo = src.GetType().GetProperty(propName);
        //        if (propertyInfo != null &&
        //            (propertyInfo.PropertyType.IsPrimitive ||
        //            propertyInfo.PropertyType == typeof(Decimal) ||
        //            propertyInfo.PropertyType == typeof(String))
        //            )
        //        {
        //            propertyInfo.SetValue(src, Convert.ChangeType(value, propertyInfo.PropertyType), null);
        //        }
        //        else
        //        {
        //            Type t = Nullable.GetUnderlyingType(propertyInfo.PropertyType) ?? propertyInfo.PropertyType;
        //            object safeValue = (value == null) ? null
        //                               : Convert.ChangeType(value, t);

        //            propertyInfo.SetValue(src, safeValue, null);
        //        }

        //    }
        //    catch{
        //    }
        //}

        //private static Type getFormIntanceType(string formName) { //TODO: Retrieve this from some kind of repository
        //    Type returnType=null;

        //    //  returnType = Type.GetType("DomainModel.Common.SpaAccRsltWorkNotPerformed");
        //    switch(formName){
        //        case "WNP":
        //            returnType = typeof(DomainModel.SpaAccResult.SpaAccRsltWorkNotPerformed);
        //            break;
        //        case "NI":
        //            returnType = typeof(DomainModel.SpaAccResult.SpaAccRsltNeighborhood);
        //            break;
        //        case "GI":
        //            returnType = typeof(DomainModel.SpaAccResult.SpaAccRsltGeneral);
        //            break;
        //        case "PS":
        //            returnType = typeof(DomainModel.SpaAccResult.SpaAccRsltPoolAndSpa);
        //            break;
        //        case "PI":
        //            returnType = typeof(DomainModel.SpaAccResult.SpaAccRsltProperty);
        //            break;
        //        case "UT":
        //            returnType = typeof(DomainModel.SpaAccResult.SpaAccRsltUtility);
        //            break;
        //        case "CV":
        //            returnType = typeof(DomainModel.SpaAccResult.SpaAccRsltCodeViolation);
        //            break;
        //        case "DA":
        //            returnType = typeof(DomainModel.SpaAccResult.SpaAccRsltExteriorDamage);
        //            break;
        //        case "DW":
        //            returnType = typeof(DomainModel.SpaAccResult.SpaAccRsltDwelling);
        //            break;
        //        case "OI":
        //            returnType = typeof(DomainModel.SpaAccResult.SpaAccRsltOccupancy);
        //            break;
        //        case "RS":
        //            returnType = typeof(DomainModel.SpaAccResult.SpaAccRsltService);
        //            break;
        //        case "II":
        //            returnType = typeof(DomainModel.SpaAccResult.SpaAccRsltInteriorInfo);
        //            break;
        //        case "ID":
        //            returnType = typeof(DomainModel.SpaAccResult.SpaAccRsltInteriorDamage);
        //            break;
        //        case "FEMA":
        //            returnType = typeof(DomainModel.SpaAccResult.SpaAccRsltFEMA);
        //            break;
        //        case "IL":
        //            returnType = typeof(DomainModel.SpaAccResult.SpaAccRsltInsuranceLoss);
        //            break;
        //        case "REO":
        //            returnType = typeof(DomainModel.SpaAccResult.SpaAccRsltREO);
        //            break;
        //    }
        //    return returnType;
        //}
        
    }


  
}