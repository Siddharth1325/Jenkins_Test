﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BusinessSvcImpl.DataObjects.SpaAccounting.Dto;
using CommonLib;
using Insp = Inspections.ServiceProxy.InspectionSvc;

namespace BusinessSvcImpl.Utilities
{
    public class BillingOrderMapping
    {
        public Order CopyInspectionOrder(Order platformOrder, Insp.Order inspectionOrder, List<WorkOrderItem> workOrderItemList)
        {
            if (inspectionOrder == null) throw new ArgumentNullException("inspectionOrder");
            if (platformOrder == null) throw new ArgumentNullException("platformOrder");

            Order returnOrder = platformOrder;
            workOrderItemList = new List<WorkOrderItem>();

            returnOrder.AddressLine1 = inspectionOrder.AddressLine1;
            returnOrder.AddressLine2 = inspectionOrder.AddressLine2;
            returnOrder.BorrowerFirstName = inspectionOrder.BorrowerFirstName;
            returnOrder.BorrowerLastName = inspectionOrder.BorrowerLastName;
            returnOrder.BorrowerMiddleInitial = inspectionOrder.BorrowerMiddleInitial;
            returnOrder.CityName = inspectionOrder.CityName;
            returnOrder.CompletedDate = inspectionOrder.CompletedDate;
            returnOrder.CountyName = inspectionOrder.CountyName;
            returnOrder.DepartmentCode = inspectionOrder.DepartmentCode;
            returnOrder.DepartmentType = inspectionOrder.DepartmentType;
            returnOrder.DueToClientDate = inspectionOrder.DueToClientDate;
            returnOrder.HardDelete = inspectionOrder.HardDelete;
            returnOrder.IsDoNotBillClient = inspectionOrder.IsDoNotBillClient;
            returnOrder.IsDoNotConvert = inspectionOrder.IsDoNotConvert;
            returnOrder.IsDoNotPayVendor = inspectionOrder.IsDoNotPayVendor;
            returnOrder.IsFrequent = inspectionOrder.IsFrequent;
            returnOrder.IsInitial = inspectionOrder.IsInitial;
            returnOrder.IsQCOrdered = inspectionOrder.IsqcOrdered;
            returnOrder.IsRushOrder = inspectionOrder.IsRushOrder;
            returnOrder.IsSkipDupChecks = inspectionOrder.IsSkipDupChecks;
            returnOrder.MBACodeGroup = inspectionOrder.MbaCodeGroup;
            returnOrder.MBACodeType = inspectionOrder.MbaCodeType;
            returnOrder.OrderSourceGroup = inspectionOrder.OrderSourceGroup;
            returnOrder.OrderSourceType = inspectionOrder.OrderSourceType;
            returnOrder.OrderStatusGroup = inspectionOrder.OrderStatusGroup;
            returnOrder.OrderStatusType = inspectionOrder.OrderStatusType;
            returnOrder.OrderType = inspectionOrder.OrderType;
            returnOrder.OrderTypeGroup = inspectionOrder.OrderTypeGroup;
            returnOrder.ReceivedDate = inspectionOrder.ReceivedDate;
            returnOrder.RecommendedVendor = inspectionOrder.RecommendedVendor;
            returnOrder.RequestedDate = inspectionOrder.RequestedDate;
            returnOrder.SpecialInstructions = inspectionOrder.SpecialInstructions;
            returnOrder.StateCode = inspectionOrder.StateCode;
            returnOrder.TransmittedDate = inspectionOrder.TransmittedDate;
            returnOrder.ZipCode = inspectionOrder.ZipCode;
            returnOrder.ZipPlusFour = inspectionOrder.ZipPlusFour;

            if(inspectionOrder.Loan != null)
                returnOrder.Loan = CopyInspectionLoan(platformOrder.Loan, inspectionOrder.Loan);

            if (inspectionOrder.WorkOrderItems != null && inspectionOrder.WorkOrderItems.Count > 0)
            {
                List<WorkOrderItem> platformWorkOrderItemList = new List<WorkOrderItem>();
                foreach (WorkOrder workOrder in platformOrder.WorkOrders)
                {
                    platformWorkOrderItemList.AddRange(workOrder.WorkOrderItems);
                }
                foreach (Insp.WorkOrderItem inspectionWorkOrderItem in inspectionOrder.WorkOrderItems)
                {
                    WorkOrderItem platformWorkOrderItem = platformWorkOrderItemList.Where(x => x.SourceWorkOrderItemId == inspectionWorkOrderItem.WorkOrderItemId).FirstOrDefault();
                    if (platformWorkOrderItem == null)
                    {
                        Logging.LogWarn(string.Format("Work Order Item with Source Id {0} not found in platform", inspectionWorkOrderItem.WorkOrderItemId));
                        continue;
                    }                    
                    platformWorkOrderItem = CopyInspectionWorkOrderItem(platformWorkOrderItem, inspectionWorkOrderItem);
                    workOrderItemList.Add(platformWorkOrderItem);
                }
            }

            if (inspectionOrder.WorkOrders != null && inspectionOrder.WorkOrders.Count > 0)
            {
                List<WorkOrder> platformWorkOrderList = new List<WorkOrder>();
                foreach (Insp.WorkOrder inspectionWorkOrder in inspectionOrder.WorkOrders)
                {
                    WorkOrder platformWorkOrder = platformOrder.WorkOrders.Where(x => x.SourceWorkOrderId == inspectionWorkOrder.WorkOrderId).FirstOrDefault();
                    if (platformWorkOrder == null)
                    {
                        Logging.LogWarn(string.Format("Work Order with Source Id {0} not found in platform", inspectionWorkOrder.WorkOrderId));
                        continue;                        
                    }

                    platformWorkOrder = CopyInspectionWorkOrder(platformWorkOrder, inspectionWorkOrder);
                    platformWorkOrderList.Add(platformWorkOrder);
                }
                returnOrder.WorkOrders = platformWorkOrderList;
            }

            if (inspectionOrder.Cancellations != null && inspectionOrder.Cancellations.Count > 0)
            {
                List<Cancellation> platformCancellationList = new List<Cancellation>();
                foreach (Insp.Cancellation inspectionCancellation in inspectionOrder.Cancellations)
                {
                    Cancellation platformCancellation = platformOrder.Cancellations.Where(x => x.SourceCancellationId == inspectionCancellation.CancellationId).FirstOrDefault();
                    if (platformCancellation == null)
                    {
                        Logging.LogWarn(string.Format("Cancellation with Source Id {0} not found in platform", inspectionCancellation.CancellationId));
                        continue;                        
                    }

                    platformCancellation = CopyInspectionCancellation(platformCancellation, inspectionCancellation);
                    platformCancellationList.Add(platformCancellation);
                }
                returnOrder.Cancellations = platformCancellationList;
            }
            return returnOrder;
        }

        public Loan CopyInspectionLoan(Loan platformLoan, Insp.Loan inspectionLoan)
        {
            if (inspectionLoan == null) throw new ArgumentNullException("inspectionLoan");
            if (platformLoan == null) throw new ArgumentNullException("platformLoan");
            platformLoan.AlternatePhone = inspectionLoan.AlternatePhone;
            platformLoan.AlternatePhoneTypeGroup = inspectionLoan.AlternatePhoneTypeGroup;
            platformLoan.AlternatePhoneType = inspectionLoan.AlternatePhoneType;
            platformLoan.BillMortgagor = inspectionLoan.BillMortgagor;
            platformLoan.BorrowerFirstName = inspectionLoan.BorrowerFirstName;
            platformLoan.BorrowerLastName = inspectionLoan.BorrowerLastName;
            platformLoan.BorrowerMiddleInitial = inspectionLoan.BorrowerMiddleInitial;
            platformLoan.CeaseAndDesistDate = inspectionLoan.CeaseAndDesistDate;
            platformLoan.CeaseAndDesistReason = inspectionLoan.CeaseAndDesistReason;
            platformLoan.CodeViolationDate = inspectionLoan.CodeViolationDate;
            platformLoan.DepartmentType = inspectionLoan.DepartmentType;
            platformLoan.DepartmentTypeGroup = inspectionLoan.DepartmentTypeGroup;
            platformLoan.DoorKeyCode = inspectionLoan.DoorKeyCode;
            platformLoan.EligibleOccupancyType = inspectionLoan.EligibleOccupancyType;
            platformLoan.ExtensionApprovedDate = inspectionLoan.ExtensionApprovedDate;
            platformLoan.FirstTimePartialVacantDate = inspectionLoan.FirstTimePartialVacantDate;
            platformLoan.FirstTimeVacantDate = inspectionLoan.FirstTimeVacantDate;
            platformLoan.GuarantorCaseNumber = inspectionLoan.GuarantorCaseNumber;
            platformLoan.HardDelete = inspectionLoan.HardDelete;
            platformLoan.InitialSecureDate = inspectionLoan.InitialSecureDate;
            platformLoan.InspectionFreqType = inspectionLoan.InspectionFreqType;
            platformLoan.InvestorCode = inspectionLoan.InvestorCode;
            platformLoan.InvestorIdentifier = inspectionLoan.InvestorIdentifier;
            platformLoan.InvestorName = inspectionLoan.InvestorName;
            platformLoan.IsAssetLoan = inspectionLoan.IsAssetLoan;
            platformLoan.IsBadAddress = inspectionLoan.IsBadAddress;
            platformLoan.IsCeaseAndDesist = inspectionLoan.IsCeaseAndDesist;
            platformLoan.IsNonStandardFrequent = inspectionLoan.IsNonStandardFrequent;
            platformLoan.LastGrassCutDate = inspectionLoan.LastGrassCutDate;
            platformLoan.LastOccupancyDate = inspectionLoan.LastOccupancyDate;
            platformLoan.LastPartialVacantDate = inspectionLoan.LastPartialVacantDate;
            platformLoan.LastVacantDate = inspectionLoan.LastVacantDate;
            platformLoan.LoanNumber = inspectionLoan.LoanNumber;
            platformLoan.LoanStatus = inspectionLoan.LoanStatus;
            platformLoan.LoanType = inspectionLoan.LoanType;
            platformLoan.LockBoxCode = inspectionLoan.LockBoxCode;
            platformLoan.LowType = inspectionLoan.LowType;
            platformLoan.MailAddress1 = inspectionLoan.MailAddress1;
            platformLoan.MailAddress2 = inspectionLoan.MailAddress2;
            platformLoan.MailCityName = inspectionLoan.MailCityName;
            platformLoan.MailStateCode = inspectionLoan.MailStateCode;
            platformLoan.MailZipCode = inspectionLoan.MailZipCode;
            platformLoan.MortgageDueDate = inspectionLoan.MortgageDueDate;
            platformLoan.NonStandardFreqReason = inspectionLoan.NonStandardFreqReason;
            platformLoan.OccupancyStatusGroup = inspectionLoan.OccupancyStatusGroup;
            platformLoan.OccupancyStatusType = inspectionLoan.OccupancyStatusType;
            platformLoan.OutstandingBalance = inspectionLoan.OutstandingBalance;
            platformLoan.PrimaryPhone = inspectionLoan.PrimaryPhone;
            platformLoan.PrimaryPhoneType = inspectionLoan.PrimaryPhoneType;
            platformLoan.PrimaryPhoneTypeGroup = inspectionLoan.PrimaryPhoneTypeGroup;
            platformLoan.PropAddress1 = inspectionLoan.PropAddress1;
            platformLoan.PropAddress2 = inspectionLoan.PropAddress2;
            platformLoan.PropCityName = inspectionLoan.PropCityName;
            platformLoan.PropCountyName = inspectionLoan.PropCountyName;
            platformLoan.PropStateCode = inspectionLoan.PropStateCode;
            platformLoan.PropZipCode = inspectionLoan.PropZipCode;
            platformLoan.RedemptionConfirmDate = inspectionLoan.RedemptionConfirmDate;
            platformLoan.SourceLoanId = inspectionLoan.LoanId;
            platformLoan.SubClientProfileId = inspectionLoan.SubClientProfileId;
            platformLoan.ValidAddress1 = inspectionLoan.ValidAddress1;
            platformLoan.ValidAddress2 = inspectionLoan.ValidAddress2;
            platformLoan.ValidCityName = inspectionLoan.ValidCityName;
            platformLoan.ValidCountyName = inspectionLoan.ValidCountyName;
            platformLoan.ValidLatitude = inspectionLoan.ValidLatitude;
            platformLoan.ValidLongitude = inspectionLoan.ValidLongitude;
            platformLoan.ValidStateCode = inspectionLoan.ValidStateCode;
            platformLoan.ValidZipCode = inspectionLoan.ValidZipCode;
            platformLoan.ValidZipPlusFour = inspectionLoan.ValidZipPlusFour;
            platformLoan.WinterizationDate = inspectionLoan.WinterizationDate;
            //platformLoan.LastSubscriptionUpdateDate = inspectionLoan.LastSubscriptionUpdateDate;
            platformLoan.Municipality = inspectionLoan.Municipality;
            platformLoan.MunicipalityZipCode = inspectionLoan.MunicipalityZipCode;
            //platformLoan.OrdinanceProfileId = inspectionLoan.OrdinanceProfileId;
            //platformLoan.ChargeOffDate = inspectionLoan.ChargeOffDate;
            //platformLoan.IsPropertyForSale = inspectionLoan.IsPropertyForSale;
            //platformLoan.SaleByGroup = inspectionLoan.SaleByGroup;
            //platformLoan.SaleBYType = inspectionLoan.SaleBYType;
            //platformLoan.IsPropertyForRent = inspectionLoan.IsPropertyForRent;
            //platformLoan.RentByGroup = inspectionLoan.RentByGroup;
            //platformLoan.RentByType = inspectionLoan.RentByType;
            //platformLoan.IsPoolSecuredGroup = inspectionLoan.IsPoolSecuredGroup;
            //platformLoan.IsPoolSecuredType = inspectionLoan.IsPoolSecuredType;
            //platformLoan.ClientSystemLoanType = inspectionLoan.ClientSystemLoanType;
            //platformLoan.ClientSystemInvestor = this.ClientSystemInvestor;
            platformLoan.TaxId = inspectionLoan.TaxId;
            platformLoan.InitialRegistrationDue = inspectionLoan.InitialRegistrationDue;
            platformLoan.RenewalDate = inspectionLoan.RenewalDate;
            platformLoan.LastRenewal = inspectionLoan.LastRenewal;
            platformLoan.OnlineRegistration = inspectionLoan.OnlineRegistration;
            //platformLoan.ComplianCeWIndow = inspectionLoan.ComplianCeWIndow;
            platformLoan.ComplianceNotes = inspectionLoan.ComplianceNotes;
            platformLoan.RenewalType = inspectionLoan.RenewalType;
            platformLoan.VPRStatus = inspectionLoan.VPRStatus;
            //platformLoan.VPRAttorneyId = inspectionLoan.VPRAttorneyId;
            platformLoan.LegalDescription = inspectionLoan.LegalDescription;
            //platformLoan.ARTNotes = inspectionLoan.ARTNotes;
            //platformLoan.VerifyLocationNotes = inspectionLoan.VerifyLocationNotes;
            //platformLoan.VerifyLocationAt = inspectionLoan.VerifyLocationAt;
            platformLoan.LastWOOccupancyStatusType = inspectionLoan.LastWOOccupancyStatusType;
            //platformLoan.DueforRenewalDate = inspectionLoan.DueforRenewalDate;
            platformLoan.DamageReviewAmount = inspectionLoan.DamageReviewAmount;
            return platformLoan;
        }

        public WorkOrder CopyInspectionWorkOrder(WorkOrder platformWorkOrder, Insp.WorkOrder inspectionWorkOrder)
        {
            if (inspectionWorkOrder == null) throw new ArgumentNullException("inspectionWorkOrder");
            if (platformWorkOrder == null) throw new ArgumentNullException("platformWorkOrder");
            platformWorkOrder.AcctProcessedDate = inspectionWorkOrder.AcctProcessedDate;
            platformWorkOrder.AddressLine1 = inspectionWorkOrder.AddressLine1;
            platformWorkOrder.AddressLine2 = inspectionWorkOrder.AddressLine2;
            platformWorkOrder.AssignedDate = inspectionWorkOrder.AssignedDate;
            platformWorkOrder.AssignedVendorId = inspectionWorkOrder.AssignedVendorId;
            platformWorkOrder.BorrowerFirstName = inspectionWorkOrder.BorrowerFirstName;
            platformWorkOrder.BorrowerLastName = inspectionWorkOrder.BorrowerLastName;
            platformWorkOrder.BorrowerMiddleInitial = inspectionWorkOrder.BorrowerMiddleInitial;
            platformWorkOrder.CancellationReasonGroup = inspectionWorkOrder.CancellationReasonGroup;
            platformWorkOrder.CancellationReasonType = inspectionWorkOrder.CancellationReasonType;
            platformWorkOrder.CityName = inspectionWorkOrder.CityName;
            platformWorkOrder.CompletedDate = inspectionWorkOrder.CompletedDate;
            platformWorkOrder.CountyName = inspectionWorkOrder.CountyName;
            platformWorkOrder.DoorCardMessageText = inspectionWorkOrder.DoorCardMessageText;
            platformWorkOrder.DoorCardType = inspectionWorkOrder.DoorCardType;
            platformWorkOrder.DueFromVendorDate = inspectionWorkOrder.DueFromVendorDate;
            platformWorkOrder.DueToClientDate = inspectionWorkOrder.DueToClientDate;
            platformWorkOrder.HardDelete = inspectionWorkOrder.HardDelete;
            platformWorkOrder.InspectorUniqueId = inspectionWorkOrder.InspectorUniqueId;
            platformWorkOrder.InvoiceDate = inspectionWorkOrder.InvoiceDate;
            platformWorkOrder.IsBillClient = inspectionWorkOrder.IsBillClient;
            platformWorkOrder.IsCountedTowardScore = inspectionWorkOrder.IsCountedTowardScore;
            platformWorkOrder.IsRushOrder = inspectionWorkOrder.IsRushOrder;
            platformWorkOrder.OrigVendorDueDate = inspectionWorkOrder.OrigVendorDueDate;
            platformWorkOrder.PayVendorGroup = inspectionWorkOrder.PayVendorGroup;
            platformWorkOrder.PayVendorType = inspectionWorkOrder.PayVendorType;
            platformWorkOrder.RequestedDate = inspectionWorkOrder.RequestedDate;
            platformWorkOrder.SpecialInstructions = inspectionWorkOrder.SpecialInstructions;
            platformWorkOrder.StateCode = inspectionWorkOrder.StateCode;
            platformWorkOrder.TotalAmountDue = inspectionWorkOrder.TotalAmountDue;
            platformWorkOrder.TransmittedDate = inspectionWorkOrder.TransmittedDate;
            platformWorkOrder.WindowEndDate = inspectionWorkOrder.WindowEndDate;
            platformWorkOrder.WindowStartDate = inspectionWorkOrder.WindowStartDate;
            platformWorkOrder.WorkOrderStatusGroup = inspectionWorkOrder.WorkOrderStatusGroup;
            platformWorkOrder.WorkOrderStatusType = inspectionWorkOrder.WorkOrderStatusType;
            platformWorkOrder.ZipCode = inspectionWorkOrder.ZipCode;
            platformWorkOrder.ZipPlusFour = inspectionWorkOrder.ZipPlusFour;
            platformWorkOrder.InspectionDate1 = inspectionWorkOrder.InspectionDate1;
            platformWorkOrder.InspectionDate2 = inspectionWorkOrder.InspectionDate2;
            platformWorkOrder.InspectionDate3 = inspectionWorkOrder.InspectionDate3;
            platformWorkOrder.IsWorkPerformed = inspectionWorkOrder.IsWorkPerformed;
            platformWorkOrder.SubmissionDate = inspectionWorkOrder.SubmissionDate;
            platformWorkOrder.AccessDeniedType = inspectionWorkOrder.AccessDeniedType;
            platformWorkOrder.BadAddrGroupCode = inspectionWorkOrder.BadAddrGroupCode;
            platformWorkOrder.OrdinanceProfileId = inspectionWorkOrder.OrdinanceProfileId;

            return platformWorkOrder;
        }

        public WorkOrderItem CopyInspectionWorkOrderItem(WorkOrderItem platformWorkOrderItem, Insp.WorkOrderItem inspectionWorkOrderItem)
        {
            if (inspectionWorkOrderItem == null) throw new ArgumentNullException("inspectionWorkOrderItem");
            if (platformWorkOrderItem == null) throw new ArgumentNullException("platformWorkOrderItem");
            platformWorkOrderItem.AdjustedDueDate = inspectionWorkOrderItem.AdjustedDueDate;
            platformWorkOrderItem.CompletedDate = inspectionWorkOrderItem.CompletedDate;
            platformWorkOrderItem.DueFromVendorDate = inspectionWorkOrderItem.DueFromVendorDate;
            platformWorkOrderItem.DueToClientDate = inspectionWorkOrderItem.DueToClientDate;
            platformWorkOrderItem.HardDelete = inspectionWorkOrderItem.HardDelete;
            platformWorkOrderItem.ServiceId = inspectionWorkOrderItem.ServiceId;
            platformWorkOrderItem.WorkOrderItemStatusType = inspectionWorkOrderItem.WorkOrderItemStatusType;

            return platformWorkOrderItem;
        }

        public Cancellation CopyInspectionCancellation(Cancellation platformCancellation, Insp.Cancellation inspectionCancellation)
        {
            if (inspectionCancellation == null) throw new ArgumentNullException("inspectionCancellation");
            if (platformCancellation == null) throw new ArgumentNullException("platformCancellation");
            platformCancellation.CancellationComments = inspectionCancellation.CancellationComments;
            platformCancellation.CancellationDate = inspectionCancellation.CancellationDate;
            platformCancellation.CancellationReasonGroup = inspectionCancellation.CancellationReasonGroup;
            platformCancellation.CancellationReasonType = inspectionCancellation.CancellationReasonType;
            platformCancellation.HardDelete = inspectionCancellation.HardDelete;

            return platformCancellation;
        }
    }
}
