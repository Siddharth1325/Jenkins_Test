﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Crsf.Core;
using Crsf.Core.Interface;
using Crsf.Core.Service;
using InRule.Common.Exceptions;
using ServiceLink.Billing.Definition;
using ServiceLink.Billing.Configuration;
using BRM = ServiceLink.Billing.RuleModel;

namespace ServiceLink.Billing.Implementation
{
    public sealed class BillingStepFactory
    {
        private BillingStepFactory() { }

        public static Collection<IBillingStep> GetBillingSteps(BillingEngineConfig bec, IBillingEngine billingEngine)
        {
            if (bec == null) throw new ArgumentNullException("bec");
            if (billingEngine == null || billingEngine.BillingContext == null) throw new ArgumentNullException("billingEngine");
            if (string.Compare(bec.Id, billingEngine.Id, true) != 0 || string.Compare(bec.ApplicationName, billingEngine.ApplicationName, true) != 0 || Type.GetType(bec.EngineType) != billingEngine.GetType())
                throw new ArgumentOutOfRangeException("billingEngine", "billingEngine doesn't match the intended configuration");

            BRM.BillingEngine engineEntity = new BRM.BillingEngine();
            engineEntity.BillingSteps = new List<BRM.BillingStep>();
            engineEntity.Id = billingEngine.Id;
            engineEntity.ApplicationName = billingEngine.ApplicationName;

            BRM.BillingContext contextEntity = new BRM.BillingContext();
            contextEntity.ContextDataXml = BRM.RuleModelUtil.SerializeRuleModelToXml(Type.GetType(bec.BillingContext.ContextDataSetting.DataType), billingEngine.BillingContext.ContextData);
            engineEntity.BillingContext = contextEntity;

            engineEntity.BillingSteps = new List<BRM.BillingStep>();

            string[] stepIds = new BillingStepRuleSvc().SetBillingEngineSteps(engineEntity);
            Collection<IBillingStep> billingSteps = new Collection<IBillingStep>();
            foreach(string stepId in stepIds)
            {
                BillingStepConfig bsc = bec.BillingSteps.Where(p => string.Compare(stepId, p.Id, true) == 0).FirstOrDefault();
                if (bsc == null) throw new RuleException(string.Format("Step with Id of \"{0}\" is not found in billing engine \"{1}\" configuration. Please check rule set {2} against billing engine step configuration",
                                                         stepId, bec.Id, BillingStepRuleSvc.RuleSetName));
                IBillingStep step = Activator.CreateInstance(Type.GetType(bsc.StepType), billingEngine.BillingContext) as IBillingStep;
                billingSteps.Add(step);
            }

            return billingSteps;
        }
    }

    public class BillingStepRuleSvc : BusinessRuleServiceBase
    {
        public const string RuleEntityName = "BillingEngine";
        public const string RuleGroupName = "ServiceLinkBillingEngineStepRule";
        public const string RuleSetName = "BillingEngineStepRules";

        [BusinessRuleMethod(Entity = BillingStepRuleSvc.RuleEntityName, RuleGroup = BillingStepRuleSvc.RuleGroupName, RuleSet = BillingStepRuleSvc.RuleSetName)]
        public string[] SetBillingEngineSteps(BRM.BillingEngine engineEntity)
        {
            if (engineEntity == null) throw new ArgumentNullException("engineEntity");

            IBusinessRuleResponse ruleResp = base.ExecuteRule(engineEntity);

            if (ruleResp.ResponseMetadata != null && ruleResp.ResponseMetadata.Any(md => md.DataType == BusinessRuleResultMetadataType.ERROR || md.DataType == BusinessRuleResultMetadataType.VALIDATION))
            {
                StringBuilder sb = new StringBuilder();
                foreach (var error in ruleResp.ResponseMetadata.Where(md => md.DataType == BusinessRuleResultMetadataType.ERROR || md.DataType == BusinessRuleResultMetadataType.VALIDATION))
                {
                    sb.Append(error.Message).Append("\n");
                }
                throw new RuleException(sb.ToString());
            }
            else
            {
                BRM.BillingEngine billingEngineUpdated = ruleResp.EntityState as BRM.BillingEngine;
                if(billingEngineUpdated == null || billingEngineUpdated.BillingSteps == null || billingEngineUpdated.BillingSteps.Count == 0)
                    throw new RuleException(string.Format("Rule application {0} failed to set any billing step in rule set {1} on entity {2}", BillingStepRuleSvc.RuleGroupName, BillingStepRuleSvc.RuleSetName, BillingStepRuleSvc.RuleEntityName));
                return (ruleResp.EntityState as BRM.BillingEngine).BillingSteps.OrderBy(p => p.Sequence).ToList().Select(p => p.Id).ToArray();                    
            }

        }
    }
}
