﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CommonLib.Context;
using ServiceLink.Billing.Configuration;
using ServiceLink.Billing.Definition;

namespace ServiceLink.Billing.Implementation
{
    public sealed class BillingEngineFactory
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1026:DefaultParametersShouldNotBeUsed")]
        public static string GetBillingEngineId(string lobName, string applicationName, string productCode = null)
        {
            if(string.IsNullOrWhiteSpace(lobName) || string.IsNullOrWhiteSpace(applicationName))
                return null;
            BillingEngineConfigStore cs = BillingEngineConfigStore.Instance;
            BillingEngineConfig bec = cs.GetBillingEngineConfig(lobName, applicationName, productCode);
            if (bec == null)
                throw new NotSupportedException(string.Format("Billing Engine for {0}-{1}-{2} is not supported", lobName, applicationName, productCode));
            else 
                return bec.Id;
        }
    
        private BillingEngineFactory() { }
        
        public static IBillingEngine GetEngine(string billingEngineId, int workOrderId)
        {
            if (string.IsNullOrEmpty(billingEngineId)) throw new ArgumentNullException("billingEngineId");
            if (workOrderId <= 0) throw new ArgumentOutOfRangeException("workOrderId");

            if(ApplicationContext.Instance == null || ApplicationContext.Instance.UserContext == null || 
                (string.IsNullOrEmpty(ApplicationContext.Instance.UserContext.TenantHierarchyId) || !(ApplicationContext.Instance.UserContext.TenantId.HasValue)))
                throw new BillingException("Application Context missing, or required Tenant Hierarchy Id/ApplicationId missing", BillingExceptionType.SystemFailure);
            
            BillingEngineConfigStore cs = BillingEngineConfigStore.Instance;
            BillingEngineConfig bec = cs.GetBillingEngineConfig(billingEngineId);
            if (bec == null) throw new ConfigurationErrorsException(string.Format("Billing Engine configuration for Billing Engine Id ({0}) can't be found.", billingEngineId));

            Type engineType = Type.GetType(bec.EngineType);
            IBillingEngine engine = Activator.CreateInstance(engineType, bec, workOrderId) as IBillingEngine;
            Collection<IBillingStep> billingSteps = BillingStepFactory.GetBillingSteps(bec, engine);
            foreach(IBillingStep billingStep in billingSteps)
            {
                engine.AddBillingStep(billingStep);
            }

            string engineImplCheckError = null;
            if(CheckEngineImpl(engine, bec, out engineImplCheckError))
                return engine;
            else
                throw new System.Reflection.TargetException(engineImplCheckError);
        }
        public static IBillingEngine GetEngine(string billingEngineId, IList<int> workOrderIds)
        {
            if (string.IsNullOrEmpty(billingEngineId)) throw new ArgumentNullException("billingEngineId");
            if (workOrderIds.Count <= 0) throw new ArgumentOutOfRangeException("workOrderIds");

            if (ApplicationContext.Instance == null || ApplicationContext.Instance.UserContext == null ||
                (string.IsNullOrEmpty(ApplicationContext.Instance.UserContext.TenantHierarchyId) || !(ApplicationContext.Instance.UserContext.TenantId.HasValue)))
                throw new BillingException("Application Context missing, or required Tenant Hierarchy Id/ApplicationId missing", BillingExceptionType.SystemFailure);

            BillingEngineConfigStore cs = BillingEngineConfigStore.Instance;
            BillingEngineConfig bec = cs.GetBillingEngineConfig(billingEngineId);
            if (bec == null) throw new ConfigurationErrorsException(string.Format("Billing Engine configuration for Billing Engine Id ({0}) can't be found.", billingEngineId));

            Type engineType = Type.GetType(bec.EngineType);
            IBillingEngine engine = Activator.CreateInstance(engineType, bec, workOrderIds) as IBillingEngine;
            Collection<IBillingStep> billingSteps = BillingStepFactory.GetBillingSteps(bec, engine);
            foreach (IBillingStep billingStep in billingSteps)
            {
                engine.AddBillingStep(billingStep);
            }

            string engineImplCheckError = null;
            if (CheckEngineImpl(engine, bec, out engineImplCheckError))
                return engine;
            else
                throw new System.Reflection.TargetException(engineImplCheckError);
        }
    
        private static bool CheckEngineImpl(IBillingEngine engine, BillingEngineConfig bec, out string engineImplCheckError)
        {
            engineImplCheckError = null;
            if (string.IsNullOrEmpty(engine.Id))
            {
                engineImplCheckError = string.Format("Billing Engine ({0}) missing [Id] value", engine.GetType().FullName);
                return false;
            }
            else if (string.IsNullOrEmpty(engine.ApplicationName))
            {
                engineImplCheckError = string.Format("Billing Engine ({0}) missing [ApplicationName] value", engine.GetType().FullName);
                return false;
            }
            else if(string.Compare(engine.Id, bec.Id, true) != 0)
            {
                engineImplCheckError = string.Format("Billing Engine ({0}) [Id] value \"{1}\" doesn't match value from configuration \"{2}\" ", engine.GetType().FullName, engine.Id, bec.Id);
                return false;
            }
            else if (string.Compare(engine.ApplicationName, bec.ApplicationName, true) != 0)
            {
                engineImplCheckError = string.Format("Billing Engine ({0}) [ApplicationName] value \"{1}\" doesn't match value from configuration \"{2}\"", engine.GetType().FullName, engine.ApplicationName, bec.ApplicationName);
                return false;
            }
            else if (engine.BillingContext == null)
            {
                engineImplCheckError = string.Format("Billing Engine ({0}) has null Billing Context", engine.GetType().FullName);
                return false;
            }
            else if(engine.BillingSteps == null || engine.BillingSteps.Count == 0)
            {
                engineImplCheckError = string.Format("Billing Engine ({0}) has null Billing Steps", engine.GetType().FullName);
                return false;
            }
            else if(!engine.Validate())
            {
                engineImplCheckError = string.Format("Billing Engine ({0}) Validate() returns false", engine.GetType().FullName);
                return false;
            }

            return true;
        }
    }
}
