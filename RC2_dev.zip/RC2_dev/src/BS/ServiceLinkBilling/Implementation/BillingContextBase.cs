﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ServiceLink.Billing.Definition;
using System.Collections.ObjectModel;

namespace ServiceLink.Billing.Implementation
{
    public abstract class BillingContextBase : IBillingContext
    {
        private Type _ContextDataType = null;
        private Collection<Adjustment> _CostAdjustments = new Collection<Adjustment>();
        private Collection<Adjustment> _PriceAdjustments = new Collection<Adjustment>();
        private Collection<AccountsDetail> _AccountsPayableDetails = new Collection<AccountsDetail>();
        private Collection<AccountsDetail> _AccountsReceivableDetails = new Collection<AccountsDetail>();

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1065:DoNotRaiseExceptionsInUnexpectedLocations")]
        public virtual object ContextData
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        public decimal? BaseCost
        {
            get;
            set;
        }

        public decimal? BasePrice
        {
            get;
            set;
        }

        public string BaseCostSelectionReason
        {
            get;
            set;
        }

        public string BasePriceSelectionReason
        {
            get;
            set;
        }

        public decimal? FinalCost
        {
            get;
            set;
        }

        public decimal? FinalPrice
        {
            get;
            set;
        }

        public Collection<Adjustment> CostAdjustments
        {
            get { return _CostAdjustments; }
        }

        public Collection<Adjustment> PriceAdjustments
        {
            get { return _PriceAdjustments; }
        }

        public decimal APTotalAmountDue
        {
            get;
            set;
        }

        public decimal ARTotalAmountDue
        {
            get;
            set;
        }

        public Collection<AccountsDetail> AccountsPayableDetails
        {
            get { return _AccountsPayableDetails; }
        }
        public Collection<AccountsDetail> AccountsReceivableDetails
        {
            get { return _AccountsReceivableDetails; }
        }

        public decimal PriceTracker
        { 
            get; 
            set; 
        }

        public decimal CostTracker 
        { 
            get; 
            set; 
        }

        public bool Successful
        {
            get;
            set;
        }

        public string FailureReason
        {
            get;
            set;
        }

        public int AccountsPayableId 
        { 
            get; 
            set; 
        }

        public int AccountsReceivableId 
        { 
            get; 
            set; 
        }

        public virtual bool Validate()
        {
            return _ContextDataType != null && ContextData != null && ContextData.GetType() == _ContextDataType;
        }

        public Type ContextDataType
        {
            get { return _ContextDataType; }
            set { _ContextDataType = value; }
        }
    }
}
