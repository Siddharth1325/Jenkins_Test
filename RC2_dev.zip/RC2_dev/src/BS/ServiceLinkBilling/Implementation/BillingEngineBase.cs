﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CommonLib;
using ServiceLink.Billing.Configuration;
using ServiceLink.Billing.Definition;

namespace ServiceLink.Billing.Implementation
{
    public abstract class BillingEngineBase : IBillingEngine
    {
        public const string BillingApplicationName = "Accounting";

        private IBillingContext _BillingContext = null;
        private Collection<IBillingStep> _BillingSteps = new Collection<IBillingStep>();

        protected BillingEngineBase(BillingEngineConfig bec)
        {
            if (bec == null)
                throw new ArgumentNullException("bec");

            _BillingContext = Activator.CreateInstance(Type.GetType(bec.BillingContext.ContextType)) as IBillingContext;
            _BillingContext.ContextDataType = Type.GetType(bec.BillingContext.ContextDataSetting.DataType);
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1065:DoNotRaiseExceptionsInUnexpectedLocations")]
        public virtual string Id
        {
            get
            {
                throw new NotImplementedException();
            }
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1065:DoNotRaiseExceptionsInUnexpectedLocations")]
        public virtual string ApplicationName
        {
            get
            {
                throw new NotImplementedException();
            }
        }

        public IBillingContext BillingContext
        {
            get { return _BillingContext; }
        }

        public Collection<IBillingStep> BillingSteps
        {
            get
            {
                return _BillingSteps;
            }
        }

        public virtual void Init(object billableEntity)
        {
            if (billableEntity == null)
                throw new ArgumentNullException("billableEntity");
            if (_BillingContext.ContextDataType != billableEntity.GetType())
                throw new ArgumentException(string.Format("Billing Context Data Type Mis-Match: {0} set in configuration, but {1} was passed in", 
                                                          _BillingContext.ContextDataType.FullName, billableEntity.GetType().FullName));

            _BillingContext.ContextData = billableEntity;
        }

        public virtual void AddBillingStep(IBillingStep billingStep)
        {
            _BillingSteps.Add(billingStep);
        }

        public virtual bool Validate()
        {
            return this._BillingContext != null && this._BillingContext.Validate();
        }

        public virtual void Execute()
        {
            foreach(IBillingStep step in _BillingSteps)
            {
                step.GetStepOnlyData();
                if (step.Validate())
                {
                    step.ProcessStep();
                    if(!step.BillingContext.Successful)
                    {
                        BillingException be = new BillingException(step.BillingContext.FailureReason, BillingExceptionType.SystemFailure);
                        Logging.LogError(be);
                        throw be;
                    }
                    //else if(step.BillingContext.FinalPrice.HasValue && step.BillingContext.FinalPrice == 0.00m
                    //        && step.BillingContext.FinalCost.HasValue && step.BillingContext.FinalCost.Value == 0.00m)
                    //{
                    //    break;
                    //}
                }
                else
                {
                    BillingException be = new BillingException(string.Format("Billing Step ({0}) validation failed", step.Id), BillingExceptionType.SystemFailure);
                    Logging.LogError(be);
                    throw be;
                }
            }
        }

        public virtual void CreateBillingData()
        {
        }

    }
}
