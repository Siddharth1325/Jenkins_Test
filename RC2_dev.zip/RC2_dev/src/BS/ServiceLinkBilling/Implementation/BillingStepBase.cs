﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ServiceLink.Billing.Definition;

namespace ServiceLink.Billing.Implementation
{
    public abstract class BillingStepBase : IBillingStep
    {
        private IBillingContext _BillingContext = null;

        protected BillingStepBase(IBillingContext billingContext)
        {
            _BillingContext = billingContext;
        }
        
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1065:DoNotRaiseExceptionsInUnexpectedLocations")]
        public virtual string Id
        {
            get { throw new NotImplementedException(); }
        }

        public IBillingContext BillingContext
        {
            get { return _BillingContext; }
        }

        public bool IsCrsfStep
        {
            get;
            set;
        }

        public virtual void GetStepOnlyData()
        {
        }

        public virtual bool Validate()
        {
            return this._BillingContext != null && this._BillingContext.Validate();
        }

        public virtual void ProcessStep()
        {
        }
    }
}
