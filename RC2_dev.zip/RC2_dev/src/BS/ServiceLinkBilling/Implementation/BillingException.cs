﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace ServiceLink.Billing.Implementation
{
    [Serializable]
    public class BillingException : Exception
    {
        private BillingExceptionType _BillingExceptionType;
        public BillingExceptionType BillingExceptionType { get { return _BillingExceptionType; } }

        public BillingException() : base() { }

        public BillingException(string message) : base(message) { }

        public BillingException(string message, Exception innerException) : base(message, innerException) { }

        public BillingException(string message, BillingExceptionType exceptionType) : base(message) { _BillingExceptionType = exceptionType; }

        protected BillingException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
            this._BillingExceptionType = (BillingExceptionType)Enum.Parse(typeof(BillingExceptionType), info.GetString("BillingExceptionType"));
        }

        public override void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            if (info == null) throw new ArgumentNullException("info");
            info.AddValue("BillingExceptionType", this._BillingExceptionType.ToString());
            base.GetObjectData(info, context);
        }
    }

    [Serializable]
    public enum BillingExceptionType
    {
        DataIssue,
        SystemFailure,
        Unknown
    }
}