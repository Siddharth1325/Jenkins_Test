﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;

namespace ServiceLink.Billing.Configuration
{
    [XmlRoot(ElementName = "BillingEngine", Namespace = BillingEngineConfigStore.ConfigSchema, IsNullable = false)]
    public class BillingEngineConfig
    {
        [XmlAttribute(AttributeName = "Id")]
        public string Id { get; set; }

        [XmlAttribute(AttributeName = "LineOfBusinessName")]
        public string LineOfBusinessName { get; set; }

        [XmlAttribute(AttributeName = "ApplicationName")]
        public string ApplicationName { get; set; }

        [XmlAttribute(AttributeName="ProductCodes")]
        public string ProductCodes { get; set; }

        [XmlElement(ElementName = "AssemblyName", IsNullable = false)]
        public string AssemblyName { get; set; }

        [XmlElement(ElementName = "EngineType", IsNullable = false)]
        public string EngineType { get; set; }

        [XmlElement(ElementName = "BillingContext", IsNullable = false)]
        public BillingContextConfig BillingContext { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1819:PropertiesShouldNotReturnArrays")]
        [XmlArray(ElementName = "BillingSteps", IsNullable = false)]
        [XmlArrayItem(ElementName = "BillingStep", IsNullable = false)]
        public BillingStepConfig[] BillingSteps { get; set; }
    }

    public class BillingContextConfig
    {
        [XmlElement(ElementName = "AssemblyName", IsNullable = false)]
        public string AssemblyName { get; set; }

        [XmlElement(ElementName = "ContextType", IsNullable = false)]
        public string ContextType { get; set; }

        [XmlElement("ContextDataSetting")]
        public ContextDataSettingConfig ContextDataSetting { get; set; }
    }

    public class BillingStepConfig
    {
        [XmlAttribute(AttributeName = "Id")]
        public string Id { get; set; }

        [XmlAttribute(AttributeName = "IsCrsfStep")]
        public bool IsCrsfStep { get; set; }

        [XmlElement(ElementName = "AssemblyName", IsNullable = false)]
        public string AssemblyName { get; set; }

        [XmlElement(ElementName = "StepType", IsNullable = false)]
        public string StepType { get; set; }
    }

    public class ContextDataSettingConfig
    {
        [XmlElement(ElementName = "AssemblyName", IsNullable = false)]
        public string AssemblyName { get; set; }

        [XmlElement(ElementName = "DataType", IsNullable = false)]
        public string DataType { get; set; }
    }
}
