﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Linq;
using System.Xml.Schema;
using System.Xml.Serialization;
using System.Threading.Tasks;

namespace ServiceLink.Billing.Configuration
{
    public sealed class ConfigXmlUtil
    {
        private ConfigXmlUtil() { }

        #region ValidateConfigFile
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1021:AvoidOutParameters", MessageId = "3#")]
        public static bool ValidateConfigFile(string filePath, string schemaName, string schemaDocPath, out string validationError)
        {
            bool isValid = true;
            XmlSchemaSet schemas = new XmlSchemaSet();            
            schemas.Add(schemaName, schemaDocPath);
            XDocument configXml = XDocument.Load(filePath);
            StringBuilder sb = new StringBuilder();
            configXml.Validate(schemas, (o, e) =>
            {
                sb.Append(e.Message).Append("\n");
                isValid = false;
            });
            validationError = isValid ? null : sb.ToString();
            return isValid;
        }
        #endregion

        #region ParseBillingEngineConfig
        public static BillingEngineConfig ParseBillingEngineConfig(string configFilePath)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(BillingEngineConfig));
            serializer.UnknownNode += new XmlNodeEventHandler(serializer_UnknownNode);
            serializer.UnknownAttribute += new XmlAttributeEventHandler(serializer_UnknownAttribute);

            BillingEngineConfig bec = null;
            using (FileStream fs = new FileStream(configFilePath, FileMode.Open, FileAccess.Read))
            {
                bec = (BillingEngineConfig)serializer.Deserialize(fs);
            }                                    

            return bec;
        }

        private static void serializer_UnknownNode(object sender, XmlNodeEventArgs e)
        {
            //AssignmentLogger.LogError(string.Format("Unknown Node: {0} \t {1}", e.Name, e.Text));
        }

        private static void serializer_UnknownAttribute(object sender, XmlAttributeEventArgs e)
        {
            //XmlAttribute attr = e.Attr;            
            //AssignmentLogger.LogError(string.Format("Unknown attribute: {0} \t {1}", attr.Name, attr.Value));
        }
        #endregion
    }
}
