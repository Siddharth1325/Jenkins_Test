﻿using System;
using System.Collections.Generic;
using System.Collections.Concurrent;
using System.Configuration;
using System.Reflection;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CommonLib;
using ServiceLink.Billing.Definition;

namespace ServiceLink.Billing.Configuration
{
    public class BillingEngineConfigStore
    {
        public const string ConfigStoreDir = @"../Config";
        public const string HostingDir = @"../Hosting";
        public const string ConfigStoreAppSettingKey = "BillingEngineConfigDir";
        public const string HostingDirectoryAppSettingKey = "BillingEngineHostingDir";
        public const string ConfigSchema = "http://www.bkfs.com/ServiceLink/BillingEngine/1.00";
        public const string SchemaFileName = "BillingEngineConfig.xsd";
        private string _CurrentHostingDir = string.Empty;

        internal static BillingEngineConfigStore Instance = new BillingEngineConfigStore();
        private ConcurrentDictionary<string, BillingEngineConfig> _BillingEngineConfigs = null;

        #region Constructors
        private BillingEngineConfigStore()
        {
            AppDomain.CurrentDomain.AssemblyResolve += CurrentDomain_AssemblyResolve;
            _BillingEngineConfigs = new ConcurrentDictionary<string, BillingEngineConfig>();
            InitConfigStore();
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Reliability", "CA2001:AvoidCallingProblematicMethods", MessageId = "System.Reflection.Assembly.LoadFrom")]
        Assembly CurrentDomain_AssemblyResolve(object sender, ResolveEventArgs args)
        {
            string dllName = args.Name.Split(new[] { ',' })[0] + ".dll";
            return Assembly.LoadFrom(Path.Combine(_CurrentHostingDir, dllName));
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA2204:Literals should be spelled correctly", MessageId = "BillingEngineConfig")]
        private void InitConfigStore()
        {            
            string hostingDir = null;   
            if (System.Web.HttpContext.Current != null)
            {
                hostingDir = System.Web.HttpContext.Current.Server.MapPath(ConfigurationManager.AppSettings[HostingDirectoryAppSettingKey]);
            }
            else
            {
                hostingDir = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, string.IsNullOrEmpty(ConfigurationManager.AppSettings[HostingDirectoryAppSettingKey]) ? HostingDir : ConfigurationManager.AppSettings[HostingDirectoryAppSettingKey]);
            }
            if (!Directory.Exists(hostingDir))
            {
                ConfigurationException cfgex = new ConfigurationErrorsException(string.Format("Billing Engine Hosting folder {0} doesn't exist", hostingDir));
                Logging.LogError(cfgex);
                throw cfgex;
            }

            string configStoreDir = null;          
            if (System.Web.HttpContext.Current != null)
            {
                configStoreDir = System.Web.HttpContext.Current.Server.MapPath(ConfigurationManager.AppSettings[ConfigStoreAppSettingKey]);
            }
            else
            {
                configStoreDir = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, string.IsNullOrEmpty(ConfigurationManager.AppSettings[ConfigStoreAppSettingKey]) ? ConfigStoreDir : ConfigurationManager.AppSettings[ConfigStoreAppSettingKey]);
            }
            if(!Directory.Exists(configStoreDir))
            {
                ConfigurationException cfgex = new ConfigurationErrorsException(string.Format("Billing Engine configuration folder {0} doesn't exist", configStoreDir));
                Logging.LogError(cfgex);
                throw cfgex;
            }
            else if (!File.Exists(configStoreDir + @"/" + SchemaFileName))
            {
                ConfigurationException cfgex = new ConfigurationErrorsException(string.Format("Billing Engine configuration folder {0} doesn't contain configuration schema file ({1})", configStoreDir, SchemaFileName));
                Logging.LogError(cfgex);
                throw cfgex;                
            }

            ProcessBillingEngineConfiguration(configStoreDir, hostingDir);
        }

        private void ProcessBillingEngineConfiguration(string configDir, string hostingDir)
        {
            string[] fileNames = Directory.GetFiles(configDir, "*.xml", SearchOption.TopDirectoryOnly);
            if(fileNames != null && fileNames.Length > 0)
            {
                foreach(string file in fileNames)
                {
                    string error = null;
                    if (!ConfigXmlUtil.ValidateConfigFile(file, ConfigSchema, configDir + @"/" + SchemaFileName, out error))
                    {
                        Logging.LogError(string.Format("{0} is not an valid configuration for Billing Engine: \n{1}", file, error));
                    }
                    else
                    {
                        BillingEngineConfig bec = ConfigXmlUtil.ParseBillingEngineConfig(file);
                        if (bec == null)
                            Logging.LogError(string.Format("{0} or its content can't be parsed thus it is ignored: \n{1}", file, error));
                        else
                        {
                            if (_BillingEngineConfigs.ContainsKey(bec.Id))
                            {
                                ConfigurationException cfgex = new ConfigurationErrorsException(string.Format("Billing Engine configuration folder {0} contains multiple configuration file for same engine id({1})", configDir, bec.Id));
                                Logging.LogError(cfgex);
                                throw cfgex; 
                            }
                            else if (_BillingEngineConfigs.Any(p => CompareBillingEngineConfig(p.Value, bec)))
                            {
                                ConfigurationException cfgex = new ConfigurationErrorsException(
                                    string.Format("Billing Engine configuration folder {0} contains multiple configuration file for same {1}-{2}-{3}", configDir, bec.LineOfBusinessName, bec.ApplicationName, bec.ProductCodes));
                                Logging.LogError(cfgex);
                                throw cfgex; 
                            }
                            if (LoadBillingEningeTypes(hostingDir, bec, out error) && ValidateBillingEngineType(bec, out error))
                                _BillingEngineConfigs[bec.Id] = bec;
                            else
                                Logging.LogError(string.Format("{0} has invalid settings thus it is ignored: \n{1}", file, error));
                        }
                    }
                }
            }
        }

        private bool CompareBillingEngineConfig(BillingEngineConfig bec1, BillingEngineConfig bec2)
        {
            if (bec1 == null && bec2 == null) return true;
            
            if ((bec1 == null && bec2 != null) || (bec1 != null && bec2 == null)) return false;
            
            if (string.Compare(bec1.LineOfBusinessName, bec2.LineOfBusinessName, true) == 0
                && string.Compare(bec1.ApplicationName, bec2.ApplicationName, true) == 0
                 && string.Compare(bec1.ProductCodes, bec2.ProductCodes, true) == 0)
                return true;
            
            if (string.Compare(bec1.LineOfBusinessName, bec2.LineOfBusinessName, true) == 0
                && string.Compare(bec1.ApplicationName, bec2.ApplicationName, true) == 0
                 && string.Compare(bec1.ProductCodes, bec2.ProductCodes, true) != 0)
            {
                if(!string.IsNullOrEmpty(bec1.ProductCodes) && string.IsNullOrEmpty(bec2.ProductCodes)) return false;
                
                if(string.IsNullOrEmpty(bec1.ProductCodes) && !string.IsNullOrEmpty(bec2.ProductCodes)) return false;
                
                string[] prdCodes1 = bec1.ProductCodes.ToUpper().Split(new string[] {",", " "}, StringSplitOptions.RemoveEmptyEntries);
                string[] prdCodes2 = bec2.ProductCodes.ToUpper().Split(new string[] {",", " "}, StringSplitOptions.RemoveEmptyEntries);
                IEnumerable<string> overlapCodes = prdCodes1.Intersect(prdCodes2);
                if (overlapCodes != null && overlapCodes.Count() > 0) return true;
                else return false;
            }

            return false;
        }
        #endregion

        #region LoadBillingEningeTypes
        private bool LoadBillingEningeTypes(string hostingDirectory, BillingEngineConfig bec, out string loadError)
        {
            bool loadSuccess = true;
            loadError = null;

            string targetDir = Path.Combine(hostingDirectory, bec.ApplicationName, bec.Id);
            _CurrentHostingDir = targetDir;
            if(!Directory.Exists(targetDir))
            {
                loadError = string.Format(@"Billing Engine hosting folder {0} doesn't exist for {1}\{2}", hostingDirectory, bec.ApplicationName, bec.Id);
                Logging.LogError(loadError);
                return false;
            }

            try
            {
                Assembly.LoadFrom(Path.Combine(targetDir, bec.AssemblyName));
                Assembly.LoadFrom(Path.Combine(targetDir, bec.BillingContext.AssemblyName));
                Assembly.LoadFrom(Path.Combine(targetDir, bec.BillingContext.ContextDataSetting.AssemblyName));
                foreach(BillingStepConfig bsc in bec.BillingSteps)
                {
                    Assembly.LoadFrom(Path.Combine(targetDir, bsc.AssemblyName));
                }
            }
            catch(Exception ex)
            {
                Logging.LogError(ex);
                loadError = ex.Message;
                loadSuccess = false;
            }

            return loadSuccess;
        }
        #endregion

        #region ValidateBillingEngineType
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1021:AvoidOutParameters", MessageId = "1#")]
        public bool ValidateBillingEngineType(BillingEngineConfig bec, out string validationError)
        {
            if (bec == null)
            {
                validationError = "Can't validate null BillingEngineConfig";
                return false;
            }

            bool isValid = true;
            StringBuilder sb = new StringBuilder();

            isValid &= CheckType(bec.EngineType, typeof(IBillingEngine), sb);
            isValid &= CheckType(bec.BillingContext.ContextType, typeof(IBillingContext), sb);
            foreach (BillingStepConfig bsc in bec.BillingSteps)
            {
                isValid &= CheckType(bsc.StepType, typeof(IBillingStep), sb);
            }

            validationError = isValid ? null : sb.ToString();

            return isValid;
        }

        private bool CheckType(string typeName, Type desiredType, StringBuilder sb)
        {
            bool isValid = true;
            try
            {
                Type t = Type.GetType(typeName, true, false);
                isValid = desiredType.IsInterface ? desiredType.IsAssignableFrom(t) : t == desiredType;

                if (!isValid)
                    sb.Append(string.Format("{0} is not as expected as {1}", t.FullName, desiredType.FullName)).Append("\n");
            }
            catch (TypeLoadException e)
            {
                isValid = false;
                sb.Append(e.Message).Append("\n");
            }
            catch (Exception e)
            {
                isValid = false;
                sb.Append(e.Message).Append("\n");
            }

            return isValid;
        }

        #endregion

        #region GetBillingEngineConfig
        protected internal BillingEngineConfig GetBillingEngineConfig(string billingEngineId)
        {
            if (string.IsNullOrEmpty(billingEngineId))
                throw new ArgumentNullException("billingEngineId");

            return _BillingEngineConfigs.SingleOrDefault(p => string.Compare(p.Key, billingEngineId, true) == 0).Value;
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1026:DefaultParametersShouldNotBeUsed")]
        protected internal BillingEngineConfig GetBillingEngineConfig(string lobName, string applicationName, string productCode = null)
        {
            if (string.IsNullOrEmpty(lobName))
                throw new ArgumentNullException("lobName");
            else if (string.IsNullOrEmpty(applicationName))
                throw new ArgumentNullException("applicationName");

            if (string.IsNullOrEmpty(productCode))
            {
                var becList = _BillingEngineConfigs.Where(p => string.Compare(p.Value.LineOfBusinessName, lobName, true) == 0 
                                                            && string.Compare(p.Value.ApplicationName, applicationName, true) == 0
                                                            && string.IsNullOrEmpty(p.Value.ProductCodes)).ToList();
                if (becList == null || becList.Count == 0 || becList.Count > 1)
                    return null;
                else
                    return becList.First().Value;
            }
            else
            {
                var becList = _BillingEngineConfigs.Where(p => string.Compare(p.Value.LineOfBusinessName, lobName, true) == 0 && string.Compare(p.Value.ApplicationName, applicationName, true) == 0
                        && !string.IsNullOrEmpty(p.Value.ProductCodes)
                        && p.Value.ProductCodes.ToUpper().Split(new string[] { ",", " " }, StringSplitOptions.RemoveEmptyEntries).Contains(productCode.Trim().ToUpper())).ToList();
                Logging.LogInfo(string.Format("GetBillingEngineConfig becList.Count {0}, productCode {1}", becList.Count, productCode));
                if (becList == null || becList.Count == 0)
                {
                    becList = _BillingEngineConfigs.Where(p => string.Compare(p.Value.LineOfBusinessName, lobName, true) == 0 && string.Compare(p.Value.ApplicationName, applicationName, true) == 0).ToList();
                    if (becList == null || becList.Count == 0 || becList.Count > 1)
                        return null;
                    else
                        return becList.First().Value;
                }
                else if (becList.Count > 1)
                    return null;
                else
                {
                    Logging.LogInfo(string.Format("GetBillingEngineConfig becList.First.EngineType {0}", becList.First().Value.EngineType));
                    return becList.First().Value;
                }
            }
        }

        #endregion

        #region GetBillingEngineType
        protected internal Type GetBillingEngineType(string billingEngineId)
        {
            if (string.IsNullOrEmpty(billingEngineId))
                throw new ArgumentNullException("billingEngineId");

            BillingEngineConfig bec = _BillingEngineConfigs.SingleOrDefault(p => string.Compare(p.Key, billingEngineId, true) == 0).Value;
            if (bec == null) throw new ConfigurationErrorsException(string.Format("Billing Engine configuration for Billing Engine Id ({0}) can't be found.", billingEngineId));
            else return Type.GetType(bec.EngineType);
        }
        #endregion

        #region GetAllStepTypesForBillingEngineType
        protected internal Dictionary<string, Type> GetAllStepTypesForBillingEngineType(string billingEngineId)
        {
            if (string.IsNullOrEmpty(billingEngineId))
                throw new ArgumentNullException("billingEngineId");

            BillingEngineConfig bec = _BillingEngineConfigs.SingleOrDefault(p => string.Compare(p.Key, billingEngineId, true) == 0).Value;
            if (bec == null) throw new ConfigurationErrorsException(string.Format("Billing Engine configuration for Billing Engine Id ({0}) can't be found.", billingEngineId));
            else
            {
                Dictionary<string, Type> allSteps = new Dictionary<string, Type>();
                foreach (BillingStepConfig bsc in bec.BillingSteps)
                {
                    allSteps.Add(bsc.Id, Type.GetType(bsc.StepType));
                }
                return allSteps;
            }
        }
        #endregion

        #region GetBillingContextType
        protected internal Type GetBillingContextType(string billingEngineId)
        {
            if (string.IsNullOrEmpty(billingEngineId))
                throw new ArgumentNullException("billingEngineId");

            BillingEngineConfig bec = _BillingEngineConfigs.SingleOrDefault(p => string.Compare(p.Key, billingEngineId, true) == 0).Value;
            if (bec == null) throw new ConfigurationErrorsException(string.Format("Billing Engine configuration for Billing Engine Id ({0}) can't be found.", billingEngineId));
            else if (bec.BillingContext == null) throw new ConfigurationErrorsException(string.Format("Billing Engine configuration for Billing Engine Id ({0}) missing Billing Context setting.", billingEngineId));
            else return Type.GetType(bec.BillingContext.ContextType);
        }
        #endregion
    }

}
