﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiceLink.Billing.Definition
{
    /// <summary>
    /// IBillingStep definition
    /// </summary>
    public interface IBillingStep
    {
        /// <summary>
        /// Unique Identifier of a billing step within a billing engine
        /// </summary>
        string Id { get; }

        /// <summary>
        /// BillingContext
        /// </summary>
        IBillingContext BillingContext { get; }

        /// <summary>
        /// if the step contains logic hosted in BRE from which Crsf will be used to execute
        /// </summary>
        bool IsCrsfStep { get; set; }

        /// <summary>
        /// Get data only needed in the step; otherwise, the data should come from IBillingContext
        /// </summary>
        void GetStepOnlyData();

        /// <summary>
        /// Validate
        /// </summary>
        /// <returns>if the step is valid</returns>
        bool Validate();

        /// <summary>
        /// Process step logic
        /// </summary>
        void ProcessStep();       

    }
}
