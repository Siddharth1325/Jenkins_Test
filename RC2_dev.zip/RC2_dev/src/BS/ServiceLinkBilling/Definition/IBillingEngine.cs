﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiceLink.Billing.Definition
{
    /// <summary>
    /// IBillingEngine definition
    /// </summary>
    public interface IBillingEngine
    {
        /// <summary>
        /// Unique Identifier of a billing engine
        /// </summary>
        string Id { get; }

        /// <summary>
        /// ServiceLink LOB Application Name
        /// </summary>
        string ApplicationName { get; }

        /// <summary>
        /// Billing Context
        /// </summary>
        IBillingContext BillingContext { get; }

        /// <summary>
        /// Billing Steps
        /// </summary>
        Collection<IBillingStep> BillingSteps { get; }        

        /// <summary>
        /// Initialize the steps and other preparations
        /// </summary>
        /// <param name="billableEntity">A billable entity, e.g., Work Order</param>
        void Init(object billableEntity);

        /// <summary>
        /// AddBillingStep
        /// </summary>
        /// <param name="step">IBillingStep</param>
        void AddBillingStep(IBillingStep billingStep);

        /// <summary>
        /// Validate billing setup at engine level
        /// </summary>
        /// <returns>If billing engine setup valid</returns>
        bool Validate();

        /// <summary>
        /// Execute engine- looping through and executing steps (normally)
        /// </summary>
        void Execute();

        /// <summary>
        /// Create AR and/or AP data
        /// </summary>
        void CreateBillingData();
    }
}
