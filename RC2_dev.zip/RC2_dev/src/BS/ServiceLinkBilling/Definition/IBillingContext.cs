﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiceLink.Billing.Definition
{
    /// <summary>
    /// Adjustment definition
    /// </summary>
    public class Adjustment
    {
        /// <summary>
        /// Adjust Percentage
        /// </summary>
        /// <remarks>Percentage of change, e.g., -1 (-100%) means set the to zero, -0.5 (-50%) means reduce by half</remarks>
        public decimal AdjustPercentage { get; set; }

        /// <summary>
        /// AdjustmentGroupCode
        /// </summary>
        public string AdjustmentGroupCode { get; set; }

        /// <summary>
        /// AdjustmentTypeCode
        /// </summary>
        public string AdjustmentTypeCode { get; set; }
    }

    public class Accounts
    {
        /// <summary>
        /// Total Amount Due
        /// </summary>
        public decimal TotalAmountDue { get; set; }
    }

    public class AccountsDetail
    {
        /// <summary>
        /// Order Id
        /// </summary>
        public int OrderId { get; set; }

        /// <summary>
        /// Vendor Work Order Id
        /// </summary>
        public int? VendorWorkOrderId { get; set; }

        /// <summary>
        /// Work Order Id
        /// </summary>
        public int? WorkOrderId { get; set; }

        /// <summary>
        /// Work Order Item Id
        /// </summary>
        public int? WorkOrderItemId { get; set; }

        /// <summary>
        /// Work Order Line Item Id
        /// </summary>
        public int? WorkOrderLineItemId { get; set; }

        /// <summary>
        /// Source Order Id
        /// </summary>
        public int SourceOrderId { get; set; }

        /// <summary>
        /// Source Vendor Work Order Id
        /// </summary>
        public int? SourceVendorWorkOrderId { get; set; }

        /// <summary>
        /// Source Work Order Id
        /// </summary>
        public int? SourceWorkOrderId { get; set; }

        /// <summary>
        /// Source Work Order Item Id
        /// </summary>
        public int? SourceWorkOrderItemId { get; set; }

        /// <summary>
        /// Source Work Order Line Item Id
        /// </summary>
        public int? SourceWorkOrderLineItemId { get; set; }

        /// <summary>
        /// Quantity
        /// </summary>
        public int Quantity { get; set; }

        /// <summary>
        /// BaseUnitCost
        /// </summary>
        public decimal BaseUnitCost { get; set; }

        /// <summary>
        /// BaseTotalCost
        /// </summary>
        public decimal BaseTotalCost { get; set; }

        /// <summary>
        /// AStatusGroup
        /// </summary>
        public string AStatusGroup { get; set; }

        /// <summary>
        /// AStatusType
        /// </summary>
        public string AStatusType { get; set; }

        /// <summary>
        /// FeeTypeId
        /// </summary>
        public int? FeeTypeId { get; set; }
        
        /// <summary>
        /// FeeTypeName
        /// </summary>
        public string FeeTypeName { get; set; }

        /// <summary>
        /// PaymentId
        /// </summary>
        public int? PaymentId { get; set; }
    }

    /// <summary>
    /// IBillingContext definition
    /// </summary>
    public interface IBillingContext
    {
        /// <summary>
        /// Base Cost
        /// </summary>
        decimal? BaseCost { get; set; }

        /// <summary>
        /// Base Price
        /// </summary>
        decimal? BasePrice { get; set; }

        /// <summary>
        /// Base Cost selected reason
        /// </summary>
        string BaseCostSelectionReason { get; set; }

        /// <summary>
        /// Base Price selected reason
        /// </summary>
        string BasePriceSelectionReason { get; set; }

        /// <summary>
        /// Final Cost
        /// </summary>
        decimal? FinalCost { get; set; }

        /// <summary>
        /// Final Price
        /// </summary>
        decimal? FinalPrice { get; set; }

        /// <summary>
        /// Cost Adjustments
        /// </summary>
        Collection<Adjustment> CostAdjustments { get; }

        /// <summary>
        /// Price Adjustments
        /// </summary>
        Collection<Adjustment> PriceAdjustments { get; }

        /// <summary>
        /// AccountsPayable Total Amount Due
        /// </summary>
        decimal APTotalAmountDue { get; set; }

        /// <summary>
        /// AccountsReceivable Total Amount Due
        /// </summary>
        decimal ARTotalAmountDue { get; set; }

        /// <summary>
        /// Accounts Payable Details
        /// </summary>
        Collection<AccountsDetail> AccountsPayableDetails { get; }

        /// <summary>
        /// Accounts Receivable Details
        /// </summary>
        Collection<AccountsDetail> AccountsReceivableDetails { get; }

        /// <summary>
        /// PriceTracker
        /// </summary>
        decimal PriceTracker { get; set; }

        /// <summary>
        /// CostTracker
        /// </summary>
        decimal CostTracker { get; set; }

        /// <summary>
        /// Billing operation status
        /// </summary>
        bool Successful { get; set; }

        /// <summary>
        /// Billing operation failed reason
        /// </summary>
        string FailureReason { get; set; }

        /// <summary>
        /// AccountsPayableId
        /// </summary>
        int AccountsPayableId { get; set; }

        /// <summary>
        /// AccountsReceivableId
        /// </summary>
        int AccountsReceivableId { get; set; }

        /// <summary>
        /// Context Data Types
        /// </summary>
        Type ContextDataType { get; set; }

        /// <summary>
        /// ContextData
        /// </summary>
        object ContextData { get; set; }
        
        /// <summary>
        /// Validate
        /// </summary>
        /// <returns>if the billing context is valid</returns>
        bool Validate();
    }
}
