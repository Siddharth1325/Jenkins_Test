﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using CommonLib.DataObjects;

namespace BusinessServices.ServiceLinkBilling
{
    [ServiceContract(Namespace = "http://www.bkfs.com/ServiceLink/BillingEngine/1.00")]
    public interface IServiceLinkBillingService
    {
        [OperationContract]
        BillingResponse CreateBilling(BillingRequest request);
        
        [OperationContract]
        PreservationBillingResponse CreatePresBilling(PreservationBillingRequest request);
    }

    [DataContract(Namespace = "http://www.bkfs.com/ServiceLink/BillingEngine/1.00")]
    [Serializable]
    public class BillingRequest : BaseRequestDto
    {
        [DataMember]
        public string TenantGuid { get; set; }

        [DataMember]
        public int WorkOrderId { get; set; }
    }

    [DataContract(Namespace = "http://www.bkfs.com/ServiceLink/BillingEngine/1.00")]
    [Serializable]
    public class BillingResponse : BaseResponseDto
    {
        [DataMember]
        public int AccountsPayableId { get; set; }

        [DataMember]
        public int AccountsReceivableId { get; set; }

        [DataMember]
        public string ErrorInfo { get; set; }
    }
    [DataContract(Namespace = "http://www.bkfs.com/ServiceLink/BillingEngine/1.00")]
    [Serializable]
    public class PreservationBillingRequest : BaseRequestDto
    {
        [DataMember]
        public string TenantGuid { get; set; }

        [DataMember]
        public int VuowSubmissionId { get; set; }

        [DataMember]
        public IList<int> WorkOrderIds { get; set; }
    }

    [DataContract(Namespace = "http://www.bkfs.com/ServiceLink/BillingEngine/1.00")]
    [Serializable]
    public class PreservationBillingResponse : BaseResponseDto
    {
        [DataMember]
        public string ErrorInfo { get; set; }
    }
}
