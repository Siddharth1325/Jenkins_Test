﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using CommonLib.DataObjects;

namespace BusinessServices.ServiceLinkBilling
{
    [ServiceContract(Namespace = "http://www.bkfs.com/ServiceLink/BillingEngine/Bpm/1.00")]
    public interface IBpmServiceLinkBillingService
    {
        [OperationContract]
        BpmBillingResponse BpmCreateBilling(BpmBillingRequest request);
        
        [OperationContract]
        BpmBillingSyncResponse BpmBillingSync(BpmBillingSyncRequest request);
    }

    [DataContract(Namespace = "http://www.bkfs.com/ServiceLink/BillingEngine/Bpm/1.00")]
    [Serializable]
    public class BpmBillingRequest : BaseRequestDto
    {
        [DataMember]
        public string TenantGuid { get; set; }

        [DataMember]
        public int WorkOrderId { get; set; }
    }

    [DataContract(Namespace = "http://www.bkfs.com/ServiceLink/BillingEngine/Bpm/1.00")]
    [Serializable]
    public class BpmBillingResponse : BaseResponseDto
    {
        [DataMember]
        public int AccountsPayableId { get; set; }

        [DataMember]
        public int AccountsReceivableId { get; set; }

        [DataMember]
        public string ErrorInfo { get; set; }
    }

    [DataContract(Namespace = "http://www.bkfs.com/ServiceLink/BillingEngine/Bpm/2.00")]
    [Serializable]
    public class BpmBillingSyncRequest : BaseRequestDto
    {
        [DataMember]
        public string TenantGuid { get; set; }

        [DataMember]
        public int WorkOrderId { get; set; }
    }

    [DataContract(Namespace = "http://www.bkfs.com/ServiceLink/BillingEngine/Bpm/2.00")]
    [Serializable]
    public class BpmBillingSyncResponse : BaseResponseDto
    {
        [DataMember]
        public string ErrorInfo { get; set; }
    }
}
