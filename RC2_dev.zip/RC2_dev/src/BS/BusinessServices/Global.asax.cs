﻿using BusinessSvcImpl.Utilities;
using CommonLib.Persistence;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.SessionState;

namespace BusinessServices
{
    public class Global : System.Web.HttpApplication
    {

        protected void Application_Start(object sender, EventArgs e)
        {
            log4net.Config.XmlConfigurator.Configure(new System.IO.FileInfo(AppDomain.CurrentDomain.BaseDirectory + "Log4Net.config"));
            IChangeListener listener = null;
            try
            {
                listener = new AccountingChangeListener();
                listener.SetupChangeListner();
            }
            catch (Exception ex)
            {
                if (listener != null)
                {
                    listener.InitializationStatus = false;
                }
                CommonLib.Logging.LogError(String.Format("Accounting Listener Initialization failed {0} ", listener), ex);
            }
           
        }

        protected void Session_Start(object sender, EventArgs e)
        {

        }

        protected void Application_BeginRequest(object sender, EventArgs e)
        {

        }

        protected void Application_AuthenticateRequest(object sender, EventArgs e)
        {

        }

        protected void Application_Error(object sender, EventArgs e)
        {

        }

        protected void Session_End(object sender, EventArgs e)
        {

        }

        protected void Application_End(object sender, EventArgs e)
        {

        }
    }
}