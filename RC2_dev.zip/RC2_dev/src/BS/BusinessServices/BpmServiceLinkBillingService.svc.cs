﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Configuration;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Transactions;
using Newtonsoft.Json;
using CommonLib;
using CommonLib.Context;
using CommonLib.Utilities;
using Delegate.SpaAcc;
using ServiceLink.Billing.Definition;
using ServiceLink.Billing.Implementation;
using Reference.ServiceProxy.ReferenceService;
using BillProxy = Billing.ServiceProxy.BpmBillingSvc;

namespace BusinessServices.ServiceLinkBilling
{
    [ServiceBehavior(InstanceContextMode = InstanceContextMode.PerCall)]
    public class BpmServiceLinkBillingService : IBpmServiceLinkBillingService
    {
        public BpmBillingResponse BpmCreateBilling(BpmBillingRequest request)
        {
            bool UseFSBilling = Helper.GetAppConfig<bool>("UseFSBilling");
            BpmBillingResponse response = new BpmBillingResponse();
            
            if (ApplicationContext.Instance.UserContext == null) throw new CommonLib.FSException.FSBusinessException("UserContext is missing from BPM initiated request");
            else if (ApplicationContext.Instance.UserContext.UserId <= 0) throw new CommonLib.FSException.FSBusinessException("UserContext is missing UserId value");
            else Logging.LogDebug("BpmCreateBilling receives request with UserContext as: " + JsonConvert.SerializeObject(ApplicationContext.Instance.UserContext));
            if (request == null) throw new ArgumentNullException("request");
            if (string.IsNullOrEmpty(request.TenantGuid)) throw new ArgumentNullException("request", "request missing TenantGuid");
            if (request.WorkOrderId <= 0) throw new ArgumentOutOfRangeException("request", "request has invalid WorkOrderId");

            Logging.LogDebug("Acct BpmCreateBilling receives request for work order: " + request.WorkOrderId.ToString());

            string applicationName = string.Empty;
            string lobName = string.Empty;
            GetTenantConfigurationResponse tenantConfig = null;
            using (ReferenceDataServiceClient proxy = new ReferenceDataServiceClient())
            {
                tenantConfig = proxy.GetTenantConfigurationDetail(new GetTenantConfigurationRequest() { TenantGuid = Guid.Parse(request.TenantGuid) });
            }
            if (tenantConfig == null || tenantConfig.TenantConfigurationDetail == null ||
                string.IsNullOrWhiteSpace(tenantConfig.TenantConfigurationDetail.ApplicationName) || string.IsNullOrWhiteSpace(tenantConfig.TenantConfigurationDetail.LineOfBusinessName))
            {
                throw new NotSupportedException(string.Format("Currently the platform doesn't support the attempted TenantGuid {0}", request.TenantGuid));
            }
            applicationName = tenantConfig.TenantConfigurationDetail.ApplicationName;
            lobName = tenantConfig.TenantConfigurationDetail.LineOfBusinessName;

            UserContext userContext = ApplicationContext.Instance.UserContext;
            userContext.TenantHierarchyId = tenantConfig.TenantConfigurationDetail.TenantGuid.ToString();
            userContext.TenantId = tenantConfig.TenantConfigurationDetail.ApplicationId;

            if (!UseFSBilling)
            {
                try
                {
                    DateTime startTime = DateTime.Now;

                    new AccountingBillingDelegate().SyncTxnEntitiesBySourceWorkOrderId(request.WorkOrderId);

                        string productCode = new Delegate.SpaAcc.AccountingBillingDelegate().GetProductCodeBySourceWorkOrderId(request.WorkOrderId);
                        string billingEngineId = BillingEngineFactory.GetBillingEngineId(lobName, applicationName, productCode);
                        if (string.IsNullOrWhiteSpace(billingEngineId))
                            throw new NotSupportedException(string.Format("Currently the platform accounting doesn't support the attempted '{0}' LOB, '{1}' Application, '{2}' Product", lobName, applicationName, productCode));

                    IBillingEngine engine = BillingEngineFactory.GetEngine(billingEngineId, request.WorkOrderId);
                    engine.Execute();
                    engine.CreateBillingData();

                    Logging.LogDebug(string.Format("Processed billing with txn sync for inspection work order {0}, duration {1} (msec)", request.WorkOrderId.ToString(), (DateTime.Now - startTime).TotalMilliseconds));

                    response.AccountsPayableId = engine.BillingContext.AccountsPayableId;
                    response.AccountsReceivableId = engine.BillingContext.AccountsReceivableId;                  
                }
                catch (Exception ex)
                {
                    if (ApplicationContext.Instance != null && ApplicationContext.Instance.UserContext != null)
                        ApplicationContext.Instance.UserContext.RemoveChanges();
                    Logging.LogError(ex);
                    response.AccountsPayableId = 0;
                    response.AccountsReceivableId = 0;
                    Exception innerEx = ex.InnerException != null ? ex.InnerException : ex;
                    BillingException bex = innerEx as BillingException;
                    response.ErrorInfo = bex != null ? JsonConvert.SerializeObject(bex)
                        : JsonConvert.SerializeObject(new BillingException(ex.Message, BillingExceptionType.SystemFailure));
                }
                return response;
            }
            else
            {
                BillProxy.BpmBillingResponse billingResponse = null;
                DateTime startTime = DateTime.Now;
                using (BillProxy.BpmServiceLinkBillingServiceClient proxy = new BillProxy.BpmServiceLinkBillingServiceClient())
                {
                    billingResponse = proxy.BpmCreateBilling(new BillProxy.BpmBillingRequest() { TenantGuid = request.TenantGuid, WorkOrderId = request.WorkOrderId });
                }
                if (billingResponse != null)
                {
                    response.AccountsPayableId = billingResponse.AccountsPayableId;
                    response.AccountsReceivableId = billingResponse.AccountsReceivableId;
                    response.ErrorInfo = billingResponse.ErrorInfo;

                    Logging.LogDebug(string.Format("Processed billing for inspection work order {0}, duration {1} (msec)", request.WorkOrderId.ToString(), (DateTime.Now - startTime).TotalMilliseconds));

                    /*
                    // Sync if there are no errors
                    if (string.IsNullOrEmpty(billingResponse.ErrorInfo))
                    {
                        startTime = DateTime.Now;
                        new AccountingBillingDelegate().SyncTxnEntitiesByWorkOrderId(request.WorkOrderId);
                        Logging.LogDebug(string.Format("Processed txn sync for inspection work order {0}, duration {1} (msec)", request.WorkOrderId, (DateTime.Now - startTime).TotalMilliseconds));
                    }
                    else
                    {
                        Logging.LogError(billingResponse.ErrorInfo);
                        response.AccountsPayableId = 0;
                        response.AccountsReceivableId = 0;
                        response.ErrorInfo = JsonConvert.SerializeObject(new BillingException(billingResponse.ErrorInfo, BillingExceptionType.SystemFailure));
                    }
                    */
                }
                else
                {
                    throw new ArgumentOutOfRangeException("workOrderId", string.Format("Can't bill and synch work order for given id ({0})", request.WorkOrderId.ToString()));
                }
                return response;
            }
        }

        public BpmBillingSyncResponse BpmBillingSync(BpmBillingSyncRequest request)
        {
            BpmBillingSyncResponse response = new BpmBillingSyncResponse();
            try
            {
                if (ApplicationContext.Instance.UserContext == null) throw new CommonLib.FSException.FSBusinessException("UserContext is missing from BPM initiated request");
                else if (ApplicationContext.Instance.UserContext.UserId <= 0) throw new CommonLib.FSException.FSBusinessException("UserContext is missing UserId value");
                else Logging.LogDebug("BillingSync receives request with UserContext as: " + JsonConvert.SerializeObject(ApplicationContext.Instance.UserContext));
                if (request == null) throw new ArgumentNullException("request");
                if (string.IsNullOrEmpty(request.TenantGuid)) throw new ArgumentNullException("request", "request missing TenantGuid");
                if (request.WorkOrderId <= 0) throw new ArgumentNullException("request", "request has invalid work order id");

                Logging.LogDebug("BillingSync receives request for work order: " + request.WorkOrderId.ToString());

                GetTenantConfigurationResponse tenantConfig = null;
                using (ReferenceDataServiceClient proxy = new ReferenceDataServiceClient())
                {
                    tenantConfig = proxy.GetTenantConfigurationDetail(new GetTenantConfigurationRequest() { TenantGuid = Guid.Parse(request.TenantGuid) });
                }
                if (tenantConfig == null || tenantConfig.TenantConfigurationDetail == null ||
                    string.IsNullOrWhiteSpace(tenantConfig.TenantConfigurationDetail.ApplicationName) || string.IsNullOrWhiteSpace(tenantConfig.TenantConfigurationDetail.LineOfBusinessName))
                {
                    throw new NotSupportedException(string.Format("Currently the platform doesn't support the attempted TenantGuid {0}", request.TenantGuid));
                }

                UserContext userContext = ApplicationContext.Instance.UserContext;
                userContext.TenantHierarchyId = tenantConfig.TenantConfigurationDetail.TenantGuid.ToString();
                userContext.TenantId = tenantConfig.TenantConfigurationDetail.ApplicationId;

                DateTime startTime = DateTime.Now;

                new AccountingBillingDelegate().SyncTxnEntitiesByWorkOrderId(request.WorkOrderId);

                Logging.LogDebug(string.Format("Processed txn sync for work order {0}, duration {1} (msec)", request.WorkOrderId.ToString(), (DateTime.Now - startTime).TotalMilliseconds));
            }
            catch (Exception ex)
            {
                if (ApplicationContext.Instance != null && ApplicationContext.Instance.UserContext != null)
                    ApplicationContext.Instance.UserContext.RemoveChanges();
                Logging.LogError(ex);
                Exception innerEx = ex.InnerException != null ? ex.InnerException : ex;
                BillingException bex = innerEx as BillingException;
                response.ErrorInfo = bex != null ? JsonConvert.SerializeObject(bex)
                    : JsonConvert.SerializeObject(new BillingException(ex.Message, BillingExceptionType.SystemFailure));
            }
            return response;
        }
    }
}