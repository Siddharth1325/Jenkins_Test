﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using CommonLib.DataObjects;

namespace BusinessServices.ServiceLinkBilling
{
    [ServiceContract(Namespace = "http://www.bkfs.com/ServiceLinkBilling/BillingSync/1.00")]
    public interface IBillingSyncService
    {
        [OperationContract]
        AcctBillingSyncResponse BillingSync(AcctBillingSyncRequest request);
    }

    [DataContract(Namespace = "http://www.bkfs.com/ServiceLinkBilling/BillingSync/1.00")]
    [Serializable]
    public class AcctBillingSyncRequest : BaseRequestDto
    {
        [DataMember]
        public string TenantGuid { get; set; }

        [DataMember]
        public IList<int> WorkOrderIds { get; set; }
    }

    [DataContract(Namespace = "http://www.bkfs.com/ServiceLinkBilling/BillingSync/1.00")]
    [Serializable]
    public class AcctBillingSyncResponse : BaseResponseDto
    {
        [DataMember]
        public string ErrorInfo { get; set; }
    }
}
