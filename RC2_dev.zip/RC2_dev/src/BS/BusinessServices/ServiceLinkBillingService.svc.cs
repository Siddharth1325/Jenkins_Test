﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Configuration;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using Newtonsoft.Json;
using CommonLib;
using CommonLib.Context;
using CommonLib.Utilities;
using Delegate.SpaAcc;
using ServiceLink.Billing.Definition;
using ServiceLink.Billing.Implementation;
using Reference.ServiceProxy.ReferenceService;
using BillProxy = Billing.ServiceProxy.BillingSvc;

namespace BusinessServices.ServiceLinkBilling
{
    [ServiceBehavior(InstanceContextMode = InstanceContextMode.PerCall)]
    public class ServiceLinkBillingService : IServiceLinkBillingService
    {
        public BillingResponse CreateBilling(BillingRequest request)
        {
            bool UseFSBilling = Helper.GetAppConfig<bool>("UseFSBilling");
            BillingResponse response = new BillingResponse();

            if (ApplicationContext.Instance.UserContext == null) throw new CommonLib.FSException.FSBusinessException("UserContext is missing from request");
            else if (ApplicationContext.Instance.UserContext.UserId <= 0) throw new CommonLib.FSException.FSBusinessException("UserContext is missing UserId value");
            else Logging.LogDebug("CreateBilling receives request with UserContext as: " + JsonConvert.SerializeObject(ApplicationContext.Instance.UserContext));
            if (request == null) throw new ArgumentNullException("request");
            if (string.IsNullOrEmpty(request.TenantGuid)) throw new ArgumentNullException("request", "request missing TenantGuid");
            if (request.WorkOrderId <= 0) throw new ArgumentNullException("request", "request has invalid work order id");

            string applicationName = string.Empty;
            string lobName = string.Empty;
            GetTenantConfigurationResponse tenantConfig = null;
            using (ReferenceDataServiceClient proxy = new ReferenceDataServiceClient())
            {
                tenantConfig = proxy.GetTenantConfigurationDetail(new GetTenantConfigurationRequest() { TenantGuid = Guid.Parse(request.TenantGuid) });
            }
            if (tenantConfig == null || tenantConfig.TenantConfigurationDetail == null ||
                string.IsNullOrWhiteSpace(tenantConfig.TenantConfigurationDetail.ApplicationName) || string.IsNullOrWhiteSpace(tenantConfig.TenantConfigurationDetail.LineOfBusinessName))
            {
                throw new NotSupportedException(string.Format("Currently the platform doesn't support the attempted TenantGuid {0}", request.TenantGuid));
            }
            applicationName = tenantConfig.TenantConfigurationDetail.ApplicationName;
            lobName = tenantConfig.TenantConfigurationDetail.LineOfBusinessName;

            UserContext userContext = ApplicationContext.Instance.UserContext;
            userContext.TenantHierarchyId = tenantConfig.TenantConfigurationDetail.TenantGuid.ToString();
            userContext.TenantId = tenantConfig.TenantConfigurationDetail.ApplicationId;

            if (!UseFSBilling)
            {
                try
                {
                    DateTime startTime = DateTime.Now;

                    new AccountingBillingDelegate().SyncTxnEntitiesBySourceWorkOrderId(request.WorkOrderId);

                    string productCode = new Delegate.SpaAcc.AccountingBillingDelegate().GetProductCodeBySourceWorkOrderId(request.WorkOrderId);
                    string billingEngineId = BillingEngineFactory.GetBillingEngineId(lobName, applicationName, productCode);
                    if (string.IsNullOrWhiteSpace(billingEngineId))
                        throw new NotSupportedException(string.Format("Currently the platform accounting doesn't support the attempted '{0}' LOB, '{1}' Application, '{2}' Product", lobName, applicationName, productCode));

                    IBillingEngine engine = BillingEngineFactory.GetEngine(billingEngineId, request.WorkOrderId);
                    engine.Execute();
                    engine.CreateBillingData();

                    Logging.LogDebug(string.Format("Processed billing with txn sync for inspection work order {0}, duration {1} (msec)", request.WorkOrderId, (DateTime.Now - startTime).TotalMilliseconds));

                    response.AccountsPayableId = engine.BillingContext.AccountsPayableId;
                    response.AccountsReceivableId = engine.BillingContext.AccountsReceivableId;
                }
                catch (Exception ex)
                {
                    if (ApplicationContext.Instance != null && ApplicationContext.Instance.UserContext != null)
                        ApplicationContext.Instance.UserContext.RemoveChanges();
                    Logging.LogError(ex);
                    response.AccountsPayableId = 0;
                    response.AccountsReceivableId = 0;
                    Exception innerEx = ex.InnerException != null ? ex.InnerException : ex;
                    BillingException bex = innerEx as BillingException;
                    response.ErrorInfo = bex != null ? JsonConvert.SerializeObject(bex)
                        : JsonConvert.SerializeObject(new BillingException(ex.Message, BillingExceptionType.SystemFailure));
                }
                return response;
            }
            else
            {
                BillProxy.BillingResponse billingResponse = null;
                DateTime startTime = DateTime.Now;
                using (BillProxy.ServiceLinkBillingServiceClient proxy = new BillProxy.ServiceLinkBillingServiceClient())
                {
                    billingResponse = proxy.CreateBilling(new BillProxy.BillingRequest() { TenantGuid = request.TenantGuid, WorkOrderId = request.WorkOrderId });
                }
                if (billingResponse != null)
                {
                    response.AccountsPayableId = billingResponse.AccountsPayableId;
                    response.AccountsReceivableId = billingResponse.AccountsReceivableId;
                    response.ErrorInfo = billingResponse.ErrorInfo;

                    Logging.LogDebug(string.Format("Processed billing for inspection work order {0}, duration {1} (msec)", request.WorkOrderId, (DateTime.Now - startTime).TotalMilliseconds));

                    
                    // Sync if there are no errors
                    if (string.IsNullOrEmpty(billingResponse.ErrorInfo))
                    {
                        startTime = DateTime.Now;
                        new AccountingBillingDelegate().SyncTxnEntitiesByWorkOrderId(request.WorkOrderId);
                        Logging.LogDebug(string.Format("Processed txn sync for inspection work order {0}, duration {1} (msec)", request.WorkOrderId, (DateTime.Now - startTime).TotalMilliseconds));
                    }
                    else
                    {
                        Logging.LogError(billingResponse.ErrorInfo);
                        response.AccountsPayableId = 0;
                        response.AccountsReceivableId = 0;
                        response.ErrorInfo = JsonConvert.SerializeObject(new BillingException(billingResponse.ErrorInfo, BillingExceptionType.SystemFailure));
                    }                    
                }
                else
                {
                    throw new ArgumentOutOfRangeException("workOrderId", string.Format("Can't bill and synch work order for given id ({0})", request.WorkOrderId));
                }
                return response;
            }
        }

        public PreservationBillingResponse CreatePresBilling(PreservationBillingRequest request)
        {
            bool UseFSBilling = Helper.GetAppConfig<bool>("UseFSBilling");
            PreservationBillingResponse response = new PreservationBillingResponse();

            if (ApplicationContext.Instance.UserContext == null) throw new CommonLib.FSException.FSBusinessException("UserContext is missing from request");
            else if (ApplicationContext.Instance.UserContext.UserId <= 0) throw new CommonLib.FSException.FSBusinessException("UserContext is missing UserId value");
            else Logging.LogDebug("CreateBilling receives request with UserContext as: " + JsonConvert.SerializeObject(ApplicationContext.Instance.UserContext));
            if (request == null) throw new ArgumentNullException("request");
            if (string.IsNullOrEmpty(request.TenantGuid)) throw new ArgumentNullException("request", "request missing TenantGuid");
            if (request.WorkOrderIds.Count <= 0) throw new ArgumentNullException("request", "request has invalid work order id(s)");

            Logging.LogDebug("Acct CreatePresBilling receives request for work order(s): " + string.Join(", ", request.WorkOrderIds.ToArray()));

            string applicationName = string.Empty;
            string lobName = string.Empty;
            GetTenantConfigurationResponse tenantConfig = null;
            using (ReferenceDataServiceClient proxy = new ReferenceDataServiceClient())
            {
                tenantConfig = proxy.GetTenantConfigurationDetail(new GetTenantConfigurationRequest() { TenantGuid = Guid.Parse(request.TenantGuid) });
            }
            if (tenantConfig == null || tenantConfig.TenantConfigurationDetail == null ||
                string.IsNullOrWhiteSpace(tenantConfig.TenantConfigurationDetail.ApplicationName) || string.IsNullOrWhiteSpace(tenantConfig.TenantConfigurationDetail.LineOfBusinessName))
            {
                throw new NotSupportedException(string.Format("Currently the platform doesn't support the attempted TenantGuid {0}", request.TenantGuid));
            }
            applicationName = tenantConfig.TenantConfigurationDetail.ApplicationName;
            lobName = tenantConfig.TenantConfigurationDetail.LineOfBusinessName;

            UserContext userContext = ApplicationContext.Instance.UserContext;
            userContext.TenantHierarchyId = tenantConfig.TenantConfigurationDetail.TenantGuid.ToString();
            userContext.TenantId = tenantConfig.TenantConfigurationDetail.ApplicationId;

            if (!UseFSBilling)
            {
                try
                {
                    DateTime startTime = DateTime.Now;

                    foreach (int workOrderId in request.WorkOrderIds)
                    {
                        new AccountingBillingDelegate().SyncTxnEntitiesPresBySourceWorkOrderId(workOrderId);
                    }

                    string billingEngineId = BillingEngineFactory.GetBillingEngineId(lobName, applicationName, null);
                    if (string.IsNullOrWhiteSpace(billingEngineId))
                        throw new NotSupportedException(string.Format("Currently the platform accounting doesn't support the attempted '{0}' LOB, '{1}' Application", lobName, applicationName));

                    IBillingEngine engine = BillingEngineFactory.GetEngine(billingEngineId, request.WorkOrderIds);
                    engine.Execute();
                    engine.CreateBillingData();

                    Logging.LogDebug(string.Format("Processed billing with txn sync for preservation work order(s) {0}, duration {1} (msec)", string.Join(", ", request.WorkOrderIds.ToArray()), (DateTime.Now - startTime).TotalMilliseconds));

                }
                catch (Exception ex)
                {
                    if (ApplicationContext.Instance != null && ApplicationContext.Instance.UserContext != null)
                        ApplicationContext.Instance.UserContext.RemoveChanges();
                    Logging.LogError(ex);
                    Exception innerEx = ex.InnerException != null ? ex.InnerException : ex;
                    BillingException bex = innerEx as BillingException;
                    response.ErrorInfo = bex != null ? JsonConvert.SerializeObject(bex)
                        : JsonConvert.SerializeObject(new BillingException(ex.Message, BillingExceptionType.SystemFailure));
                }
                return response;
            }
            else
            {
                BillProxy.PreservationBillingResponse billingResponse = null;
                DateTime startTime = DateTime.Now;
                using (BillProxy.ServiceLinkBillingServiceClient proxy = new BillProxy.ServiceLinkBillingServiceClient())
                {
                    billingResponse = proxy.CreatePresBilling(new BillProxy.PreservationBillingRequest() { TenantGuid = request.TenantGuid, WorkOrderIds = request.WorkOrderIds.ToList() });
                }
                if (billingResponse != null)
                {
                    response.ErrorInfo = billingResponse.ErrorInfo;

                    Logging.LogDebug(string.Format("Processed billing for preservation work order {0}, duration {1} (msec)", string.Join(", ", request.WorkOrderIds.ToArray()), (DateTime.Now - startTime).TotalMilliseconds));

                    /*
                    // Sync if there are no errors
                    if (string.IsNullOrEmpty(billingResponse.ErrorInfo))
                    {
                        foreach (int workOrderId in request.WorkOrderIds)
                        {
                            startTime = DateTime.Now;
                            new AccountingBillingDelegate().SyncTxnEntitiesByWorkOrderId(workOrderId);
                            Logging.LogDebug(string.Format("Processed txn sync for preservation work order {0}, duration {1} (msec)", workOrderId, (DateTime.Now - startTime).TotalMilliseconds));
                        }
                    }
                    else
                    {
                        Logging.LogError(billingResponse.ErrorInfo);
                        response.ErrorInfo = JsonConvert.SerializeObject(new BillingException(billingResponse.ErrorInfo, BillingExceptionType.SystemFailure));
                    }
                    */
                }
                else
                {
                    throw new ArgumentOutOfRangeException("workOrderId", string.Format("Can't bill and synch work order for given id ({0})", string.Join(", ", request.WorkOrderIds.ToArray())));
                }
                return response;
            }
        }
    }
}