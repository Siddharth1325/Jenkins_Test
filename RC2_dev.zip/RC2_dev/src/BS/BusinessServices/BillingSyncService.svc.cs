﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Configuration;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using Newtonsoft.Json;
using CommonLib;
using CommonLib.Context;
using Delegate.SpaAcc;
using ServiceLink.Billing.Definition;
using ServiceLink.Billing.Implementation;
using Reference.ServiceProxy.ReferenceService;
using BillProxy = Billing.ServiceProxy.BillingSvc;

namespace BusinessServices.ServiceLinkBilling
{
    [ServiceBehavior(InstanceContextMode = InstanceContextMode.PerCall)]
    public class BillingSyncService : IBillingSyncService
    {
        public AcctBillingSyncResponse BillingSync(AcctBillingSyncRequest request)
        {
            AcctBillingSyncResponse response = new AcctBillingSyncResponse();
            try
            {
                if (ApplicationContext.Instance.UserContext == null) throw new CommonLib.FSException.FSBusinessException("UserContext is missing from BPM initiated request");
                else if (ApplicationContext.Instance.UserContext.UserId <= 0) throw new CommonLib.FSException.FSBusinessException("UserContext is missing UserId value");
                else Logging.LogDebug("BillingSync receives request with UserContext as: " + JsonConvert.SerializeObject(ApplicationContext.Instance.UserContext));
                if (request == null) throw new ArgumentNullException("request");
                if (string.IsNullOrEmpty(request.TenantGuid)) throw new ArgumentNullException("request", "request missing TenantGuid");
                if (request.WorkOrderIds.Count <= 0) throw new ArgumentNullException("request", "request has invalid work order id(s)");

                Logging.LogDebug("BillingSync receives request for work order(s): " + string.Join(", ", request.WorkOrderIds.ToArray()));

                GetTenantConfigurationResponse tenantConfig = null;
                using (ReferenceDataServiceClient proxy = new ReferenceDataServiceClient())
                {
                    tenantConfig = proxy.GetTenantConfigurationDetail(new GetTenantConfigurationRequest() { TenantGuid = Guid.Parse(request.TenantGuid) });
                }
                if (tenantConfig == null || tenantConfig.TenantConfigurationDetail == null ||
                    string.IsNullOrWhiteSpace(tenantConfig.TenantConfigurationDetail.ApplicationName) || string.IsNullOrWhiteSpace(tenantConfig.TenantConfigurationDetail.LineOfBusinessName))
                {
                    throw new NotSupportedException(string.Format("Currently the platform doesn't support the attempted TenantGuid {0}", request.TenantGuid));
                }

                UserContext userContext = ApplicationContext.Instance.UserContext;
                userContext.TenantHierarchyId = tenantConfig.TenantConfigurationDetail.TenantGuid.ToString();
                userContext.TenantId = tenantConfig.TenantConfigurationDetail.ApplicationId;

                DateTime startTime = DateTime.Now;

                foreach (int workOrderId in request.WorkOrderIds)
                {
                    new AccountingBillingDelegate().SyncTxnEntitiesByWorkOrderId(workOrderId);
                }

                Logging.LogDebug(string.Format("Processed txn sync for work order {0}, duration {1} (msec)", string.Join(", ", request.WorkOrderIds.ToArray()), (DateTime.Now - startTime).TotalMilliseconds));
            }
            catch (Exception ex)
            {
                if (ApplicationContext.Instance != null && ApplicationContext.Instance.UserContext != null)
                    ApplicationContext.Instance.UserContext.RemoveChanges();
                Logging.LogError(ex);
                Exception innerEx = ex.InnerException != null ? ex.InnerException : ex;
                BillingException bex = innerEx as BillingException;
                response.ErrorInfo = bex != null ? JsonConvert.SerializeObject(bex)
                    : JsonConvert.SerializeObject(new BillingException(ex.Message, BillingExceptionType.SystemFailure));
            }
            return response;
        }
    }
}
