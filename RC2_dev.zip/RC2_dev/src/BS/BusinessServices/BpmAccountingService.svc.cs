﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Transactions;
using Newtonsoft.Json;
using CommonLib;
using CommonLib.Context;
using BusinessSvcImpl.DataObjects.SpaAccounting.Dto;
using BusinessSvcImpl.DataObjects.SpaAccountingService.Dto;
using BusinessSvcImpl.SvcImpl.SpaAcc;
using BusinessServices.ServiceLinkBilling;
using Insp = Inspections.ServiceProxy.InspectionSvc;
using TxnDelegate = Delegate.TxnDelegate;
using Dom = DomainModel.Accounting;
using User.ServiceProxy;
using User.ServiceProxy.UserRepository;
using BusinessSvcImpl.Utilities;


namespace BusinessSvcImpl.SvcImpl.SpaAcc
{
    /// <summary>
    /// Implementation of legacy IBpmAccountingService to keep backwards compatiblity
    /// </summary>
    [ServiceBehavior(InstanceContextMode = InstanceContextMode.PerCall)]
    public class BpmAccountingService : IBpmAccountingService
    {
        private static string _LEGACY_TENANT_GUID = "14E2BB4E-F2BE-4BF0-83E2-34CA323B61E8";

        public BpmAccountingBillingResponse BpmCreateBillingForWorkOrder(BpmAccountingBillingRequest request)
        {
            if (request == null)
                throw new ArgumentNullException("request");
            else if (string.IsNullOrEmpty(request.ApplicationCode))
                throw new ArgumentOutOfRangeException("request", "Missing ApplicationCode");
            else if (request.WorkOrderId <= 0)
                throw new ArgumentOutOfRangeException("request", "Invalid WorkOrderId");

            if (ApplicationContext.Instance == null)
                throw new CommonLib.FSException.FSBusinessException("ApplicationContext is missing from BPM initiated request");
            else if (ApplicationContext.Instance.UserContext == null)
                throw new CommonLib.FSException.FSBusinessException("UserContext is missing from BPM initiated request");
            else if(ApplicationContext.Instance.UserContext.UserId <= 0)
                throw new CommonLib.FSException.FSBusinessException("UserContext is missing UserId value from BPM initiated request");
            else
                ApplicationContext.Instance.UserContext.TenantHierarchyId = _LEGACY_TENANT_GUID.ToString();
            
            BpmAccountingBillingResponse response = new BpmAccountingBillingResponse();
            try
            {
                CopyInspectionData(request.ApplicationCode, request.WorkOrderId);
                BpmBillingResponse billingResponse = new BpmServiceLinkBillingService().BpmCreateBilling(new BpmBillingRequest() { TenantGuid = _LEGACY_TENANT_GUID, WorkOrderId = request.WorkOrderId });
                response.AccountsPayableId = billingResponse.AccountsPayableId;
                response.AccountsReceivableId = billingResponse.AccountsReceivableId;
                response.AccountingErrorInformation = billingResponse.ErrorInfo;
            }
            catch (Exception ex)
            {
                Logging.LogError(ex);
                response.AccountsPayableId = 0;
                response.AccountsReceivableId = 0;
                response.AccountingErrorInformation = ex.Message;
            }
            return response;
        }

        private void CopyInspectionData(string applicationCode, int workOrderId)
        {
            if (string.IsNullOrWhiteSpace(applicationCode))
                throw new ArgumentNullException("applicationCode");

            UserServiceProxy userProxy = new UserServiceProxy();
            User.ServiceProxy.UserRepository.Application userApplication = userProxy.GetApplicationByApplictionCode(applicationCode);
            if(userApplication == null)
                throw new ArgumentOutOfRangeException("applicationCode", "applicationCode is invalid");
            
            TxnDelegate.WorkOrderDelegate workOrderDelegate = new TxnDelegate.WorkOrderDelegate();
            Dom.WorkOrder internalWorkOrder = workOrderDelegate.GetWorkOrder(userApplication.ApplicationId, workOrderId);
            Dom.Order internalOrder = new TxnDelegate.OrderDelegate().GetOrder(internalWorkOrder.OrderId.Value, DomainModel.Common.CommonEnums.OrderChild.All);
            Dom.Loan platformLoan = internalOrder.Loan;

            Insp.GetOrderResponse orderResponse = null;
            using (Insp.InspServiceClient inspectionService = new Insp.InspServiceClient())
            {
                Insp.GetOrderRequest orderRequest = new Insp.GetOrderRequest()
                {
                    Order = new Insp.Order() { OrderId = internalOrder.SourceOrderId }
                };
                orderResponse = inspectionService.GetOrderDetailsWithCancellation(orderRequest);
            }
            if (orderResponse == null || orderResponse.Order == null)
                throw new ArgumentOutOfRangeException("workOrderId", string.Format("There is no Inspection Order with OrderId ({0})", internalOrder.SourceOrderId));

            List<WorkOrderItem> workOrderItemList = new List<WorkOrderItem>();
            BillingOrderMapping orderMapping = new BillingOrderMapping();
            Order platformOrder = orderMapping.CopyInspectionOrder(new Order().MapFromDomainModel<Dom.Order, Order>(internalOrder), orderResponse.Order, workOrderItemList);

            if (orderResponse.Order.Loan != null)
            {
                new TxnDelegate.LoanDelegate().SaveLoan(platformOrder.Loan.MapToDomainModel<Dom.Loan>(new Dom.Loan()));
            }

            internalOrder = new TxnDelegate.OrderDelegate().SaveOrder(platformOrder.MapToDomainModel<Dom.Order>(new Dom.Order()));

            if (orderResponse.Order.WorkOrders != null && orderResponse.Order.WorkOrders.Count > 0)
            {
                foreach (WorkOrder platformWorkOrder in platformOrder.WorkOrders)
                {
                    workOrderDelegate.SaveWorkOrder(platformWorkOrder.MapToDomainModel<Dom.WorkOrder>(new Dom.WorkOrder()));
                }
            }

            if (orderResponse.Order.WorkOrderItems != null && orderResponse.Order.WorkOrderItems.Count > 0)
            {
                TxnDelegate.WorkOrderItemDelegate workOrderItemDelegate = new TxnDelegate.WorkOrderItemDelegate();

                foreach (WorkOrderItem platformWorkOrderItem in workOrderItemList)
                {
                    workOrderItemDelegate.SaveWorkOrderItem(platformWorkOrderItem.MapToDomainModel<Dom.WorkOrderItem>(new Dom.WorkOrderItem()));
                }
            }

            if (orderResponse.Order.Cancellations != null && orderResponse.Order.Cancellations.Count > 0)
            {
                TxnDelegate.CancellationDelegate cancellationDelegate = new TxnDelegate.CancellationDelegate();

                foreach (Cancellation platformCancellation in platformOrder.Cancellations)
                {
                    cancellationDelegate.SaveCancellation(platformCancellation.MapToDomainModel<Dom.Cancellation>(new Dom.Cancellation()));
                }
            }
        }
    }
}