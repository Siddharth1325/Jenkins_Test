using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("BusinessServices")]
[assembly: AssemblyDescription("BusinessServices")]
[assembly: AssemblyCompany("???")]
[assembly: AssemblyProduct("BusinessServices")]
[assembly: AssemblyCopyright("Copyright © ??? 2014")]
[assembly: ComVisible(false)]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: Guid("00320EF8-D483-46DF-ACB9-4DFD92A4FB48")]
[assembly: log4net.Config.XmlConfigurator(ConfigFile = "Log4Net.config", Watch = true)]
[assembly: AssemblyVersion("1.17.0.0")]
[assembly: AssemblyFileVersion("1.0.0")]