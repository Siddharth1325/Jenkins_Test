﻿using System;
using System.Collections.Generic;
using DataAccess.Persistence;
using System.Linq;
using System.Web;
using System.Reflection;
using System.Data.Entity.Core.Metadata.Edm;
using System.Text;
using Newtonsoft.Json;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using CommonLib;


namespace BusinessServices.App_Code
{
    public class AppInit
    {

        public static void AppInitialize()
        {
            InitDataAccess("Acct.DataAccess");
            InitAssemblyTypes("Acct.Delegate");
            InitAssemblyTypes("Acct.DomainModel");
            InitServiceContract();
        }

        public static void InitAssemblyTypes(string name)
        {
            try
            {
                //TODO: initialize host
                Logging.LogDebug("AppInit - InitAssemblyTypes");
                Assembly module = AppDomain.CurrentDomain.Load(name);
                if (module == null) return;
                Logging.LogDebug("Assembly Loaded - " + name);
                Type[] types = module.GetTypes();

            }
            catch (Exception e)
            {
                Logging.LogError(e);
            }
        }

        public static void InitServiceContract()
        {
            try
            {
                //TODO: initialize host
                Logging.LogDebug("AppInit - InitServiceContract");
                Assembly bsImpl = AppDomain.CurrentDomain.Load("AcctBusinessSvcImpl");
                if (bsImpl == null) return;
                Logging.LogDebug("Assembly Loaded - BusinessSvcImpl");
                Type[] types = bsImpl.GetTypes();

            }
            catch (Exception e)
            {
                Logging.LogError(e);
            }
        }
        public static void InitDataAccess(string module)
        {
            try
            {
                Logging.LogDebug("AppInit - InitDataAccess");
                Type t = typeof(CustomDbContext);
                Assembly dataAccess = AppDomain.CurrentDomain.Load(module);
                if (dataAccess == null) return;
                Logging.LogDebug("Assembly Loaded - " + module);
                Type[] types = dataAccess.GetTypes();
                foreach (Type type in types)
                {
                    // Logging.LogDebug("Processing type - " + type.ToString());
                    if (type.IsSubclassOf(t))
                    {
                        try
                        {
                            using (CustomDbContext context = (CustomDbContext)Activator.CreateInstance(type))
                            {
                                Logging.LogDebug("Initializing DbContext - " + type.ToString());
                                var objectContext = ((IObjectContextAdapter)context).ObjectContext;
                                var sspace = objectContext.MetadataWorkspace.GetItemCollection(System.Data.Entity.Core.Metadata.Edm.DataSpace.SSpace) as StoreItemCollection;
                                context.Database.ExecuteSqlCommand("Select 1;");
                                Logging.LogDebug("SQL executed on DB for type- " + type.ToString());
                            }
                        }
                        catch (Exception e)
                        {
                            Logging.LogError(e);
                        }
                    }

                }
            }
            catch (Exception e)
            {
                Logging.LogError(e);
            }
        }
    }
}
