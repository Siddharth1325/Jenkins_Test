﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Transactions;
using BusinessSvcImpl.SvcImpl.SpaAcc;
using BusinessSvcImpl.DataObjects.SpaAccounting.Dto;
using CommonLib.Context;
using System.Linq;
using DataAccess.Accounting;
using BusinessSvcImpl.DataObjects.SpaAccountingService.Dto;
using System.Collections.Generic;

namespace AccountingTest
{
    [Ignore]   
    [TestClass]    
    public class AdjustmentTest
    {
        TransactionScope transScope;
        SpaAccountingService accountingService;
        ApplicationContext appContext;

        [TestInitialize]
        public void TestInitialize()
        {
            accountingService = new SpaAccountingService();
            transScope = new TransactionScope();
            appContext = GetUserContext();
        }

        private ApplicationContext GetUserContext()
        {
            appContext = ApplicationContext.Instance;
            if (appContext != null && appContext.UserContext == null)
            {
                UserContext userContext = new UserContext() { FirstName = "Administrator", IsActive = true, LastName = "Administrator", UserId = 1001, UserName = "Administrator", ApplicationId = 10016, TenantHierarchyId = "57F9B2BD-21BA-4028-AAC8-A382FE62B95A" };

                appContext.UserContext = userContext;
            }
            return appContext;
        }

        [TestCleanup]
        public void TestCleanup()
        {
            transScope.Dispose();
            accountingService = null;
        }


        [TestMethod]
        [Ignore]

        public void IsSaveDisputePayableAdjustmentHistorySaveAllData()
        {
            //this is initial test, data should be save in adjustment table as well
            DisputePayableAdjustmentHistory disPayAdjHistRequest = new DisputePayableAdjustmentHistory();
            DisputePayableAdjustmentHistory disPayAdjHistResult = new DisputePayableAdjustmentHistory();            
            disPayAdjHistRequest.AdjustmentHistoryRecordGroup = "ADJHIST";
            disPayAdjHistRequest.AdjustmentHistoryRecordType = "ADJED";
            disPayAdjHistRequest.AgreedUnitCost = 12.04m;
            disPayAdjHistRequest.ApplicationId = 10016;            
            disPayAdjHistRequest.HistoryDate = DateTime.UtcNow;
            disPayAdjHistRequest.LineItemDescription = "LineItemDescription";
            disPayAdjHistRequest.OrderHierarchyId = 1765;
            disPayAdjHistRequest.Quantity = 10;
            disPayAdjHistRequest.RecordNumber = 1;
            disPayAdjHistRequest.ServiceDescription = "ServiceDescription";
            disPayAdjHistRequest.VendorAdjComments = "VendorAdjComments";
            disPayAdjHistRequest.VendorDiscountAdjPercentage = 12m;
            disPayAdjHistRequest.VendorFee = 23m;
            disPayAdjHistRequest.VendorFeeAdjstdAmt = 12.34m;
            disPayAdjHistRequest.VendorFeeAfterDiscount = 23.34m;
            disPayAdjHistRequest.VendorFinalFee = 412.98m;
            disPayAdjHistRequest.VendorFinalFeeAdjstdAmt = 411.12m;
            disPayAdjHistRequest.VendorMinServiceFee = 12.43m;
            disPayAdjHistRequest.VendorOneTimeFee = 50.23m;
            disPayAdjHistRequest.VendorOneTimeFeeAdjstdAmt = 100.23m;
            disPayAdjHistRequest.VendorTripFee = 5.12m;
            disPayAdjHistRequest.VendorTripFeeAdjstdAmt = 10.21m;
            disPayAdjHistRequest.CreatedById = appContext.UserContext.UserId;
            disPayAdjHistRequest.LastUpdatedById = appContext.UserContext.UserId;
            
            disPayAdjHistResult = accountingService.SaveDisputePayableAdjustmentHistory(disPayAdjHistRequest);

            Assert.IsNotNull(disPayAdjHistResult, "Save Method should return saved (SaveDisputePayableAdjustmentHistory) Object");
            Assert.AreEqual(disPayAdjHistRequest.VendorFinalFee, disPayAdjHistResult.VendorFinalFee, "Save same value as of input object");
            Assert.AreEqual(disPayAdjHistRequest.VendorTripFee, disPayAdjHistResult.VendorTripFee, "Save same value as of input object");
        }


        [TestMethod]
        [Ignore]

        public void IsSaveDisputeReceivableAdjustmentHistorySaveAllData()
        {
            //this is initial test, data should be save in adjustment table as well
            DisputeReceivableAdjustmentHistory disRecAdjHistRequest = new DisputeReceivableAdjustmentHistory();
            DisputeReceivableAdjustmentHistory disRecAdjHistResult = new DisputeReceivableAdjustmentHistory();            
            disRecAdjHistRequest.AdjustmentHistoryRecordGroup = "ADJHIST";
            disRecAdjHistRequest.AdjustmentHistoryRecordType = "ADJED";
            disRecAdjHistRequest.AgreedClientUnitPrice = 12.04m;
            disRecAdjHistRequest.ApplicationId = 10016;
            disRecAdjHistRequest.ClientAdjComments = "ClientAdjComments";
            disRecAdjHistRequest.ClientPriceAdjstdAmt = 12.56m;
            disRecAdjHistRequest.ClientPrice = 56.23m;
            disRecAdjHistRequest.ClientRushFee = 56.21m;
            disRecAdjHistRequest.ClientRushFeeAdjstdAmt = 56.10m;
            disRecAdjHistRequest.ClientTripFee = 12m;
            disRecAdjHistRequest.ClientTripFeeAdjstdAmt = 12m;            
            disRecAdjHistRequest.HistoryDate = DateTime.UtcNow;
            disRecAdjHistRequest.LineItemDescription = "LineItemDescription";
            disRecAdjHistRequest.OrderHierarchyId = 1765;
            disRecAdjHistRequest.Quantity = 10;
            disRecAdjHistRequest.RecordNumber = 4;
            disRecAdjHistRequest.ServiceDescription = "ServiceDescription";
            disRecAdjHistRequest.CreatedById = appContext.UserContext.UserId;
            disRecAdjHistRequest.LastUpdatedById = appContext.UserContext.UserId;

            disRecAdjHistResult = accountingService.SaveDisputeReceivableAdjustmentHistory(disRecAdjHistRequest);

            Assert.IsNotNull(disRecAdjHistResult, "Save Method should return saved (SaveDisputePayableAdjustmentHistory) Object");
            Assert.AreEqual(disRecAdjHistResult.ClientRushFeeAdjstdAmt, disRecAdjHistRequest.ClientRushFeeAdjstdAmt, "Save same value as of input object");
            Assert.AreEqual(disRecAdjHistResult.RecordNumber, disRecAdjHistRequest.RecordNumber, "Save same value as of input object");
        }

        [TestMethod]
        [Ignore]

        public void CheckForFirstAdjustmentClientTripAndRushFeeOrderLevelChangeSetDataInToAdjustmntAndHistoryTables()
        {
            DisputeReceivableAdjustmentHistory disRecAdjHistRequest = new DisputeReceivableAdjustmentHistory();
            DisputeReceivableAdjustmentHistory disRecAdjHistResult = new DisputeReceivableAdjustmentHistory();

            // Dummy Data used
            int dummyDisputeReceivableAdjustmentHistoryIdFromUI = 128; //this is ID nneed to sent by UI, currently ID in adjusted mode and has record number more than 0, read for dummy purpose
            int dummyOrderHirarchyIdFromUI = 1951; //
                                    
            disRecAdjHistRequest.ApplicationId = 10016;
            disRecAdjHistRequest.ClientAdjComments = "User Entered Comment";            
            disRecAdjHistRequest.ClientRushFee = 12;
            disRecAdjHistRequest.ClientRushFeeAdjstdAmt = 2;
            disRecAdjHistRequest.ClientTripFee = 14;
            disRecAdjHistRequest.ClientTripFeeAdjstdAmt = 5;
            disRecAdjHistRequest.OrderHierarchyId = dummyOrderHirarchyIdFromUI;            
            disRecAdjHistRequest.RecordNumber = 1;
            disRecAdjHistRequest.DisputeReceivableAdjustmentHistoryId = dummyDisputeReceivableAdjustmentHistoryIdFromUI;
                        
            disRecAdjHistResult = accountingService.SaveDisputeReceivableAdjustmentHistory(disRecAdjHistRequest);

            //Assert.IsNotNull(disRecAdjHistResult.AccountsReceivableAdjustments.FirstOrDefault(ara => ara.DisputeReceivableAdjustmentHistoryId == disRecAdjHistResult.DisputeReceivableAdjustmentHistoryId), "Record should be saved for newly adjusted history Id in adjustment table");            
            Assert.IsNotNull(disRecAdjHistResult, "Save Method should return saved (SaveDisputePayableAdjustmentHistory) Object");
            Assert.AreEqual(disRecAdjHistResult.ClientRushFeeAdjstdAmt, disRecAdjHistRequest.ClientRushFeeAdjstdAmt, "Save same value as of input object");
            Assert.AreEqual(disRecAdjHistResult.ClientRushFee, disRecAdjHistRequest.ClientRushFee, "Save same value as of input object");
            Assert.AreEqual(disRecAdjHistResult.RecordNumber, disRecAdjHistRequest.RecordNumber, "Save same value as of input object");
        }

        [TestMethod]
        [Ignore]

        public void CheckForNextAdjustmentClientTripAndRushFeeOrderLevelChangeSetDataInToAdjustmntAndHistoryTables()
        {
            DisputeReceivableAdjustmentHistory disRecAdjHistRequest = new DisputeReceivableAdjustmentHistory();
            DisputeReceivableAdjustmentHistory disRecAdjHistResult = new DisputeReceivableAdjustmentHistory();

            // Dummy Data used
            int dummyDisputeReceivableAdjustmentHistoryIdFromUI = 157; //this is ID nneed to sent by UI, currently ID in adjusted mode and has record number more than 0, read for dummy purpose
            int dummyOrderHirarchyIdFromUI = 1951; //

            disRecAdjHistRequest.ApplicationId = 10016;
            disRecAdjHistRequest.ClientAdjComments = "User Entered Comment";
            disRecAdjHistRequest.ClientRushFee = 12;
            disRecAdjHistRequest.ClientRushFeeAdjstdAmt = 2;
            disRecAdjHistRequest.ClientTripFee = 14;
            disRecAdjHistRequest.ClientTripFeeAdjstdAmt = 5;
            disRecAdjHistRequest.OrderHierarchyId = dummyOrderHirarchyIdFromUI;
            disRecAdjHistRequest.RecordNumber = 2;
            disRecAdjHistRequest.DisputeReceivableAdjustmentHistoryId = dummyDisputeReceivableAdjustmentHistoryIdFromUI;

            disRecAdjHistResult = accountingService.SaveDisputeReceivableAdjustmentHistory(disRecAdjHistRequest);

            //Assert.IsNotNull(disRecAdjHistResult.AccountsReceivableAdjustments.FirstOrDefault(ara => ara.DisputeReceivableAdjustmentHistoryId == disRecAdjHistResult.DisputeReceivableAdjustmentHistoryId), "Record should be saved for newly adjusted history Id in adjustment table");            
            Assert.IsNotNull(disRecAdjHistResult, "Save Method should return saved (SaveDisputePayableAdjustmentHistory) Object");
            Assert.AreEqual(disRecAdjHistResult.ClientRushFeeAdjstdAmt, disRecAdjHistRequest.ClientRushFeeAdjstdAmt, "Save same value as of input object");
            Assert.AreEqual(disRecAdjHistResult.ClientRushFee, disRecAdjHistRequest.ClientRushFee, "Save same value as of input object");
            Assert.AreEqual(disRecAdjHistResult.RecordNumber, disRecAdjHistRequest.RecordNumber, "Save same value as of input object");
        }

        [TestMethod]
        [Ignore]

        public void CheckForNextAdjustmentVendorFeeOrderLevelChangeSetDataInToAdjustmntAndHistoryTables()
        {
            DisputePayableAdjustmentHistory disPayAdjHistRequest = new DisputePayableAdjustmentHistory();
            DisputePayableAdjustmentHistory disPayAdjHistResult = new DisputePayableAdjustmentHistory();

            // Dummy Data used
            int dummyDisputePayableAdjustmentHistoryIdFromUI = 180; //this is ID nneed to sent by UI, currently ID in adjusted mode and has record number more than 0, read for dummy purpose
            int dummyOrderHirarchyIdFromUI = 1956; //

            disPayAdjHistRequest.ApplicationId = 10016;
            disPayAdjHistRequest.VendorAdjComments = "User Entered Comment";
            disPayAdjHistRequest.VendorOneTimeFee = 10;
            disPayAdjHistRequest.VendorOneTimeFeeAdjstdAmt = 2;
            disPayAdjHistRequest.VendorTripFee = 20;
            disPayAdjHistRequest.VendorTripFeeAdjstdAmt =4;
            disPayAdjHistRequest.VendorMinServiceFee = 30;
            disPayAdjHistRequest.VendorMinServiceFeeAdjstdAmt = 5;
            disPayAdjHistRequest.RecordNumber = 1;
            disPayAdjHistRequest.DisputePayableAdjustmentHistoryId = dummyDisputePayableAdjustmentHistoryIdFromUI;

            disPayAdjHistResult = accountingService.SaveDisputePayableAdjustmentHistory(disPayAdjHistRequest);

            //Assert.IsNotNull(disPayAdjHistResult.AccountsReceivableAdjustments.FirstOrDefault(ara => ara.DisputePayableAdjustmentHistoryId == disRecAdjHistResult.DisputePayableAdjustmentHistoryId), "Record should be saved for newly adjusted history Id in adjustment table");            
            Assert.IsNotNull(disPayAdjHistResult, "Save Method should return saved (SaveDisputePayableAdjustmentHistory) Object");
            Assert.AreEqual(disPayAdjHistResult.VendorOneTimeFeeAdjstdAmt, disPayAdjHistRequest.VendorOneTimeFeeAdjstdAmt, "Save same value as of input object");
            Assert.AreEqual(disPayAdjHistResult.VendorMinServiceFeeAdjstdAmt, disPayAdjHistRequest.VendorMinServiceFeeAdjstdAmt, "Save same value as of input object");            
        }

        [TestMethod]
        [Ignore]

        public void GetMainDataRespectiveListForFeeTypeALL()
        {
            AdjustmentDetailResponse result = null;
            AdjustmentDetailRequest request = new AdjustmentDetailRequest() { UpdateGridType = "ALL", OrderId = 186486, PageSize = 100, SkipCount = 0, LoanID = null };
            result = accountingService.GetBillingAdjustmentLists(request);
            Assert.IsNotNull(result);
            
        }

        [TestMethod]
        [Ignore]
        public void GetMainDataRespectiveListForFeeTypeVendor()
        {
            AdjustmentDetailResponse result = null;
            AdjustmentDetailRequest request = new AdjustmentDetailRequest() { UpdateGridType = "VENDOR", OrderId = 186486, PageSize = 100, SkipCount = 0, LoanID = null };
            result = accountingService.GetBillingAdjustmentLists(request);
            Assert.IsNotNull(result.vendorFeeAdjustmentResponseList);
            Assert.IsNull(result.clientAdjustMentResponseList);

        }
        #region Supplier Dispute

        [TestMethod]
        [Ignore]
        public void Test_GetSupplierDisputeSearch()
        {
            BusinessSvcImpl.DataObjects.SpaAccountingService.Dto.GetSupplierDisputeSearchRequest request = new BusinessSvcImpl.DataObjects.SpaAccountingService.Dto.GetSupplierDisputeSearchRequest();
            request.SearchInput = new SupplierDisputeSearchInput();
            request.SearchInput.VendorId = 10008;
            request.PageSize = 100;
            request.SkipCount = 0;
            var response = accountingService.GetSupplierDisputeSearchResults(request);
            Assert.IsNotNull(response.SearchResults);
            Assert.AreNotEqual(response.SearchResults.Count, 0);
        }
        [TestMethod]
        [Ignore]
        public void Test_GetSupplierDisputeById()
        {
            var response = accountingService.GetSupplierDisputeById(1);
            Assert.IsNotNull(response.SupplierDispute);
        }
        [TestMethod]
        [Ignore]
        public void Test_Update_SaveSupplierDispute()
        {
            var response = accountingService.GetSupplierDisputeById(1);
            response.SupplierDispute.BulkId = response.SupplierDispute.BulkId + 1;
            SaveSupplierDisputeRequest request = new SaveSupplierDisputeRequest();
            // response.SupplierDispute.SupplierDisputeId = 0;
            request.SupplierDispute = response.SupplierDispute;
            var result = accountingService.SaveSupplierDispute(request);
            Assert.IsTrue(result.Result);
        }
        [TestMethod]
        [Ignore]
        public void Test_Add_SaveSupplierDispute()
        {
            var response = accountingService.GetSupplierDisputeById(1);
            response.SupplierDispute.BulkId = response.SupplierDispute.BulkId + 1;
            SaveSupplierDisputeRequest request = new SaveSupplierDisputeRequest();
            response.SupplierDispute.SupplierDisputeId = 0;
            request.SupplierDispute = response.SupplierDispute;
            var result = accountingService.SaveSupplierDispute(request);
            Assert.IsTrue(result.Result);
        }
        [TestMethod]
        [Ignore]
        public void Test_GetSupplierDisputeDocumentByDisputeId()
        {
            var response = accountingService.GetSupplierDisputeDocumentByDisputeId(1);
            Assert.AreNotEqual(response.DisputeDocuments.Count, 0);
        }

        [TestMethod]
        [Ignore]
        public void Test_Add_SaveSupplierDisputeDocument()
        {
            SaveSupplierDisputeDocumentRequest request = new SaveSupplierDisputeDocumentRequest();
            request.DisputeDocument = new SupplierDisputeDocument()
                                    {
                                        DocumentId = 70,
                                        CreatedById = 1001,
                                        CreatedDate = DateTime.Now,
                                        SupplierDisputeId = 1
                                    };
            var result = accountingService.SaveSupplierDisputeDocument(request);
            Assert.IsTrue(result.Result);

        }
        [TestMethod]
        [Ignore]
        public void Test_Update_SaveSupplierDisputeDocument()
        {
            var response = accountingService.GetSupplierDisputeDocumentByDisputeId(1);
            SaveSupplierDisputeDocumentRequest request = new SaveSupplierDisputeDocumentRequest();
            response.DisputeDocuments[0].DocumentId = 73;
            request.DisputeDocument = response.DisputeDocuments[0];
            var result = accountingService.SaveSupplierDisputeDocument(request);
            Assert.IsTrue(result.Result);
        }
        [TestMethod]
        [Ignore]
        public void Test_GetSupplierDisputeFollowupByDisputeId()
        {
            var response = accountingService.GetSupplierDisputeFollowupByDisputeId(1);
            Assert.AreNotEqual(response.DisputeFollowups.Count, 0);
        }
        [TestMethod]
        [Ignore]
        public void Test_Add_SaveSupplierDisputeFollowup()
        {
            SaveSupplierDisputeFollowupRequest request = new SaveSupplierDisputeFollowupRequest();
            request.DisputeFollowups = new List<SupplierDisputeFollowup>();
            request.DisputeFollowups.Add(new SupplierDisputeFollowup()
            {
                CreatedById = 1001,
                CreatedDate = DateTime.Now,
                SupplierDisputeId = 2,
                FollowupAssignDate = DateTime.Now,
                FollowupCompleteDate = DateTime.Now.AddDays(1),
                Modified = true
            });
            var result = accountingService.SaveSaveSupplierDisputeFollowup(request);
            Assert.IsTrue(result.Result);
        }
        [TestMethod]
        [Ignore]
        public void Test_Update_SaveSupplierDisputeFollowup()
        {
            SaveSupplierDisputeFollowupRequest request = new SaveSupplierDisputeFollowupRequest();
            request.DisputeFollowups = new List<SupplierDisputeFollowup>();
            request.DisputeFollowups.Add(new SupplierDisputeFollowup()
            {
                CreatedById = 1001,
                CreatedDate = DateTime.Now,
                SupplierDisputeId = 2,
                FollowupAssignDate = DateTime.Now,
                FollowupCompleteDate = DateTime.Now.AddDays(1),
                Modified = true
            });
            var response = accountingService.GetSupplierDisputeFollowupByDisputeId(1);
            response.DisputeFollowups[0].AssignedToUserId = 1123;
            response.DisputeFollowups[0].Modified = true;
            request.DisputeFollowups.Add(response.DisputeFollowups[0]);
            var result = accountingService.SaveSaveSupplierDisputeFollowup(request);
            Assert.IsTrue(result.Result);
        }
        [TestMethod]
        [Ignore]
        public void Test_GetSupplierDisputeEscalationByDisputeId()
        {
            var response = accountingService.GetSupplierDisputeEscalationByDisputeId(1);
            Assert.AreNotEqual(response.SupplierDisputeEscalations.Count, 0);
        }
          [TestMethod]
          [Ignore]
        public void TestGetSpentToDateByLoanId() {
          var result=  accountingService.GetSpentToDateByLoanId(98323);

        }

        //[TestMethod]
        //[Ignore]
        //public void discTest()
        //{
        //    var ls = new AccountingRepository().GetDiscountAdjustmentDetail(99, 17660);
        //}

        [TestMethod]
        [Ignore]
        public void Test_Save_SaveSupplierDisputeEscalation()
        {
            SaveSupplierDisputeEscalationRequest request = new SaveSupplierDisputeEscalationRequest();
            request.SupplierDisputeEscalations = new List<SupplierDisputeEscalation>();
            request.SupplierDisputeEscalations.Add(new SupplierDisputeEscalation()
            {
                CreatedById = 1001,
                CreatedDate = DateTime.Now,
                SupplierDisputeId = 1,
                Modified = true,
                AssignedToUserId = 1123,
                EscalationAssignDate = DateTime.Now,
                EscalationCompleteDate = DateTime.Now.AddDays(1),
            });
            var result = accountingService.SaveSupplierDisputeEscalation(request);
            Assert.IsTrue(result.Result);
        }
        [TestMethod]
        [Ignore]
        public void Test_Update_SaveSupplierDisputeEscalation()
        {
            SaveSupplierDisputeEscalationRequest request = new SaveSupplierDisputeEscalationRequest();
            request.SupplierDisputeEscalations = new List<SupplierDisputeEscalation>();
            request.SupplierDisputeEscalations.Add(new SupplierDisputeEscalation()
            {
                CreatedById = 1001,
                CreatedDate = DateTime.Now,
                SupplierDisputeId = 2,
                Modified = true,
                AssignedToUserId = 1123,
                EscalationAssignDate = DateTime.Now,
                EscalationCompleteDate = DateTime.Now.AddDays(1),
            });
            var response = accountingService.GetSupplierDisputeEscalationByDisputeId(1);
            response.SupplierDisputeEscalations[0].AssignedToUserId = 1220;
            response.SupplierDisputeEscalations[0].Modified = true;
            request.SupplierDisputeEscalations.Add(response.SupplierDisputeEscalations[0]);
            var result = accountingService.SaveSupplierDisputeEscalation(request);
            Assert.IsTrue(result.Result);
        }
        #endregion
    }
}
