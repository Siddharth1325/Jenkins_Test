﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Transactions;
using BusinessSvcImpl.SvcImpl.SpaAcc;
using BusinessSvcImpl.DataObjects.SpaAccounting.Dto;
using CommonLib.Context;
using System.Linq;
using DataAccess.Accounting;
using BusinessSvcImpl.DataObjects.SpaAccountingService.Dto;

namespace AccountingTest
{
    [TestClass]
    class AccountingServiceTest
    {
        TransactionScope transScope;
        SpaAccountingService accountingService;
        ApplicationContext appContext;

        [TestInitialize]
        public void TestInitialize()
        {
            accountingService = new SpaAccountingService();
            transScope = new TransactionScope();
            appContext = GetUserContext();
        }
        private ApplicationContext GetUserContext()
        {
            appContext = ApplicationContext.Instance;
            if (appContext != null && appContext.UserContext == null)
            {
                UserContext userContext = new UserContext() { FirstName = "Administrator", IsActive = true, LastName = "Administrator", UserId = 1001, UserName = "Administrator", ApplicationId = 10016, TenantHierarchyId = "57F9B2BD-21BA-4028-AAC8-A382FE62B95A" };

                appContext.UserContext = userContext;
            }
            return appContext;
        }
        [TestMethod]
        [Ignore]
        public void Test_GetSupplierDisputeSearch()
        {
            BusinessSvcImpl.DataObjects.SpaAccountingService.Dto.GetSupplierDisputeSearchRequest request = new BusinessSvcImpl.DataObjects.SpaAccountingService.Dto.GetSupplierDisputeSearchRequest();
            request.SearchInput = new SupplierDisputeSearchInput();
            request.SearchInput.VendorId = 10005;
            var  response = accountingService.GetSupplierDisputeSearchResults(request);
        }

        [TestMethod]
        [Ignore]
        public void GetInvoiceData()
        {
           var result =  accountingService.GetRRRInvoiceData(new GetRRRInvoiceDataRequest() { InvoiceExportId = 456 });
        }

        [TestMethod]
        [Ignore]
        public void GetInvoiceDecisionDetailView()
        {
            var result = accountingService.GetRRRInvoiceDecisionDetailsData(new GetRRRInvoiceDecisionDetailsDataRequest { RRRInvoiceJSONHeaderId = 38 });
        }

        [TestMethod]
        [Ignore]
        public void test_SaveInvoiceDecisionItemTracking()
        {
            RRRInvoiceDecisionItemTrackingRequest req = new RRRInvoiceDecisionItemTrackingRequest();
            req.RRRInvoiceDecisionItemTracking = new RRRInvoiceDecisionItemTracking
            {
                RRRInvoiceJSONDetailId = 37,
                DecisionInvoiceNo = 64123792,                
                SLFSDecision="AGREE",
                NewQuantity=1,
                NewItemPrice=150,
                NewItemSubtotal=150,
                NewItemTax=0,
                NewItemTotal=150,
                SLFSResponseToClient="Testing",
            };
            accountingService.SaveInvoiceDecisionTrackingDetails(req);
        }
       
    }
}
