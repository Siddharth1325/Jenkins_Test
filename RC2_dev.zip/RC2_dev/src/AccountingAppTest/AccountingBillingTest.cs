﻿using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using BusinessSvcImpl.SvcImpl.SpaAcc;
using BusinessSvcImpl.DataObjects.SpaAccountingService.Dto;
using AdminInvestorRM = Admin.ServiceProxy.InvestorService;
using CommonLib.Context;
using Delegate.SpaAcc;
using BusinessServices.ServiceLinkBilling;

namespace AccountingAppTest
{
    [TestClass]
    public class AccountingBillingTest
    {
        [TestInitialize]
        public void TestSetup()
        {
            GetUserContext();
        }
        private ApplicationContext GetUserContext()
        {
            ApplicationContext appContext = ApplicationContext.Instance;
            if (appContext.UserContext == null)
            {
                //TODO: get rid of hard codded value
                //for now copy over AppUser to userContext, will later remove user Context and use App user.
                UserContext userContext = new UserContext() { FirstName = "Administrator", IsActive = true, LastName = "Administrator", UserId = 1001, UserName = "Administrator" };

                appContext.UserContext = userContext;
            }
            return appContext;
        }
        public AccountingBillingTest()
        {
            log4net.Config.XmlConfigurator.Configure(new System.IO.FileInfo(AppDomain.CurrentDomain.BaseDirectory + "Log4Net.config"));
        }

        [TestMethod]
        [Ignore]
        public void test_generate_ap_ar()
        {
            var svc = new SpaAccountingService();
            var response = svc.CreateBillingForWorkOrder(new AccountingBillingRequest() { ApplicationCode = "FSDV1", WorkOrderId = 1200000030 });
            Assert.IsNotNull(response);
        }
        [TestMethod]
        [Ignore]
        public void TestVertexIntegration()
        {
            using (var txn = new System.Transactions.TransactionScope(System.Transactions.TransactionScopeOption.Required))
            {
                var svc = new SpaAccountingService();
                ApplicationContext.Instance.UserContext.TenantHierarchyId = "14E2BB4E-F2BE-4BF0-83E2-34CA323B61E8";
                var req = new CalculateVertexTaxRequest { AccountTaxBatchID = 197, TenantGuid = "14E2BB4E-F2BE-4BF0-83E2-34CA323B61E8" };
                svc.CalculateVertexTaxUsingTaxBatchId(req);
                txn.Complete();
            }
        }
        [TestMethod]
        [Ignore]
        public void Test_SearchIMStandardMapping()
        {
            var request = new GetIMStandardMappingRequest
            {
                ClientId = null,
                Products = new List<string> { "73", "81", "99" },
                //Products = new List<string>(),
                Services = null,
                LOBType = "INSPECT",
                LineItems = null,
                PageSize = 10,
                SkipCount = 10,

            };
            ApplicationContext.Instance.UserContext.TenantHierarchyId = "14E2BB4E-F2BE-4BF0-83E2-34CA323B61E8";
            var svc = new SpaAccountingService();
            var response = svc.SearchIMStandardMapping(request);
            Assert.IsNotNull(response);
        }

        [TestMethod]
        [Ignore]
        public void Test_BillSync()
        {
            ApplicationContext.Instance.UserContext.TenantHierarchyId = "57F9B2BD-21BA-4028-AAC8-A382FE62B95A";
            new BpmServiceLinkBillingService().BpmBillingSync(new BpmBillingSyncRequest() { WorkOrderId = 1200167716, TenantGuid= "57F9B2BD-21BA-4028-AAC8-A382FE62B95A" });
            new BpmServiceLinkBillingService().BpmBillingSync(new BpmBillingSyncRequest() { WorkOrderId = 1200167717, TenantGuid = "57F9B2BD-21BA-4028-AAC8-A382FE62B95A" });
        }

    }
}
