﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.ServiceModel;
using System.Runtime.Serialization;
using CommonLib.Context;

namespace AccountingAppTest
{
    [TestClass]
    public class TestRemmittanceSearch
    {
        [TestInitialize]
        public void TestSetup()
        {
            GetUserContext();
        }
        private ApplicationContext GetUserContext()
        {
            ApplicationContext appContext = ApplicationContext.Instance;
            if (appContext.UserContext == null)
            {
                //TODO: get rid of hard codded value
                //for now copy over AppUser to userContext, will later remove user Context and use App user.
                UserContext userContext = new UserContext() { FirstName = "Administrator", IsActive = true, LastName = "Administrator", UserId = 1001, UserName = "Administrator" };

                appContext.UserContext = userContext;
            }
            return appContext;
        }
     //   [TestMethod]
        public void TestMethod1()
        {
           

        }


       
        public void TestGenericRepo()
        {

        }
    }
}
