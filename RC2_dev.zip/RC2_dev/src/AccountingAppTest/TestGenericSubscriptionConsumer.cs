﻿using Accounting.ServiceProxy.ComInt;
using CommonLib.Context;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;
using System.Xml;

namespace AccountingAppTest
{
    [TestClass]
    public class TestGenericSubscriptionConsumer
    {
        [TestInitialize]
        public void TestSetup()
        {
            GetUserContext();
        }
        private ApplicationContext GetUserContext()
        {
            ApplicationContext appContext = ApplicationContext.Instance;
            if (appContext.UserContext == null)
            {
                //TODO: get rid of hard codded value
                //for now copy over AppUser to userContext, will later remove user Context and use App user.
                UserContext userContext = new UserContext() { FirstName = "Administrator", IsActive = true, LastName = "Administrator", UserId = 1001, UserName = "Administrator" };

                appContext.UserContext = userContext;
            }
            return appContext;
        }

        [TestMethod]
        [Ignore]

        public void test_get_workorder_byworkorderid_GenericRepo()
        {
            CommonLib.Persistence.GenericRepo<DataAccess.Accounting.AccountingData> repo = new CommonLib.Persistence.GenericRepo<DataAccess.Accounting.AccountingData>();


            var wo = repo.GetEntityByKeys<DomainModel.Accounting.WorkOrder>(new DomainModel.Accounting.WorkOrder() { ApplicationId = 1001, SourceWorkOrderId = 1200000001 });

            string Test = "Test";


        }

        [TestMethod]
        [Ignore]
        public void TestGenericConsumer()
        {

            Random Rnd = new Random();
           var i = Rnd.Next(1000, 3000);

            //CommonIntSvcProxy proxy = new CommonIntSvcProxy();

            CommonIntSvcProxy.submitMessage();

           using (TransactionScope scope = new TransactionScope())
           {
               CommonLib.Messaging.Ict.EntityUpdate dto = new CommonLib.Messaging.Ict.EntityUpdate();

               dto.EntityName = "DataAccess.ClientProfile";
               string PayLoad = @"C:\ProjectWorks\FieldServices\Accounting\Dev4\src\AccountingAppTest\SubscriptionUpdates\OrderEntity.xml";
               XmlDocument doc = new XmlDocument();
               doc.Load(PayLoad);

               var Message = new CommonLib.Messaging.Ict.PlatformMqMessage();
               Message = CommonLib.Util.RelectionUtils.GetObjectFromXml<CommonLib.Messaging.Ict.PlatformMqMessage>(doc);

               IntCommonSvcLib.Service.Impl.IntegrationCommonSvcImpl svc = new IntCommonSvcLib.Service.Impl.IntegrationCommonSvcImpl();

               svc.Process(Message);

               scope.Complete();
           }


        }
    }
}
