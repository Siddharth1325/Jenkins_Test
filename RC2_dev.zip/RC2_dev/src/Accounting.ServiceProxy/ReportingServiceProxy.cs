﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Accounting.ServiceProxy.ReportingSvc;
using System.Text.RegularExpressions;

namespace Accounting.ServiceProxy
{
    public class ReportingServiceProxy
    {
        private readonly string _userName;
        private readonly string _password;
        private readonly string _domain;

        public ReportingServiceProxy(string userName, string password, string domain)
        {
            if (userName == null) throw new ArgumentNullException("userName");
            if (password == null) throw new ArgumentNullException("password");
            if (domain == null) throw new ArgumentNullException("domain");

            _userName = userName;
            _password = password;
            _domain = domain;
        }

        public List<Report> GetReports(string applicationId)
        {
            var req = new GetReportsRequest
            {
                ApplicationId = applicationId,
                ReportFolderPath = "/"
            };

            GetReportsResponse result;
            using (var clnt = ConfigureClient())
            {
                result = clnt.GetReports(req);
            }
            return result.Reports.ToList();
        }

        public List<ReportParameter> GetReportParameters(string reportPath, string applicationId)
        {
            if (reportPath == null) throw new ArgumentNullException("reportPath");

            var request = new GetReportParametersRequest
            {
                ApplicationId = applicationId,
                ReportPath = reportPath,
            };

            return RunGetReportParameters(request);
        }

        public List<ReportParameter> GetReportParameters(string reportPath, string applicationId, string parentName,
            string parentValue)
        {
            if (reportPath == null) throw new ArgumentNullException("reportPath");

            var request = new GetReportParametersRequest
            {
                ApplicationId = applicationId,
                ReportPath = reportPath,
                ParameterValues = new[]
                {
                    new ParameterValue {Name = parentName, Value = parentValue}
                }
            };

            return RunGetReportParameters(request);
        }

        public QueueReportResponse GenerateReport(QueueReportRequest request)
        {
            var regex = new Regex("(;)\\1+");
            if (request.ReportParamaters != null)
            request.ReportParamaters = regex.Replace(request.ReportParamaters.TrimStart(new char[] { ';' }), ";");

            using (var client = ConfigureClient())
            {
                return client.QueueReport(request);
            }
        }

        public List<ReportQueue> GetReportsStatus(ReportStatusCheckEnum statusType, string applicationId, string userId)
        {
            var request = new GetReportQueuesRequest
            {
                ApplicationId = applicationId,
                ReportStatusCheckType = statusType,
                UserId = userId
            };

            GetReportQueuesResponse result;
            using (var client = ConfigureClient())
            {
                result = client.GetReportQueues(request);
            }

            return result.ReportQueues.ToList();

        }

        public List<ReportQueue> CheckStatus(int queueId, int applicationId)
        {
            //            var request = new CheckStatusRequest
            //            {
            //                ApplicationId = applicationId.ToString(),
            //                ReportQueueId = queueId
            //            };

            //            return result.ReportQueues.ToList();
            throw new NotImplementedException("IMPLEMENT ME");
        }
        
        private List<ReportParameter> RunGetReportParameters(GetReportParametersRequest request)
        {
            GetReportParametersResponse result;
            using (var client = ConfigureClient())
            {
                result = client.GetReportParameters(request);
            }

            return result.ReportParameters.ToList();
        }

        public CheckStatusResponse GetReport(int reportQueueId, string appId, string userId)
        {
            var request = new CheckStatusRequest
            {
                ApplicationId = appId,
                ReportQueueId = reportQueueId,
                IncludeContent = true,
                UserId = userId
            };

            using (var client = ConfigureClient())
            {
                return client.CheckStatus(request);
            }
        }

        private ReportingServiceClient ConfigureClient()
        {
            //TODO put these fields into config.
            var clnt = new ReportingServiceClient();
            clnt.ClientCredentials.Windows.ClientCredential.UserName = _userName;
            clnt.ClientCredentials.Windows.ClientCredential.Password = _password;
            clnt.ClientCredentials.Windows.ClientCredential.Domain = _domain;
            clnt.ClientCredentials.Windows.AllowedImpersonationLevel =
                System.Security.Principal.TokenImpersonationLevel.Impersonation;

            return clnt;
        }

    }
}
