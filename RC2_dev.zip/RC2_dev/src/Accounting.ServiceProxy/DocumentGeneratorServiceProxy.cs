﻿using System;
using Accounting.ServiceProxy.DocumentGeneratorService;

namespace Accounting.ServiceProxy
{
    public static class DocumentGeneratorServiceProxy
    {
        public static GenerateDocumentResponse GenerateDocument(GenerateDocumentRequest request)
        {
            if (request.Metadata == null) return null;

            GenerateDocumentResponse response;

            using (var serviceClient = new DocumentGeneratorServiceClient())
            {
                response = serviceClient.GenerateDocument(request);
            }

            return response;
        }


        public static DocumentStatusResponse IsAvaliable(IsDocumentReadyRequest request)
        {
            DocumentStatusResponse response;

            using (var serviceClient = new DocumentGeneratorServiceClient())
            {
                response = serviceClient.IsAvaliable(request);
            }

            return response;
        }
    }
}
