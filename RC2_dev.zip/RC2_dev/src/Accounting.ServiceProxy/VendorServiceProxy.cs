﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Accounting.ServiceProxy.VendorSvc;

namespace Accounting.ServiceProxy
{
    public static class VendorServiceProxy
    {
        //  GetVendorInfoById
        public static VendorProfile1 GetVendorInfoById(int vendorId)
        {
            using (VMServiceClient client = new VMServiceClient())
            {
                GetVendorProfileRequest request = new GetVendorProfileRequest()
                {
                    VendorId = vendorId,
                    vpCollection = VendorProfileCollection.None
                };
               
                GetVendorProfileResponse response = client.GetVendorDetails(request);

                return response.VendorProfileInfo;
            }
        }

        public static VendorProfile1 GetVendorUserInformation(string appUserId)
        {
            using (VMServiceClient client = new VMServiceClient())
            {

                GetVendorUserResponse response = client.GetVendorUserInformation(int.Parse(appUserId));
                if (response != null && response.vendorProfile != null && response.vendorProfile.Count() > 0)
                    return response.vendorProfile[0];
                else
                   return null;
                
            }
        }
        public static GetVendorProfilesResponse GetVendorProfiles()
        {
            using (VMServiceClient client = new VMServiceClient())
            {
                GetVendorProfilesResponse response = client.GetVendorProfiles();
                return response;
           
            }
        }

    }
}
