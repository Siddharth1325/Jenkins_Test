﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Accounting.ServiceProxy.AccountingSvc;


namespace Accounting.ServiceProxy
{
    public static class AccountingServiceProxy
    {
        public static GetOrderSearchResponse GetOrderSearchResults(GetOrderSearchRequest request)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                //GetOrderSearchRequest request = new GetOrderSearchRequest();
                //request.SearchInput = orderDto;


                return serviceClient.GetOrderSearchResults(request);
            }
        }

        # region Dispute

        public static GetDisputeSearchResponse GetDisputeSearchResults(GetDisputeSearchRequest request)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                return serviceClient.GetDisputeSearchResults(request);
            }
        }

        public static GetInvoiceDecisionSearchResponse GetInvoiceDecisionSearchResults(GetInvoiceDecisionSearchRequest request)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                return serviceClient.GetInvoiceDecisionSearchResults(request);
            }
        }

        public static UpdateRRRHeaderInternalStatusResponse UpdateRRRHeaderInternalStatus(UpdateRRRHeaderInternalStatusRequest request)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                return serviceClient.UpdateRRRHeaderInternalStatus(request);
            }
        }

        public static GetAccountingDisputeResponse GetAccountingDisputeById(int disputeId)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                return serviceClient.GetAccountingDisputeById(disputeId);
            }
        }

        public static SaveAccountingDisputeResponse SaveAccountingDispute(SaveAccountingDisputeRequest request)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                return serviceClient.SaveAccountingDispute(request);
            }
        }

        public static SaveVendorDisputeCommentsResponse SaveVendorDisputeComments(SaveVendorDisputeCommentsRequest request)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                return serviceClient.SaveVendorDisputeComments(request);
            }
        }

        public static GetDisputeDocumentResponse GetDisputeDocumentByDisputeId(int disputeId)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                return serviceClient.GetDisputeDocumentByDisputeId(disputeId);
            }
        }

        public static SaveDisputeDocumentResponse SaveDisputeDocument(SaveDisputeDocumentRequest request)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                return serviceClient.SaveDisputeDocument(request);
            }
        }


        public static SaveDisputeFollowupResponse SaveDisputeFollowUp(SaveDisputeFollowupRequest request)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                return serviceClient.SaveDisputeFollowup(request);
            }
        }

        public static GetDisputeFollowupResponse GetDisputeFollowUpByDisputeId(int disputeId)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                return serviceClient.GetDisputeFollowUpByDisputeId(disputeId);
            }
        }



        #endregion
        public static GetAccountsPayableByWorkOrderIdResponse GetAccountingWorkOrderPayables(int workOrderId, CommonEnumsAccountsPayableChild childEnum)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                GetAccountsPayableByWorkOrderIdRequest request = new GetAccountsPayableByWorkOrderIdRequest()
                {
                    WorkOrderId = workOrderId,
                    ChildEnum = childEnum
                };

                return serviceClient.GetAccountsPayableByWorkOrderId(request);
            }
        }


        public static GetARInvoiceDetailsResponse GetAccountingReceivablesInvoiceDetail(GetARInvoiceDetailsRequest request)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                return serviceClient.GetARInvoiceDetails(request);
            }
        }


        public static GetARInvoiceDetailsResponse GetAccountingReceivablesInvoiceDetailWithoutPaging(GetARInvoiceDetailsRequest request)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                return serviceClient.GetARInvoiceDetailsWithoutPaging(request);
            }
        }


      
        public static GetAPInvoiceDetailsResponse GetAccountingPayableInvoiceDetail(GetAPInvoiceDetailsRequest request)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                return serviceClient.GetAPInvoiceDetails(request);
            }
        }


        public static GetAPInvoiceDetailsResponse GetAccountingPayableInvoiceDetailWithoutPaging(GetAPInvoiceDetailsRequest request)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                return serviceClient.GetAPInvoiceDetailsWithoutPaging(request);
            }
        }



        public static GetAPDetailsResponse GetAPDetails(GetAPDetailsRequest request)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                return serviceClient.GetAPDetails(request);
            }
        }

        public static GetARDetailsResponse GetARDetails(GetARDetailsRequest request)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                return serviceClient.GetARDetails(request);
            }
        }
        public static GetAccountsReceivableByWorkOrderIdResponse GetAccountingWorkOrderReceivables(int workOrderID, CommonEnumsAccountsReceivableChild childEnum)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                GetAccountsReceivableByWorkOrderIdRequest request = new GetAccountsReceivableByWorkOrderIdRequest()
                {
                    WorkOrderId = workOrderID,
                    ChildEnum = childEnum
                };

                return serviceClient.GetAccountsReceivableByWorkOrderId(request);
            }
        }

        public static GetAPAdjustmentDetailViewResponse GetApAdjustmentDetailViewById(int vendorWorkOrderId, int workOrderId)
        {

            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                GetAPAdjustmentDetailViewRequest request = new GetAPAdjustmentDetailViewRequest()
                {
                    WorkOrderId = workOrderId,
                    VendorWorkOrderId = vendorWorkOrderId
                };

                return serviceClient.GetApAdjustmentDetailViewById(request);
            }
        }

        public static GetARAdjustmentDetailViewResponse GetARAdjustmentDetailViewById(int orderId, int workOrderId)
        {

            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                GetARAdjustmentDetailViewRequest request = new GetARAdjustmentDetailViewRequest()
                {
                    WorkOrderId = workOrderId,
                    OrderId = orderId
                };

                GetARAdjustmentDetailViewResponse response = new GetARAdjustmentDetailViewResponse();

                return serviceClient.GetARAdjustmentDetailViewById(request);
            }
        }

        public static SaveAdjustmentCodeResponse SaveAccountingAdjustmentsCode(AccountingAdjustmentCode saveInput)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                SaveAdjustmentCodeRequest request = new SaveAdjustmentCodeRequest();
                request.AccountingAdjustmentCode = saveInput;
                return serviceClient.SaveAccountingAdjustmentsCode(request);
            }
        }

        public static GetAdjustmentCodeResponse GetAccountingAdjustmentsCode(int accountingAdjustmentCodeID)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                GetAdjustmentCodeRequest request = new GetAdjustmentCodeRequest()
                {
                    AccountingAdjustmentCodeIdk__BackingField = accountingAdjustmentCodeID
                };
                return serviceClient.GetAccountingAdjustmentsCode(request);
            }
        }

        public static SearchAdjustmentCodeResponse SearchAccountingAdjustmentsCode(SearchAdjustmentCodeRequest request)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                // SearchAdjustmentCodeRequest request = new SearchAdjustmentCodeRequest { SearchInputk__BackingField = filter };
                return serviceClient.SearchAccountingAdjustmentsCode(request);
            }
        }

        public static GetAdjustmentCodesResponse GetDistinctAccoutingAdjustmentCodes(GetAdjustmentCodesRequest request)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                return serviceClient.GetDistinctAccoutingAdjustmentCodes(request);
            }
        }

        public static SaveGLCodeResponse SaveGLCode(SaveGLCodeRequest saveGLCoderequest)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                SaveGLCodeResponse response = serviceClient.SaveGLCode(saveGLCoderequest);

                return response;
            }
        }

        public static SearchAccountingGLCodeResponse SearchAccountingGLCode(SearchAccountingGLCodeRequest accounttingGLCodeRequest)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                SearchAccountingGLCodeResponse serviceResponse = serviceClient.SearchAccountingGLCode(accounttingGLCodeRequest);

                return serviceResponse;
            }
        }

        public static GetGLCodeByIdResponse GetAccountingGLCodeById(GetGLCodeByIdRequest glCodeRequest)
        {

            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                GetGLCodeByIdResponse serviceResponse = serviceClient.GetGLCodeById(glCodeRequest);
                return serviceResponse;
            }
        }

        public static GetAccountsReceivableInvoiceResponse GetAccountsReceivableInvoice(GetAccountsReceivableInvoiceRequest invoiceRequest)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                return serviceClient.GetAccountsReceivableInvoice(invoiceRequest);
            }
        }

        public static GetRemittanceSearchResponse GetRemittanceSearchResults(GetRemittanceSearchRequest getSearchResultsRequestDto)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                return serviceClient.GetRemittanceSearchResults(getSearchResultsRequestDto);
            }
        }

        public static AccountingBillingResponse CreateBillingForWorkOrder(AccountingBillingRequest request)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                return serviceClient.CreateBillingForWorkOrder(request);
            }
        }

        public static GetAccountsPayableInvoiceResponse GetAccountsPayableInvoice(GetAccountsPayableInvoiceRequest serviceRequest)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                return serviceClient.GetAccountsPayableInvoice(serviceRequest);
            }
        }

        public static GetWorkOrderIdFromPayableInvoiceNumberResponse GetWorkOrderIdFromPayableInvoiceID(GetWorkOrderIdFromPayableInvoiceNumberRequest serviceRequest)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                return serviceClient.GetWorkOrderIdFromPayableInvoiceNumber(serviceRequest);
            }
        }

        public static GetWorkOrderIdFromReceivableInvoiceNumberResponse GetWorkOrderIdFromReceivableInvoiceID(GetWorkOrderIdFromReceivableInvoiceNumberRequest serviceRequest)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                return serviceClient.GetWorkOrderIdFromReceivableInvoiceNumber(serviceRequest);
            }
        }

        public static GetPayableDetailResponse GetPayableDetail(GetPayableDetailRequest serviceRequest)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                return serviceClient.GetPayableDetail(serviceRequest);
            }
        }

        public static GetIMClearMappingResponse SearchIMClearMapping(GetIMClearMappingRequest request)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                return serviceClient.SearchIMClearMapping(request);
            }
        }

        public static GetIMStandardMappingResponse SearchIMStandardMapping(GetIMStandardMappingRequest request)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                return serviceClient.SearchIMStandardMapping(request);
            }
        }

        public static GetIMChaseMappingResponse SearchIMChaseMapping(GetIMChaseMappingRequest request)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                return serviceClient.SearchIMChaseMapping(request);
            }
        }


        public static SaveIMStandardMappingResponse SaveIMStandardMapping(SaveIMStandardMappingRequest request)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                return serviceClient.SaveIMStandardMapping(request);
            }
        }

        public static GetIMStandardMappingIdResponse GetIMStandardMappingById(GetIMStandardMappingIdRequest request)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                return serviceClient.GetIMStandardMappingById(request);
            }
        }


        public static GetAllInvestorProfileResponse GetAllInvestorProfile()
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                return serviceClient.GetAllInvestorProfile();
            }
        }

        public static SaveIMChaseMappingResponse SaveIMChaseMapping(SaveIMChaseMappingRequest request)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                return serviceClient.SaveIMChaseMapping(request);
            }
        }

        public static GetIMChaseMappingIdResponse GetIMChaseMappingById(GetIMChaseMappingIdRequest request)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                return serviceClient.GetIMChaseMappingById(request);
            }
        }

        public static IClearLSCIMappingResponse SaveLSCIMapping(IClearLSCIMappingRequest request)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                return serviceClient.SaveLSCIMapping(request);
            }
        }

        public static IClearMBAMappingResponse SaveMBAMapping(IClearMBAMappingRequest request)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                return serviceClient.SaveMBAMapping(request);
            }
        }

        public static IClearProductMappingResponse SaveProdMapping(IClearProductMappingRequest request)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                return serviceClient.SaveProdMapping(request);
            }
        }


        public static GetIClearMappingResponse GetIClinetMapping(GetIClearMappingdRequest request)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                return serviceClient.GetIClinetMapping(request);
            }
        }

        public static DeleteIMStandardMappingResponse DeleteIMStandardMapping(DeleteIMStandardMappingRequest request)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                return serviceClient.DeleteIMStandardMapping(request);
            }
        }

        public static DeleteIMChaseMappingResponse DeleteIMChaseMapping(DeleteIMChaseMappingRequest request)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                return serviceClient.DeleteIMChaseMapping(request);
            }
        }

        public static DeleteIClearMappingResponse DeleteIClearMapping(DeleteIClearMappingRequest request)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                return serviceClient.DeleteIClearMapping(request);
            }
        }

        public static WorkOrder GetWorkOrderById(int workOrderId)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                GetWorkOrderRequest request = new GetWorkOrderRequest()
                {

                    WorkOrderId = workOrderId
                };

                GetWorkOrderResponse response = serviceClient.GetWorkOrderById(request);

                if (response.WorkOrder == null)
                    return null;

                return response.WorkOrder;
            }
        }

        public static WorkOrder GetWorkOrderBySrcId(int srcWorkOrderId)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                GetSourceWorkOrderRequest request = new GetSourceWorkOrderRequest()
                {

                    SourceWorkOrderId = srcWorkOrderId
                };

                GetWorkOrderResponse response = serviceClient.GetWorkOrderBySrcId(request);

                if (response.WorkOrder == null)
                    return null;

                return response.WorkOrder;
            }
        }

        public static GetWorkOrderResponse GetWorkOrderResponseBySrcId(int srcWorkOrderId, string type)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                var request = new GetSourceWorkOrderRequest(){SourceWorkOrderId = srcWorkOrderId,Type= type};

                GetWorkOrderResponse response = serviceClient.GetWorkOrderBySrcId(request);

                return response;
            }
        }
        public static GetBulkExceptionResponse GetImportExceptions(GetImportBulkExceptionRequest request)
        {
            using (SpaAccountingServiceClient client = new SpaAccountingServiceClient())
            {
                GetBulkExceptionResponse response = client.GetImportBulkException(request);

                return response;
            }
        }

        public static List<WorkOrder> GetWorkOrderDetailsByIdList(List<int> workOrderIdList)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                GetWorkOrderDetailsByIdsRequest request = new GetWorkOrderDetailsByIdsRequest()
                {
                    WorkOrderIdList = workOrderIdList.ToArray()
                };

                GetWorkOrderDetailsByIdsResponse response = serviceClient.GetWorkOrderDetailsByIds(request);

                if (response != null)
                    return new List<WorkOrder>(response.WorkOrderList);
            }

            return null;
        }

        public static WorkOrder GetFullWorkOrderById(int workOrderId)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                GetWorkOrderRequest request = new GetWorkOrderRequest()
                {
                    WorkOrderId = workOrderId
                };

                GetWorkOrderResponse response = serviceClient.GetFullWorkOrderById(request);

                if (response != null)
                    return response.WorkOrder;
            }

            return null;
        }

        public static GetFeeTypeResponse GetFeeTypeList()
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                GetFeeTypeResponse response = new GetFeeTypeResponse();
                response = serviceClient.GetFeeTypeList();
                return response;
            }

        }
        public static GetProductFeeTypeResponse GetProductFeeTypeList(ProductFeeTypeRequest request)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                GetProductFeeTypeResponse response = new GetProductFeeTypeResponse();
                response = serviceClient.GetProductFeeTypeList(request);
                return response;
            }

        }
        public static ApInvoiceSummaryViewResponse GetAPInvoiceDetailSummary(GetAccountsPayableInvoiceRequest request)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                ApInvoiceSummaryViewResponse response = new ApInvoiceSummaryViewResponse();
                response = serviceClient.GetAPInvoiceDetailSummary(request);
                return response;
            }
        }

        public static CostingInfoResponse GetAccountingCostingInfo(CostingInfoRequest request)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                CostingInfoResponse response = new CostingInfoResponse();
                response = serviceClient.GetAccountingCostingInfo(request);
                return response;
            }
        }

        public static GetStateTaxConfigurationResponse GetStateTaxConfiguration(GetStateTaxConfigurationRequest request)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                GetStateTaxConfigurationResponse response = new GetStateTaxConfigurationResponse();
                response = serviceClient.GetStateTaxConfiguration(request);
                return response;
            }
        }
        public static SaveStateTaxConfigurationResponse SaveStateTaxConfiguration(SaveStateTaxRequest request)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                SaveStateTaxConfigurationResponse response = new SaveStateTaxConfigurationResponse();
                response = serviceClient.SaveStateTaxConfiguration(request);
                return response;
            }
        }

        public static GetAccountsTaxResponse SearchGetAccountsTax(GetAccountsTaxRequest request)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                GetAccountsTaxResponse response = new GetAccountsTaxResponse();
                response = serviceClient.GetAccountsTax(request);
                return response;

            }
        }
        public static GetVPRGenInformationResponse GetVPRGenInformation()
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                GetVPRGenInformationResponse response = new GetVPRGenInformationResponse();
                response = serviceClient.GetVPRGenInformation();
                return response;
            }
        }
       
        public static void CalculateTax(CalculateVertexTaxRequest request)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                serviceClient.CalculateVertexTaxUsingTaxBatchId(request);
            }
        }
    

        public static GetVendorDisputeCommentsResponse GetVendorDisputeComments(int AccountingDisputeId)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                return serviceClient.GetVendorDisputeComments(AccountingDisputeId);
            }
        }

        public static void MoveFile(int documentId, string fileType)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                serviceClient.MoveFile(documentId, fileType);
            }
        }

        // For Sake of removing Errors

        public static List<CronologicalAdjustmentListResponse> GetCronologicalAdjustmentlist(AdjustmentDetailRequest request)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                return serviceClient.GetCronologicalAdjustmentList(request).ToList();
            }
        }

        public static AdjustmentDetailResponse GetAdjustmentLists(AdjustmentDetailRequest request)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                return serviceClient.GetBillingAdjustmentLists(request);
            }
        }

        public static PrdSrvMainDataResponse GetPrdSrvMainData(PrdSrvMainDataRequest request)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                return serviceClient.GetPrdSrvMainData(request);
            }
        }

        public static FeeAdjustmentDetailResponse GetFeeAdjustmentDetails(FeeAdjustmentDetailRequest request)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                return serviceClient.GetFeeAdjustmentDetails(request);
            }
        }

        public static DisputeReceivableAdjustmentHistory SaveDisputeReceivableAdjustmentHistory(DisputeReceivableAdjustmentHistory request)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                return serviceClient.SaveDisputeReceivableAdjustmentHistory(request);
            }
        }

        public static DisputePayableAdjustmentHistory SaveDisputePayableAdjustmentHistory(DisputePayableAdjustmentHistory request)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                return serviceClient.SaveDisputePayableAdjustmentHistory(request);
            }
        }
        public static bool SaveDisputeEntities(SaveDisputeEntitiesRequest request)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                return serviceClient.SaveDisputeEntities(request);
            }
        }


        public static WorkOrderSummaryARInvoiceResultResponse WorkOrderSummaryARInvoiceSearch(int workOrderId)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                return serviceClient.WorkOrderSummaryARInvoiceSearch(workOrderId);
            }
        }

        public static WorkOrderSummaryAPInvoiceResultResponse WorkOrderSummaryAPInvoiceSearch(int workOrderId)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                return serviceClient.WorkOrderSummaryAPInvoiceSearch(workOrderId);
            }
        }

        public static bool IsAdjustmentExists(int sourceOrderId)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                return serviceClient.IsAdjustmentExists(sourceOrderId);
            }
        }

        public static ApTraceResponse GetApTrace(int workOrderId)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                return serviceClient.GetApTrace(workOrderId);
            }
        }


        public static ArTraceResponse GetArTrace(int workOrderId)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                return serviceClient.GetArTrace(workOrderId);
            }
        }

        public static bool IsDocumentAccessible(int documentId)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                return serviceClient.IsDocumentAccessible(documentId);
            }
        }
        public static bool IsSupplierDisputeDocumentAccessible(int documentId)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                return serviceClient.IsSupplierDisputeDocumentAccessible(documentId);
            }
        }

        public static SaveNewCheckResponse SaveNewCheck(SaveNewCheckRequest request)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                return serviceClient.SaveNewCheck(request);
            }
        }


        public static RejectCheckResponse RejectCheck(RejectCheckRequest request)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                return serviceClient.RejectCheck(request);
            }
        }


        public static CheckDeliveryConfirmationResponse SaveCheckDeliveryConfirmation(CheckDeliveryConfirmationRequest request)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                return serviceClient.SaveCheckDeliveryConfirmation(request);
            }
        }

        public static CheckLogSearchResponse FtvCheckLogSearch(CheckLogSearchRequest searchRequest)
        {

            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                return serviceClient.FtvCheckLogSearch(searchRequest);
            }

        }

        public static CheckLogSearchExportResponse FtvCheckLogSearchExport(CheckLogSearchRequest searchRequest)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                return serviceClient.FtvCheckLogSearchExport(searchRequest);
            }
        }


        public static SaveCheckInformationResponse SaveBasicCheckInfo(SaveCheckInformationRequest request)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                return serviceClient.SaveBasicCheckInfo(request);
            }

        }

        public static PayeeDetailResponse GetPayeeList(PayeeDetailsRequest request)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                return serviceClient.GetPayeeList(request);
            }
        }
        public static GetSupplierDisputeSearchResponse GetSupplierDisputeSearchResults(GetSupplierDisputeSearchRequest request)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                return serviceClient.GetSupplierDisputeSearchResults(request);
            }
        }

        public static bool AssignUserToSupplierDisputes(AssignUserToSupplierDisputesRequest request)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                return serviceClient.AssignUserToSupplierDisputes(request);                    
                   
            }
        }

        public static bool SaveVendorEscalation(SaveVendorEscalationRequest request)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                return serviceClient.SaveVendorEscalation(request);

            }
        }

        public static bool DeleteSupplierDisputeDocument(int supplierDisputeDocumentId)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                return serviceClient.DeleteSupplierDisputeDocument(supplierDisputeDocumentId);

            }
        }

        public static GetSupplierDisputeResponse GetSupplierDisputeById(int disputeId)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                return serviceClient.GetSupplierDisputeById(disputeId);

            }
        }
        public static SaveSupplierDisputeResponse SaveSupplierDispute(SaveSupplierDisputeRequest request)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                return serviceClient.SaveSupplierDispute(request);

            }
        }
        public static SaveSupplierDisputeDocumentResponse SaveSupplierDisputeDocument(SaveSupplierDisputeDocumentRequest request)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                request.DisputeDocument.AdditionalDocumentType = request.DisputeDocument.AdditionalDocType;
                request.DisputeDocument.AdditionalDocumentGroup="DOC";
                return serviceClient.SaveSupplierDisputeDocument(request);

            }
        }
        public static GetSupplierDisputeDocumentResponse GetSupplierDisputeDocumentByDisputeId(int disputeId)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                return serviceClient.GetSupplierDisputeDocumentByDisputeId(disputeId);

            }
        }
        public static GetSupplierDisputeFollowupResponse GetSupplierDisputeFollowupByDisputeId(int disputeId)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                return serviceClient.GetSupplierDisputeFollowupByDisputeId(disputeId);

            }
        }
        public static SaveSupplierDisputeFollowupResponse SaveSaveSupplierDisputeFollowup(SaveSupplierDisputeFollowupRequest request)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                return serviceClient.SaveSaveSupplierDisputeFollowup(request);

            }
        }
        public static GetSupplierDisputeEscalationResponse GetSupplierDisputeEscalationByDisputeId(int disputeId)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                return serviceClient.GetSupplierDisputeEscalationByDisputeId(disputeId);
            }
        }
        public static SaveSupplierDisputeEscalationResponse SaveSupplierDisputeEscalation(SaveSupplierDisputeEscalationRequest request)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                return serviceClient.SaveSupplierDisputeEscalation(request);
            }
        }
        public static GetRelatedSupplierDisputeResponse GetRelatedSupplierDispute(int disputeId)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                return serviceClient.GetRelatedSupplierDispute(disputeId);
            }
        }
        public static GetDisputeWorkOrderDetailsResponse GetDisputeWorkOrderDetails(int disputeId)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                return serviceClient.GetDisputeWorkOrderDetails(disputeId);
            }
        }
        #region VendorDisputeBulkImport
        public static void SaveMoveDocument(int documentId, string fileType)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                serviceClient.CopyDocumentToBulkImportLocation(documentId, fileType);
            }
        }
        public static GetSupplierConfigurationBulkFileResponse GetSupplierConfigurationBulkFiles(GetSupplierConfigurationBulkFilesRequest request)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                return serviceClient.GetSupplierConfigurationBulkFiles(request);
            }
        }
        #endregion

        public static SpentToDateResponse GetSpentToDateByLoanId(int LoanId)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                return serviceClient.GetSpentToDateByLoanId(LoanId);
            }
        }

        public static PenaltyDataResponse GetPenaltyAdjustmentHistory(int orderId)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                return serviceClient.GetPenaltyAdjustmentLists(orderId);
            }
        }

        public static DisputePenaltyAdjustmentHistory SavePenaltyAdjustmentHistory(DisputePenaltyAdjustmentHistory request)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                return serviceClient.SaveDisputePenaltyAdjustmentHistory(request);
            }
        }

        public static AdjustmentScoreCard[] GetPenaltyAdjustmentsDataForScoreCard(int vendorWorkOrderId)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                return serviceClient.GetPenaltyAdjustmentsDataForScoreCard(vendorWorkOrderId);
            }
        }

        public static GetRRRInvoiceDataResponse GetRRRInvoiceData(GetRRRInvoiceDataRequest request)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                return serviceClient.GetRRRInvoiceData(request);
            }
        }

        public static SaveRRRInvoiceDecisionResponse SaveRrrInvoiceDecision(SaveRrrInvoiceDecisionRequest request)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                return serviceClient.SaveRrrInvoiceDecision(request);
            }
        }

        public static SaveRrrDecisionInvoiceResponse SaveRrrDecisionInvoice(SaveRrrDecisionInvoiceRequest request)
        {
            using (SpaAccountingServiceClient serviceClient = new SpaAccountingServiceClient())
            {
                return serviceClient.SaveRrrDecisionInvoice(request);
            }
        }

        public static GetRRRInvoiceDecisionDetailsDataResponse GetRRRInvoiceDecisionDetailsData(GetRRRInvoiceDecisionDetailsDataRequest request)
        {
            using (var serviceClient = new SpaAccountingServiceClient())
            {
                return serviceClient.GetRRRInvoiceDecisionDetailsData(request);
            }
        }

        public static void SaveInvoiceDecisionTrackingDetails(RRRInvoiceDecisionItemTrackingRequest request)
        {
            using (var serviceClient = new SpaAccountingServiceClient())
            {
                serviceClient.SaveInvoiceDecisionTrackingDetails(request);
            }
        }
    }
}

