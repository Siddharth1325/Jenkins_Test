﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Accounting.ServiceProxy.ProductSvc;

namespace Accounting.ServiceProxy
{
    public static class ProductServiceProxy
    {
        public static string GetProductCode(int productId)
        {
            using (ProductServiceClient client = new ProductServiceClient())
            {
                GetProductRequest request = new GetProductRequest()
                {
                    ProductId = productId
                };

                GetProductResponse response = client.GetProduct(request);

                return response.Product.ProductCode;
            }
        }

        public static Product GetProductById(int productId)
        {
            using (ProductServiceClient client = new ProductServiceClient())
            {
                GetProductRequest request = new GetProductRequest()
                {
                    ProductId = productId
                };

                GetProductResponse response = client.GetProduct(request);

                return response.Product;
            }
        }

        public static bool IsVPRProduct(int productId)
        {
            Product product = GetProductById(productId);
            List<string> pNames = new List<string>() { "Initial Registration", "Registration Renewal", "De-Registration", "Registration Amendment" };
            if (pNames.Contains(product.ProductName))
                return true;
            return false;
        }

        public static GetServicesByProductIdResponse GetServiceByProduct(int productId)
        {
            using (ProductServiceClient client = new ProductServiceClient())
            {
                GetServicesByProductIdRequest request = new GetServicesByProductIdRequest()
                {
                    ProductId = productId
                };

                GetServicesByProductIdResponse response = client.GetServicesByProductId(request);

                return response;
            }
        }
        public static GetServiceListResponse GetService()
        {
            using (ProductServiceClient client = new ProductServiceClient())
            {
                GetServiceListRequest request = new GetServiceListRequest()
                {
                   PageSize = 10000,
                   SkipCount = 0
                };

                GetServiceListResponse response = client.GetServiceList(request);

                return response;
            }
        }
    }
}
