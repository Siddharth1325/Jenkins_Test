﻿using Accounting.ServiceProxy.ComIntSvc;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;

namespace Accounting.ServiceProxy.ComInt
{
    public class CommonIntSvcProxy
    {
        public static T GetObjectFromXml<T>( XmlDocument xml)
        {
           
            T objectInstance;
           
            var serializer = new XmlSerializer(typeof(T));
            {
                using (var reader = new StringReader(xml.OuterXml))
                {
                    objectInstance = (T)serializer.Deserialize(reader);
                }
            }

            return objectInstance;
        }
        public static void submitMessage()
        {


            IntegrationCommonSvcClient client = new IntegrationCommonSvcClient();

            Accounting.ServiceProxy.ComIntSvc.PlatformMqMessage msg = new PlatformMqMessage();

            string PayLoad = @"C:\ProjectWorks\FieldServices\Accounting\Dev4\src\AccountingAppTest\SubscriptionUpdates\Asset.xml";
            XmlDocument doc = new XmlDocument();
            doc.Load(PayLoad);

           
           var Message = CommonIntSvcProxy.GetObjectFromXml<PlatformMqMessage>(doc);


           client.Process(Message);



        }
    }
}
