﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Accounting.ServiceProxy.ClientSvc;

namespace Accounting.ServiceProxy
{
    public static class ClientServiceProxy
    {
        public static SubClientProfile GetSubClientProfile(int subClientProfileId)
        {
            using (ClientServiceClient client = new ClientServiceClient())
            {
                GetSubClientRequest request = new GetSubClientRequest()
                {
                    SubClientProfileId = subClientProfileId,
                    MasterRequired = false
                };
                GetSubClientResponse response = client.GetSubClient(request);

                return response.subClient;
            }
        }

        public static GetClientLSCIListResponse GetLSCINumbers()
        {
            using (ClientServiceClient client = new ClientServiceClient())
            {

                GetClientLSCIListResponse response = client.GetClientLSCIList(new GetClientLSCIListRequest());
                if (response == null)
                    return new GetClientLSCIListResponse() { ClientLSCIList = new SubClientProfile[0] };
                else if (response.ClientLSCIList != null)
                {
                    response.ClientLSCIList.GroupBy(x => x.ClientLSCI)
                    .Select(x => x.FirstOrDefault()).OrderBy(x => x.ClientLSCI).ToList();
                }
                return response;
            }
        }

        public static GetClientProductsResponse GetClientProducts(int clinetId)
        {
            GetMasterClientResponse masterclientResponse = GetMasterClientProfile(clinetId);
            if (masterclientResponse != null && masterclientResponse.Client != null)
            {
                if (masterclientResponse.Client.ClientProducts.Count() != 0)
                    return new GetClientProductsResponse() { ClientProducts = masterclientResponse.Client.ClientProducts };

                using (ClientServiceClient client = new ClientServiceClient())
                {
                    GetClientProductsResponse response = client.GetMasterClientProducts(new GetClientProductsRequest() { ClientId = masterclientResponse.Client.MasterClientProfileId });
                    if (response == null)
                        return new GetClientProductsResponse() { ClientProducts = new ClientProduct[0] };
                    return response;
                }
            }
            return new GetClientProductsResponse() { ClientProducts = new List<ClientProduct>().ToArray() };
        }

       

        public static GetMasterClientResponse GetMasterClientProfileByMstrId(int mstrClientId)
        {
            using (ClientServiceClient client = new ClientServiceClient())
            {

                GetMasterClientResponse response = client.GetMasterClient(new GetMasterClientRequest() { MasterClientProfileId = mstrClientId, mcCollection = MasterClientCollectionEnumeration.AllCollection });
                if (response == null)
                    return new GetMasterClientResponse();
                else
                {
                    return response;
                }

            }
        }
        public static MasterClientProfile GetMasterClientProfileWithAddress(int masterClientProfileID)
        {
            using (ClientServiceClient client = new ClientServiceClient())
            {
                GetMasterClientRequest request = new GetMasterClientRequest()
                {
                    MasterClientProfileId = masterClientProfileID,
                    mcCollection = MasterClientCollectionEnumeration.AllCollection
                };
                GetMasterClientResponse response = client.GetMasterClient(request);

                if (response.Client == null)
                    return null;

                return response.Client;
            }
        }

        public static GetClientLSCIListResponse GetClientLSCINumbers(int clinetId)
        {
            GetMasterClientResponse masterclientResponse = GetMasterClientProfile(clinetId);// new GetMasterClientResponse() { Client = new MasterClientProfile() { MasterClientProfileId = clinetId } };
            if (masterclientResponse != null && masterclientResponse.Client != null)
                using (ClientServiceClient client = new ClientServiceClient())
                {
                    GetClientLSCIListResponse response = client.GetClientLSCIList(new GetClientLSCIListRequest());
                    if (response == null)
                        return new GetClientLSCIListResponse() { ClientLSCIList = new SubClientProfile[0] };
                    else if (response.ClientLSCIList != null)
                    {
                        return new GetClientLSCIListResponse()
                        {
                            ClientLSCIList = response.ClientLSCIList.Where(x => x.MasterClientProfileId == masterclientResponse.Client.MasterClientProfileId && x.ClientLSCI != null).GroupBy(x => x.ClientLSCI)
                                .Select(x => x.FirstOrDefault()).OrderBy(x => x.ClientLSCI).ToArray()
                        };
                    }
                    return response;
                }
            return new GetClientLSCIListResponse() { ClientLSCIList = new List<SubClientProfile>().ToArray() };
        }

  

        public static GetClientLSCIListResponse GetLSCINumbersByMstrClientId(int mstrClientId)
        {
            using (ClientServiceClient client = new ClientServiceClient())
            {

                GetClientLSCIListResponse response = client.GetClientLSCIList(new GetClientLSCIListRequest());
                if (response == null)
                    return new GetClientLSCIListResponse() { ClientLSCIList = new SubClientProfile[0] };
                else if (response.ClientLSCIList != null)
                {
                    return new GetClientLSCIListResponse()
                    {
                        ClientLSCIList = response.ClientLSCIList.Where(x => x.MasterClientProfileId == mstrClientId).GroupBy(x => x.ClientLSCI)
                            .Select(x => x.FirstOrDefault()).OrderBy(x => x.ClientLSCI).ToArray()
                    };
                }
                return response;
            }
        }


        public static GetMasterClientResponse GetMasterClientProfile(int clientNumber)
        {
            using (ClientServiceClient client = new ClientServiceClient())
            {

                GetMasterProfileClientNumberResponse response = client.GetMasterProfileForClientNumber(new GetMasterProfileClientNumberRequest() { ClientNumber = clientNumber });
                if (response == null)
                    return new GetMasterClientResponse();
                else
                    return new GetMasterClientResponse() { Client = response.MasterClientProfile };
                }
            }

        public static int? GetClientNumberbySubclientProfileId(int subClientProfileId)
        {
            using (ClientServiceClient client = new ClientServiceClient())
            {
                GetSubClientRequest request = new GetSubClientRequest()
                {
                    SubClientProfileId = subClientProfileId,
                    MasterRequired = false
                };
                var response = client.GetSubClient(request);

                if (response != null)
                {
                    GetMasterClientResponse masterclientResponse = client.GetMasterClient(new GetMasterClientRequest() { MasterClientProfileId = response.subClient.MasterClientProfileId, mcCollection = MasterClientCollectionEnumeration.AllCollection });
                    
                    if (masterclientResponse != null)
                        return masterclientResponse.Client.ClientNumber;
                }

            }
            return null;




        }


       


      

    }
}
