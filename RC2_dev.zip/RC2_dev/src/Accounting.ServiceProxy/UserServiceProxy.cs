﻿using Accounting.ServiceProxy.AccountingSvc;
using user = Accounting.ServiceProxy.UserSvc;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;


namespace Accounting.ServiceProxy
{
    public static class UserServiceProxy
    {
        public static List<UserAppMenu> GetAppUserAccessibleMenuResource(int appUserId)
        {
            var response = new List<UserAppMenu>();

            using (SpaAccountingServiceClient svc = new SpaAccountingServiceClient())
            {
                response = svc.GetAppUserAccessibleMenuResource(appUserId).ToList();
            }
            return response;
        }

        public static List<UserAppMenu> GetUserFavoritesByUser(int appUserId)
        {
            var response = new List<UserFavorite>();
            var userAppMenus = new List<UserAppMenu>();
            using (Accounting.ServiceProxy.UserSvc.UserRepoServiceClient svc = new Accounting.ServiceProxy.UserSvc.UserRepoServiceClient())
            {
                var favMenus = svc.GetUserFavoritesByUserId(appUserId);

                foreach (var res in favMenus)
                {
                    var userMenu = new UserAppMenu
                    {
                        AppUserId = res.AppUserId,
                        ResourceName = res.ResourceName,
                        UserFavoriteId = res.UserFavoriteId,
                        DisplayName = res.ResourceDescription,
                        UserFavoriteName = res.FavoriteName,
                        UserFavoriteUrl = res.FavoriteUrl
                    };
                    var appSettingConfigName = res.ApplicationName + "Domain";

                    if (ConfigurationManager.AppSettings.AllKeys.Contains(appSettingConfigName))
                    {
                        userMenu.AppFullUrl = ConfigurationManager.AppSettings[appSettingConfigName] + res.FavoriteUrl;
                    }
                    else
                    {
                        userMenu.AppFullUrl = res.FavoriteUrl;
                    }
                    userAppMenus.Add(userMenu);
                }
            }

            return userAppMenus;
        }

        public static List<UserAppMenu> GetLastAccessedApplicationsForUser(int appUserId)
        {
            var response = new List<UserAppMenu>();

            using (SpaAccountingServiceClient svc = new SpaAccountingServiceClient())
            {
                response = svc.GetLastAccessedApplicationsForUser(appUserId).ToList();
            }

            // TODO Make this a server operation
            return response
                .OrderByDescending(x => x.UserLastAccessedItemId)
                .ToList();
        }

        public static UserAppMenu AddUserFavorite(UserSvc.UserFavorite userFavorite)
        {
            var request = new UserSvc.AddUserFavoriteRequest
            {
                Favorite = FrontEndToRepoUserFavorite(userFavorite)
            };
            UserSvc.AddUserFavoriteResponse response;
            using (var svc = new Accounting.ServiceProxy.UserSvc.UserRepoServiceClient())
            {
                response = svc.AddUserFavoriteFull(request);
            }

            return UserFavoriteToAppMenu(response.Favorite);
        }

        private static UserSvc.UserFavorite FrontEndToRepoUserFavorite(UserSvc.UserFavorite userFavorite)
        {
            return new UserSvc.UserFavorite
            {
                AppUserId = userFavorite.AppUserId,
                ApplicationId = userFavorite.ApplicationId,
                ApplicationName = userFavorite.ApplicationName,
                FavoriteName = userFavorite.FavoriteName,
                FavoriteUrl = userFavorite.FavoriteUrl,
                ResourceName = userFavorite.ResourceName,
                ResourceDescription = userFavorite.ResourceDescription,
                UserFavoriteId = userFavorite.UserFavoriteId
            };
        }

        private static UserAppMenu UserFavoriteToAppMenu(UserSvc.UserFavorite favorite)
        {
            return new UserAppMenu
            {
                AppUserId = favorite.AppUserId,
                DisplayName = favorite.ResourceDescription,
                ResourceName = favorite.ResourceName,
                UserFavoriteId = favorite.UserFavoriteId,
                UserFavoriteName = favorite.FavoriteName,
                UserFavoriteUrl = favorite.FavoriteUrl
            };

        }

        public static bool RemoveUserFavorite(int userFavoriteId)
        {
            using (SpaAccountingServiceClient svc = new SpaAccountingServiceClient())
            {
                return svc.RemoveUserFavorite(userFavoriteId);
            }
        }

        public static UserAppMenu AddUserLastAccessedItem(int appUserid, string accessUrl, string urlParameter, string displayName)
        {
            var response = new UserAppMenu();

            using (SpaAccountingServiceClient svc = new SpaAccountingServiceClient())
            {
                response = svc.AddUserLastAccessedItem(appUserid, accessUrl, urlParameter, displayName);
            }

            return response;
        }

        public static Accounting.ServiceProxy.UserSvc.GetAppTenantsResponse GetApplicationTenants(int appId, int appUserId)
        {


            using (user.UserRepoServiceClient proxy = new user.UserRepoServiceClient())
            {
                return proxy.GetAppTenants(new Accounting.ServiceProxy.UserSvc.GetAppTenantsRequest() { AppId = appId, AppUserId = appUserId });

            }

        }
        public static Accounting.ServiceProxy.UserSvc.GetAppMenuItemsResp GetApplicationMenuItems(int appId, string TenantHierarchyId, int appUserId, int? menuParentId)
        {


            using (Accounting.ServiceProxy.UserSvc.UserRepoServiceClient svc = new Accounting.ServiceProxy.UserSvc.UserRepoServiceClient())
            {
                return svc.GetApplicationMenuItems(new Accounting.ServiceProxy.UserSvc.GetAppMenuItemsReq() { AppId = appId, TenantIdentifier = TenantHierarchyId, AppUserId = appUserId, ParentMenuId = menuParentId });
            }

        }
        public static System.Collections.Generic.List<Accounting.ServiceProxy.UserSvc.AppPrivilegesForUserDto> GetAppPrivilegesForUser(Accounting.ServiceProxy.UserSvc.GetAppPrivilegesForUserRequest request)
        {
            using (var svc = new Accounting.ServiceProxy.UserSvc.UserRepoServiceClient())
            {
                return svc.GetAppPrivilegesForUser(request).ApplicationPrivileges;
            }
        }
        public static Accounting.ServiceProxy.UserSvc.GetUserAccessibleTenantsResponse GetUserAccessibleTenants(int appUserId)
        {

            using (Accounting.ServiceProxy.UserSvc.UserRepoServiceClient proxy = new Accounting.ServiceProxy.UserSvc.UserRepoServiceClient())
            {
                var Resp = proxy.GetUserAccessibleTenants(new Accounting.ServiceProxy.UserSvc.GetUserAccessibleTenantsRequest() { AppUserId = appUserId });
                return Resp;
            }

        }
        public static string GetUserName(int userId)
        {
            Accounting.ServiceProxy.UserSvc.GetAppUserResponse response = null;
            using (Accounting.ServiceProxy.UserSvc.UserRepoServiceClient svc =
                new Accounting.ServiceProxy.UserSvc.UserRepoServiceClient())
            {
                Accounting.ServiceProxy.UserSvc.GetAppUserRequest request = new UserSvc.GetAppUserRequest();
                request.UserId = userId;
                response = svc.GetAppUser(request);
            }

            return string.Format("{0}" + " " + "{1}", response.AppUser.FirstName, response.AppUser.LastName);
        }

        public static Accounting.ServiceProxy.UserSvc.GetAppUsersResponse GetAppUserByType(string userType)
        {

            Accounting.ServiceProxy.UserSvc.GetAppUsersResponse response = null;
            using (Accounting.ServiceProxy.UserSvc.UserRepoServiceClient svc =
                new Accounting.ServiceProxy.UserSvc.UserRepoServiceClient())
            {
                Accounting.ServiceProxy.UserSvc.GetAppUsersByTypeRequestDto request = new UserSvc.GetAppUsersByTypeRequestDto();
                request.UserType = userType;
                response = svc.GetAppUsersByType(request);
            }

            return response;
        }

        public static user.GetAppUserBasicInfoResponse GetAppUserBasicInfoByType(user.GetAppUsersByTypeRequestDto appUsersRequest)
        {
            using (user.UserRepoServiceClient svc =new user.UserRepoServiceClient())
            {
                var response = svc.GetAppUserBasicInfoByType(appUsersRequest);
                return response;
            }

        }

        public static user.GetAppUserBasicInfoResponse GetAllAppUserBasicInfoByType(user.GetAppUsersByTypeRequestDto appUsersRequest)
        {
            using (user.UserRepoServiceClient svc = new user.UserRepoServiceClient())
            {
                var response = svc.GetAllAppUserBasicInfoByType(appUsersRequest);
                return response;
            }

        }
    }
}
