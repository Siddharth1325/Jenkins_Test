﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Accounting.ServiceProxy.ReferenceSvc;

namespace Accounting.ServiceProxy
{
    public static class ReferenceServiceProxy
    {
        public static List<ReferenceData> GetData(GroupCodeEnum groupCode)
        {
            GetReferenceDataResponse returnListdto;
            List<GroupCodeEnum> groupIds = new List<GroupCodeEnum>();
            groupIds.Add(groupCode);
            GetReferenceDataRequest request = new GetReferenceDataRequest();

            List<GroupCodeEnum> enumList = new List<GroupCodeEnum>();
            enumList.Add(groupCode);
            request.ReferenceGroupIds = enumList;

            List<ReferenceData> refDataDto;

            using (var svr = new ReferenceDataServiceClient())
            {
                returnListdto = svr.GetReferenceDataElement(request);
                returnListdto.ReferenceDtos.TryGetValue(groupCode.ToString(), out refDataDto);
            }

            if (refDataDto == null)
                refDataDto = new List<ReferenceData>();

            return new List<ReferenceData>(refDataDto);
        }

        public static ReferenceData GetElementByCode(GroupCodeEnum groupCode, string elementCode)
        {
            using (ReferenceDataServiceClient client = new ReferenceDataServiceClient())
            {
                GetReferenceDataElementByCodeRequest request = new GetReferenceDataElementByCodeRequest()
                {
                    GroupCode = groupCode.ToString(),
                    ElementCode = elementCode
                };

                GetReferenceDataElementByCodeResponse response = client.GetReferenceDataElementByCode(request);
                if (response != null)
                    return response.ReferenceDataElement;
            }
            return null;
        }


        public static List<ReferenceData> GetDataByApplicationId(GroupCodeEnum groupCode, int? applicationId)
        {
            GetReferenceDataResponse returnListdto;
            string grpcode = groupCode.ToString();
            List<string> groupIds = new List<string>();
            groupIds.Add(grpcode);
            ReferenceDataRequest request = new ReferenceDataRequest();

            List<string> enumList = new List<string>();
            enumList.Add(grpcode);
            request.ReferenceGroupIds = enumList;
            request.ApplicationId = applicationId;

            List<ReferenceData> refDataDto;

            using (var svr = new ReferenceDataServiceClient())
            {
                returnListdto = svr.GetReferenceDataByAppId(request);
                returnListdto.ReferenceDtos.TryGetValue(groupCode.ToString(), out refDataDto);
            }

            if (refDataDto == null)
                refDataDto = new List<ReferenceData>();

            return new List<ReferenceData>(refDataDto);
        }

        public static GetCompanyInfoResponse GetCompanyInfo(string companyCode)
        {
            GetCompanyInfoResponse response;
            using (var svr = new ReferenceDataServiceClient())
            {
                response = svr.GetCompanyInfo(companyCode);
            }
            return response;
        }


        public static GetTenantConfigurationResponse GetAppListForTenant(string TenantGuid)
        {


            using (ReferenceDataServiceClient proxy = new ReferenceDataServiceClient())
            {
                return proxy.GetTenantConfigurationDetail(new GetTenantConfigurationRequest() { TenantGuid = new Guid(TenantGuid) });

            }

        }
    }
}
