﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Accounting.ServiceProxy.InspectionsSvc;

namespace Accounting.ServiceProxy
{
    public static class InspectionServiceProxy
    {
        public static WorkOrder GetWorkOrderById(int workOrderId)
        {
            using(InspServiceClient client = new InspServiceClient())
            {
                GetWorkOrderRequest request = new GetWorkOrderRequest()
                {
                    WorkOrder = new WorkOrder()
                    {
                        WorkOrderId = workOrderId
                    }
                };

                GetWorkOrderResponse response = client.GetWorkOrder(request);

                if (response.WorkOrder == null || response.WorkOrder.Length == 0)
                    return null;

                return response.WorkOrder[0];
            }
        }

        public static Order GetOrderById(int orderId)
        {
            using (InspServiceClient client = new InspServiceClient())
            {
                GetOrderDetailsRequest request = new GetOrderDetailsRequest()
                {
                    OrderDetail = new Order()
                    {
                        OrderId = orderId
                    }
                };

                GetOrderDetailsResponse response = client.GetOrderDetails(request);

                if (response.OrderDetail == null)
                    return null;

                return response.OrderDetail;
            }
        }

        public static Loan GetLoanById(int loanId)
        {
            using (InspServiceClient client = new InspServiceClient())
            {
                GetLoanbyIdRequest request = new GetLoanbyIdRequest()
                {
                    Loan = new Loan() 
                    { 
                        LoanId = loanId 
                    }
                };

                GetLoanbyIdResponse response = client.GetLoanbyId(request);
             
                if (response.Loan == null)
                    return null;

                return response.Loan;
            }
        }

        public static GetBulkExceptionResponse GetImportExceptions(GetImportBulkExceptionRequest request)
        {
            using (InspServiceClient client = new InspServiceClient())
            {
                GetBulkExceptionResponse response = client.GetImportBulkException(request);
             
                return response;
            }
        }
        
        public static List<WorkOrder> GetWorkOrderDetailsByIdList(List<int> workOrderIdList)
        {
            using(InspServiceClient client = new InspServiceClient())
            {
                GetWorkOrderDetailsByIdsRequest request = new GetWorkOrderDetailsByIdsRequest()
                {
                    WorkOrderIdList = workOrderIdList.ToArray()
                };

                GetWorkOrderDetailsByIdsResponse response = client.GetWorkOrderDetailsByIds(request);

                if (response != null)
                    return new List<WorkOrder>(response.WorkOrderList);
            }

            return null;
        }

        public static InspectionResultGeneralResponse GetInspectionResultByWorkOrderId(List<int> workOrderIdList)
        {
            using (InspServiceClient client = new InspServiceClient())
            {
                InspectionResultGeneralRequest request = new InspectionResultGeneralRequest()
                {
                    WorkOrderIdList = workOrderIdList.ToArray()
                };

                return client.GetInspectionResultGeneralByWorkOrderId(request);
            }
        }

    }
}
