﻿using Accounting.ServiceProxy.Documentsvc;
using System.IO;

namespace Accounting.ServiceProxy
{
    public static class DocumentManagementServiceProxy
    {
        public static GetDocumentResponse GetDocument(GetDocumentRequest request)
        {
            GetDocumentResponse response = null;

            using (var serviceClient = new DocumentServiceClient())
            {
                string description;
                string name;
                long? size;
                string type;
                string mimeType;
                int documentId;
                bool isTemporary;
                string errorMessage;
                bool isSuccess;

                Stream outStream;
                serviceClient.GetDocument(request.RequestData
                    , out description
                    , out documentId
                    , out name
                    , out size
                    , out type
                    , out isTemporary
                    , out errorMessage
                    , out mimeType
                    , out isSuccess
                    , out outStream);

                if (outStream != null)
                {
                    response = new GetDocumentResponse
                    {
                        DocumentDescription = description,
                        MimeType = mimeType,
                        StreamData = outStream,
                        DocumentType = type,
                        DocumentName = name,
                        DocumentSize = size,
                        DocumentId = documentId
                    };
                }
            }

            return response;
        }

        public static UploadDocumentResponse SaveDocument(UploadDocumentRequest request)
        {
            UploadDocumentResponse response;

            using (var serviceClient = new DocumentServiceClient())
            {                
                string createdByUserId;
                int documentId;                

                serviceClient.SaveDocument(ref request.ApplicationId, ref request.DocumentDescription, ref request.DocumentName,
                    ref request.DocumentType, request.DocumentTypeGroup, ref request.IsTemporary, ref request.MimeType,
                    request.DocumentStream, out createdByUserId, out documentId);

                response = new UploadDocumentResponse
                {
                    CreatedByUser = createdByUserId,
                    DocumentName = request.DocumentName,
                    DocumentId = documentId,
                    DocumentDescription = request.DocumentDescription,
                    DocumentType = request.DocumentType,
                    MimeType = request.MimeType,
                    IsTemporary = request.IsTemporary
                };


            }

            return response;
        }

        public static DeleteDocumentResponse DeleteDocument(DeleteDocumentRequest request)
        {
            DeleteDocumentResponse response;

            using (var serviceClient = new DocumentServiceClient())
            {
                response = serviceClient.DeleteDocument(request);
            }

            return response;
        }

        public static GetDocumentMetadataResponse GetDocumentMetadata(GetDocumentMetadataRequest request)
        {
            GetDocumentMetadataResponse response;

            using (var serviceClient = new DocumentServiceClient())
            {
                string description;
                string name;
                long? size;
                string type;
                string mimeType;
                int documentId;
                bool isTemporary;
                string errorMessage;
                bool isSuccess;

                serviceClient.GetDocumentMetadata(request.RequestData
                    , out description
                    , out documentId
                    , out name
                    , out size
                    , out type
                    , out isTemporary
                    , out errorMessage
                    , out mimeType
                    , out isSuccess
                    );

                response = new GetDocumentMetadataResponse
                {
                    DocumentDescription = description,
                    MimeType = mimeType,
                    DocumentType = type,
                    DocumentName = name,
                    DocumentSize = size,
                    DocumentId = documentId
                };
            }

            return response;
        }

        public static SaveDocumentMetadataResponse SaveDocumentMetadata(SaveDocumentMetadataRequest request)
        {
            SaveDocumentMetadataResponse response;

            using (var serviceClient = new DocumentServiceClient())
            {
                string createdByUserId;

                serviceClient.SaveDocumentMetadata(ref request.DocumentDescription, ref request.DocumentId, ref request.DocumentName,
                    ref request.DocumentType, ref request.IsTemporary, ref request.MimeType, out createdByUserId);

                response = new SaveDocumentMetadataResponse
                {
                    CreatedByUser = createdByUserId,
                    DocumentName = request.DocumentName,
                    DocumentId = request.DocumentId,
                    DocumentDescription = request.DocumentDescription,
                    DocumentType = request.DocumentType,
                    MimeType = request.MimeType,
                    IsTemporary = request.IsTemporary
                };
            }

            return response;
        }
    }
}
