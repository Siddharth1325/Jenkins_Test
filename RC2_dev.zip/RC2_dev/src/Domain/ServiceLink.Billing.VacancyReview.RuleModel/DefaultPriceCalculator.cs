﻿using System;
namespace ServiceLink.Billing.VacancyReview.RuleModel
{
    [Serializable]
    public class DefaultPriceCalculator
    {
        public decimal BasePrice { get; set; }
        public decimal PriceTracker { get; set; }
        public string BasePriceSelectionReason { get; set; }
        public string FailureReason { get; set; }
        public int? SwitchedProductId { get; set; }
        public bool Successful { get; set; }
        public bool IsDirty { get; set; }
        public ClientPricing ClientPricing { get; set; }
        public Loan Loan { get; set; }
        public Product Product { get; set; }
        public InvestorProfile InvestorProfile { get; set; }
        public Order Order { get; set; }
    }
}
