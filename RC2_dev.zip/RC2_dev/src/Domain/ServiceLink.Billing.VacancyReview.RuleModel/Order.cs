﻿using System;

namespace ServiceLink.Billing.VacancyReview.RuleModel
{
    [Serializable]
    public class Order
    {
        public bool? IsRushOrder { get; set; }
        public bool? IsInitial { get; set; }
    }
}
