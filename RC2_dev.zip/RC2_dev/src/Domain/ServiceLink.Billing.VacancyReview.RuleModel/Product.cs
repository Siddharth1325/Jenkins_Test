﻿using System;

namespace ServiceLink.Billing.VacancyReview.RuleModel
{
    [Serializable]
    public class Product
    {
        public int? ProductId { get; set; }
        public string ProductCode { get; set; }
    }
}
