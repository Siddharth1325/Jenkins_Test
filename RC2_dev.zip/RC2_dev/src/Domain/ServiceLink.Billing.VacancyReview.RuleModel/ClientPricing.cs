﻿using System;

namespace ServiceLink.Billing.VacancyReview.RuleModel
{
    [Serializable]
    public class ClientPricing
    {
        public decimal? RushRate { get; set; }
        public decimal? InitialRate { get; set; }
        public decimal? SubsequentRate { get; set; }
        public decimal? StandardRate { get; set; }
    }
}
