﻿using System;

namespace ServiceLink.Billing.VacancyReview.RuleModel
{
    public class VacancyReviewRuleSummary
    {
        public decimal? BasePrice { get; set; }
        public decimal PriceTracker { get; set; }
        public string BasePriceSelectionReason { get; set; }
        public string FailureReason { get; set; }
        public bool Successful { get; set; }
        public bool IsDirty { get; set; }
    }
}
