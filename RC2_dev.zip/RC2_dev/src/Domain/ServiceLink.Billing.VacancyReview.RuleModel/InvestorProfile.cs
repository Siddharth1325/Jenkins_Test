﻿using System;

namespace ServiceLink.Billing.VacancyReview.RuleModel
{
    [Serializable]
    public class InvestorProfile
    {
        public int? InvestorProfileId { get; set; }
    }
}
