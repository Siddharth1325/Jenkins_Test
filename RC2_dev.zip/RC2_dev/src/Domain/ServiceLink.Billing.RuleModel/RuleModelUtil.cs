﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;

namespace ServiceLink.Billing.RuleModel
{
    public sealed class RuleModelUtil
    {
        private static ConcurrentDictionary<Type, XmlSerializer> serializers = new ConcurrentDictionary<Type, XmlSerializer>();

        private static XmlSerializer GetSerializer(Type type)
        {
            return serializers.GetOrAdd(type, t => { return new XmlSerializer(t, new XmlRootAttribute(type.Name) { IsNullable = true }); });
        }

        private RuleModelUtil() { }

        public static object MapDomainObjectToRuleModel(object from, Type toType)
        {
            if (toType == null) throw new ArgumentNullException("toType");
            if (from == null) return null;

            object to = Activator.CreateInstance(toType);

            Type fromType = from.GetType();
            foreach (PropertyInfo tpi in toType.GetProperties(BindingFlags.Public | BindingFlags.Instance | BindingFlags.GetProperty | BindingFlags.SetProperty))
            {
                PropertyInfo fpi = null;
                if ((fpi = fromType.GetProperty(tpi.Name, BindingFlags.Public | BindingFlags.Instance | BindingFlags.GetProperty | BindingFlags.SetProperty)) != null)
                {
                    //Handle all value type and string properties with same name
                    if ((fpi.PropertyType.IsValueType && tpi.PropertyType.IsValueType && fpi.PropertyType == tpi.PropertyType) ||
                        (fpi.PropertyType == typeof(string) && tpi.PropertyType == typeof(string)))
                    {
                        tpi.SetValue(to, fpi.GetValue(from));
                    }
                    //Handle all array properties of same element type
                    else if (fpi.PropertyType.IsArray && tpi.PropertyType.IsArray &&
                        Type.GetType(fpi.PropertyType.FullName.Replace("[]", string.Empty)) == Type.GetType(tpi.PropertyType.FullName.Replace("[]", string.Empty)))
                    {
                        Type elementType = Type.GetType(fpi.PropertyType.FullName.Replace("[]", string.Empty));
                        var array = fpi.GetValue(from) as Array;
                        Array copied = Array.CreateInstance(elementType, array.Length);
                        for (int i = 0; i < array.Length; i++)
                        {
                            copied.SetValue(array.GetValue(i), i);
                        }
                        tpi.SetValue(to, copied);
                    }
                }
            }

            return to;
        }

        public static string SerializeRuleModelToXml(Type type, object value)
        {
            if (type == null || value == null) return null;
            else if (!type.IsAssignableFrom(value.GetType())) return null;

            XmlSerializer serializer = GetSerializer(type);
            XmlWriterSettings settings = new XmlWriterSettings();
            settings.Encoding = new UnicodeEncoding(false, false);
            settings.Indent = false;
            settings.OmitXmlDeclaration = false;
            StringWriter textWriter = new StringWriter();

            using (XmlWriter xmlWriter = XmlWriter.Create(textWriter, settings))
            {
                serializer.Serialize(xmlWriter, value);
            }
            return textWriter.ToString();

        }

        public static object DeserializeXmlToRuleModel(string xml, Type type)
        {
            if (string.IsNullOrEmpty(xml)) return null;
            else if (type == null) return null;

            object ret = null;
            //XmlRootAttribute xRoot = new XmlRootAttribute();
            //xRoot.ElementName = type.Name;
            //xRoot.IsNullable = true;
            XmlSerializer serializer = GetSerializer(type);
            XmlReaderSettings settings = new XmlReaderSettings();
            settings.CheckCharacters = false;
            settings.DtdProcessing = DtdProcessing.Ignore;
            settings.IgnoreComments = true;
            settings.IgnoreProcessingInstructions = true;
            settings.IgnoreWhitespace = true;
            StringReader textReader = new StringReader(xml);
            using (XmlReader xmlReader = XmlReader.Create(textReader, settings))
            {
                ret = serializer.Deserialize(xmlReader);
            }
            return ret;
        }
    }
}
