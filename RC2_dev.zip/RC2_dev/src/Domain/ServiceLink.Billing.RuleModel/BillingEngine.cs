﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiceLink.Billing.RuleModel
{
    public class BillingEngine
    {
        public string Id
        {
            get;
            set;
        }

        public string ApplicationName
        {
            get;
            set;
        }

        public BillingContext BillingContext
        {
            get;
            set;
        }

        public List<BillingStep> BillingSteps
        {
            get;
            set;
        }

    }
}
