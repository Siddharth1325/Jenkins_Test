﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiceLink.Billing.RuleModel
{
    public class BillingContext
    {
        public string ContextDataXml
        {
            get;
            set;
        }

        public decimal? BaseCost
        {
            get;
            set;
        }

        public decimal? BasePrice
        {
            get;
            set;
        }

        public string BaseCostSelectionReason
        {
            get;
            set;
        }

        public string BasePriceSelectionReason
        {
            get;
            set;
        }

        public decimal? FinalCost
        {
            get;
            set;
        }

        public decimal? FinalPrice
        {
            get;
            set;
        }

        public bool Successful
        {
            get;
            set;
        }

        public string FailureReason
        {
            get;
            set;
        }
    }
}
