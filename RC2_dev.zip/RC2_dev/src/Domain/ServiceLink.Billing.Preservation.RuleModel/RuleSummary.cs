﻿using System;
using System.Collections.Generic;

namespace ServiceLink.Billing.Preservation.RuleModel
{
    [Serializable]
    public class RuleSummary
    {
        public bool Successful { get; set; }
        public Account AccountsPayable { get; set; }
        public Account AccountsReceivable { get; set; }
    }
}
