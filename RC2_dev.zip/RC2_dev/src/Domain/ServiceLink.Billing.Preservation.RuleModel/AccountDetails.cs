﻿using System;

namespace ServiceLink.Billing.Preservation.RuleModel
{
    [Serializable]
    public class AccountDetails
    {
        public int OrderId { get; set; }
        public int? VendorWorkOrderId { get; set; }
        public int? WorkOrderId { get; set; }
        public int? WorkOrderItemId { get; set; }
        public int? WorkOrderLineItemId { get; set; }
        public int SourceOrderId { get; set; }
        public int? SourceVendorWorkOrderId { get; set; }
        public int? SourceWorkOrderId { get; set; }
        public int? SourceWorkOrderItemId { get; set; }
        public int? SourceWorkOrderLineItemId { get; set; }
        public int Quantity { get; set; }
        public decimal BaseTotalCost { get; set; }
        public decimal BaseUnitCost { get; set; }
        public string AStatusGroup { get; set; }
        public string AStatusType { get; set; }
        public int? FeeTypeId { get; set; }
        public string FeeTypeName { get; set; }
    }
}