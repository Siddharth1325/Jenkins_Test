﻿using System;
using System.Collections.Generic;

namespace ServiceLink.Billing.Preservation.RuleModel
{
    [Serializable]
    public class PreservationBilling
    {
        public ProductServiceDetails ProductServiceDetails { get; set; }
        public Account AccountsPayable { get; set; }
        public Account AccountsReceivable { get; set; }
    }
}
