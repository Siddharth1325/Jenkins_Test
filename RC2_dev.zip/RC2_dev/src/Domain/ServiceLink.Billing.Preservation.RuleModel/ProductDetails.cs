﻿using System;
using System.Collections.Generic;

namespace ServiceLink.Billing.Preservation.RuleModel
{
    [Serializable]
    public class ProductDetails
    {
        public ProductDetails()
        {
            ServiceItemDetails = new List<ServiceItemDetails>();
        }
        public int WorkOrderId { get; set; }
        public int SourceWorkOrderId { get; set; }
        public string WorkOrderStatusType { get; set; }
        public int ProductId { get; set; }
        public string ProductCode { get; set; }
        public string ProductName { get; set; }
        public string ProductCategory { get; set; }
        public int OrderId { get; set; }
        public int SourceOrderId { get; set; }
        public decimal? ClientRushFee { get; set; }
        public decimal? ClientTripFee { get; set; }
        public int VendorWorkOrderId { get; set; }
        public int SourceVendorWorkOrderId { get; set; }
        public decimal? VendorOneTimeFee { get; set; }
        public decimal? VendorTripFee { get; set; }
        public decimal? VendorMinServiceFee { get; set; }
        public decimal? VendorOneTimeFinalFee { get; set; }
        public List<ServiceItemDetails> ServiceItemDetails { get; set; }
    }
}
