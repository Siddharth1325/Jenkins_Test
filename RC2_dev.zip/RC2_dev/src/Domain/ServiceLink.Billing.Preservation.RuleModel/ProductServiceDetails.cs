﻿using System;
using System.Collections.Generic;

namespace ServiceLink.Billing.Preservation.RuleModel
{
    [Serializable]
    public class ProductServiceDetails : List<ProductDetails>
    {

    }
}
