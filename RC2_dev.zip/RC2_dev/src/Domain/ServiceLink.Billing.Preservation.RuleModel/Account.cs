﻿using System;
using System.Collections.Generic;

namespace ServiceLink.Billing.Preservation.RuleModel
{
    [Serializable]
    public class Account
    {
        public List<AccountDetails> AccountDetails { get; set; }
    }
}
