﻿using System;

namespace ServiceLink.Billing.Preservation.RuleModel
{
    [Serializable]
    public class ServiceItemDetails
    {
        public int WorkOrderItemId { get; set; }
        public int SourceWorkOrderItemId { get; set; }
        public bool IsParentService { get; set; }
        public string ServiceCode { get; set; }
        public string ServiceName { get; set; }
        public string WorkPerformed { get; set; }
        public string WorkNotPerformedReason { get; set; }
        public string VendorFeeType { get; set; }
        public decimal? VendorFlatFee { get; set; }
        public string VendorDiscountType { get; set; }
        public decimal? VendorDiscount { get; set; }
        public bool IsClientBilling { get; set; }
        public decimal? VendorFinalCost { get; set; }
        public decimal? ClientFinalPrice { get; set; }
        public decimal? InitialClientPrice { get; set; }
        public decimal? InitialVendorCost { get; set; }

        public int? WorkOrderLineItemId { get; set; }
        public int? SourceWorkOrderLineItemId { get; set; }
        public string LineItemCode { get; set; }
        public string LineItemName { get; set; }
        public int? Quantity { get; set; }
        public decimal? VarianceCost { get; set; }
        public decimal? VendorFee { get; set; }
        public decimal? AgreedUnitCost { get; set; }
        public decimal? AgreedClientPrice { get; set; }
        public decimal? LVendorFinalCost { get; set; }
        public decimal? LClientFinalPrice { get; set; }
        public decimal? UnitCost { get; set; }
        public decimal? UnitPrice { get; set; }
    }
}
