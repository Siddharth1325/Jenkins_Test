﻿using System;

namespace ServiceLink.Billing.Inspection.RuleModel
{
    public class VendorSlaAdjustor
    {
        public decimal CostTracker { get; set; }
        public decimal FinalCost { get; set; }
        public decimal PriceTracker { get; set; }
        public decimal FinalPrice { get; set; }
        public DateTime? OrderDate { get; set; }
        public int? NumberOfBusinessDaysSubmissionDate { get; set; }
        public int? NumberOfBusinessDaysTransmittedDate { get; set; }
        public int? NumberOfBusinessDaysCompletedDate { get; set; }
        public DateTime? DateTimeMinValue { get; set; }
        public bool IsDirtyCost { get; set; }
        public bool IsDirtyPrice { get; set; }
        public WorkOrder WorkOrder { get; set; }
        public InspectionResult InspectionResult { get; set; }
        public ClientAccounting ClientAccounting { get; set; }
        public CostAdjustments CostAdjustments { get; set; }
        public PriceAdjustments PriceAdjustments { get; set; }
    }
}
