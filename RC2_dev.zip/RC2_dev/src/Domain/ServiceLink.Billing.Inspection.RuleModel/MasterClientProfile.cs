﻿using System;

namespace ServiceLink.Billing.Inspection.RuleModel
{
    public class MasterClientProfile
    {
        public string ClientName { get; set; }
    }
}
