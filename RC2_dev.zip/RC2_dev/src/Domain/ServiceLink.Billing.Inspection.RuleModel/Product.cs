﻿using System;

namespace ServiceLink.Billing.Inspection.RuleModel
{
    public class Product
    {
        public int? ProductId { get; set; }

        public string ProductCode { get; set; }
    }
}
