﻿using System;

namespace ServiceLink.Billing.Inspection.RuleModel
{
    [Serializable]
    public class ClientAccounting
    {
        public bool? IsBillOutOfCompliance { get; set; }
        public bool? IsPayOutOfCompliance { get; set; }
        public bool? IsBillForPrevBadAddress { get; set; }
        public bool? IsBillForInsufficientAddress { get; set; }
        public bool? IsBillCancellations { get; set; }
        public decimal? PrevBadAddressAmount { get; set; }
        public decimal? InsufficientAddressAmount { get; set; }
        public decimal? CancellationAmount { get; set; }
        public int? InspectionPerformedThreshold { get; set; }
        public int? InspectionTransmitThreshold { get; set; }
        public int? InspectionReturnedThreshold { get; set; }
        public bool? IsBillForAccessDenied { get; set; }
        public decimal? AccessDeniedAmount { get; set; }
        public bool? IsBillForBadAddress { get; set; }
        public decimal? BadAddressAmount { get; set; }
        public bool? IsBillWorkNotPerformed { get; set; }
        public decimal? WorkNotPerformedAmount { get; set; }
    }
}