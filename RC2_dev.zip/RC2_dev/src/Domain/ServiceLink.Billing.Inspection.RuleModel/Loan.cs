﻿using System;

namespace ServiceLink.Billing.Inspection.RuleModel
{
    public class Loan
    {
        public int? SubClientProfileId { get; set; }
        public string ValidCountyName { get; set; }
        public string ValidStateCode { get; set; }
        public string ValidZipCode { get; set; }

    }
}
