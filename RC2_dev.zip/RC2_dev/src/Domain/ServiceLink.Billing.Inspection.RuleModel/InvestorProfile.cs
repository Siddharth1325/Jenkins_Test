﻿using System;

namespace ServiceLink.Billing.Inspection.RuleModel
{
    public class InvestorProfile
    {
        public int? InvestorProfileId { get; set; }
    }
}
