﻿using System;

namespace ServiceLink.Billing.Inspection.RuleModel
{
    [Serializable]
    public class Order
    {
        public bool? IsDoNotPayVendor { get; set; }
        public bool? IsDoNotBillClient { get; set; }
        public DateTime? RequestedDate { get; set; }
        public DateTime? ReceivedDate { get; set; }
        public bool? IsRushOrder { get; set; }
        public bool? IsInitial { get; set; }

        public bool? IsFrequent { get; set; }
    }
}
