﻿using System;

namespace ServiceLink.Billing.Inspection.RuleModel
{
    public class SubClientProfile
    {
        public int? SubClientProfileId { get; set; }
    }
}
