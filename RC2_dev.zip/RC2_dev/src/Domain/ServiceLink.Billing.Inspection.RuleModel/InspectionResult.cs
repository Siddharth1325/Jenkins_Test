﻿using System;
using System.Collections.Generic;

namespace ServiceLink.Billing.Inspection.RuleModel
{
    [Serializable]
    public class InspectionResult
    {
        public DateTime? SubmissionDate { get; set; }
        public bool? IsWorkPerformed { get; set; }

        public List<InspRsltWorkNotPerformed> InspRsltWorkNotPerformed { get; set; }
    }
}
