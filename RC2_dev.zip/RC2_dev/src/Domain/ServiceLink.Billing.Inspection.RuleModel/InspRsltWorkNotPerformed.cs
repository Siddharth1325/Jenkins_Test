﻿using System;

namespace ServiceLink.Billing.Inspection.RuleModel
{
    public class InspRsltWorkNotPerformed
    {
        public string AccessDeniedGroup { get; set; }
        public string BadAddrGroupCode { get; set; }
        public string WorkNotPerformedReasonGroup { get; set; }
    }
}
