﻿using System;

namespace ServiceLink.Billing.Inspection.RuleModel
{
    [Serializable]
    public class ClientWindowAdjustor
    {
        public decimal CostTracker { get; set; }
        public decimal FinalCost { get; set; }
        public decimal PriceTracker { get; set; }
        public decimal FinalPrice { get; set; }
        public bool? isOutOfCompliance { get; set; }
        public bool Calculated { get; set; }
        public bool Successful { get; set; }
        public bool IsDirtyCost { get; set; }
        public bool IsDirtyPrice { get; set; }
        public WorkOrder WorkOrder { get; set; }
        public InspectionResult InspectionResult { get; set; }
        public ClientAccounting ClientAccounting { get; set; }
        public CostAdjustments CostAdjustments { get; set; }
        public PriceAdjustments PriceAdjustments { get; set; }
    }
}
