﻿using System;

namespace ServiceLink.Billing.Inspection.RuleModel
{
    [Serializable]
    public class WorkOrder
    {
        public bool? IsBillClient { get; set; }

        public string PayVendorGroup { get; set; }

        public string PayVendorType { get; set; }

        public DateTime? WindowEndDate { get; set; }

        public DateTime? WindowStartDate { get; set; }
        
        public string WorkOrderStatusType { get; set; }

        public string CancellationReasonType { get; set; }

        public int? AssignedVendorId { get; set; }

        public DateTime? DueFromVendorDate { get; set; }

        public DateTime? TransmittedDate { get; set; }

        public DateTime? CompletedDate { get; set; }

        public DateTime? AcctProcessedDate { get; set; }

        public int? WorkOrderId { get; set; }
    }
}
