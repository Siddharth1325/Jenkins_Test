﻿using System;

namespace ServiceLink.Billing.Inspection.RuleModel
{
    [Serializable]
    public class CostAdjustments
    {
        public string AdjustmentGroupCode { get; set; }
        public string AdjustmentTypeCode { get; set; }
        public decimal AdjustPercentage { get; set; }

    }
}
