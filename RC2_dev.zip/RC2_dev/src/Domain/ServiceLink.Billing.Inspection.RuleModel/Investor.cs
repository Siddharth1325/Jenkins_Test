﻿using System;

namespace ServiceLink.Billing.Inspection.RuleModel
{
    public class Investor
    {
        public string InvestorName { get; set; }
    }
}
