﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DomainModel.Common
{
    [Serializable]
    public class CommonEnums
    {
        public enum AccountsPayableChild
        {
            All,
            None,
            PayableInvoice,
            APInvoicePayable,
            PayableAdjustment,
            PayableRemittance,
            WorkOrderAPInvoice,
            PayableDetail,
            PayableTrace
        }

        public enum AccountsReceivableChild
        {
            All,
            None,
            ReceivableInvoice,
            ARInvoiceReceivable,
            ReceivableAdjustment,
            WorkOrderARInvoice,
            ReceivableDetail,
            ReceivableTrace
        }

        public enum AccountingWorkOrderReceivableChild
        {
            All,
            None,
            ReceivableInvoice,
            ARInvoiceReceivable,
            ReceivableAdjustment,
            Receivable,
            ReceivableDetail,
            ReceivableTrace
        }

        public enum AccountingWorkOrderPayableChild
        {
            All,
            None,
            PayableInvoice,
            APInvoicePayable,
            PayableAdjustment,
            PayableRemittance,
            Payable,
            PayableDetail,
            PayableTrace
        }

        public enum OrderChild
        {
            All,
            None,
            Loan,
            WorkOrder,
            WorkOrderItem,
            Cancellation
        }
    }
}
