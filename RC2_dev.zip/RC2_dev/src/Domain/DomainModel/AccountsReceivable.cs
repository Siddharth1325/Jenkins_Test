namespace DomainModel.Accounting
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;
    using CommonLib.ModelAttrib;

    [Table("act.AccountsReceivable")]
    public partial class AccountsReceivable : BaseDomainModel
    {
        public AccountsReceivable()
        {
            AccountingARInvoiceReceivables = new HashSet<AccountingARInvoiceReceivable>();
            AccountsReceivableDetails = new HashSet<AccountsReceivableDetail>();
        }

        public int AccountsReceivableId { get; set; }
        
        [SecondaryKeyPropAttribute(Order = 1)]
        public int ApplicationId { get; set; }

        [SecondaryKeyPropAttribute(Order = 2)]
        [MapProp("AccountsReceivableId")]
        public int? SourceAccountsReceivableId { get; set; }

        public int? WorkOrderId { get; set; }

        [Required]
        [StringLength(8)]
        public string GLTransTypeGroup { get; set; }

        [Required]
        [StringLength(8)]
        public string GLTransType { get; set; }

        [Column(TypeName = "money")]
        public decimal? SubtotalDue { get; set; }

        [Column(TypeName = "money")]
        public decimal? TaxesDue { get; set; }

        [Column(TypeName = "money")]
        public decimal TotalAmountDue { get; set; }

        public bool? IsEligibleForTran32 { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? Tran32ProcessedDate { get; set; }

        public int CreatedById { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime CreatedDate { get; set; }

        public int? LastUpdatedById { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? LastUpdatedDate { get; set; }

        [Column(TypeName = "timestamp")]
        [MaxLength(8)]
        [Timestamp]
        public byte[] Version { get; set; }

        public virtual WorkOrder WorkOrders { get; set; }

        public virtual ICollection<AccountingARInvoiceReceivable> AccountingARInvoiceReceivables { get; set; }

        public virtual ICollection<AccountsReceivableDetail> AccountsReceivableDetails { get; set; }
    }
}
