﻿using DomainModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DomainModel.Accounting
{
    public class SupplierDisputeSearchResult : BaseDomainModel
    {
        public int BulkId { get; set; }
        public int SupplierDisputeId { get; set; }
        public int VendorId { get; set; }
        public int? FieldScapeWorkOrderId { get; set; }
        public int? InspWorkOrderId { get; set; }
        public int? VendorWorkOrderId { get; set; }
        public DateTime? DisputeDate { get; set; }
        public DateTime? DisputeDueDate { get; set; }
        public string DisputeStatus { get; set; }

        public string DisputeStatusType { get; set; }

        public string EscalationResolutionStatusType { get; set; }

        public string EscalationResolutionStatus { get; set; }
        public DateTime? EscalationDueDate { get; set; }
        public decimal? AdditionalAmtApproved { get; set; }
        public string DisputeReason { get; set; }
        public string VendorDisputeComments { get; set; }
        public string DisputeResolutionType { get; set; }
        public string DisputeResolution { get; set; }
        public DateTime? DisputeCompletedDate { get; set; }

        public string SLFSResponseToVendor { get; set; }
        public DateTime? EscalationCompleteDate { get; set; }
        public string EscalationComments { get; set; }
        public DateTime? EscalationDate { get; set; }
        public string SLFSResponseToEscalation { get; set; }

        public bool EscalatedByVendor { get; set; }

        public string VendorName { get; set; }
		public string PropertyAddress1 { get; set; }
		public string PropertyAddress2 { get; set; } 
		public string PropertyCity { get; set; }
		public string PropertyState { get; set; }
		public string PropertyZip { get; set; }
		public string ProductName { get; set; }
		public string ClientNumber { get; set; }
		public decimal? DisputeAmount { get; set; }
		public string Decision { get; set; }
		public string Resolution { get; set; }
        public string EscalationDecision { get; set; }
        public string SLFSEscalationComments { get; set; } 
    }
}
