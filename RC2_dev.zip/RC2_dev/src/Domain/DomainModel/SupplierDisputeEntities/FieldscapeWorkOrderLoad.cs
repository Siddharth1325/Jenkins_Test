﻿namespace DomainModel.Accounting
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("stg.FieldScapeWorkOrderLoad")]
    public partial class FieldscapeWorkOrderLoad : BaseDomainModel
    {
        [Key]
        public int FieldScapeWorkOrderLoadId { get; set; }

        public int? ClientNumber { get; set; }

        public string LSCI { get; set; }
        public int? VendorNumber { get; set; }
        public string LoanNumber { get; set; }

        public string PropAddress1 { get; set; }
        public string PropAddress2 { get; set; }
        public string PropCityName { get; set; }
        public string PropStateCode { get; set; }
        public string PropZipCode { get; set; }
        public int WorkOrderNumber { get; set; }
        public DateTime? ContractorPerformedDate { get; set; }
        public DateTime? UpdateDate { get; set; }
        public DateTime? BilledDate { get; set; }
         [Column(TypeName = "money")]
        public decimal? ContInvAmt { get; set; }
         [Column(TypeName = "money")]
        public decimal? DiscountAmount { get; set; }
        public decimal? DiscountPerc { get; set; }

        [Column(TypeName = "money")]
        public decimal? PostDiscContInvAmt { get; set; }
        [Column(TypeName = "money")]
        public decimal? CPInvoiceAmount { get; set; }

        [Column(TypeName = "money")]
        public decimal? ContPaidInvAmt { get; set; }
        public string InvoiceNumber { get; set; }
        public DateTime? PaymentDate { get; set; }
        [Column(TypeName = "money")]
        public decimal? AmountBilledToClient { get; set; }
        public int? LastAdjustmentId { get; set; }
        [Column(TypeName = "money")]
        public decimal? ContractorPayableRevisedAmount { get; set; }
        public bool? IsLoadedToday { get; set; }
        public string Investorname { get; set; }
        public string CheckNumber { get; set; }
        public string LoanType { get; set; }
        public string LoanTypeGroupCode { get; set; }
    }
}
