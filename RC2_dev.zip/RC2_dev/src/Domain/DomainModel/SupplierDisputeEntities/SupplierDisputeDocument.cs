namespace DomainModel.Accounting
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("disp.SupplierDisputeDocument")]
    public partial class SupplierDisputeDocument : BaseDomainModel
    {
        public int SupplierDisputeDocumentId { get; set; }

        public int DocumentId { get; set; }

        public int SupplierDisputeId { get; set; }

        [StringLength(8)]
        public string AdditionalDocumentGroup { get; set; }

        [StringLength(8)]
        public string AdditionalDocumentType { get; set; }

        public int CreatedById { get; set; }
        [Column("IsVisibleToVendor")]
        public bool VisibleToVendor { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime CreatedDate { get; set; }

        public int? LastUpdatedById { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? LastUpdatedDate { get; set; }

        [Column(TypeName = "timestamp")]
        [MaxLength(8)]
        [Timestamp]
        public byte[] Version { get; set; }

    }
}
