﻿namespace DomainModel.Accounting
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("disp.SupplierDispute")]
    public partial class SupplierDispute : BaseDomainModel
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public SupplierDispute()
        {
            supplierDisputeDocuments = new HashSet<SupplierDisputeDocument>();
            supplierDisputeFollowups = new HashSet<SupplierDisputeFollowup>();
            supplierDisputeEscalations = new HashSet<SupplierDisputeEscalation>();
        }

        [Key]
        public int SupplierDisputeId { get; set; }
        
        public int? AssignUserId { get; set; }
        
        public int? FieldScapeWorkOrderId { get; set; }
        public int? VendorWorkOrderId { get; set; }
        public int? InspWorkOrderId { get; set; }
        
        public int BulkId { get; set; }
        [StringLength(4000)]
        public string VendorDisputeComments { get; set; }
        [StringLength(4000)]
        public string SLFSResponseToVendor { get; set; }
        [StringLength(4000)]
        public string VendorEscalationComments { get; set; }
        [StringLength(4000)]
        public string SLFSResponseToEscalation { get; set; }
        [StringLength(8)]
        public string DisputeStatusGroup { get; set; }
        [StringLength(8)]
        public string DisputeStatusType { get; set; }
        [StringLength(8)]
        public string DisputeResolutionGroup { get; set; }
        [StringLength(8)]
        public string DisputeResolutionType { get; set; }
        public DateTime? DisputeCompleteDate { get; set; }
        [StringLength(8)]
        public string ResponsibleDepartmentGroup { get; set; }

        [StringLength(8)]
        public string ResponsibleDepartmentType { get; set; }
        [StringLength(8)]
        public string DisputeGroup { get; set; }

        [StringLength(8)]
        public string DisputeType { get; set; }
        public int? DisputeErrorCausedById { get; set; }

        [Column(TypeName = "money")]
        public decimal? CreditVendorAmount { get; set; }
        [Column(TypeName = "money")]
        public decimal? DebitVendorAmount { get; set; }
        [Column(TypeName = "money")]
        public decimal? DisputeAmount { get; set; }
        [StringLength(20)]
        public string RebillNumber { get; set; }
        [Column(TypeName = "money")]
        public decimal? HardLossAmount { get; set; }
        [StringLength(8)]
        public string DisputeErrorGroup { get; set; }

        [StringLength(8)]
        public string DisputeErrorType { get; set; }
        public int? ApprovedById { get; set; }
        public int? DisputecompletedById { get; set; }
        public int? VendorId { get; set; }
        public int CreatedById { get; set; }
        [Column(TypeName = "datetime2")]
        public DateTime CreatedDate { get; set; }
        public int? LastUpdatedById { get; set; }
        [Column(TypeName = "datetime2")]
        public DateTime? LastUpdatedDate { get; set; }
        [Column(TypeName = "timestamp")]
        [MaxLength(8)]
        [Timestamp]
        public byte[] Version { get; set; }
        public string DisputeReasonType { get; set; }
        public string DisputeReasonGroup { get; set; }
        [Column("IsVisibleToVendor")]
        public bool EscalatedByVendor { get; set; }
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<SupplierDisputeDocument> supplierDisputeDocuments { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<SupplierDisputeFollowup> supplierDisputeFollowups { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<SupplierDisputeEscalation> supplierDisputeEscalations { get; set; }

        
    }
}
