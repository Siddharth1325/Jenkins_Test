﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.Spatial;

namespace DomainModel.Accounting
{
    [Table("stg.BulkFile")]// Todo
    public class SupplierConfigurationBulkFile : BaseDomainModel
    {
        [Key]
        [Column("BulkFileID")]
        public int SupplierConfigurationBulkFileId { get; set; }

        [Column("FileTypeEleCde")]
        public string ConfigurationType { get; set; }

        [Column("FileName")]
        public string FileName { get; set; }

        [NotMapped]
        public int DocumentId { get; set; } // Not found
        public int? VendorId { get; set; } 
        [Column("FileStatus")]
        public string Status { get; set; }

        [Column("FileCount")]
        public int? TotalRecordCount { get; set; }

        [Column("CreateSuccessCount")]
        public int? SuccessRecordCount { get; set; }// Not found

        [Column("CreateFailureCount")]
        public int? FailedRecordCount { get; set; }// Not sure

        [Column("FileStatusDesc")]
        public string FailureMessage { get; set; }

        [NotMapped]
        public int? MasterClientProfileId { get; set; }
        [NotMapped]
        public int? SubClientProfileId { get; set; }
        [NotMapped]
        public int? ClientNumber { get; set; }
        [NotMapped]
        public string ClientName { get; set; }

       // [Column("AppUserID")]
        [NotMapped]
        public int CreatedById { get; set; }

        [Column("FileDate", TypeName = "datetime2")]
        
        public DateTime? CreatedDate { get; set; }
       // public string FileTypeEleCde { get; set; }
       // [Column("DBLastUpdatedBy")]
        [NotMapped]
        public int? LastUpdatedById { get; set; }

        [Column("DBLastUpdatedDate", TypeName = "datetime2")]       
        public DateTime? LastUpdatedDate { get; set; }
        
        [Column(TypeName = "timestamp")]
        [MaxLength(8)]
        [Timestamp]
        [NotMapped]
        public byte[] Version { get; set; }

        [Column("BulkID")]
        public string BulkId { get; set; }

        public int AppUserID { get; set; }
        [Column("UserName")]
        public string UploadedBy { get; set; }

    }
}
