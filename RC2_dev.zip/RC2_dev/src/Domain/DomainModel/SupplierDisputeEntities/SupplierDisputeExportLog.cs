﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.Spatial;

namespace DomainModel.Accounting
{
    [Table("stg.StagingVendorBulkDispute")]
    public class SupplierDisputeExportLog : BaseDomainModel
    {
        [Key]
        public long BulkVendorDisputeId { get; set; }
        [MaxLength(50)]
        public string BulkId { get; set; }
        public long Linenumber { get; set; }
        [MaxLength(20)]
        public string VendorID { get; set; }
        [MaxLength(20)]
        public string Appuserid { get; set; }
        [MaxLength(20)]
        public string FieldScapeWO { get; set; }
        [MaxLength(20)]
        public string AssetShieldInspectionWO { get; set; }
        [MaxLength(20)]
        public string PreservationVendorWO { get; set; }
        [MaxLength(50)]
        public string DisputedAmount { get; set; }
        [MaxLength(1000)]
        public string DisputeReason { get; set; }
        public string DisputeComments { get; set; }
        [MaxLength(50)]
        public string RecordStatus { get; set; }
        [MaxLength(500)]
        public string StatusMessage { get; set; }
        [MaxLength(100)]
        public string DBCreatedBy { get; set; }
        [Column(TypeName = "datetime2")]
        public DateTime? DBCreatedDate { get; set; }
        [MaxLength(100)]
        public string DBLastUpdatedBy { get; set; }
        [Column(TypeName = "datetime2")]
        public DateTime? DBLastUpdatedDate { get; set; }
    }
}
