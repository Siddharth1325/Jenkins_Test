namespace DomainModel.Accounting
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("disp.SupplierDisputeFollowup")]
    public partial class SupplierDisputeFollowup : BaseDomainModel
    {
        [Key]
        public int SupplierDisputeFollowupId { get; set; }

        public int SupplierDisputeId { get; set; }

        [StringLength(8)]
        public string FollowupStatusGroup { get; set; }

        [StringLength(8)]
        public string FollowupStatusType { get; set; }
        public int? AssignedToUserId { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? FollowupAssignDate { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? FollowupCompleteDate { get; set; }
        [StringLength(8)]
        public string FollowupResolutionStatusGroup { get; set; }

        [StringLength(8)]
        public string FollowupResolutionStatusType { get; set; }

        public int CreatedById { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime CreatedDate { get; set; }

        public int? LastUpdatedById { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? LastUpdatedDate { get; set; }

        [Column(TypeName = "timestamp")]
        [MaxLength(8)]
        [Timestamp]
        public byte[] Version { get; set; }
    }
}
