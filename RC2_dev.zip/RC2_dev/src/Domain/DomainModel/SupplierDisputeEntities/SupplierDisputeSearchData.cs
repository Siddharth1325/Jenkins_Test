﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DomainModel.Accounting
{
    public class SupplierDisputeSearchData : BaseDomainModel
    {
        public int BulkId { get; set; }
        public int SupplierDisputeId { get; set; }
        public int VendorId { get; set; }
        public int? FieldScapeWorkOrderId { get; set; }
        public int? InspWorkOrderId { get; set; }
        public int? VendorWorkOrderId { get; set; }
        public DateTime DisputeDate { get; set; }

        public string isputeStatusGroup { get; set; }
        public string isputeStatusType { get; set; }
        public DateTime? EscalationDate { get; set; }
        public string EscalationResoulation { get; set; }
        public decimal? diffAmountApprove { get; set; }
        public string PropertyAddress { get; set; }
    }
}
