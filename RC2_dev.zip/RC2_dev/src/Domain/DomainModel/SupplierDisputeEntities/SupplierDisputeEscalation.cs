﻿namespace DomainModel.Accounting
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("disp.SupplierDisputeEscalation")]
    public partial class SupplierDisputeEscalation : BaseDomainModel
    {
        [Key]
        public int SupplierDisputeEscalationId { get; set; }

        public int SupplierDisputeId { get; set; }

        [StringLength(8)]
        public string EscalationDisputeStatusGroup { get; set; }

        [StringLength(8)]
        public string EscalationDisputeStatusType { get; set; }
        public int? AssignedToUserId { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? EscalationAssignDate { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? EscalationCompleteDate { get; set; }
        [StringLength(8)]
        public string EscalationResolutionStatusGroup { get; set; }

        [StringLength(8)]
        public string EscalationResolutionStatusType { get; set; }

        public string EscalationComments { get; set; }

        public string SLFSEscalationComments { get; set; }

        public bool EscalatedByVendor { get; set; }

        public int CreatedById { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime CreatedDate { get; set; }

        public int? LastUpdatedById { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? LastUpdatedDate { get; set; }


        public DateTime? EscalationDueDate { get; set; }

        [Column(TypeName = "timestamp")]
        [MaxLength(8)]
        [Timestamp]
        public byte[] Version { get; set; }
    }
}
