﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DomainModel.Accounting
{
    public class SupplierDisputeSearchInput : BaseDomainModel
    {
        public int? VendorId { get; set; }
        public int? AssignUserId { get; set; }
        public int? BulkId { get; set; }
        public string State { get; set; }
        public int? FieldScapeWorkOrderId { get; set; }
        public int? VendorWorkOrderId { get; set; }
        public int? InspWorkOrderId { get; set; }
        public string DisputeStatusType { get; set; }
        public DateTime? DisputeSubmittedFromDate { get; set; }
        public DateTime? DisputeSubmittedToDate { get; set; }
        public DateTime? DisputeDueDateFrom { get; set; }
        public DateTime? DisputeDueDateTo { get; set; }
        public string EscalationResolution { get; set; }
        public DateTime? EscalationResolutionFromDate { get; set; }
        public DateTime? EscalationResolutionToDate { get; set; }
       
    }
}
