namespace DomainModel.Accounting
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("act.AccountsPayableInvoice")]
    public partial class AccountsPayableInvoice : BaseDomainModel
    {
        public AccountsPayableInvoice()
        {
            AccountingAPInvoicePayables = new HashSet<AccountingAPInvoicePayable>();
            AccountsPayableAdjustments = new HashSet<AccountsPayableAdjustment>();
            AccountsPayableRemittances = new HashSet<AccountsPayableRemittance>();           
        }

        public int AccountsPayableInvoiceId { get; set; }

        public int ApplicationId { get; set; }

        public int? VendorProfileId { get; set; }

        [Required]
        [StringLength(25)]
        public string InvoiceNumber { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime InvoiceDate { get; set; }

        [Column(TypeName = "money")]
        public decimal InvoiceAmount { get; set; }

        public int CreatedById { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime CreatedDate { get; set; }

        public int? LastUpdatedById { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? LastUpdatedDate { get; set; }

        [Column(TypeName = "timestamp")]
        [MaxLength(8)]
        [Timestamp]
        public byte[] Version { get; set; }

        public virtual ICollection<AccountingAPInvoicePayable> AccountingAPInvoicePayables { get; set; }

        public virtual ICollection<AccountsPayableAdjustment> AccountsPayableAdjustments { get; set; }

        public virtual ICollection<AccountsPayableRemittance> AccountsPayableRemittances { get; set; }

    }
}
