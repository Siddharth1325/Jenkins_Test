namespace DomainModel.Accounting
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("fs.Order")]
    public partial class Order
    {
        public Order()
        {
            WorkOrders = new HashSet<WorkOrder>();
            WorkOrderItems = new HashSet<WorkOrderItem>();
        }

        public int OrderId { get; set; }

        public int? LoanId { get; set; }

        [StringLength(5)]
        public string OrderTypeGroup { get; set; }

        [StringLength(8)]
        public string OrderType { get; set; }

        [StringLength(5)]
        public string OrderStatusGroup { get; set; }

        [StringLength(8)]
        public string OrderStatusType { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime RequestedDate { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime ReceivedDate { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? DueToClientDate { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? CompletedDate { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? TransmittedDate { get; set; }

        [Required]
        [StringLength(100)]
        public string BorrowerFirstName { get; set; }

        [StringLength(1)]
        public string BorrowerMiddleInitial { get; set; }

        [Required]
        [StringLength(100)]
        public string BorrowerLastName { get; set; }

        [Required]
        [StringLength(100)]
        public string AddressLine1 { get; set; }

        [StringLength(100)]
        public string AddressLine2 { get; set; }

        [Required]
        [StringLength(100)]
        public string CityName { get; set; }

        [StringLength(2)]
        public string StateCode { get; set; }

        [Required]
        [StringLength(5)]
        public string ZipCode { get; set; }

        [StringLength(4)]
        public string ZipPlusFour { get; set; }

        [StringLength(2000)]
        public string SpecialInstructions { get; set; }

        [StringLength(5)]
        public string LOBTypeGroup { get; set; }

        [StringLength(8)]
        public string LOBType { get; set; }

        [StringLength(5)]
        public string MBACodeGroup { get; set; }

        [StringLength(8)]
        public string MBACodeType { get; set; }

        [StringLength(25)]
        public string DepartmentCode { get; set; }

        public int OrderedProductId { get; set; }

        public int? ConvertedProductId { get; set; }

        [StringLength(5)]
        public string DepartmentTypeGroup { get; set; }

        [StringLength(8)]
        public string DepartmentType { get; set; }

        public int? RecommendedVendor { get; set; }

        public bool IsDoNotPayVendor { get; set; }

        public bool IsDoNotBillClient { get; set; }

        public bool IsSkipDupChecks { get; set; }

        public bool IsQCOrdered { get; set; }

        public bool IsRushOrder { get; set; }

        public bool IsFrequent { get; set; }

        [Required]
        [StringLength(5)]
        public string OrderSourceGroup { get; set; }

        [Required]
        [StringLength(8)]
        public string OrderSourceType { get; set; }

        public int CreatedById { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime CreatedDate { get; set; }

        public int? LastUpdatedById { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? LastUpdatedDate { get; set; }

        [Column(TypeName = "timestamp")]
        [MaxLength(8)]
        [Timestamp]
        public byte[] Version { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? WindowStartDate { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? WindowEndDate { get; set; }

        public virtual Loan Loan { get; set; }

        public virtual Product Product { get; set; }

        public virtual ICollection<WorkOrder> WorkOrders { get; set; }

        public virtual ICollection<WorkOrderItem> WorkOrderItems { get; set; }

        public virtual Product Product1 { get; set; }

        public virtual VendorProfile VendorProfile { get; set; }
    }
}
