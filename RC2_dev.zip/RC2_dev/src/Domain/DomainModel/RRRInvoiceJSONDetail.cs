﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DomainModel.Accounting
{
    [Table("exp.RRRInvoiceJSONDetail")]
    [System.CodeDom.Compiler.GeneratedCode("EF", "6.1.0")]
    public partial class RRRInvoiceJSONDetail : BaseDomainModel
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public RRRInvoiceJSONDetail()
        {
            RRRDecisionInvoiceItemTrackings = new HashSet<RRRDecisionInvoiceItemTracking>();
        }

        [Key]
        public int RRRInvoiceJSONDetailId { get; set; }
        public int? RRRInvoiceJSONHeaderId { get; set; }
        public int ApplicationId { get; set; }
        public int? AccountsReceivableDetailId { get; set; }
        public int? AccountingExportDetailId { get; set; }
        public string Category { get; set; }
        public string Description { get; set; }
        public int? BillingCode { get; set; }
        public int? Quantity { get; set; }
        public decimal? ItemPrice { get; set; }
        public decimal? ItemSubtotal { get; set; }
        public decimal? ItemTax { get; set; }
        public decimal? ItemTotal { get; set; }
        [StringLength(8)]
        public string RecordStatusGroup { get; set; }
        [StringLength(8)]
        public string RecordStatusType { get; set; }
        public decimal? ItemApprovedAmount { get; set; }
        public string ItemDecisionComments { get; set; }
        public string ItemDecisionStatus { get; set; }
        public int? CreatedById { get; set; }
        public DateTime? CreatedDate { get; set; }
        public int? LastUpdatedById { get; set; }
        public DateTime? LastUpdatedDate { get; set; }
        [Column(TypeName = "timestamp")]
        [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        [MaxLength(8)]
        public byte[] Version { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? SLFSDecisionDate { get; set; }

        [StringLength(8)]
        public string SLFSDecisionGroup { get; set; }

        [StringLength(8)]
        public string SLFSDecisionType { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<RRRDecisionInvoiceItemTracking> RRRDecisionInvoiceItemTrackings { get; set; }

    }
}
