namespace DomainModel.Accounting
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("act.AccountsPayableAdjustment")]
    public partial class AccountsPayableAdjustment : BaseDomainModel
    {
        public int AccountsPayableAdjustmentId { get; set; }

        public int ApplicationId { get; set; }

        public int? AccountsPayableInvoiceId { get; set; }

        public int? DisputePayableAdjustmentHistoryId { get; set; }

        public int? DisputePenaltyAdjustmentHistoryId { get; set; }

        public int? AccountsPayableDetailId { get; set; } 

        public int? WorkOrderId { get; set; }

        [Required]
        [StringLength(8)]
        public string AdjustmentType { get; set; }

        [Required]
        [StringLength(5)]
        public string AdjustmentCode { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime AdjustmentDate { get; set; }

        [Column(TypeName = "money")]
        public decimal Amount { get; set; }

        [Required]
        [StringLength(8)]
        public string GLTransTypeGroup { get; set; }

        [Required]
        [StringLength(8)]
        public string GLTransType { get; set; }

        [StringLength(8)]
        public string APAdjStatusGroup { get; set; }

        [StringLength(8)]
        public string APAdjStatusType { get; set; }
        
        [Required]
        [StringLength(10)]
        public string Operation { get; set; }

        [Required]
        [StringLength(10)]
        public string Function { get; set; }

        [Required]
        [StringLength(10)]
        public string NaturalAccount { get; set; }

        [StringLength(2000)]
        public string Comments { get; set; }

        [StringLength(2000)]
        public string SupplierComment { get; set; }

        public int CreatedById { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime CreatedDate { get; set; }

        public int? LastUpdatedById { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? LastUpdatedDate { get; set; }

        [Column(TypeName = "timestamp")]
        [MaxLength(8)]
        [Timestamp]
        public byte[] Version { get; set; }

        public virtual DisputePayableAdjustmentHistory DisputePayableAdjustmentHistory { get; set; }
    }
}
