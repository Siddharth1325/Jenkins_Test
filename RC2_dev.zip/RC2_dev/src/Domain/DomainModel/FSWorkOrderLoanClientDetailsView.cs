﻿

namespace DomainModel.Accounting
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;
    
    [Table("act.FSWorkOrderLoanClientDetailsView")]
    public partial class FSWorkOrderLoanClientDetailsView
    {
        [Key]
        [Column(Order = 0)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int WorkOrderId { get; set; }

        [Key]
        [Column(Order = 1)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int SourceWorkOrderId { get; set; }

        [Key]
        [Column(Order = 2)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int OrderId { get; set; }

        [Key]
        [Column(Order = 3)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int LoanId { get; set; }

        [StringLength(8)]
        public string LoanType { get; set; }

        [StringLength(5)]
        public string InvestorIdentifier { get; set; }

        [StringLength(25)]
        public string ClientLSCI { get; set; }

        [StringLength(100)]
        public string ValidAddress1 { get; set; }

        [StringLength(100)]
        public string ValidAddress2 { get; set; }

        [StringLength(100)]
        public string ValidCityName { get; set; }

        [StringLength(100)]
        public string ValidCountyName { get; set; }

        [StringLength(2)]
        public string ValidStateCode { get; set; }

        [StringLength(9)]
        public string ValidZipCode { get; set; }

        [StringLength(4)]
        public string ValidZipPlusFour { get; set; }

        [StringLength(100)]
        public string PropertyAddress1 { get; set; }

        [StringLength(100)]
        public string PropertyAddress2 { get; set; }

        [StringLength(100)]
        public string PropertyCityName { get; set; }

        [StringLength(100)]
        public string PropertyCountyName { get; set; }

        [StringLength(2)]
        public string PropertyStateCode { get; set; }

        [StringLength(9)]
        public string PropertyZipCode { get; set; }

        [StringLength(4)]
        public string PropertyZipPlusFour { get; set; }
    }
}
