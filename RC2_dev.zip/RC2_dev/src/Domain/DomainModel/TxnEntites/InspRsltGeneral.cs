namespace DomainModel.InspResult
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    // this does not exists in Accouting but we get updates from insp, so we map it to this temporarily and eventually save it in WorkOrder.
    [Table("fs.InspRsltGeneral")]
    [System.CodeDom.Compiler.GeneratedCode("EF", "6.1.0")]
    public partial class InspRsltGeneral:BaseDomainModel
    {
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int InspRsltGeneralId { get; set; }
        [StringLength(25), RegularExpression(@"^[a-zA-Z0-9\-\s]*$", ErrorMessage = "Invalid field value")]
        public string InspectorUniqueId { get; set; }

        [StringLength(40), RegularExpression(@"^[a-zA-Z0-9]*$", ErrorMessage = "Invalid field value")]
        public string GateAccessCode { get; set; }

        [StringLength(40), RegularExpression(@"^[a-zA-Z0-9]*$", ErrorMessage = "Invalid field value")]
        public string DoorKeyCode { get; set; }

        [StringLength(40), RegularExpression(@"^[a-zA-Z0-9]*$", ErrorMessage = "Invalid field value")]
        public string LockBoxCode { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? InspectionDate1 { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? InspectionDate2 { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? InspectionDate3 { get; set; }

        public bool? IsDoorCardLeft { get; set; }

        [StringLength(4000)]
        public string ReasonNoDoorCard { get; set; }

        [Column(TypeName = "money"), RegularExpression(@"^\d{1,15}(\.\d{1,4})?$", ErrorMessage = "Invalid field value"), Range(0, 922337203685477, ErrorMessage = "Out of Range")]
        public decimal? MarketValueOpinion { get; set; }

        public bool? IsCorrectedAddress { get; set; }

        [StringLength(100)]
        public string CorrectedAddress1 { get; set; }

        [StringLength(100)]
        public string CorrectedAddress2 { get; set; }

        [StringLength(100)]
        public string CorrectedCityName { get; set; }

        [StringLength(2)]
        public string CorrectedStateCode { get; set; }

        [StringLength(8), RegularExpression(@"^[0-9]{5}$", ErrorMessage = "Invalid field value.")]
        public string CorrectedZipCode { get; set; }

        [StringLength(4000)]
        public string HowNewAddressFound { get; set; }

        [StringLength(20), RegularExpression(@"^-?(([0-8]?[0-9])|90)(\.[0-9]{1,6})?$", ErrorMessage = "Invalid field value."), Range(-90.0, 90.0, ErrorMessage = "Out of Range")]
        public string GeoLatitude { get; set; }

        [StringLength(20), RegularExpression(@"^-?(([1][0-7][0-9])|([1-9]?[0-9])|180)(\.[0-9]{1,6})?$", ErrorMessage = "Invalid field value."), Range(-180.0, 180.0, ErrorMessage = "Out of Range")]
        public string GeoLongitude { get; set; }

        [StringLength(8)]
        public string IsHOAGroup { get; set; }

        [StringLength(8)]
        public string IsHOAType { get; set; }

        public bool? IsGated { get; set; }

        public bool? IsCommunityInfoAvailable { get; set; }

        [StringLength(200)]
        public string CommunityInfoUnavailReason { get; set; }

        [StringLength(100)]
        public string CommunityName { get; set; }

        [StringLength(100), RegularExpression(@"^[0-9\-]{1,100}$", ErrorMessage = "Invalid field value.")]
        public string CommunityNumber { get; set; }

        [StringLength(100)]
        public string CommunityAddress1 { get; set; }

        [StringLength(100)]
        public string CommunityAddress2 { get; set; }

        [StringLength(100)]
        public string CommunityCityName { get; set; }

        [StringLength(2)]
        public string CommunityStateCode { get; set; }

        [StringLength(5)]
        public string CommunityZipCode { get; set; }

        [StringLength(4000)]
        public string Notes { get; set; }

        [StringLength(4000)]
        public string Comments { get; set; } 

        public int CreatedById { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime CreatedDate { get; set; }

        public int? LastUpdatedById { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? LastUpdatedDate { get; set; }

        [Column(TypeName = "timestamp")]
        [MaxLength(8)]
        [Timestamp]
        public byte[] Version { get; set; }

       
    }
}
