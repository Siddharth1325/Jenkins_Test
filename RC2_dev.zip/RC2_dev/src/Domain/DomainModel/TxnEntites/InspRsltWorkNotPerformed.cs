namespace DomainModel.InspResult
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;
    // this does not exists in Accouting but we get updates from insp, so we map it to this temporarily and eventually save it in WorkOrder.
    [Table("fs.InspRsltWorkNotPerformed")]
    [System.CodeDom.Compiler.GeneratedCode("EF", "6.1.0")]
    public partial class InspRsltWorkNotPerformed : BaseDomainModel
    {
        public InspRsltWorkNotPerformed()
        {
            
        }

        public int InspRsltWorkNotPerformedId { get; set; }

        public int? InspectionResultId { get; set; }

        [StringLength(8)]
        public string WorkNotPerformedReasonGroup { get; set; }

        [StringLength(8)]
        public string WorkNotPerformedReasonType { get; set; }

        [StringLength(8)]
        public string BadAddrGroupCode { get; set; }

        [StringLength(1000)]
        public string OtherBadAddrReason { get; set; }

        [StringLength(8)]
        public string CheckWithGroupCode { get; set; }

        [StringLength(1000)]
        public string OtherCheckWithReason { get; set; }

        [StringLength(8)]
        public string OutOfAreaGroup { get; set; }

        [StringLength(8)]
        public string OutOfAreaType { get; set; }

        [StringLength(8)]
        public string AccessDeniedGroup { get; set; }

        [StringLength(8)]
        public string AccessDeniedType { get; set; }

        [StringLength(8)]
        public string KeyCodeGroup { get; set; }

        [StringLength(8)]
        public string KeyCodeType { get; set; }

        [StringLength(1000)]
        public string OtherKeyCodeReason { get; set; }

        [StringLength(8)]
        public string GuardGroup { get; set; }

        [StringLength(8)]
        public string GuardType { get; set; }

        public bool? IsWeather7Days { get; set; }

        public bool? IsNoTrespass { get; set; }

        [StringLength(1000)]
        public string NoTrespassExplain { get; set; }

        public bool? IsViewableFromStreet { get; set; }

        [StringLength(100)]
        public string CommunityName { get; set; }

        [StringLength(100)]
        public string CommunityNumber { get; set; }

        [StringLength(100)]
        public string CommunityAddress { get; set; }

        [StringLength(1000)]
        public string AccessConstraints { get; set; }

        [StringLength(1000)]
        public string OtherExplain { get; set; }

        [StringLength(1000)]
        public string Comments { get; set; }

        [StringLength(1000)]
        public string WeatherConditionExplain { get; set; }

        public int CreatedById { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime CreatedDate { get; set; }
         
        public int? LastUpdatedById { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? LastUpdatedDate { get; set; }

        [Column(TypeName = "timestamp")]
        [MaxLength(8)]
        [Timestamp]
        public byte[] Version { get; set; }

    }
}
