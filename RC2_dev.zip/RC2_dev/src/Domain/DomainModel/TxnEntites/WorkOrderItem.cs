using CommonLib.ModelAttrib;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.Spatial;

namespace DomainModel.Accounting
{
    [Table("txn.WorkOrderItem")]
    public partial class WorkOrderItem : BaseDomainModel
    {
        public WorkOrderItem()
        {
            WorkOrderLineItems = new HashSet<WorkOrderLineItem>();
        }

        [MapIgnoreProp()]
        public int WorkOrderItemId { get; set; }

        [SecondaryKeyPropAttribute(Order = 1)]
        public int ApplicationId { get; set; }

        [SecondaryKeyPropAttribute(Order = 2)]
        [MapProp("WorkOrderItemId")]
        public int SourceWorkOrderItemId { get; set; }

        public int? OrderId { get; set; }

        public int? WorkOrderId { get; set; }

        [StringLength(8)]
        public string WorkOrderItemStatusGroup { get; set; }

        [StringLength(8)]
        public string WorkOrderItemStatusType { get; set; }

        public int? ProductId { get; set; }

        public int? ServiceId { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? DueToClientDate { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? DueFromVendorDate { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? AdjustedDueDate { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? CompletedDate { get; set; }

        [Column(TypeName = "datetime2")]
        [MapProp("LastUpdatedDate")]
        public DateTime? LastSubscriptionUpdateDate { get; set; }
        public bool IsClientBilling { get; set; }

        [StringLength(8)]
        public string WorkPerformedGroup { get; set; }

        [StringLength(8)]
        public string WorkPerformed { get; set; }

        [StringLength(8)]
        public string WorkNotPerformedReasonGroup { get; set; }

        [StringLength(8)]
        public string WorkNotPerformedReason { get; set; }

        [StringLength(8)]
        public string VendorFeeType { get; set; }

        [Column(TypeName = "money")]
        public decimal? VendorFlatFee { get; set; }

        [Column(TypeName = "money")]
        public decimal? VendorAgreedPrice { get; set; }

        [Column(TypeName = "money")]
        public decimal? ClientAgreedPrice { get; set; }

        [Column(TypeName = "money")]
        public decimal? VendorFinalCost { get; set; }

        [Column(TypeName = "money")]
        public decimal? ClientFinalPrice { get; set; }

        [StringLength(8)]
        public string VendorDiscountType { get; set; }

        [Column(TypeName = "money")]
        public decimal? VendorDiscount { get; set; }

        [Column(TypeName = "money")]
        public decimal? InitialClientPrice { get; set; }

        [Column(TypeName = "money")]
        public decimal? InitialVendorCost { get; set; }

        public bool? IsWaiveDiscount { get; set; }

        [StringLength(1000)]
        public string VendorCostComment { get; set; }

        [StringLength(1000)]
        public string DiscountComment { get; set; }

        public bool? IsServiceLevelBilling { get; set; }

        public decimal? Penalty { get; set; }

        public int CreatedById { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime CreatedDate { get; set; }

        public int? LastUpdatedById { get; set; }

        [Column(TypeName = "datetime2")]

        public DateTime? LastUpdatedDate { get; set; }

        [Column(TypeName = "timestamp")]
        [MaxLength(8)]
        [Timestamp]
        public byte[] Version { get; set; }

        public virtual Product Product { get; set; }

        public virtual WorkOrder WorkOrder { get; set; }

        public virtual ICollection<WorkOrderLineItem> WorkOrderLineItems { get; set; }
    }
}
