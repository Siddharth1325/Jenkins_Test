using CommonLib.ModelAttrib;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.Spatial;

namespace DomainModel.Accounting
{
    [Table("txn.Order")]
    public partial class Order : BaseDomainModel
    {
        public Order()
        {
            Cancellations = new HashSet<Cancellation>();
            WorkOrders = new HashSet<WorkOrder>();
            VendorWorkOrders = new HashSet<VendorWorkOrder>();
        }
        [MapIgnoreProp()]
        public int OrderId { get; set; }
        [SecondaryKeyPropAttribute(Order = 1)]
        public int ApplicationId { get; set; }

        [SecondaryKeyPropAttribute(Order = 2)]
        [MapProp("OrderId")]
        public int SourceOrderId { get; set; }

        public int LoanId { get; set; }

        [StringLength(8)]
        public string OrderTypeGroup { get; set; }

        [StringLength(8)]
        public string OrderType { get; set; }

        [StringLength(8)]
        public string OrderStatusGroup { get; set; }

        [StringLength(8)]
        public string OrderStatusType { get; set; }

        [StringLength(8)]
        public string CancellationReasonGroup { get; set; }

        [StringLength(8)]
        public string CancellationReasonType { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime RequestedDate { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime ReceivedDate { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? DueToClientDate { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? CompletedDate { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? TransmittedDate { get; set; }

        [Required]
        [StringLength(100)]
        public string BorrowerFirstName { get; set; }

        [StringLength(1)]
        public string BorrowerMiddleInitial { get; set; }

        [Required]
        [StringLength(100)]
        public string BorrowerLastName { get; set; }

        [Required]
        [StringLength(100)]
        public string AddressLine1 { get; set; }

        [StringLength(100)]
        public string AddressLine2 { get; set; }

        [Required]
        [StringLength(100)]
        public string CityName { get; set; }

        [StringLength(2)]
        public string StateCode { get; set; }

        [Required]
        [StringLength(5)]
        public string ZipCode { get; set; }

        [StringLength(4)]
        public string ZipPlusFour { get; set; }

        [StringLength(100)]
        public string CountyName { get; set; }

        [StringLength(2000)]
        public string SpecialInstructions { get; set; }

        [StringLength(8)]
        [MapProp("LobTypeGroup")]
        public string ProductCategoryGroup { get; set; }

        [StringLength(8)]
        [MapProp("LobType")]
        public string ProductCategory { get; set; }

        [StringLength(8)]
        [MapProp("MbaCodeGroup")]
        public string MBACodeGroup { get; set; }

        [StringLength(8)]
        [MapProp("MbaCodeType")]
        public string MBACodeType { get; set; }

        [StringLength(25)]
        public string DepartmentCode { get; set; }

        public int OrderedProductId { get; set; }

        public int? ConvertedProductId { get; set; }

        [StringLength(8)]
        public string DepartmentTypeGroup { get; set; }

        [StringLength(8)]
        public string DepartmentType { get; set; }

        public int? RecommendedVendor { get; set; }

        public bool IsDoNotPayVendor { get; set; }

        public bool IsDoNotBillClient { get; set; }
	
	    public bool IsDonotSendToMSP { get; set; }

        public bool IsDoNotConvert { get; set; }

        public bool IsSkipDupChecks { get; set; }

        [MapProp("IsqcOrdered")]
        public bool IsQCOrdered { get; set; }

        public bool BPMProcessExists { get; set; }

        public bool IsRushOrder { get; set; }

        public bool IsFrequent { get; set; }

        public bool IsInitial { get; set; }

        [Required]
        [StringLength(8)]
        public string OrderSourceGroup { get; set; }

        [Required]
        [StringLength(8)]
        public string OrderSourceType { get; set; }

        [StringLength(8)]
        public string FileTypeGroup { get; set; }

        [StringLength(8)]
        public string FileType { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? CancellationDate { get; set; }

        public int? ClientSystemId { get; set; }
        [StringLength(10)]
        public string ClientDepartment { get; set; }

        public int CreatedById { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime CreatedDate { get; set; }

        public int? LastUpdatedById { get; set; }

        [Column(TypeName = "datetime2")]
       
        public DateTime? LastUpdatedDate { get; set; }

        [Column(TypeName = "timestamp")]
        [MaxLength(8)]
        [Timestamp]
        public byte[] Version { get; set; }

        public virtual Product OrderedProduct { get; set; }

        public virtual Product ConvertedProduct { get; set; }

        public virtual ICollection<Cancellation> Cancellations { get; set; }

        public virtual Loan Loan { get; set; }

        public virtual ICollection<WorkOrder> WorkOrders { get; set; }

        public virtual ICollection<VendorWorkOrder> VendorWorkOrders { get; set; }

        [StringLength(40)]
        public string RequestorCode { get; set; }

        [Column(TypeName = "datetime2")]
        [MapProp("LastUpdatedDate")]
        public DateTime? LastSubscriptionUpdateDate { get; set; }

        [Column(TypeName = "money")]
        public decimal? ClientRushFee { get; set; }

        [Column(TypeName = "money")]
        public decimal? ClientTripFee { get; set; }

        public string PresLoanTypeGroup { get; set; }
        public string PresLoanType { get; set; }

        public string RevenueGroup { get; set; }

        public string RevenueType { get; set; }

        public string OriginalRecordId { get; set; }
        public string OrderBy { get; set; }
        public string BillTo { get; set; }
        public string PartnerSystemId { get; set; }
        public string PackageName { get; set; }
        public DateTime? QcCompletedDate { get; set; }

    }
}
