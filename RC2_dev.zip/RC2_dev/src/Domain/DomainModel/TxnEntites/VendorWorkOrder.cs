﻿using CommonLib.ModelAttrib;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.Spatial;

namespace DomainModel.Accounting
{
    [Table("txn.VendorWorkOrder")]
    public partial class VendorWorkOrder : BaseDomainModel
    {
        [MapIgnoreProp()]
        public int VendorWorkOrderId { get; set; }

        [SecondaryKeyPropAttribute(Order = 1)]
        public int ApplicationId { get; set; }

        [SecondaryKeyPropAttribute(Order = 2)]
        [MapProp("VendorWorkOrderId")]
        public int SourceVendorWorkOrderId { get; set; }

        public int OrderId { get; set; }
        public int? AssignedVendorId { get; set; }
        [Column(TypeName = "datetime2")]
        public DateTime? AssignedDate { get; set; }
        [Column(TypeName = "datetime2")]
        public DateTime? CompletedDate { get; set; }

        [StringLength(8)]
        public string WorkOrderStatusGroup { get; set; }

        [StringLength(8)]
        public string WorkOrderStatusType { get; set; }

        public string BpmProcessId { get; set; }

        public bool IsOneTimeFee { get; set; }

        [Column(TypeName = "money")]
        public decimal? VendorOneTimeFee { get; set; }

        [Column(TypeName = "money")]
        public decimal? VendorTripFee { get; set; }

        [Column(TypeName = "money")]
        public decimal? VendorMinServiceFee { get; set; }

        [Column(TypeName = "money")]
        public decimal? VendorOneTimeFinalFee { get; set; }

        [StringLength(1000)]
        public string OneTimeFeeComment { get; set; }

        [StringLength(1000)]
        public string TripFeeComment { get; set; }

        [StringLength(1000)]
        public string MinServiceFeeComment { get; set; }

        public decimal? VendorCostAfterPenalty { get; set; }

        public decimal? Penalty { get; set; }

        public int CreatedById { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime CreatedDate { get; set; }

        public int? LastUpdatedById { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? LastUpdatedDate { get; set; }

        [Column(TypeName = "timestamp")]
        [MaxLength(8)]
        [Timestamp]
        public byte[] Version { get; set; }

        public virtual Order Order { get; set; }
    }
}