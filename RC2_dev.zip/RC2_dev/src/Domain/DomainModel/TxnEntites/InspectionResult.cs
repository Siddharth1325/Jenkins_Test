namespace DomainModel.InspResult 
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;
    // this does not exists in Accouting but we get updates from insp, so we map it to this temporarily and eventually save it in WorkOrder.
    [Table("fs.InspectionResult")]
    [System.CodeDom.Compiler.GeneratedCode("EF", "6.1.0")]
    public partial class InspectionResult: BaseDomainModel
    {
        public InspectionResult()
        {
           
        }
        [Key]
        public int InspectionResultId { get; set; }

        public int? OrderId { get; set; }

        public int? WorkOrderId { get; set; }

        public int? SubmittedById { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime SubmissionDate { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? InitialSubmissionDate { get; set; }
        
        public bool IsWorkPerformed { get; set; }
        [StringLength(4000)]
        public string Comments { get; set; }
        public string SavedResults { get; set; }

        public int CreatedById { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime CreatedDate { get; set; }

        public int? LastUpdatedById { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? LastUpdatedDate { get; set; }

        [Column(TypeName = "timestamp")]
        [MaxLength(8)]
        [Timestamp]
        public byte[] Version { get; set; }

      
    }
}
