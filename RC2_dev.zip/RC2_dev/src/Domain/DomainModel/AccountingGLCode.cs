namespace DomainModel.Accounting
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("act.AccountingGLCode")]
    public partial class AccountingGLCode : BaseDomainModel
    {
        public int AccountingGLCodeId { get; set; }

        public int ApplicationId { get; set; }

        [Required]
        [StringLength(8)]
        public string ProductCategoryGroup { get; set; }

        [Required]
        [StringLength(8)]
        public string ProductCategory { get; set; }

        [Required]
        [StringLength(8)]
        public string GLTransTypeGroup { get; set; }

        [Required]
        [StringLength(8)]
        public string GLTransType { get; set; }

        [StringLength(8)]
        public string ReserveTypeGroup { get; set; }

        [StringLength(8)]
        public string ReserveType { get; set; }

        [Required]
        [StringLength(5)]
        public string GLCompany { get; set; }

        [Required]
        [StringLength(6)]
        public string LocationCode { get; set; }

        [Required]
        [StringLength(6)]
        public string Operation { get; set; }

        [Required]
        [StringLength(4)]
        public string Function { get; set; }

        [Required]
        [StringLength(6)]
        public string NaturalAccount { get; set; }

        [Required]
        [StringLength(5)]
        public string Intercompany { get; set; }

        [Required]
        [StringLength(4)]
        public string FRU1 { get; set; }

        [Required]
        [StringLength(4)]
        public string FRU2 { get; set; }
        public int? ServiceId { get; set; }

        public int? ProductId { get; set; }

        public int? FeeTypeId { get; set; }

        public int? MasterClientProfileId { get; set; }

        public int? LineItemId { get; set; }

        public bool IsActive { get; set; }

        public int CreatedById { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime CreatedDate { get; set; }

        public int? LastUpdatedById { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? LastUpdatedDate { get; set; }

        [Column(TypeName = "timestamp")]
        [MaxLength(8)]
        [Timestamp]
        public byte[] Version { get; set; }

        public virtual Service Service { get; set; }
        public virtual FeeType FeeType { get; set; }

        public virtual Product Product { get; set; }

        public virtual MasterClientProfile MasterClientProfile  { get; set; }

        public virtual LineItem LineItem { get; set; }
    }
}
