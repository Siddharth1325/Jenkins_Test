namespace DomainModel.Accounting
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("act.AccountsReceivableInvoice")]
    public partial class AccountsReceivableInvoice : BaseDomainModel
    {
        public AccountsReceivableInvoice()
        {
            AccountingARInvoiceReceivables = new HashSet<AccountingARInvoiceReceivable>();
            AccountsReceivableAdjustments = new HashSet<AccountsReceivableAdjustment>();
            //TODO
            // ExportedARInvoices = new HashSet<ExportedARInvoice>();
            // ExportedOracleARInvoices = new HashSet<ExportedOracleARInvoice>();
        }

        public int AccountsReceivableInvoiceId { get; set; }

        public int ApplicationId { get; set; }

        public int MasterClientProfileId { get; set; }

        [Required]
        [StringLength(8)]
        public string ProductCategoryGroup { get; set; }

        [Required]
        [StringLength(8)]
        public string ProductCategory { get; set; }

        [Required]
        [StringLength(8)]
        public string InvoiceTypeGroup { get; set; }

        [Required]
        [StringLength(8)]
        public string InvoiceType { get; set; }

        [Required]
        [StringLength(8)]
        public string BillFreqGroup { get; set; }

        [Required]
        [StringLength(8)]
        public string BillFreqType { get; set; }

        [Required]
        [StringLength(8)]
        public string DepartmentCode { get; set; }

        [Required]
        [StringLength(25)]
        public string InvoiceNumber { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime InvoiceDate { get; set; }

        [Column(TypeName = "money")]
        public decimal InvoiceAmount { get; set; }

        public int CreatedById { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime CreatedDate { get; set; }

        public int? LastUpdatedById { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? LastUpdatedDate { get; set; }

        [Column(TypeName = "timestamp")]
        [MaxLength(8)]
        [Timestamp]
        public byte[] Version { get; set; }

        public virtual ICollection<AccountingARInvoiceReceivable> AccountingARInvoiceReceivables { get; set; }

        public virtual ICollection<AccountsReceivableAdjustment> AccountsReceivableAdjustments { get; set; }
        //TODO
        //public virtual ICollection<ExportedARInvoice> ExportedARInvoices { get; set; }

        // public virtual ICollection<ExportedOracleARInvoice> ExportedOracleARInvoices { get; set; }
    }
}
