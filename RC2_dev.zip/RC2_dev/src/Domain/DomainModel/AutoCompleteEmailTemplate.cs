﻿namespace DomainModel.Accounting
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("fs.AutoCompleteEmailTemplate")]
    [System.CodeDom.Compiler.GeneratedCode("EF", "6.1.0")]
    public partial class AutoCompleteEmailTemplate : BaseDomainModel
    {

        public AutoCompleteEmailTemplate() { }

        public int AutoCompleteEmailTemplateId { get; set; }

        public string TemplateCode { get; set; }

        public string ToAddress { get; set; }

        public string CCAddress { get; set; }

        public string Subject { get; set; }

        public string Template { get; set; }

        public string FromAddress { get; set; }

        public int? MasterClientProfileId { get; set; }

        public int? SubClientProfileId { get; set; }

        public int? CreatedById { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime CreatedDate { get; set; }

        public int? LastUpdatedById { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? LastUpdatedDate { get; set; }

        [Column(TypeName = "timestamp")]
        [MaxLength(8)]
        [Timestamp]
        public byte[] Version { get; set; }

    }
}
