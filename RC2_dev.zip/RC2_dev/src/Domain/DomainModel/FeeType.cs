﻿namespace DomainModel.Accounting
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("adm.FeeType")]
    public partial class FeeType : BaseDomainModel
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public FeeType()
        {
            ProductFeeTypes = new HashSet<ProductFeeType>();
        }
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int FeeTypeId { get; set; }

        public bool? IsRevenue { get; set; }
        
        [Column("FeeType")]
        public string FeeTypeCode { get; set; }

        [StringLength(18)]
        public string FeeTypeName { get; set; }

        public int? CreatedById { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime CreatedDate { get; set; }

        public int? LastUpdatedById { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? LastUpdatedDate { get; set; }

        [Column(TypeName = "timestamp")]
        [MaxLength(8)]
        [Timestamp]
        public byte[] Version { get; set; }
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<ProductFeeType> ProductFeeTypes { get; set; }
    }
}
