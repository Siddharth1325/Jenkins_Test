﻿namespace DomainModel.Accounting
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

   // [Table("act.APDetailView")]
    public partial class APDetailView : BaseDomainModel
    {
        [Key]
        public Guid ApDetailViewId { get; set; }

        public int? VendorId { get; set; }

        [StringLength(255)]
        public string VendorName { get; set; }

        [StringLength(40)]
        public string ProductName { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? APDate { get; set; }

        //[Key]
        [Column(Order = 0, TypeName = "money")]
        public decimal BaseAmount { get; set; }

        //[Key]
        [Column(Order = 1, TypeName = "money")]
        public decimal EligibleAmount { get; set; }

        public string PriceAdjReason { get; set; }

        [StringLength(25)]
        public string InvoiceNumber { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? InvoiceDate { get; set; }

      //  [Key]
        [Column(Order = 2, TypeName = "datetime2")]
        public DateTime CheckDate { get; set; }

      //  [Key]
        [Column(Order = 3)]
        [StringLength(12)]
        public string CheckNumber { get; set; }

       // [Key]
        [Column(Order = 4, TypeName = "money")]
        public decimal PaidAmount { get; set; }

      //  [Key]
        [Column(Order = 5)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int WorkOrderId { get; set; }

       // [Key]
        [Column(Order = 6)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int SourceWorkOrderId { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? Date { get; set; }

        //[Key]
        [Column(Order = 7)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int ApplicationId { get; set; }

        [StringLength(8)]
        public string Status { get; set; }

        public string ProductCode { get; set; }

        public int? VendorWorkOrderId { get; set; }
    }
}
