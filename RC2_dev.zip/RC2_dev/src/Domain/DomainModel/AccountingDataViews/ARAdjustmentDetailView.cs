﻿namespace DomainModel.Accounting
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("act.ARAdjustmentDetailView")]
    public partial class ARAdjustmentDetailView : BaseDomainModel
    {
         [Key]
        public Guid ARAdjustmentDetailViewId { get; set; }

        public int OrderId { get; set; }

        public int SourceOrderId { get; set; }

        public int? WorkOrderId { get; set; }

        public int? SourceWorkOrderId { get; set; }

        [StringLength(25)]
        public string InvoiceNumber { get; set; }
     
        public int AccountsReceivableAdjustmentId { get; set; }

        public int? AccountsReceivableDetailId { get; set; }

        [StringLength(8)]
        public string AdjustmentType { get; set; }

        public int? AccountsTaxBatchId { get; set; }
       
        [Column(TypeName = "money")]
        public decimal Amount { get; set; }

        [Column(TypeName = "money")]
        public decimal? TaxRate { get; set; }

        [Column(TypeName = "money")]
        public decimal? TaxAmount { get; set; }

        [StringLength(10)]
        public string Operation { get; set; }

        [StringLength(10)]
        public string FunctionValue { get; set; }

        [StringLength(10)]
        public string NaturalAccount { get; set; }

        [StringLength(2000)]
        public string Comments { get; set; }
       
        [Column(TypeName = "datetime2")]
        public DateTime AdjustmentDate { get; set; }
     
        [StringLength(5)]
        public string AdjustmentCode { get; set; }

        public string ProductCategory { get; set; }

        [StringLength(25)]
        public string AdjInvoiceNumber { get; set; }
    }
}
