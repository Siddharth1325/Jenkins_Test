﻿namespace DomainModel.Accounting
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("act.PresBillingDetailView")]
    public partial class PresBillingDetailView : BaseDomainModel
    {
        [Key, Column(Order = 0)]
        public Int64 RowNum { get; set; }
        public int WorkOrderId { get; set; }
        public int SourceWorkOrderId { get; set; }
        public string WorkOrderStatusType { get; set; }
        public int ProductId { get; set; }
        public string ProductCode { get; set; }
        public string ProductName { get; set; }
        public string ProductCategory { get; set; }
        public int OrderId { get; set; }
        public int SourceOrderId { get; set; }
        public decimal? ClientRushFee { get; set; }
        public decimal? ClientTripFee { get; set; }

        public int VendorWorkOrderId { get; set; }
        public int SourceVendorWorkOrderId { get; set; }
        public decimal? VendorOneTimeFee { get; set; }
        public decimal? VendorTripFee { get; set; }
        public decimal? VendorMinServiceFee { get; set; }
        public decimal? VendorOneTimeFinalFee { get; set; }

        public int WorkOrderItemId { get; set; }
        public int SourceWorkOrderItemId { get; set; }
        public string ServiceName { get; set; }
        public string ServiceCode { get; set; }
        public string WorkPerformed { get; set; }
        public string WorkNotPerformedReason { get; set; }
        public bool IsClientBilling { get; set; }
        public string VendorFeeType { get; set; }
        public decimal? VendorFlatFee { get; set; }
        public decimal? VendorFinalCost { get; set; }
        public decimal? ClientFinalPrice { get; set; }
        public string VendorDiscountType { get; set; }
        public decimal? VendorDiscount { get; set; }
        public decimal? VendorAgreedPrice { get; set; }
        public decimal? ClientAgreedPrice { get; set; }
        public decimal? InitialClientPrice { get; set; }
        public decimal? InitialVendorCost { get; set; }

        public int? WorkOrderLineItemId { get; set; }
        public int? SourceWorkOrderLineItemId { get; set; }
        public string LineItemCode { get; set; }
        public string LineItemName { get; set; }
        public int? Quantity { get; set; }
        public string UnitOfMeasureType { get; set; }
        public decimal? UnitCost { get; set; }
        public decimal? VarianceCost { get; set; }
        public decimal? AgreedUnitCost { get; set; }
        public decimal? VendorFee { get; set; }
        public decimal? LVendorFinalCost { get; set; }
        public decimal? UnitPrice { get; set; }
        public decimal? AgreedClientPrice { get; set; }
        public decimal? LClientFinalPrice { get; set; }
    }
}
