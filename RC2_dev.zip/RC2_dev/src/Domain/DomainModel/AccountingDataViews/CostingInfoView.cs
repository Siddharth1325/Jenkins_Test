﻿namespace DomainModel.Accounting
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("act.CostingInfoView")]
    public partial class CostingInfoView : BaseDomainModel
    {
        [Key]
        [Column(Order = 0, TypeName = "money")]
        public decimal Amount { get; set; }

        //[Key]
        [Column(Order = 1)]
        [StringLength(8)]
        public string AdjustmentType { get; set; }

        [Key]
        [Column(Order = 2, TypeName = "money")]
        public decimal TotalAmountDue { get; set; }

        // [Key]
        [Column(Order = 3)]
        [StringLength(25)]
        public string InvoiceNumber { get; set; }

        public int? VendorId { get; set; }

        [StringLength(100)]
        public string VendorName { get; set; }

        [Key]
        [Column(Order = 4)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int WorkOrderId { get; set; }

        public string ProductCode { get; set; }

        [NotMapped]
        public bool isVPR { get; set; }
    }
}
