﻿namespace DomainModel.Accounting
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("act.ARDetailView")]
    public partial class ARDetailView : BaseDomainModel
    {
        public int? ClientNumber { get; set; }

        [StringLength(100)]
        public string ClientName { get; set; }

        [Key]
        [Column(Order = 8)]
        [StringLength(40)]
        public string ProductName { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? ARDate { get; set; }

        [Key]
        [Column(Order = 0, TypeName = "money")]
        public decimal BaseAmount { get; set; }

        [Key]
        [Column(Order = 1, TypeName = "money")]
        public decimal EligibleAmount { get; set; }

        [Key]
        [Column(Order = 2, TypeName = "money")]
        public decimal TaxRate { get; set; }

        [Key]
        [Column(Order = 3, TypeName = "money")]
        public decimal TaxAmount { get; set; }

        [Column(TypeName = "money")]
        public decimal? TotalAmount { get; set; }

        public string PriceAdjReason { get; set; }

        [StringLength(25)]
        public string InvoiceNumber { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? InvoiceDate { get; set; }

        [Key]
        [Column(Order = 4)]
        [StringLength(1)]
        public string Status { get; set; }

        [Key]
        [Column(Order = 5)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int WorkOrderId { get; set; }

        [Key]
        [Column(Order = 6)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int SourceWorkOrderId { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? Date { get; set; }

        [Key]
        [Column(Order = 7)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int ApplicationId { get; set; }


        public int OrderId { get; set; }

        public string ProductCategory { get; set; }

        public int? OrderHierarchyId { get; set; }


       


      

    }
}
