namespace DomainModel.Accounting
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

   // [Table("act.APInvoiceDetailView")]
    public partial class APInvoiceDetailView : BaseDomainModel
    {
        [Key]
        public Guid APInvoiceDetailViewId { get; set; }

        [StringLength(25)]
        public string InvoiceNumber { get; set; }

        public int? VendorProfileId { get; set; }
        public int? WorkOrderId { get; set; }

        [StringLength(25)]
        public string InspectorUniqueId { get; set; }


        [Column(TypeName = "money")]
        public decimal? FinalTotalCost { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? AssignedDate { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? CompletedDate { get; set; }

        [StringLength(10)]
        public string ProductCategory { get; set; }

        [StringLength(8)]
        public string EligibleOccupancyType { get; set; }

        [StringLength(210)]
        public string PropertyAddress { get; set; }

        public string PriceAdjReason { get; set; }


        public int ApplicationId { get; set; }

        public string ServiceName { get; set; }

        public Int32? AccountsPayableAdjustmentId { get; set; }

        public int? SourceVendorWorkOrderId { get; set; }

        public string QCSupplierComment { get; set; }
    }
}
