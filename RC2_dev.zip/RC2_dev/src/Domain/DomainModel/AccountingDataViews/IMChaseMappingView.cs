namespace DomainModel.Accounting
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;


    [Table("act.IMChaseMappingView")]
    public partial class IMChaseMappingView : BaseDomainModel
    {
        [Key]
        public int IMChaseMappingId { get; set; }

        public int ApplicationId { get; set; }

        public int ClientNumber { get; set; }

        [StringLength(25)]
        public string ClientLSCI { get; set; }

        [StringLength(25)]
        public string RequestorCode { get; set; }

        [StringLength(8)]
        public string MBACodeType { get; set; }

        [StringLength(10)]
        public string IMInvoiceType { get; set; }

        [StringLength(40)]
        public string IMOrderType { get; set; }

        [StringLength(10)]
        public string IMLineItem { get; set; }
        [StringLength(8)]
        public string LOBType { get; set; }

        public bool? IsTax { get; set; }

        public bool? IsRush { get; set; }

        [StringLength(40)]
        public string ServiceName { get; set; }

        public int? ServiceId { get; set; }
        public int? LineItemId { get; set; }
        [Column("LineItemName")]
        [StringLength(40)]
        public string ServiceItem { get; set; }

        [StringLength(100)]
        public string FeeTypeName { get; set; }

        [StringLength(51)]
        public string Product { get; set; }
        
        [StringLength(10)]
        public string ProductCode { get; set; }
        public int? ProductId { get; set; }
    }
}
