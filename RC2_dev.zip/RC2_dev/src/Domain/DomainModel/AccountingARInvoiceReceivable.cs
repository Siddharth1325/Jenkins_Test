namespace DomainModel.Accounting
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("act.AccountingARInvoiceReceivable")]
    public partial class AccountingARInvoiceReceivable : BaseDomainModel
    {
        public int AccountingARInvoiceReceivableId { get; set; }

        public int ApplicationId { get; set; }

        public int? AccountsReceivableInvoiceId { get; set; }
        public int? AccountsReceivableAdjustmentId { get; set; }

        public int? AccountsReceivableId { get; set; }
        public int? AccountsReceivableDetailId { get; set; }

        public int CreatedById { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime CreatedDate { get; set; }

        public int? LastUpdatedById { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? LastUpdatedDate { get; set; }

        [Column(TypeName = "timestamp")]
        [MaxLength(8)]
        [Timestamp]
        public byte[] Version { get; set; }

        //public virtual AccountsReceivable AccountsReceivable { get; set; }

        public virtual AccountsReceivableDetail AccountsReceivableDetail { get; set; }

        public virtual AccountsReceivableInvoice AccountsReceivableInvoice { get; set; }
    }
}
