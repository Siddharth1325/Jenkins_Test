namespace DomainModel.Accounting
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("fs.WorkOrder")]
    public partial class WorkOrder : BaseDomainModel
    {
        public int WorkOrderId { get; set; }

        public int? OrderId { get; set; }

        public int ProductId { get; set; }

        [StringLength(5)]
        public string WorkOrderStatusGroup { get; set; }

        [StringLength(8)]
        public string WorkOrderStatusType { get; set; }

        public int? AssignedVendorId { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? AssignedDate { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime RequestedDate { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? WindowStartDate { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? WindowEndDate { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? DueToClientDate { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? OrigVendorDueDate { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? DueFromVendorDate { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? CompletedDate { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? AcctProcessedDate { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? TransmittedDate { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? CancellationDate { get; set; }

        [Required]
        [StringLength(100)]
        public string BorrowerFirstName { get; set; }

        [StringLength(1)]
        public string BorrowerMiddleInitial { get; set; }

        [Required]
        [StringLength(100)]
        public string BorrowerLastName { get; set; }

        [Required]
        [StringLength(100)]
        public string AddressLine1 { get; set; }

        [StringLength(100)]
        public string AddressLine2 { get; set; }

        [Required]
        [StringLength(100)]
        public string CityName { get; set; }

        [StringLength(2)]
        public string StateCode { get; set; }

        [Required]
        [StringLength(5)]
        public string ZipCode { get; set; }

        [StringLength(4)]
        public string ZipPlusFour { get; set; }

        [StringLength(100)]
        public string CountyName { get; set; }

        [StringLength(2000)]
        public string SpecialInstructions { get; set; }

        public bool IsRushOrder { get; set; }

        public bool? IsBillClient { get; set; }

        [StringLength(5)]
        public string PayVendorGroup { get; set; }

        [StringLength(8)]
        public string PayVendorType { get; set; }

        public bool? IsCountedTowardScore { get; set; }

        [StringLength(5)]
        public string DoorCardTypeGroup { get; set; }

        [StringLength(8)]
        public string DoorCardType { get; set; }

        [StringLength(4000)]
        public string DoorCardMessageText { get; set; }

        public int CreatedById { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime CreatedDate { get; set; }

        public int? LastUpdatedById { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? LastUpdatedDate { get; set; }

        [Column(TypeName = "timestamp")]
        [MaxLength(8)]
        [Timestamp]
        public byte[] Version { get; set; }
    }
}
