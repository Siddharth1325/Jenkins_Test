namespace DomainModel.Accounting
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("fs.WorkOrderItem")]
    public partial class WorkOrderItem
    {
        public WorkOrderItem()
        {
            AccountsPayableDetails = new HashSet<AccountsPayableDetail>();
            AccountsReceivableDetails = new HashSet<AccountsReceivableDetail>();
        }

        public int WorkOrderItemId { get; set; }

        public int? OrderId { get; set; }

        public int? WorkOrderId { get; set; }

        [StringLength(5)]
        public string WorkOrderItemStatusGroup { get; set; }

        [StringLength(8)]
        public string WorkOrderItemStatusType { get; set; }

        public int? ProductId { get; set; }

        public int? ServiceId { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? DueToClientDate { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? DueFromVendorDate { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? AdjustedDueDate { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? CompletedDate { get; set; }

        public int CreatedById { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime CreatedDate { get; set; }

        public int? LastUpdatedById { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? LastUpdatedDate { get; set; }

        [Column(TypeName = "timestamp")]
        [MaxLength(8)]
        [Timestamp]
        public byte[] Version { get; set; }

        public virtual ICollection<AccountsPayableDetail> AccountsPayableDetails { get; set; }

        public virtual ICollection<AccountsReceivableDetail> AccountsReceivableDetails { get; set; }

        public virtual Order Order { get; set; }

        public virtual Product Product { get; set; }

        public virtual WorkOrder WorkOrder { get; set; }
    }
}
