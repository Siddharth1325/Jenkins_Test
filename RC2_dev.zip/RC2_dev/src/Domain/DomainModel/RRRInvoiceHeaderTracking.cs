﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DomainModel.Accounting
{
    [Table("exp.RRRInvoiceHeaderTracking")]
    [System.CodeDom.Compiler.GeneratedCode("EF", "6.1.0")]
    public partial class RRRInvoiceHeaderTracking : BaseDomainModel
    {
        public int RRRInvoiceHeaderTrackingId { get; set; }

        public int? RRRInvoiceJsonHeaderId { get; set; }

        [StringLength(8)]
        public string ChangeFrom { get; set; }

        [StringLength(8)]
        public string ChangeTo { get; set; }

        [StringLength(100)]
        public string UserName { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? StatusUpdateDate { get; set; }

        public int CreatedById { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime CreatedDate { get; set; }

        public int? LastUpdatedById { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? LastUpdatedDate { get; set; }

        [StringLength(40)]
        public string DBCreatedBy { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? DBCreatedDate { get; set; }

        [StringLength(40)]
        public string DBLastUpdatedBy { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? DBLastUpdatedDate { get; set; }

        [Column(TypeName = "timestamp")]
        [MaxLength(8)]
        [Timestamp]
        public byte[] Version { get; set; }
    }
}
