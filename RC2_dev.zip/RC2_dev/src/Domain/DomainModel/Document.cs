﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



namespace DomainModel.Accounting
{
    [Table("doc.Document")]
    [System.CodeDom.Compiler.GeneratedCode("EF", "6.1.0")]
    public class Document : BaseDomainModel
    {

        public int DocumentId { get; set; }

        [Required]
        [StringLength(100)]
        public string DocumentName { get; set; }

        [StringLength(100)]
        public string DocumentDesc { get; set; }

        [Required]
        [StringLength(5)]
        public string DocTypeGroup { get; set; }

        [Required]
        [StringLength(8)]
        public string DocumentType { get; set; }

        [StringLength(100)]
        public string MimeType { get; set; }

        public long? DocumentSize { get; set; }

        [Required]
        [StringLength(1000)]
        public string DocumentPath { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime UploadDate { get; set; }

        public bool IsTemporary { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? ExpirationDate { get; set; }

        public bool IsActive { get; set; }

        public int CreatedById { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime CreatedDate { get; set; }

        public int? LastUpdatedById { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? LastUpdatedDate { get; set; }

        [Column(TypeName = "timestamp")]
        [MaxLength(8)]
        [Timestamp]
        public byte[] Version { get; set; }

    }
}
