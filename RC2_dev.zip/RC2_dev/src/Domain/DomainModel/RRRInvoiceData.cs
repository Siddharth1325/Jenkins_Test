﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DomainModel.Accounting
{
    public class RRRInvoiceData
    {
        public int RRRInvoiceJSONHeaderId { get; set; }

        public Guid RecordID { get; set; }
        public string LoanNumber { get; set; }
        public int ClientOrderNumber { get; set; }
        public int VendorOrderNumber { get; set; }
        public string LoanType { get; set; }
        public string PackageName { get; set; }
        public string BillTo { get; set; }
        public string OrderBy { get; set; }
        public decimal? HUDCostToDate { get; set; }
        public string TransmissionAction { get; set; }
        public Guid TransmissionID { get; set; }
        public string PartnerID { get; set; }
        public string PartnerSystemID { get; set; }

        public RRRInvoiceHeader RRRInvoiceHeader { get; set; }
    }

    public class RRRInvoiceHeader
    {

        public int RRRInvoiceJSONHeaderId { get; set; }
        public DateTime? OrderOpenDate { get; set; }
        public DateTime? CompletionDate { get; set; }
        public DateTime? InvoiceDate { get; set; }
        public string InvoiceNumber { get; set; }
        public decimal? InvoiceSubtotal { get; set; }
        public decimal? InvoiceTax { get; set; }
        public decimal? InvoiceTotal { get; set; }

        public List<RRRInvoiceDetail> RRRInvoiceDetails { get; set; }
    }

    public class RRRInvoiceDetail
    {
        public int RRRInvoiceJSONDetailId { get; set; }
        public string Category { get; set; }
        public string Description { get; set; }
        public int? BillingCode { get; set; }
        public int? Quantity { get; set; }
        public decimal? ItemPrice { get; set; }
        public decimal? ItemSubtotal { get; set; }
        public decimal? ItemTax { get; set; }
        public decimal? ItemTotal { get; set; }
    }


    public class RrrInvoiceDecisionHeader
    {
        public string HeaderDecision { get; set; }

        public string HeaderDecisionComments { get; set; }

        public decimal InvoiceApprovedAmount { get; set; }

        public int OrderId { get; set; }

        public List<RrrInvoiceDecisionDetail> RrrInvoiceDecisionDetails { get; set; }

    }

    public class RrrInvoiceDecisionDetail
    {
        public int AccountsReceivableDetailId { get; set; }

        public string ItemDecision { get; set; }

        public string ItemDecisionComments { get; set; }

        public decimal ItemApprovedAmount { get; set; }
    }

    public class GetRRRInvoiceJSONHeaderReq
    {
        public int OrderId { get; set; }

        public List<int?> AccountsReceivableDetailIds { get; set; }
    }

    public class RRRInvoiceDecisionDetail
    {
        public int RRRInvoiceJSONHeaderId { get; set; }
        public int ClientOrderNumber { get; set; }
        public string InvoiceNumber { get; set; }
        public DateTime? InvoiceDate { get; set; }
        public DateTime? SentToClientDate { get; set; }
        public DateTime? InvoiceDecisionDate { get; set; }
        public string LoanNumber { get; set; }        
        public string LoanType { get; set; }
        public string PackageName { get; set; }
        public string InvoiceDecision { get; set; }
        public string InvoiceDecisionComments { get; set; }
        public decimal? InvoiceSubtotal { get; set; }
        public decimal? InvoiceTax { get; set; }
        public decimal? InvoiceTotal { get; set; }
        public decimal? InvoiceApprovedAmount { get; set; }

        public string InternalDecision { get; set; }

        public string PartnerSystemId { get; set; }

        public List<RRRInvoiceDecisionItemDetail> RRRInvoiceDecisionItemDetails { get; set; }
    }

    public class RRRInvoiceDecisionItemDetail
    {
        public int RRRInvoiceJSONDetailId { get; set; }

        public int? AccountsReceivableDetailId { get; set; }

        public string SLFSLineItem { get; set; }
        public string ItemDescription { get; set; }
        public DateTime? PerformedDate { get; set; }
        public string SLFSDecision { get; set; }
        public string ItemDecision { get; set; }        
        public int? Quantity { get; set; }
        public decimal? ItemPrice { get; set; }
        public decimal? ItemSubtotal { get; set; }
        public decimal? ItemTax { get; set; }
        public decimal? ItemTotal { get; set; }
        public decimal? ItemApprovedAmt { get; set; }
        public string ItemDecisionComments { get; set; }

        public List<RRRInvoiceDecisionItemTracking> RRRInvoiceDecisionItemTrackings { get; set; }
    }

    public class RRRInvoiceDecisionItemTracking
    {
        public int RRRDecisionInvoiceItemTrackingId { get; set; }        
        public string SLFSDecision { get; set; }        
        public int? NewQuantity { get; set; }
        public decimal? NewItemPrice { get; set; }
        public decimal? NewItemSubtotal { get; set; }
        public decimal? NewItemTax { get; set; }
        public decimal? NewItemTotal { get; set; }        
        public string SLFSResponseToClient { get; set; }
        public string EnteredBy { get; set; }
        public DateTime EnteredDate { get; set; }
        public int? DecisionInvoiceNo { get; set; }
        public int? RRRInvoiceJSONDetailId { get; set; }

        public string ItemDecision { get; set; }
    }
 
}
