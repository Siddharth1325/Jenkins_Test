namespace DomainModel.Accounting
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("fs.Loan")]
    public partial class Loan
    {
        public Loan()
        {
            Orders = new HashSet<Order>();
        }

        public int LoanId { get; set; }

        public int? SubClientProfileId { get; set; }

        [StringLength(20)]
        public string LoanNumber { get; set; }

        public int? AssetId { get; set; }

        [StringLength(5)]
        public string LoanTypeGroup { get; set; }

        [StringLength(8)]
        public string LoanType { get; set; }

        [StringLength(5)]
        public string LoanStatusGroup { get; set; }

        [StringLength(8)]
        public string LoanStatus { get; set; }

        [StringLength(5)]
        public string InvestorIdentifier { get; set; }

        [Required]
        [StringLength(100)]
        public string BorrowerFirstName { get; set; }

        [StringLength(1)]
        public string BorrowerMiddleInitial { get; set; }

        [Required]
        [StringLength(100)]
        public string BorrowerLastName { get; set; }

        [Required]
        [StringLength(100)]
        public string PropAddress1 { get; set; }

        [StringLength(100)]
        public string PropAddress2 { get; set; }

        [Required]
        [StringLength(100)]
        public string PropCityName { get; set; }

        [Required]
        [StringLength(2)]
        public string PropStateCode { get; set; }

        [Required]
        [StringLength(5)]
        public string PropZipCode { get; set; }

        [StringLength(4)]
        public string PropZipPlusFour { get; set; }

        [StringLength(100)]
        public string PropCountyName { get; set; }

        [StringLength(100)]
        public string MailAddress1 { get; set; }

        [StringLength(100)]
        public string MailAddress2 { get; set; }

        [StringLength(100)]
        public string MailCityName { get; set; }

        [StringLength(2)]
        public string MailStateCode { get; set; }

        [StringLength(5)]
        public string MailZipCode { get; set; }

        [StringLength(4)]
        public string MailZipPlusFour { get; set; }

        [StringLength(100)]
        public string ValidAddress1 { get; set; }

        [StringLength(100)]
        public string ValidAddress2 { get; set; }

        [StringLength(100)]
        public string ValidCityName { get; set; }

        [StringLength(2)]
        public string ValidStateCode { get; set; }

        [StringLength(5)]
        public string ValidZipCode { get; set; }

        [StringLength(4)]
        public string ValidZipPlusFour { get; set; }

        [StringLength(100)]
        public string ValidCountyName { get; set; }

        [StringLength(15)]
        public string ValidLatitude { get; set; }

        [StringLength(15)]
        public string ValidLongitude { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? WinterizationDate { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? LastGrassCutDate { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? FirstTimeVacantDate { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? FirstTimePartialVacantDate { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? LastVacantDate { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? LastPartialVacantDate { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? InitialSecureDate { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? RedemptionConfirmDate { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? ExtensionApprovedDate { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? CodeViolationDate { get; set; }

        public bool IsCeaseAndDesist { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? CeaseAndDesistDate { get; set; }

        [StringLength(100)]
        public string CeaseAndDesistReason { get; set; }

        [StringLength(5)]
        public string InspFreqTypeGroup { get; set; }

        [StringLength(8)]
        public string InspectionFreqType { get; set; }

        [StringLength(5)]
        public string EligibleOccupancyGroup { get; set; }

        [StringLength(8)]
        public string EligibleOccupancyType { get; set; }

        public bool IsNonStandardFrequent { get; set; }

        [StringLength(100)]
        public string NonStandardFreqReason { get; set; }

        public int CreatedById { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime CreatedDate { get; set; }

        public int? LastUpdatedById { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? LastUpdatedDate { get; set; }

        [Column(TypeName = "timestamp")]
        [MaxLength(8)]
        [Timestamp]
        public byte[] Version { get; set; }

        public virtual ICollection<Order> Orders { get; set; }

        public virtual SubClientProfile SubClientProfile { get; set; }
    }
}
