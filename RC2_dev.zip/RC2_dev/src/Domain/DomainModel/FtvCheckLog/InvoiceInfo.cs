﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DomainModel.FtvCheckLog
{
    public class InvoiceInfo
    {
        public decimal InvoiceAmount { get; set; }
        public DateTime InvoiceDate { get; set; }
        public string InvoiceNumber { get; set; }
        public int AccountsPayableInvoiceId { get; set; }
        public int ApplicationId { get; set; }
        public string PayeeName { get; set; }
    }
}
