namespace DomainModel.Accounting
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("fs.ClientAddress")]
    public partial class ClientAddress
    {
        public int ClientAddressId { get; set; }

        public int? MasterClientProfileId { get; set; }

        public int? SubClientProfileId { get; set; }

        [Required]
        [StringLength(5)]
        public string AddrTypeGroup { get; set; }

        [Required]
        [StringLength(8)]
        public string AddressType { get; set; }

        [Required]
        [StringLength(100)]
        public string AddressLine1 { get; set; }

        [StringLength(100)]
        public string AddressLine2 { get; set; }

        [Required]
        [StringLength(100)]
        public string CityName { get; set; }

        [Required]
        [StringLength(2)]
        public string StateCode { get; set; }

        [Required]
        [StringLength(5)]
        public string ZipCode { get; set; }

        [StringLength(4)]
        public string ZipPlusFour { get; set; }

        [StringLength(100)]
        public string CountyName { get; set; }

        public int CreatedById { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime CreatedDate { get; set; }

        public int? LastUpdatedById { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? LastUpdatedDate { get; set; }

        [Column(TypeName = "timestamp")]
        [MaxLength(8)]
        [Timestamp]
        public byte[] Version { get; set; }

        public virtual MasterClientProfile MasterClientProfile { get; set; }

        public virtual SubClientProfile SubClientProfile { get; set; }
    }
}
