namespace DomainModel.Accounting
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;
    using CommonLib.ModelAttrib;

    [Table("act.AccountsReceivableDetail")]
    public partial class AccountsReceivableDetail : BaseDomainModel
    {
        public AccountsReceivableDetail()
        {
            AccountsReceivableTraces = new HashSet<AccountsReceivableTrace>();

            AccountsTaxes = new HashSet<AccountsTax>();

            AccountingARInvoiceReceivables = new HashSet<AccountingARInvoiceReceivable>();
        }

        public int AccountsReceivableDetailId { get; set; }
        
        [SecondaryKeyPropAttribute(Order = 1)]
        public int ApplicationId { get; set; }

        [SecondaryKeyPropAttribute(Order = 2)]
        [MapProp("AccountsReceivableDetailId")]
        public int? SourceAccountsReceivableDetailId { get; set; }

        public int? OrderHierarchyId { get; set; }

        public int? AccountsReceivableId { get; set; }

        public int? WorkOrderItemId { get; set; }

        public int Quantity { get; set; }

        [Required]
        [StringLength(8)]
        public string UnitsGroup { get; set; }
        public int? FeeTypeId { get; set; }

        public int? FeeTypePaymentRefId { get; set; }

        [Required]
        [StringLength(8)]
        public string UnitsType { get; set; }
        [Required]
        [StringLength(8)]
        public string ARStatusGroup { get; set; }

        [Required]
        [StringLength(8)]
        public string ARStatusType { get; set; }

        [Column(TypeName = "money")]
        public decimal BasePricePerUnit { get; set; }

        [Column(TypeName = "money")]
        public decimal BaseTotalPrice { get; set; }

        [Column(TypeName = "money")]
        public decimal FinalTotalPrice { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? AcctProcessedDate { get; set; }

        public int CreatedById { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime CreatedDate { get; set; }

        public int? LastUpdatedById { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? LastUpdatedDate { get; set; }

        [Column(TypeName = "timestamp")]
        [MaxLength(8)]
        [Timestamp]
        public byte[] Version { get; set; }

        public virtual AccountsReceivable AccountsReceivable { get; set; }

        public virtual OrderHierarchy OrderHierarchy { get; set; }

        public virtual ICollection<AccountsReceivableTrace> AccountsReceivableTraces { get; set; }

        public virtual ICollection<AccountingARInvoiceReceivable> AccountingARInvoiceReceivables { get; set; }

        public ICollection<AccountsTax> AccountsTaxes { get; set; }

        public virtual FeeType FeeType { get; set; }
    }
}
