namespace DomainModel.Accounting
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("act.AccountingAPInvoicePayable")]
    public partial class AccountingAPInvoicePayable : BaseDomainModel
    {
        public int AccountingAPInvoicePayableId { get; set; }

        public int ApplicationId { get; set; }

        public int? AccountsPayableInvoiceId { get; set; }

        public int? AccountsPayableAdjustmentId { get; set; } 

        public int? AccountsPayableId { get; set; }

        public int? AccountsPayableDetailId { get; set; }

        public int CreatedById { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime CreatedDate { get; set; }

        public int? LastUpdatedById { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? LastUpdatedDate { get; set; }

        [Column(TypeName = "timestamp")]
        [MaxLength(8)]
        [Timestamp]
        public byte[] Version { get; set; }

        public virtual AccountsPayableInvoice AccountsPayableInvoice { get; set; }

        public virtual AccountsPayableDetail AccountsPayableDetail { get; set; }

    }
}
