﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DomainModel
{
    public class Remittance : BaseDomainModel
    {
        public class SearchRequest
        {            
            public int? VendorProfileId { get; set; }
            
            public string VendorName { get; set; }
            
            public string Loan { get; set; }
            
            public string Check { get; set; }
            
            public string PresWorkOrderId { get; set; }
            
            public string InspWorkOrderId { get; set; }

            public string LOBs { get; set; }
            
            public DateTime? ChkDateFrom { get; set; }
            
            public DateTime? ChkDateTo { get; set; }
            
            public DateTime? InvoiceDateFrom { get; set; }
            
            public DateTime? InvoiceDateTo { get; set; }
            
            public DateTime? SubmissionDateFrom { get; set; }
            
            public DateTime? SubmissionDateTo { get; set; }
            
            public int? ApplicationId { get; set; }
            
            public bool IsVendorNumber { get; set; }

            public string ViewType { get; set; }


            public string ApInvoice { get; set; }
            public string OracleId { get; set; }

        }

        public class SearchResult
        {
            public int? VendorNumber { get; set; }

            public string VendorName { get; set; }

            public string InvoiceNumber { get; set; }
       
            public decimal? PaidAmount { get; set; }
       
            public DateTime? InvoiceDate { get; set; }
       
            public decimal? InvoiceAmount { get; set; }
       
            public string CheckNumber { get; set; }
       
            public DateTime? CheckDate { get; set; }
       
            public decimal? CheckAmount { get; set; }
       
            public string CheckComments { get; set; }

            public bool? IsVpr { get; set; }

            public int? OrdinanceProfileId { get; set; }

            public string ProductCategory { get; set; }

            public string OracleId { get; set; }

            public string OracleSiteCode { get; set; }
           
        }
    }
}
