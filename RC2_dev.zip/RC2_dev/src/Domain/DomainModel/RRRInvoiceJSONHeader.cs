﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DomainModel.Accounting
{
    [Table("exp.RRRInvoiceJSONHeader")]
    public partial class RRRInvoiceJSONHeader : BaseDomainModel
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public RRRInvoiceJSONHeader()
        {
            RRRInvoiceHeaderTrackings = new HashSet<RRRInvoiceHeaderTracking>();
            RRRInvoiceJSONDetails = new HashSet<RRRInvoiceJSONDetail>();
        }

        [Key]
        public int RRRInvoiceJSONHeaderId { get; set; }
        public int ApplicationId { get; set; }
        public int? InvoiceExportId { get; set; }
        public int? AccountingExportMasterId { get; set; }
        public Guid TransmissionID { get; set; }
        public string TransmissionAction { get; set; }
        [StringLength(50)]
        public string PartnerID { get; set; }
        [StringLength(50)]
        public string PartnerSystemID { get; set; }
        public Guid RecordId { get; set; }
        [StringLength(20)]
        public string LoanNumber { get; set; }
        [StringLength(4)]
        public string LoanType { get; set; }
        public int ClientOrderNumber { get; set; }
        public int VendorOrderNumber { get; set; }
        public string PackageName { get; set; }
        public string BillTo { get; set; }
        public string OrderBy { get; set; }
        public decimal? HUDCostToDate { get; set; }
        public DateTime? OrderOpenDate { get; set; }
        public DateTime? CompletionDate { get; set; }
        public DateTime? InvoiceDate { get; set; }
        [StringLength(25)]
        public string InvoiceNumber { get; set; }
        [StringLength(22)]
        public string ClientInvoiceNumber { get; set; }
        public decimal? InvoiceSubtotal { get; set; }
        public decimal? InvoiceTax { get; set; }

        public decimal? InitialInvoiceSubtotal { get; set; }
        public decimal? InitialInvoiceTax { get; set; }

        public decimal? InvoiceTotal { get; set; }
        [StringLength(8)]
        public string RecordStatusGroup { get; set; }
        [StringLength(8)]
        public string RecordStatusType { get; set; }
        public decimal? InvoiceApprovedAmount { get; set; }
        public string InvoiceDecisionComments { get; set; }
        public string InvoiceDecisionStatus { get; set; }
        public int? OrderId { get; set; }
        public int? CreatedById { get; set; }
        public DateTime? CreatedDate { get; set; }
        public int? LastUpdatedById { get; set; }
        public DateTime? LastUpdatedDate { get; set; }
        [Column(TypeName = "timestamp")]
        [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        [MaxLength(8)]
        public byte[] Version { get; set; }
        public virtual ICollection<RRRInvoiceJSONDetail> RRRInvoiceJSONDetails { get; set; }
        [Column(TypeName = "datetime2")]
        public DateTime? InvoiceDecisionDate { get; set; }

        public bool? IsSuccessReceived { get; set; }

        [StringLength(8)]
        public string InternalStatusGroup { get; set; }

        [StringLength(8)]
        public string InternalStatusType { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<RRRInvoiceHeaderTracking> RRRInvoiceHeaderTrackings { get; set; }
    }
}
