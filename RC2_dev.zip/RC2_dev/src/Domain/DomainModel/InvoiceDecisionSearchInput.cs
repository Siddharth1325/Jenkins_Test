﻿using DomainModel.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DomainModel.Accounting
{
    public class InvoiceDecisionSearchInput
    {       
        public string InvoiceNumber { get; set; }
        public string LoanNumber { get; set; }
        public int?  ClientOrderNumber { get; set; }
        public int? OrderNumber { get; set; }
        public int? WorkOrderNumber { get; set; }
        public DateTime? InvoiceFromDate { get; set; }
        public DateTime? InvoiceToDate { get; set; }
        public DateTime? InvoiceDecisionFromDate { get; set; }
        public DateTime? InvoiceDecisionToDate { get; set; }
        public DateTime? SLFSDecisionFromDate { get; set; }
        public DateTime? SLFSDecisionToDate { get; set; }
        public string InvoiceDecision { get; set; }
        public string InternalStatus { get; set; }        
    }
}
