﻿namespace DomainModel.Accounting
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("adm.LineItem")]
    [System.CodeDom.Compiler.GeneratedCode("EF", "6.1.0")]
    public partial class LineItem : BaseDomainModel
    {
        public int LineItemId { get; set; }

        public int ApplicationId { get; set; }

        [Required]
        [StringLength(10)]
        public string LineItemCode { get; set; }

        [Required]
        [StringLength(1000)]
        public string LineItemName { get; set; }

        [StringLength(1000)]
        public string LineItemDesc { get; set; }

        public int CreatedById { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime CreatedDate { get; set; }

        public int? LastUpdatedById { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? LastUpdatedDate { get; set; }

        [Column(TypeName = "timestamp")]
        [MaxLength(8)]
        [Timestamp]
        public byte[] Version { get; set; }
    }
}
