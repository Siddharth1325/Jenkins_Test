﻿namespace DomainModel.Accounting
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("act.AccountsPayableTrackingLog")]
    public partial class AccountsPayableTrackingLog : BaseDomainModel
    {

        public int AccountsPayableTrackingLogId { get; set; }

        public int? AccountsPayableInvoiceId { get; set; }

        public int? AccountsPayableRemittanceId { get; set; }

        public int? WorkOrderId { get; set; }

        [StringLength(25)]
        public string TrackingNumber { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? PostedDate { get; set; }

        [StringLength(8)]
        public string DeliveryConfirmStatusGroup { get; set; }

        [StringLength(8)]
        public string DeliveryConfirmStatus { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? DeliveryConfirmDate { get; set; }

        [StringLength(1000)]
        public string DeliveryConfirmComments { get; set; }

        [StringLength(8)]
        public string RejectionReasonGroup { get; set; }

        [StringLength(8)]
        public string RejectionReason { get; set; }

        [StringLength(1000)]
        public string RejectionReasonComments { get; set; }

        public bool IsReorderCheck { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? RejectedDate { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? ReOrderDate { get; set; }

        public int CreatedById { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime CreatedDate { get; set; }

        public int? LastUpdatedById { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? LastUpdatedDate { get; set; }

        [Column(TypeName = "timestamp")]
        [MaxLength(8)]
        [Timestamp]
        public byte[] Version { get; set; }
    }
}
