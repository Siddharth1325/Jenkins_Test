﻿namespace DomainModel.Accounting
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;


    public partial class DisputeSearchResult : BaseDomainModel
    {
        public int? DisputeId { get; set; }
        public string DisputeStatusType { get; set; }
        public string AssignedTo { get; set; }
        public DateTime? DisputeDate { get; set; }
        public DateTime? DisputeDueDate { get; set; }
        public string InvoiceNumber { get; set; }
        public string DisputeTType { get; set; }
        public string ClientName { get; set; }
        public string LoanNumber { get; set; }
        public int? VendorId { get; set; }
        public int? VendorWorkOrderId { get; set; }
        public int? InspWorkOrder { get; set; }
        public decimal DisputeAmount { get; set; }

        public string DisputeResolution { get; set; }

        public DateTime? WorkOrderCompleteDate { get; set; }

    }
}
