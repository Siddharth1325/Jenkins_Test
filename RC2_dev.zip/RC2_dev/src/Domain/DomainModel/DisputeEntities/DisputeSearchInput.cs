﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DomainModel.Accounting
{
    public partial class DisputeSearchInput : BaseDomainModel
    {
        public string DisputeStatusType { get; set; }
        public string AssignedTo { get; set; }
        public string ClientName { get; set; }
        public string LoanNumber { get; set; }
        public Nullable<int> VendorId { get; set; }
        public Nullable<int> VendorWorkOrderId { get; set; }
        public Nullable<int> InspWorkOrderId { get; set; }
        public string InvoiceNumber { get; set; }
        public Nullable<DateTime> DisputeDueDateFrom { get; set; }
        public Nullable<DateTime> DisputeDueDateTo { get; set; }
        public Nullable<int> ApplicationId { get; set; }
        public int? DisputeId { get; set; }

        public decimal? DisputeAmount { get; set; }
        public string DisputeType { get; set; }

        public string DisputeResolution { get; set; }
    }
}
