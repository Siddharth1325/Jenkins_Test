﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DomainModel.Accounting
{

    [Table("act.DisputePenaltyAdjustmentHistory")]
    public class DisputePenaltyAdjustmentHistory : BaseDomainModel
    {
        [Key]
        public int DisputePenaltyAdjustmentHistoryId { get; set; }

        public int OrderHierarchyId { get; set; }

        [StringLength(500)]
        public string GoalName { get; set; }

        [StringLength(500)]
        public string AchievementName { get; set; }

        public decimal? PenaltyAmount { get; set; }

        public decimal? AdjustmentAmount { get; set; }

        public decimal? FinalPenaltyAmount { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? AdjustmentDate { get; set; }

        [StringLength(25)]
        public string InvoiceNumber { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? InvoiceDate { get; set; }

        [StringLength(8)]
        public string RecordGroup { get; set; }

        [StringLength(8)]
        public string RecordType { get; set; }

        [Required]
        public int RecordNumber { get; set; }

        [StringLength(1000)]
        public string Comments { get; set; }

        public int CreatedById { get; set; }

        [Required]
        [Column(TypeName = "datetime2")]
        public DateTime CreatedDate { get; set; }

        public int? LastUpdatedById { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? LastUpdatedDate { get; set; }

        [Column(TypeName = "timestamp")]
        [MaxLength(8)]
        [Timestamp]
        public byte[] Version { get; set; }

        public virtual OrderHierarchy OrderHierarchy { get; set; }

        public int? SourceDisputePenaltyAdjustmentHistoryId { get; set; }

        [StringLength(1000)]
        public string SupplierComment { get; set; }
        
      
        public int ApplicationId { get; set; }

      
        public int? FeeTypeId { get; set; }
    }
}

