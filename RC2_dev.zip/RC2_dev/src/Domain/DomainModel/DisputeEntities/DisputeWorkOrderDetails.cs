﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace DomainModel.Accounting
{
    [DataContract]
    public class DisputeWorkOrderDetail
    {
        [DataMember]
        public int? FieldScapeWorkOrderId { get; set; }
        [DataMember]
        public int? VendorWorkOrderId { get; set; }
        [DataMember]
        public int? InspWorkOrderId { get; set; }
        [DataMember]
        public string ServiceNames { get; set; }
        [DataMember]
        public int? ServiceId { get; set; }
        [DataMember]
        public DateTime? BilledDate { get; set; }
        [DataMember]
        public DateTime? PaymentDate { get; set; }
        [DataMember]
        public decimal PayableAmountReceived { get; set; }
        [DataMember]
        public decimal? VendorFeeBeforeDiscount { get; set; }
        [DataMember]
        public decimal? DiscountPct { get; set; }
        [DataMember]
        public decimal? VendorFee { get; set; }
        [DataMember]
        public string ChequeNumber { get; set; }
        [DataMember]
        public string InvoiceNumber { get; set; }
        [DataMember]
        public int ClientId { get; set; }
        [DataMember]
        public int SubClientId { get; set; }
        [DataMember]
        public string LoanNumber { get; set; }
        [DataMember]
        public string LoanType { get; set; }
        [DataMember]
        public string LoanTypeGroup { get; set; }
        [DataMember]
        public string LoanTypeName { get; set; }
        [DataMember]
        public string PropAddress1 { get; set; }
        [DataMember]
        public string PropAddress2 { get; set; }
        [DataMember]
        public string PropCityName { get; set; }
        [DataMember]
        public string PropCountyName { get; set; }
        [DataMember]
        public string PropStateCode { get; set; }
        [DataMember]
        public string PropZipCode { get; set; }
        [DataMember]
        public decimal? AmountBilledToClient { get; set; }

        [DataMember]
        public int? VendorId { get; set; }

        [DataMember]
        public string VendorName { get; set; }

    }
}
