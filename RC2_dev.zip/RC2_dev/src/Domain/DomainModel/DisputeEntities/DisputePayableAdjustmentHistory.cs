﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using CommonLib.ModelAttrib;

namespace DomainModel.Accounting
{
    [Table("act.DisputePayableAdjustmentHistory")]
    public class DisputePayableAdjustmentHistory : BaseDomainModel
    {
        public DisputePayableAdjustmentHistory()
        {
            AccountsPayableAdjustments = new HashSet<AccountsPayableAdjustment>();
        }

        [Key]
        public int DisputePayableAdjustmentHistoryId { get; set; }

        [SecondaryKeyPropAttribute(Order = 1)]
        public int ApplicationId { get; set; }

        [SecondaryKeyPropAttribute(Order = 2)]
        [MapProp("DisputePayableAdjustmentHistoryId")]
        public int? SourceDisputePayableAdjustmentHistoryId { get; set; }

        public int OrderHierarchyId { get; set; }

        public int? FeeTypeId { get; set; }

        public int? FeeTypePaymentRefId { get; set; }

        public int Quantity { get; set; }

        [Column(TypeName = "money")]
        public decimal? AgreedUnitCost { get; set; }

        [Column("AgreedUnitPriceAdjstdAmt", TypeName = "money")]
        public decimal? AgreedUnitCostAdjstdAmt { get; set; }

        [Column(TypeName = "money")]
        public decimal? VendorFee { get; set; }

        [Column(TypeName = "money")]
        public decimal? VendorFeeAfterDiscount { get; set; }

        [Column(TypeName = "money")]
        public decimal? VendorFeeAdjstdAmt { get; set; }

        [Column(TypeName = "money")]
        public decimal? VendorFinalFee { get; set; }

        [Column(TypeName = "money")]
        public decimal? VendorFinalFeeAdjstdAmt { get; set; }

        public decimal? VendorDiscountAdjPercentage { get; set; }

        [Column(TypeName = "money")]
        public decimal? VendorFlatFee { get; set; }

        [Column(TypeName = "money")]
        public decimal? VendorOneTimeFee { get; set; }

        [Column(TypeName = "money")]
        public decimal? VendorTripFee { get; set; }

        [Column(TypeName = "money")]
        public decimal? VendorMinServiceFee { get; set; }

        [Column(TypeName = "money")]
        public decimal? VendorOneTimeFeeAdjstdAmt { get; set; }

        [Column(TypeName = "money")]
        public decimal? VendorTripFeeAdjstdAmt { get; set; }

        [Column(TypeName = "money")]
        public decimal? VendorMinServiceFeeAdjstdAmt { get; set; }

        [StringLength(1000)]
        public string ServiceDescription { get; set; }

        [StringLength(1000)]
        public string LineItemDescription { get; set; }

        [Column(TypeName = "DateTime2")]
        public DateTime HistoryDate { get; set; }

        [StringLength(1000)]
        public string VendorAdjComments { get; set; }

        [StringLength(1000)]
        public string SupplierComment { get; set; }

        public int RecordNumber { get; set; }

        [StringLength(8)]
        public string AdjustmentHistoryRecordGroup { get; set; }

        [StringLength(8)]
        public string AdjustmentHistoryRecordType { get; set; }

        public int? QuantityAdjusted { get; set; }

        [Column(TypeName = "money")]
        public decimal? VendorFlatFeeAdjstdAmt { get; set; }

        [Column(TypeName = "money")]
        public decimal? VendorDiscountPercentage { get; set; }

        public DateTime? InvoiceDate { get; set; }

        public string InvoiceNumber { get; set; }

        public string AdjustmentType { get; set; }

        public string DiscountComment { get; set; }

        public int CreatedById { get; set; }

        [Column(TypeName = "DateTime2")]
        public DateTime CreatedDate { get; set; }

        public int? LastUpdatedById { get; set; }

        [Column(TypeName = "DateTime2")]
        public DateTime? LastUpdatedDate { get; set; }

        public string UnitOfMeasure { get; set; }

        public string UnitOfMeasureAdjusted { get; set; }

        public decimal? Penalty { get; set; }

        public decimal? VendorWoCostAfterPenalty { get; set; }

        [Column(TypeName = "timestamp")]
        [MaxLength(8)]
        [Timestamp]
        public byte[] Version { get; set; }

        public virtual OrderHierarchy OrderHierarchy { get; set; }

        public virtual ICollection<AccountsPayableAdjustment> AccountsPayableAdjustments { get; set; }

    }
}
