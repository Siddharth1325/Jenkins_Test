﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DomainModel.Accounting
{
    public class AdjData
    {
        public Decimal? OrigTranAmount { get; set; }
        public Decimal? OrigTranTaxAmount { get; set; }
        public string AdjustmentType { get; set; }
        public Decimal? Amount { get; set; }
        public Decimal? TaxAmount { get; set; }
    }

    public class AdjustmentDetailResponseDAO
    {

        public bool IsMiscProduct { get; set; }

        public List<ClientFeeAdjustmentDetail> clientAdjustMentResponseList { get; set; }
        public List<VendorFeeAdjustmentDetail> vendorFeeAdjustmentResponseList { get; set; }
        public List<ProductServiceAdjustmentResponse> productServiceAdjustmentResponseList { get; set; }

        public List<MiscAdjustmentDetail> MiscAdjustmentDetailList { get; set; }

        public OrderTotal OrderTotals { get; set; }
    }

    public class PrdSrvMainResponseDAO
    {
        public List<FlatFeeAdjustmentDetail> flatFeeResponseList { get; set; }
        public List<DiscountAdjustmentDetail> discountResponseList { get; set; }
        public List<LineItemAdjustmentDetail> lineItemResponseList { get; set; }

        public OrderTotal OrderTotals { get; set; }
    }

    public partial class MiscAdjustmentDetail : BaseDomainModel
    {

        public int OrderId { get; set; }

        public int WorkOrderId { get; set; }

        public int Id { get; set; }

        public string IdType { get; set; }

        public int? FeeTypeId { get; set; }

        public string FeeType { get; set; }

        public decimal? Cost { get; set; }

        public decimal? CostAdjustment { get; set; }

        public string RecType { get; set; }

        public DateTime? InvoicedDate { get; set; }

        public string InvoiceNumber { get; set; }

        public decimal? Tax { get; set; }

        public string Product { get; set; }

        public int RecordNumber { get; set; }

        public int OrderHierarchyId { get; set; }

        public string Comments { get; set; }

        public string SupplierComment { get; set; }

        public DateTime? AdjustmentDate { get; set; }

        public int? FeeTypeRefId { get; set; }

        public int? VendorId { get; set; }

        public string ProductCode { get; set; }

        [Column(TypeName = "timestamp")]
        [MaxLength(8)]
        [Timestamp]
        public byte[] Version { get; set; }
    }

    public class PenaltyMainData
    {

        public PenaltyMainData()
        {
            PenaltyAdjustmentDetailList = new List<PenaltyAdjustmentDetail>();
            PenaltyVwoDetailsList = new List<PenaltyVendorWorkOrderDetail>();
        }

        public List<PenaltyAdjustmentDetail> PenaltyAdjustmentDetailList { get; set; }

        public List<PenaltyVendorWorkOrderDetail> PenaltyVwoDetailsList { get; set; }

    }

    public class PenaltyVendorWorkOrderDetail
    {
        public int VendorWorkOrderId { get; set; }

        public int VendorId { get; set; }
    }


    public partial class PenaltyAdjustmentDetail : BaseDomainModel
    {
        public int AssignedVendorId { get; set; }
        public int? OrderId { get; set; }

        public int? WorkOrderId { get; set; }
        public int? VendorWorkOrderId { get; set; }

        public int DisputePenaltyAdjustmentHistoryId { get; set; }

        public string GoalName { get; set; }

        public string AchievementName { get; set; }

        public decimal? PenaltyAmount { get; set; }

        public decimal? PenaltyAdjustmentAmount { get; set; }

        public string RecType { get; set; }

        public DateTime? InvoiceDate { get; set; }

        public string InvoiceNumber { get; set; }

        public string ProductName { get; set; }

        public string ServiceName { get; set; }

        public int RecordNumber { get; set; }

        public int OrderHierarchyId { get; set; }

        public string Comments { get; set; }

        public DateTime? AdjustmentDate { get; set; }

        [Column(TypeName = "timestamp")]
        [MaxLength(8)]
        [Timestamp]
        public byte[] Version { get; set; }

        public int? ApplicationId { get; set; }

        public int? FeeTypeId { get; set; }

        public bool IsAPAdjusted { get; set; }
    }

    public partial class PenaltyAdjustmentsScoreCard : BaseDomainModel
    {
        public string GoalName { get; set; }
        public string AchievementName { get; set; }

        public decimal AdjustmentAmount { get; set; }

        public int? WorkOrderId { get; set; }
        public int? WorkOrderItemId { get; set; }
    }

    public partial class ClientFeeAdjustmentDetail : BaseDomainModel
    {
        public int? AdjustmentDetailHistoryId { get; set; }
        public string RecType { get; set; }
        public int RecordNumber { get; set; }
        public int? IsAdjusted { get; set; }
        public int? OrderId { get; set; }
        public string ARInvoiceNumber { get; set; }
        public decimal? ClientTripFee { get; set; }
        public decimal? ClientTripFeeAdj { get; set; }
        public decimal? RushFee { get; set; }
        public decimal? RushFeeAdj { get; set; }
        public decimal? ClientTripFeeTaxAmount { get; set; }
        public decimal? RushFeeTaxAmount { get; set; }
        public DateTime? InvoicedDate { get; set; }
        public DateTime? AdjustmentDate { get; set; }
        public string Comments { get; set; }

        public string SupplierComment { get; set; }

        public int? OrderHierarchyId { get; set; }

        public bool IsArInvoiced { get; set; }

        [Column(TypeName = "timestamp")]
        [MaxLength(8)]
        [Timestamp]
        public byte[] Version { get; set; }
    }

    public partial class VendorFeeAdjustmentDetail : BaseDomainModel
    {
        public int? AdjustmentDetailHistoryId { get; set; }
        public int? OrderHierarchyId { get; set; }
        public int? VendorWorkOrderId { get; set; }
        public int? VendorId { get; set; }
        public int? IsAdjusted { get; set; }
        public decimal? OneTimeFee { get; set; }
        public decimal? OneTimeFeeAdjAmount { get; set; }
        public decimal? TripFee { get; set; }
        public decimal? TripFeeAdjAmount { get; set; }
        public decimal? MinServiceFee { get; set; }
        public decimal? MinServiceFeeAdjAmount { get; set; }

        public DateTime? AdjustmentDate { get; set; }
        public string Comments { get; set; }

        public string SupplierComment { get; set; }

        public string RecType { get; set; }
        public int RecordNumber { get; set; }
        public string InvoiceNumber { get; set; }

        public DateTime? InvoicedDate { get; set; }

        public bool IsApInvoiced { get; set; }

        [Column(TypeName = "timestamp")]
        [MaxLength(8)]
        [Timestamp]
        public byte[] Version { get; set; }

        public decimal? VwoPenalty { get; set; }
    }

    public partial class FlatFeeAdjustmentDetail : BaseDomainModel
    {
        public int? AdjustmentDetailHistoryId { get; set; }
        public int? OrderHierarchyId { get; set; }
        public decimal? FlatFeeAmount { get; set; }
        public decimal? FlatFeeAdjAmount { get; set; }
        public DateTime? AdjustmentDate { get; set; }
        public string Comments { get; set; }

        public string SupplierComment { get; set; }

        public string RecType { get; set; }
        public int? RecordNumber { get; set; }

        public DateTime? InvoicedDate { get; set; }
        public decimal? ClientPrice { get; set; }

        public decimal? ClientPriceAdjstdAmt { get; set; }

        public DateTime? ArInvoiceDate { get; set; }

        public string ArInvoiceNumber { get; set; }

        public int? ArRecordNumber { get; set; }

        public int? DisputeReceivableAdjustmentHistoryId { get; set; }

        public string ApInvoiceNumber { get; set; }

        public bool IsApInvoiced { get; set; }

        public bool IsArInvoiced { get; set; }

        public int? VendorId { get; set; }

        public bool IsAPAdjusted { get; set; }

        public bool IsARAdjusted { get; set; }

        [Column(TypeName = "timestamp")]
        [MaxLength(8)]
        [Timestamp]
        public byte[] ApVersion { get; set; }

        [Column(TypeName = "timestamp")]
        [MaxLength(8)]
        [Timestamp]
        public byte[] ArVersion { get; set; }

    }

    public partial class DiscountAdjustmentDetail : BaseDomainModel
    {
        public int? AdjustmentDetailHistoryId { get; set; }
        public int? OrderHierarchyId { get; set; }
        public decimal? DiscountPercent { get; set; }
        public decimal? DiscountPercentAdjsted { get; set; }
        public DateTime? AdjustmentDate { get; set; }
        public string Comments { get; set; }

        public string SupplierComment { get; set; }

        public string RecType { get; set; }
        public int? RecordNumber { get; set; }

        public string ApInvoiceNumber { get; set; }

        public DateTime? InvoicedDate { get; set; }

        public bool IsApInvoiced { get; set; }


        public int? VendorId { get; set; }

        [Column(TypeName = "timestamp")]
        [MaxLength(8)]
        [Timestamp]
        public byte[] ApVersion { get; set; }

    }

    public partial class LineItemAdjustmentDetail : BaseDomainModel
    {
        public int? AdjustmentDetailHistoryId { get; set; }
        public int? ARAdjustmentDetailHistoryId { get; set; }
        public int? OrderHierarchyId { get; set; }
        public string LineItemDescription { get; set; }
        public int? Quantity { get; set; }
        public string UnitOfMeasure { get; set; }
        public decimal? VendorUnitCost { get; set; }
        public decimal? VendorFee { get; set; }
        public decimal? VendorFeeAfterDiscount { get; set; }
        public decimal? ClientUnitPrice { get; set; }
        public decimal? ClientPrice { get; set; }
        public decimal? TaxAmount { get; set; }
        public DateTime? InvoicedDate { get; set; }
        public string Comments { get; set; }
        public string SupplierComment { get; set; }
        public string ApRecType { get; set; }
        public string ArRecType { get; set; }
        public int? WorkOrderLineItemId { get; set; }
        public int? APRecordNumber { get; set; }
        public int? ARRecordNumber { get; set; }

        public decimal? VendorFeeAdjAmt { get; set; }

        public decimal? ClientPriceAdjAmt { get; set; }

        public DateTime? AdjustmentDate { get; set; }

        public string ArInvoiceNumber { get; set; }

        public string ApInvoiceNumber { get; set; }

        public DateTime? ApInvoicedDate { get; set; }

        public bool IsApInvoiced { get; set; }

        public bool IsArInvoiced { get; set; }

        public int? VendorId { get; set; }

        public int? PerformedQuantity { get; set; }

        public bool IsAPAdjusted { get; set; }

        public bool IsARAdjusted { get; set; }

        [Column(TypeName = "timestamp")]
        [MaxLength(8)]
        [Timestamp]
        public byte[] ApVersion { get; set; }

        [Column(TypeName = "timestamp")]
        [MaxLength(8)]
        [Timestamp]
        public byte[] ArVersion { get; set; }
    }

    public class ClientFeeAdjustmentResponseDAO
    {
        public int? IsAdjusted { get; set; }

        public int? orderId { get; set; }

        public string ARInvoiceNumber { get; set; }

        public decimal? ClientTripFee { get; set; }

        public decimal? ClientTripFeeAdjstdAmt { get; set; }

        public decimal? ClientTripFeeTax { get; set; }

        public decimal? ClientRushFee { get; set; }

        public decimal? ClientRushFeeAdjstdAmt { get; set; }

        public decimal? ClientRushFeeTax { get; set; }

        public DateTime? InvoiceDate { get; set; }

        public DateTime? AdjustmentDate { get; set; }

        public string ClientAdjComments { get; set; }

        public int? DisputeReceivableAdjustmentHistoryId { get; set; }

        public int? OrderHierarchyId { get; set; }
    }

    public class VendorFeeAdjustmentResponseDAO
    {

        public int? IsAdjusted { get; set; }

        public int? VendorWorkOrderNumber { get; set; }

        public int? AssignedVendorId { get; set; }

        public decimal? VendorOneTimeFee { get; set; }

        public decimal? VendorOneTimeFeeAdjstdAmt { get; set; }

        public decimal? VendorTripFee { get; set; }

        public decimal? VendorTripFeeAdjstdAmt { get; set; }

        public decimal? VendorMinServiceFee { get; set; }

        public decimal? VendorMinServiceFeeAdjstdAmt { get; set; }

        public DateTime? InvoiceDate { get; set; }

        public DateTime? AdjustmentDate { get; set; }

        public string Comments { get; set; }

        public int? OrderHierarchyId { get; set; }

        public int? DisputePayableAdjustmentHistoryId { get; set; }
    }

    public partial class ProductServiceAdjustmentResponse : BaseDomainModel
    {
        public int? OrderId { get; set; }

        public int? WorkOrderId { get; set; }

        public int? VendorWorkOrderId { get; set; }

        public int? WorkOrderItemId { get; set; }

        public string Product { get; set; }

        public string Service { get; set; }

        public string Cost { get; set; }

        public string Discount { get; set; }

        public decimal? DiscountAmt { get; set; }

        public decimal? CostAfterDiscount { get; set; }

        public string ClientBilling { get; set; }

        public decimal? ClientPrice { get; set; }

        public int? IsAPAdjusted { get; set; }

        public int? IsARAdjusted { get; set; }

        public string ArInvoiceNumber { get; set; }

        public decimal? TaxAmount { get; set; }

        public DateTime? invoicedDate { get; set; }

        public int? OrderHierarchyId { get; set; }

        public int? AdjustmentHistoryPayableId { get; set; }

        public int? AdjustmentHistoryReceivableId { get; set; }

        public string RecType { get; set; }

        public string ProductCode { get; set; }

        public string ApInvoiceNumber { get; set; }

        public DateTime? ApInvoiceDate { get; set; }

        public bool IsApInvoiced { get; set; }

        public bool IsArInvoiced { get; set; }

        public int? VendorId { get; set; }

        public bool? IsServiceLevelBilling { get; set; }

        public decimal? PenaltyIncentive { get; set; }

        public decimal? CostAfterPI { get; set; }
    }

    public class CronologicalAdjustmentListResponseDAO : BaseDomainModel
    {
        public string adjustmentcategory { get; set; }

        public decimal? startingFee { get; set; }

        public decimal? AdjustedFee { get; set; }

        public decimal? EndingFee { get; set; }

        public decimal? EndingTax { get; set; }

        public string InvoiceNumber { get; set; }

        public int? orderId { get; set; }

        public int? vendorworkOrderId { get; set; }

        public int? VendorId { get; set; }

        public string ProductName { get; set; }

        public string ServiceName { get; set; }

        public string ServiceItem { get; set; }

        public string Feetype { get; set; }

        public string AdjustedBy { get; set; }

        public DateTime? AdjustmentDate { get; set; }

        public DateTime? SentToOracleDate { get; set; }

        public int RecordNumber { get; set; }
    }

    public class OrderTotal
    {
        public decimal? VendorFee { get; set; }

        public decimal? VendorFinalFee { get; set; }

        public decimal? ClientPrice { get; set; }

        public decimal? Penalties { get; set; }
    }

}
