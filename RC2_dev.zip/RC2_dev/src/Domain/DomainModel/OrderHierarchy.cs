﻿namespace DomainModel.Accounting
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;
    using CommonLib.ModelAttrib;

    [Table("act.OrderHierarchy")]
    public partial class OrderHierarchy : BaseDomainModel
    {
        public OrderHierarchy()
        {
            AccountsPayableDetails = new HashSet<AccountsPayableDetail>();
            AccountsReceivableDetails = new HashSet<AccountsReceivableDetail>();
            DisputePayableAdjustmentHistorys = new HashSet<DisputePayableAdjustmentHistory>();
            DisputeReceivableAdjustmentHistorys = new HashSet<DisputeReceivableAdjustmentHistory>();
            DisputePenaltyAdjustmentHistories = new HashSet<DisputePenaltyAdjustmentHistory>();
        }

        public int OrderHierarchyId { get; set; }
        public int OrderId { get; set; }
        
        [SecondaryKeyPropAttribute(Order = 1)]
        [MapProp("OrderHierarchyId")]
        public int? SourceOrderHierarchyId { get; set; }
        public int? VendorWorkOrderId { get; set; }
        public int? WorkOrderId { get; set; }
        public int? WorkOrderItemId { get; set; }
        public int? WorkOrderLineItemId { get; set; }
        public int CreatedById { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime CreatedDate { get; set; }

        public int? LastUpdatedById { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? LastUpdatedDate { get; set; }

        [Column(TypeName = "timestamp")]
        [MaxLength(8)]
        [Timestamp]
        public byte[] Version { get; set; }

        public virtual Order Orders { get; set; }
        public virtual VendorWorkOrder VendorWorkOrders { get; set; }
        public virtual WorkOrder WorkOrders { get; set; }
        public virtual WorkOrderItem WorkOrderItems { get; set; }
        public virtual WorkOrderLineItem WorkOrderLineItems { get; set; }
        public virtual ICollection<AccountsPayableDetail> AccountsPayableDetails { get; set; }
        public virtual ICollection<AccountsReceivableDetail> AccountsReceivableDetails { get; set; }
        public virtual ICollection<DisputePayableAdjustmentHistory> DisputePayableAdjustmentHistorys { get; set; }
        public virtual ICollection<DisputeReceivableAdjustmentHistory> DisputeReceivableAdjustmentHistorys { get; set; }

        public virtual ICollection<DisputePenaltyAdjustmentHistory> DisputePenaltyAdjustmentHistories { get; set; }
    }
}
