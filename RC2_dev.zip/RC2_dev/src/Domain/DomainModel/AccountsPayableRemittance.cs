namespace DomainModel.Accounting
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("act.AccountsPayableRemittance")]
    public partial class AccountsPayableRemittance : BaseDomainModel
    {
        public int AccountsPayableRemittanceId { get; set; }

        public int ApplicationId { get; set; }

        public int AccountsPayableInvoiceId { get; set; }

        [Required]
        [StringLength(25)]
        public string InvoiceNumber { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime InvoiceDate { get; set; }

        [StringLength(8)]
        public string InvoiceTypeGroup { get; set; }

        [StringLength(8)]
        public string InvoiceType { get; set; }

        [Column(TypeName = "money")]
        public decimal? InvoiceAmount { get; set; }

        [Required]
        [StringLength(12)]
        public string CheckNumber { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime CheckDate { get; set; }

        [StringLength(8)]
        public string CheckTypeGroup { get; set; }

        [StringLength(8)]
        public string CheckType { get; set; }

        [Column(TypeName = "money")]
        public decimal? PaidAmount { get; set; }

        [Required]
        [StringLength(30)]
        public string PayeeCode { get; set; }

        [StringLength(100)]
        public string Comments { get; set; }

        public int CreatedById { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime CreatedDate { get; set; }

        public int? LastUpdatedById { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? LastUpdatedDate { get; set; }

        [Column(TypeName = "timestamp")]
        [MaxLength(8)]
        [Timestamp]
        public byte[] Version { get; set; }

        public virtual AccountsPayableInvoice AccountsPayableInvoice { get; set; }
    }
}
