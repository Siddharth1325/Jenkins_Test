namespace DomainModel.Accounting
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("act.AccountingAdjustmentCode")]
    public partial class AccountingAdjustmentCode : BaseDomainModel
    {
        public int AccountingAdjustmentCodeId { get; set; }

        public int ApplicationId { get; set; }

        [Required]
        [StringLength(8)]
        public string AdjustmentCategoryGroup { get; set; }

        [Required]
        [StringLength(8)]
        public string AdjustmentCategoryType { get; set; }

        [Required]
        [StringLength(8)]
        public string AdjustmentTypeGroup { get; set; }

        [Required]
        [StringLength(8)]
        public string AdjustmentType { get; set; }

        [StringLength(5)]
        public string AdjustmentCode { get; set; }

        [Required]
        [StringLength(100)]
        public string Description { get; set; }

        public bool IsActive { get; set; }

        public int CreatedById { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime CreatedDate { get; set; }

        public int? LastUpdatedById { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? LastUpdatedDate { get; set; }

        [Column(TypeName = "timestamp")]
        [MaxLength(8)]
        [Timestamp]
        public byte[] Version { get; set; }
    }
}
