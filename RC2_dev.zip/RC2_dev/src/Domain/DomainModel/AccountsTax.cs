﻿using CommonLib.ModelAttrib;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.Spatial;

namespace DomainModel.Accounting
{
    [Table("act.AccountsTax")]
    public partial class AccountsTax : BaseDomainModel
    {
        public AccountsTax()
        {
        }
        public int AccountsTaxId { get; set; }

        public int? AccountsReceivableAdjustmentId { get; set; }

        public int? AccountsReceivableDetailId { get; set; }

        public int? ApplicationId { get; set; }

        [Column(TypeName = "money")]
        public decimal? TaxAmount { get; set; }

        [Column(TypeName = "money")]
        public decimal? TaxRate { get; set; }

        public int? AccountsTaxBatchId { get; set; }

        [StringLength(8)]
        public string TransmissionStatus { get; set; }

        [StringLength(8)]
        public string TransmissionStatusGroup { get; set; }

        [StringLength(1000)]
        public string ErrorMsg { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? ErrorDate { get; set; }

        public int CreatedById { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime CreatedDate { get; set; }

        public int? LastUpdatedById { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? LastUpdatedDate { get; set; }

        public int? TaxServiceClass { get; set; }

        [Column(TypeName = "timestamp")]
        [MaxLength(8)]
        [Timestamp]
        public byte[] Version { get; set; }


        public virtual AccountsReceivableDetail AccountsReceivableDetail { get; set; }
        public virtual AccountsReceivableAdjustment AccountsReceivableAdjustment { get; set; }
        public virtual AccountsTaxBatch AccountsTaxBatch { get; set; }
    }
}
