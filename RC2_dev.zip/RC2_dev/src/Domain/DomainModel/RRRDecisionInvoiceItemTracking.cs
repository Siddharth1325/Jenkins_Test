﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DomainModel.Accounting
{

    [Table("exp.RRRDecisionInvoiceItemTracking")]
    [System.CodeDom.Compiler.GeneratedCode("EF", "6.1.0")]
    public partial class RRRDecisionInvoiceItemTracking : BaseDomainModel
    {
        public int RRRDecisionInvoiceItemTrackingId { get; set; }

        public int? RRRInvoiceJSONDetailId { get; set; }

        public int? DecisionInvoiceNo { get; set; }

        [StringLength(8)]
        public string SLFSDecisionGroup { get; set; }

        [StringLength(8)]
        public string SLFSDecisionType { get; set; }

        public int? Quantity { get; set; }

        [Column(TypeName = "money")]
        public decimal? ItemPrice { get; set; }

        [Column(TypeName = "money")]
        public decimal? ItemSubtotal { get; set; }

        [Column(TypeName = "money")]
        public decimal? ItemTax { get; set; }

        [Column(TypeName = "money")]
        public decimal? ItemTotal { get; set; }

        [StringLength(100)]
        public string ItemDecision { get; set; }

        [StringLength(1000)]
        public string ItemDecisionComments { get; set; }

        [StringLength(1000)]
        public string SLFSResponsetoClient { get; set; }

        [StringLength(100)]
        public string EnteredBy { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? TrackingDate { get; set; }

        public int CreatedById { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime CreatedDate { get; set; }

        public int? LastUpdatedById { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? LastUpdatedDate { get; set; }

        [StringLength(40)]
        public string DBCreatedBy { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? DBCreatedDate { get; set; }

        [StringLength(40)]
        public string DBLastUpdatedBy { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? DBLastUpdatedDate { get; set; }

        [Column(TypeName = "timestamp")]
        [MaxLength(8)]
        [Timestamp]
        public byte[] Version { get; set; }
    }
}
