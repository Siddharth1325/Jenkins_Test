namespace DomainModel.Accounting
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;
    using CommonLib.ModelAttrib;

    [Table("act.AccountsPayableDetail")]
    public partial class AccountsPayableDetail : BaseDomainModel
    {
        public AccountsPayableDetail()
        {
            AccountsPayableTraces = new HashSet<AccountsPayableTrace>();
            AccountingAPInvoicePayables = new HashSet<AccountingAPInvoicePayable>();
        }

        public int AccountsPayableDetailId { get; set; }
        
        [SecondaryKeyPropAttribute(Order = 1)]
        public int ApplicationId { get; set; }
        
        [SecondaryKeyPropAttribute(Order = 2)]
        [MapProp("AccountsPayableDetailId")]
        public int? SourceAccountsPayableDetailId { get; set; }

        public int? OrderHierarchyId { get; set; }

        public int? AccountsPayableId { get; set; }

        public int? WorkOrderItemId { get; set; }

        public int? Quantity { get; set; }

        [Required]
        [StringLength(8)]
        public string UnitsGroup { get; set; }

        [Required]
        [StringLength(8)]
        public string UnitsType { get; set; }

        [Required]
        [StringLength(8)]
        public string APStatusGroup { get; set; }

        [Required]
        [StringLength(8)]
        public string APStatusType { get; set; }

        [Column(TypeName = "money")]
        public decimal? BaseCostPerUnit { get; set; }

        [Column(TypeName = "money")]
        public decimal BaseTotalCost { get; set; }

        [Column(TypeName = "money")]
        public decimal? FinalTotalCost { get; set; }

        public int? FeeTypeId { get; set; }

        public int? FeeTypePaymentRefId { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? AcctProcessedDate { get; set; }
        public int CreatedById { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime CreatedDate { get; set; }

        public int? LastUpdatedById { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? LastUpdatedDate { get; set; }

        [Column(TypeName = "timestamp")]
        [MaxLength(8)]
        [Timestamp]
        public byte[] Version { get; set; }

        [StringLength(1000)]
        public string QCSupplierComment { get; set; }

        public virtual AccountsPayable AccountsPayable { get; set; }
        public virtual OrderHierarchy OrderHierarchy { get; set; }       

        public virtual ICollection<AccountsPayableTrace> AccountsPayableTraces { get; set; }

        public virtual ICollection<AccountingAPInvoicePayable> AccountingAPInvoicePayables { get; set; }

        public virtual FeeType FeeType { get; set; }

        [StringLength(100)]
        public string PayeeName { get; set; }

        [StringLength(100)]
        public string CCConfirmationNumber { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime? CCPaymentDate { get; set; }
    }
}
