﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccess.Accounting.Subscriber;
using DomainModel.Accounting;

namespace Delegate.TxnDelegate
{
    public class CancellationDelegate
    {
        public Cancellation SaveCancellation(Cancellation cancellation)
        {
            return new CancellationDao().SaveCancellation(cancellation);
        }

        public Cancellation GetCancellation(int cancellationId)
        {
            return new CancellationDao().GetCancellation(cancellationId);
        }

        public List<Cancellation> GetCancellationListByOrderId(int orderId)
        {
            return new CancellationDao().GetCancellationListByOrderId(orderId);
        }
    }
}
