﻿using DataAccess.Accounting.Subscriber;
using DomainModel.Accounting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Delegate.TxnDelegate
{
    public class AssetDelegate
    {
        public Asset SaveAsset(Asset profile)
        {
            return new AssetDao().SaveAsset(profile);
        }

        public Asset GetAsset(int AssetId)
        {
            return new AssetDao().GetAsset(AssetId);
        }

        public Asset GetAsset(int AppId, int SourceAssetId)
        {
            return new AssetDao().GetAsset(AppId, SourceAssetId);
        }
    }
}
