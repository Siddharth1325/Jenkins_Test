﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccess.Accounting.Subscriber;
using DomainModel.Accounting;
using DomainModel.Common;
namespace Delegate.TxnDelegate
{
    public class OrderDelegate
    {
        public Order SaveOrder(Order order)
        {
            return new OrderDao().SaveOrder(order);
        }

        public Order GetOrder(int orderId, CommonEnums.OrderChild orderChild = CommonEnums.OrderChild.None)
        {
            return new OrderDao().GetOrder(orderId, orderChild);
        }
        public Order GetOrder(int AppId, int SourceOrderId)
        {
            return new OrderDao().GetOrder(AppId, SourceOrderId);
        }
    }
}
