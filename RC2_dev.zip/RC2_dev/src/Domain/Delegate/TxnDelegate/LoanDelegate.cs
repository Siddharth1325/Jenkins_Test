﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccess.Accounting.Subscriber;
using DomainModel.Accounting;

namespace Delegate.TxnDelegate
{
    public class LoanDelegate
    {
        public Loan SaveLoan(Loan loan)
        {
            return new LoanDao().SaveLoan(loan);
        }

        public Loan GetLoan(int loanId)
        {
            return new LoanDao().GetLoan(loanId);
        }
        public Loan GetLoan(int AppId, int SourceLoanId)
        {
            return new LoanDao().GetLoan(AppId, SourceLoanId);
        }
    }
}
