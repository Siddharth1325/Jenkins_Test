﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccess.Accounting.Subscriber;
using DomainModel.Accounting;

namespace Delegate.TxnDelegate
{
   public class WorkOrderItemDelegate
    {
        public WorkOrderItem SaveWorkOrderItem(WorkOrderItem workOrderItem)
        {
            return new WorkOrderItemDao().SaveWorkOrderItem(workOrderItem);
        }

        public WorkOrderItem GetWorkOrderItem(int workOrderItemId)
        {
            return new WorkOrderItemDao().GetWorkOrderItem(workOrderItemId);
        }

       public List<WorkOrderItem> GetWorkOrderItemByOrderId(int orderId)
        {
            return new WorkOrderItemDao().GetWorkOrderItemByOrderId(orderId);
        }
    }
}
