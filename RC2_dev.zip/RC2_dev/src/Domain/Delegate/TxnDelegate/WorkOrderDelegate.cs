﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccess.Accounting.Subscriber;
using DomainModel.Accounting;

namespace Delegate.TxnDelegate
{
   public class WorkOrderDelegate
    {
        public WorkOrder SaveWorkOrder(WorkOrder workOrder)
        {
            return new WorkOrderDao().SaveWorkOrder(workOrder);
        }
        public WorkOrder SaveWorkOrderWithUpdateGraph(WorkOrder workOrder)
        {
            return new WorkOrderDao().SaveWorkOrderWithUpdateGraph(workOrder);
        }

        public WorkOrder GetWorkOrder(int workOrderId)
        {
            return new WorkOrderDao().GetWorkOrder(workOrderId);
        }

        public WorkOrder GetWorkOrder(int AppId, int SourceWorkOrderId)
        {
            return new WorkOrderDao().GetWorkOrder(AppId, SourceWorkOrderId);
        }

       public List<WorkOrder> GetWorkOrdersByOrderId(int orderId)
        {
            return new WorkOrderDao().GetWorkOrdersByOrderId(orderId);
        }

    }
}
