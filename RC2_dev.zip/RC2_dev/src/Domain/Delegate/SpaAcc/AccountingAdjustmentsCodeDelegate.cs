﻿using CommonLib;
using CommonLib.Context;
using DataAccess.Accounting;
using DomainModel.Accounting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Delegate
{
    public class AccountingAdjustmentsCodeDelegate
    {
        public int? AppId
        {
            get
            {
                int? appId = null;
                UserContext uContext = ApplicationContext.Instance.UserContext;
                if (uContext != null)
                    appId = uContext.TenantId ?? uContext.ApplicationId;

                return appId;
            }
        }
        public AccountingAdjustmentCode SaveAccountingAdjustmentsCode(AccountingAdjustmentCode accountingAdjustmentCode)
        {
            AccountingRepository repository = new AccountingRepository();
            accountingAdjustmentCode = repository.SaveAccountingAdjustmentsCode(accountingAdjustmentCode);

            return accountingAdjustmentCode;
        }

        public AccountingAdjustmentCode GetAccountingAdjustmentCode(int accountingAdjustmentCodeId)
        {
            AccountingRepository repository = new AccountingRepository();
            int appid = AppId.Value;
            return repository.GetAccountingAdjustmentCode(accountingAdjustmentCodeId, appid);
           
        }

        public List<AccountingAdjustmentCode> SearchAccountingAdjustmentCode(AccAdjustmentCodeSearchInput searchFilter, out int totalCount)
        {
            AccountingRepository repository = new AccountingRepository();
            int appid = AppId.Value;
            return repository.SearchAccountingAdjustmentCode(searchFilter, out totalCount,appid);

        }

        public List<AccountingAdjustmentCode> GetDistinctAccoutingAdjustmentCodes(string adjustmentCategoryType, string adjustmentType)
        {
            AccountingRepository repository = new AccountingRepository();
            int appid = AppId.Value;
            return repository.GetDistinctAccoutingAdjustmentCodes(adjustmentCategoryType, adjustmentType,appid);
        }

    }
}
