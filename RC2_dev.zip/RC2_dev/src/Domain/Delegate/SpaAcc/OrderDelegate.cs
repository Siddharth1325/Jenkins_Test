﻿using CommonLib;
using CommonLib.Context;
using DataAccess.Accounting;
using DomainModel.Accounting;
using DomainModel.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Delegate
{
    public class OrderDelegate
    {
        public int? AppId
        {
            get
            {
                int? appId = null;
                UserContext uContext = ApplicationContext.Instance.UserContext;
                if (uContext != null)
                    appId = uContext.TenantId ?? uContext.ApplicationId;


                return appId;
            }
        }

        public List<OrderSearchResult> SearchOrders(OrderSearchInput input, int? skipCount, int? pageSize, int? PageNumber, out int? TotalRecordCount)
        {
            if (input == null)
                throw new ArgumentNullException("order");
            AccountingRepository orderDao = new AccountingRepository();
            int? take = (pageSize * 4); //Lets fetch 4 times more than requested, should not have any performance impact fetching whars requested OR fetching 4 times more. (this has been done to do the paging w/o fetching the full count)
            input.ApplicationId = AppId.Value;
            var result = orderDao.SearchOrders(input, skipCount.Value, take.Value); //TO-DO--> Can be moved to cache.

            TotalRecordCount = result.Count();

            if (TotalRecordCount == 0) return result;

            TotalRecordCount = CommonLib.Util.Utils.GetTotalRecordCount(TotalRecordCount, pageSize, PageNumber);

            return result.Take(pageSize.Value).ToList();//return 50 only;

        }


        public List<WorkOrderSummaryARInvoiceResult> WorkOrderSummaryARInvoiceSearch(int workOrderID)
        {
            AccountingRepository repository = new AccountingRepository();
            return repository.WorkOrderSummaryARInvoiceSearch(workOrderID);
        }


        public List<WorkOrderSummaryAPInvoiceResult> WorkOrderSummaryAPInvoiceSearch(int workOrderID)
        {
            AccountingRepository repository = new AccountingRepository();
            return repository.WorkOrderSummaryAPInvoiceSearch(workOrderID);
        }

        public List<AccountsReceivableAdjustment> GetReceivableAdjustments(int workOrderID)
        {
            AccountingRepository repository = new AccountingRepository();
            return repository.GetReceivableAdjustments(workOrderID);
        }

        public WorkOrder GetWorkOrderById(int workOrderId)
        {
            AccountingRepository repository = new AccountingRepository();
            return repository.GetWorkOrderById(workOrderId);
        }

        public WorkOrder GetWorkOrderBySrcId(int workOrderId)
        {
            AccountingRepository repository = new AccountingRepository();
            return repository.GetWorkOrderBySrcId(workOrderId);
        }

        public WorkOrder GetFullWorkOrderById(int workOrderId)
        {
            return new AccountingRepository().GetFullWorkOrderById(workOrderId);
        }

        public WorkOrder GetFullPresWorkOrderById(int workOrderId)
        {
            return new AccountingRepository().GetFullPresWorkOrderById(workOrderId);
        }

        public List<WorkOrder> GetWorkOrderDetailsByIds(List<int> workOrderIds)
        {
            AccountingRepository repository = new AccountingRepository();
            return repository.GetWorkOrderDetailsByIds(workOrderIds);

        }

        public bool GetIsSignageFeeBilledByWorkOrder(int workOrderId)
        {
            AccountingRepository repository = new AccountingRepository();
            return repository.GetIsSignageFeeBilledByWorkOrder(workOrderId);

        }

        public IList<BulkException> GetImportBulkExceptions(String fileType, DateTime? dateFrom, DateTime? dateTo)
        {
            AccountingRepository repository = new AccountingRepository();
            return repository.GetImportBulkExceptions(fileType, dateFrom, dateTo);
        }

        public List<AccountsPayableAdjustment> GetPayableAdjustments(int workOrderID)
        {
            AccountingRepository repository = new AccountingRepository();
            return repository.GetPayableAdjustments(workOrderID);
        }


        //public AccountingWorkOrder GetAccountingWorkOrderReceivables(int workOrderId, CommonEnums.AccountingWorkOrderReceivableChild childEnum)
        //{
        //    AccountingRepository repository = new AccountingRepository();

        //    AccountingWorkOrder receivableResult = repository.GetAccountingWorkOrderReceivables(workOrderId, childEnum);

        //    Logging.LogDebug(String.Format("Repository returned {0} row", receivableResult == null ? "no" : "one"));
        //    return receivableResult;
        //}

        //public AccountingWorkOrder GetAccountingWorkOrderPayables(int workOrderId, CommonEnums.AccountingWorkOrderPayableChild childEnum)
        //{
        //    AccountingRepository repository = new AccountingRepository();

        //    AccountingWorkOrder payableResult = repository.GetAccountingWorkOrderPayables(workOrderId, childEnum);

        //    Logging.LogDebug(String.Format("Repository returned {0} row", payableResult == null ? "no" : "one"));
        //    return payableResult;
        //}

        //public AccountingWorkOrder GetAccountingWorkOrderBoth(int workOrderId, CommonEnums.AccountingWorkOrderPayableChild? payableChildEnum, CommonEnums.AccountingWorkOrderReceivableChild? receivableChildEnum)
        //{
        //    AccountingRepository repository = new AccountingRepository();

        //    AccountingWorkOrder result = repository.GetAccountingWorkOrderBoth(workOrderId, payableChildEnum, receivableChildEnum);

        //    Logging.LogDebug(String.Format("Repository returned {0} row", result == null ? "no" : "one"));
        //    return result;
        //}

        public AccountsReceivable GetAccountsReceivableByWorkOrderId(int workOrderId, CommonEnums.AccountsReceivableChild childEnum)
        {
            AccountingRepository repository = new AccountingRepository();
            AccountsReceivable result = repository.GetAccountsReceivableByWorkOrderId(workOrderId, childEnum);

            // CommonLib.Logging.LogDebug(String.Format("Repository returned {0} row", result == null ? "no" : "one"));

            return result;
        }

        public AccountsPayable GetAccountsPayableByWorkOrderId(int workOrderId, CommonEnums.AccountsPayableChild childEnum)
        {
            AccountingRepository repository = new AccountingRepository();
            AccountsPayable result = repository.GetAccountsPayableByWorkOrderId(workOrderId, childEnum);

            //CommonLib.Logging.LogDebug(String.Format("Repository returned {0} row", result == null ? "no" : "one"));

            return result;
        }

        public List<string> GetARInvoiceNumbersByOrderId(int sourceOrderId)
        {
            AccountingRepository repository = new AccountingRepository();
            return repository.GetARInvoiceNumbersByOrderId(sourceOrderId);
        }

        public AccountsReceivableInvoice GetAccountsReceivableInvoice(string invoiceNumber)
        {
            AccountingRepository repository = new AccountingRepository();
            int appid = AppId.Value;
            AccountsReceivableInvoice result = repository.GetAccountsReceivableInvoice(invoiceNumber, appid);

            // CommonLib.Logging.LogDebug(String.Format("Repository returned {0} row", result == null ? "no" : "one"));

            return result;
        }

        public List<CostingInfoView> GetAccountingCostingInfo(int workOrderId)
        {
            AccountingRepository repository = new AccountingRepository();
            List<CostingInfoView> costingInfo = new List<CostingInfoView>();
            costingInfo = repository.GetAccountingCostingInfo(workOrderId);
            return costingInfo;
        }

        public AccountsPayableInvoice GetAccountsPayableInvoice(string invoiceNumber, int vendorProfileID, CommonEnums.AccountingWorkOrderPayableChild childEnum)
        {
            AccountingRepository repository = new AccountingRepository();
            int appid = AppId.Value;
            AccountsPayableInvoice result = repository.GetAccountsPayableInvoice(invoiceNumber, vendorProfileID, childEnum, appid);

            //CommonLib.Logging.LogDebug(String.Format("Repository returned {0} row", result == null ? "no" : "one"));

            return result;
        }

        public List<APInvoiceDetailView> GetAccountsPayableInvoiceDetail(string invoiceNumber, int vendorProfileID)
        {
            AccountingRepository repository = new AccountingRepository();
            int appid = AppId.Value;
            List<APInvoiceDetailView> result = repository.GetAccountsPayableInvoiceDetail(invoiceNumber, vendorProfileID, appid);

            // CommonLib.Logging.LogDebug(String.Format("Repository returned {0} row", result == null ? "no" : "one"));

            return result;
        }

        public APInvoiceDetailSummaryView GetAPInvoiceDetailSummary(string invoiceNumber, int vendorProfileId, bool isVPR)
        {
            AccountingRepository repository = new AccountingRepository();
            APInvoiceDetailSummaryView result = repository.GetAPInvoiceDetailSummary(invoiceNumber, vendorProfileId, isVPR);
            return result;
        }


        public List<AccountsPayable> GetWorkOrderAPInvoiceByInvoiceId(int invoiceId)
        {
            AccountingRepository repository = new AccountingRepository();
            List<AccountsPayable> result = repository.GetWorkOrderAPInvoice(invoiceId);

            //  CommonLib.Logging.LogDebug(String.Format("Repository returned {0} row", result == null ? "no" : "one"));

            return result;
        }

        public List<AccountsReceivable> GetWorkOrderARInvoiceByInvoiceId(int invoiceId)
        {
            AccountingRepository repository = new AccountingRepository();
            List<AccountsReceivable> result = repository.GetWorkOrderARInvoice(invoiceId);

            // CommonLib.Logging.LogDebug(String.Format("Repository returned {0} row", result == null ? "no" : "one"));

            return result;
        }

        public List<AccountsPayableDetail> GetPayableDetails(int payableId, CommonEnums.AccountingWorkOrderPayableChild childEnum)
        {
            AccountingRepository repository = new AccountingRepository();
            List<AccountsPayableDetail> result = repository.GetAccountPayableDetails(payableId, childEnum);

            //CommonLib.Logging.LogDebug(String.Format("Repository returned {0} row", result == null ? "no" : "one"));

            return result;
        }

        public List<ARInvoiceDetailView> GetARInvoiceDetails(string invoiceNumber, int pageSize, int skipCount, out int totalCount)
        {
            AccountingRepository repository = new AccountingRepository();
            List<ARInvoiceDetailView> result = repository.GetARInvoiceDetails(invoiceNumber, pageSize, skipCount, out totalCount);
            //CommonLib.Logging.LogDebug(String.Format("Repository returned {0} row", result == null ? "no" : "one"));

            return result;
        }


        public List<ARInvoiceDetailView> GetAccountingReceivablesInvoiceDetailWithoutPaging(string invoiceNumber)
        {
            AccountingRepository repository = new AccountingRepository();
            List<ARInvoiceDetailView> result = repository.GetAccountingReceivablesInvoiceDetailWithoutPaging(invoiceNumber);

            return result;
        }
        public List<APInvoiceDetailView> GetAPInvoiceDetails(string invoiceNumber, int vendorProfile, int pageSize, int skipCount, out int totalCount)
        {
            AccountingRepository repository = new AccountingRepository();
            List<APInvoiceDetailView> result = repository.GetAPInvoiceDetails(invoiceNumber, vendorProfile, pageSize, skipCount, out  totalCount);

            return result;
        }

        public List<APInvoiceDetailView> GetAPInvoiceDetailsWithoutPaging(string invoiceNumber, int vendorProfile)
        {
            AccountingRepository repository = new AccountingRepository();
            List<APInvoiceDetailView> result = repository.GetAPInvoiceDetailsWithoutPaging(invoiceNumber, vendorProfile);

            return result;
        }


        public List<APDetailView> GetAPDetails(int workOrderId, int pageSize, int skipCount, out int totalCount)
        {
            AccountingRepository repository = new AccountingRepository();
            int appid = AppId.Value;
            List<APDetailView> result = repository.GetAPDetails(workOrderId, pageSize, skipCount, out totalCount);

            return result;
        }
        public List<ARDetailView> GetARDetails(int workOrderId, int pageSize, int skipCount, out int totalCount)
        {
            AccountingRepository repository = new AccountingRepository();
            int appid = AppId.Value;
            List<ARDetailView> result = repository.GetARDetails(workOrderId, pageSize, skipCount, out totalCount);

            return result;
        }
        public List<AccountsTax> GetAccountsTax(int? workOrderId, string state, DateTime? errorDateFrom, DateTime? errorDateTo, int pageSize, int skipCount, out int totalCount)
        {
            AccountingRepository repository = new AccountingRepository();
            int appid = AppId.Value;
            List<AccountsTax> result = repository.GetAccountsTax(workOrderId, state, errorDateFrom, errorDateTo, pageSize, skipCount, out totalCount);

            return result;
        }

        public List<VPRGenInformation> GetVPRGenInformation()
        {
            AccountingRepository repository = new AccountingRepository();
            return repository.GetVPRGenInformation();
        }

        public List<ARAdjustmentDetailView> GetARAdjustmentDetailViewById(int orderId, int workOrderId)
        {
            AccountingRepository repository = new AccountingRepository();
            return repository.GetARAdjustmentDetailViewById(orderId, workOrderId);
        }

        public List<APAdjustmentDetailView> GetApAdjustmentDetailViewById(int vendorOrderId, int workOrderId)
        {
            AccountingRepository repository = new AccountingRepository();
            return repository.GetApAdjustmentDetailViewById(vendorOrderId, workOrderId);
        }

        public List<APCostingTrace> GetAccountsPayableTraceInfo(int workOrderId)
        {
            AccountingRepository repository = new AccountingRepository();
            return repository.GetAccountsPayableTraceInfo(workOrderId);
        }

        public List<SpentToDate> GetSpentToDateByLoanId(int LoanId)
        {
            AccountingRepository repository = new AccountingRepository();
            return repository.GetSpentToDateByLoanId(LoanId);
        }

        public List<ARPricingTrace> GetAccountsReceivableTraceInfo(int workOrderId)
        {
            AccountingRepository repository = new AccountingRepository();
            return repository.GetAccountsReceivableTraceInfo(workOrderId);
        }

        public string GetArInvoiceNumber(int workOrderId)
        {
            return new AccountingRepository().GetArInvoiceNumber(workOrderId);
        }

        public string GetApInvoiceNumber(int workOrderId)
        {
            return new AccountingRepository().GetApInvoiceNumber(workOrderId);
        }
        public bool IsDocumentAccessible(int documentId)
        {
            return new AccountingRepository().IsDocumentAccessible(documentId);
        }
        public bool IsSupplierDisputeDocumentAccessible(int documentId)
        {
            return new AccountingRepository().IsSupplierDisputeDocumentAccessible(documentId);
        }

    }
}
