﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccess.Accounting;
using DomainModel.Accounting;
using DataAccess;
using DomainModel.Accounting;

namespace Delegate.SpaAcc
{
    public class SpaAccDelegate
    {
        public IList<OrderSearch> OrderSearch(OrderSearch orderSearch)
        {
            OrderDAO orderDao = new OrderDAO();
            var result = orderDao.SearchOrders(orderSearch);
            return result;
        }
    }
}
