﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Admin.ServiceProxy;
using Admin.ServiceProxy.ClientService;
using CommonLib;
using CommonLib.Context;
using CommonLib.FSException;
using DataAccess;
using DataAccess.Accounting;
using DomainModel.Accounting;
using InspProxy = Inspections.ServiceProxy.InspectionSvc;
using PresProxy = Pres.ServiceProxy.PresSvc;
using BillProxy = Billing.ServiceProxy.BillingSyncSvc;
using VS = Delegate.VertexTaxService;
using RFS = Reference.ServiceProxy;
using System.Runtime.ExceptionServices;
using System.Security.Cryptography.X509Certificates;
using System.Net;

namespace Delegate.SpaAcc
{
    public class AccountingBillingDelegate
    {
        private ICollection<DataMappingConfig> _dataMappingConfigurations;

        public Application GetApplicationById(int applicationId)
        {
            if (applicationId <= 0) throw new ArgumentOutOfRangeException("applicationId");
            return new AccountingRepository().GetApplicationById(applicationId);
        }

        public Application GetApplicationByApplicationName(string applicationName)
        {
            if (string.IsNullOrEmpty(applicationName)) throw new ArgumentNullException("applicationName");
            return new AccountingRepository().GetApplicationByApplicationName(applicationName);
        }

        public void SyncTxnEntitiesByWorkOrderId(int workOrderId)
        {
            if (workOrderId <= 0) throw new ArgumentOutOfRangeException("workOrderId");
            BillProxy.WorkOrder WO = null;
            using (BillProxy.BillingServiceClient proxy = new BillProxy.BillingServiceClient())
            {
                WO = proxy.GetWorkOrderForSync(workOrderId);

            }
            if (WO == null) throw new ArgumentOutOfRangeException("workOrderId", string.Format("Can't find work order for given id ({0})", workOrderId));
            new AccountingBillingDao().SyncTxnEntitiesByWorkOrder(WO);
        }

        public void SyncTxnEntitiesBySourceWorkOrderId(int sourceWorkOrderId)
        {
            if (sourceWorkOrderId <= 0) throw new ArgumentOutOfRangeException("sourceWorkOrderId");
            InspProxy.WorkOrder inspWO = null;
            using (InspProxy.InspServiceClient proxy = new InspProxy.InspServiceClient())
            {
                inspWO = proxy.GetWorkOrderForBilling(sourceWorkOrderId);
            }
            if (inspWO == null) throw new ArgumentOutOfRangeException("sourceWorkOrderId", string.Format("Can't find inspection work order for given id ({0})", sourceWorkOrderId));
            new AccountingBillingDao().SyncTxnEntitiesByInspWorkOrder(inspWO);
        }
        public void SyncTxnEntitiesPresBySourceWorkOrderId(int sourceWorkOrderId)
        {
            if (sourceWorkOrderId <= 0) throw new ArgumentOutOfRangeException("sourceWorkOrderId");
            PresProxy.WorkOrder presWO = null;
            using (PresProxy.PresServiceClient proxy = new PresProxy.PresServiceClient())
            {
                presWO = proxy.GetWorkOrderForBilling(sourceWorkOrderId);
            }
            if (presWO == null) throw new ArgumentOutOfRangeException("sourceWorkOrderId", string.Format("Can't find preservation work order for given id ({0})", sourceWorkOrderId));
            new AccountingBillingDao().SyncTxnEntitiesByPresWorkOrder(presWO);
        }

        public List<OrderHierarchy> SaveAccountsReceiveable(List<OrderHierarchy> receivable)
        {
            int tenantApplicationId = TenantHierarchyHelper.LowestTenantApplicationId;
            foreach (var ar in receivable)
            {
                if (ar.AccountsReceivableDetails != null)
                {
                    foreach (var ard in ar.AccountsReceivableDetails)
                    {
                        ard.ApplicationId = tenantApplicationId;
                        if (ard.AccountsReceivableTraces != null)
                        {
                            foreach (var art in ard.AccountsReceivableTraces)
                                art.ApplicationId = tenantApplicationId;
                        }
                    }
                    foreach (var arh in ar.DisputeReceivableAdjustmentHistorys)
                    {
                        arh.ApplicationId = tenantApplicationId;
                    }
                }
            }
            return new AccountingBillingDao().SaveAccountsReceivableOnly(receivable);
        }

        public List<OrderHierarchy> SaveAccountsPayable(List<OrderHierarchy> payable)
        {
            int tenantApplicationId = TenantHierarchyHelper.LowestTenantApplicationId;
            foreach (var ap in payable)
            {
                if (ap.AccountsPayableDetails != null)
                {
                    foreach (var apd in ap.AccountsPayableDetails)
                    {
                        apd.ApplicationId = tenantApplicationId;
                        if (apd.AccountsPayableTraces != null)
                        {
                            foreach (var apt in apd.AccountsPayableTraces)
                                apt.ApplicationId = tenantApplicationId;
                        }
                    }
                    foreach (var aph in ap.DisputePayableAdjustmentHistorys)
                    {
                        aph.ApplicationId = tenantApplicationId;
                    }
                }
            }
            return new AccountingBillingDao().SaveAccountsPayableOnly(payable);
        }

        public void SaveAPnAR(List<OrderHierarchy> receivable, List<OrderHierarchy> payable)
        {
            int tenantApplicationId = TenantHierarchyHelper.LowestTenantApplicationId;

            foreach (var ar in receivable)
            {
                if (ar.AccountsReceivableDetails != null)
                {
                    foreach (var ard in ar.AccountsReceivableDetails)
                    {
                        ard.ApplicationId = tenantApplicationId;
                        if (ard.AccountsReceivableTraces != null)
                        {
                            foreach (var art in ard.AccountsReceivableTraces)
                                art.ApplicationId = tenantApplicationId;
                        }
                    }
                    foreach (var arh in ar.DisputeReceivableAdjustmentHistorys)
                    {
                        arh.ApplicationId = tenantApplicationId;
                    }
                }
            }

            foreach (var ap in payable)
            {
                if (ap.AccountsPayableDetails != null)
                {
                    foreach (var apd in ap.AccountsPayableDetails)
                    {
                        apd.ApplicationId = tenantApplicationId;
                        if (apd.AccountsPayableTraces != null)
                        {
                            foreach (var apt in apd.AccountsPayableTraces)
                                apt.ApplicationId = tenantApplicationId;
                        }
                    }
                    foreach (var aph in ap.DisputePayableAdjustmentHistorys)
                    {
                        aph.ApplicationId = tenantApplicationId;
                    }
                }
            }

            new AccountingBillingDao().SaveAccountsBilling(receivable, payable);
        }

        public AccountsReceivable SaveAccountsReceiveable(AccountsReceivable receivable, int workOrderId)
        {
            int tenantApplicationId = TenantHierarchyHelper.LowestTenantApplicationId;

            receivable.ApplicationId = tenantApplicationId;
            if (receivable.AccountsReceivableDetails != null)
            {
                foreach (var ard in receivable.AccountsReceivableDetails)
                {
                    ard.ApplicationId = tenantApplicationId;
                    if (ard.AccountsReceivableTraces != null)
                    {
                        foreach (var art in ard.AccountsReceivableTraces)
                            art.ApplicationId = tenantApplicationId;
                    }
                }
            }
            return new AccountingBillingDao().SaveAccountsReceivableOnly(receivable, workOrderId);
        }

        public AccountsPayable SaveAccountsPayable(AccountsPayable payable, int workOrderId)
        {
            int tenantApplicationId = TenantHierarchyHelper.LowestTenantApplicationId;

            payable.ApplicationId = tenantApplicationId;
            if (payable.AccountsPayableDetails != null)
            {
                foreach (var apd in payable.AccountsPayableDetails)
                {
                    apd.ApplicationId = tenantApplicationId;
                    if (apd.AccountsPayableTraces != null)
                    {
                        foreach (var apt in apd.AccountsPayableTraces)
                            apt.ApplicationId = tenantApplicationId;
                    }
                }
            }
            return new AccountingBillingDao().SaveAccountsPayableOnly(payable, workOrderId);
        }

        public void SaveAPnAR(AccountsReceivable receivable, AccountsPayable payable, int workOrderId)
        {
            int tenantApplicationId = TenantHierarchyHelper.LowestTenantApplicationId;

            receivable.ApplicationId = tenantApplicationId;
            if (receivable.AccountsReceivableDetails != null)
            {
                foreach (var ard in receivable.AccountsReceivableDetails)
                {
                    ard.ApplicationId = tenantApplicationId;
                    if (ard.AccountsReceivableTraces != null)
                    {
                        foreach (var art in ard.AccountsReceivableTraces)
                            art.ApplicationId = tenantApplicationId;
                    }
                }
            }

            payable.ApplicationId = tenantApplicationId;
            if (payable.AccountsPayableDetails != null)
            {
                foreach (var apd in payable.AccountsPayableDetails)
                {
                    apd.ApplicationId = tenantApplicationId;
                    if (apd.AccountsPayableTraces != null)
                    {
                        foreach (var apt in apd.AccountsPayableTraces)
                            apt.ApplicationId = tenantApplicationId;
                    }
                }
            }

            new AccountingBillingDao().SaveAccountsBilling(receivable, payable, workOrderId);
        }

        public OrderHierarchy GetSetOrderHierarchyByFK(int orderId, int? vendorWorkOrderId, int? workOrderId, int? workOrderItemId, int? workOrderLineItemId)
        {
            return new AccountingBillingDao().GetSetOrderHierarchyByFK(orderId, vendorWorkOrderId, workOrderId, workOrderItemId, workOrderLineItemId);
        }

        public FeeType GetFeeType(string feeTypeName)
        {
            return new AccountingBillingDao().GetFeeType(feeTypeName);
        }

        public DateTime? GetWorkOrderCancellationDate(int workOrderId)
        {
            return new AccountingBillingDao().GetWorkOrderCancellationDate(workOrderId);
        }

        public string GetProductCodeBySourceWorkOrderId(int sourceWorkOrderId)
        {
            return new AccountingBillingDao().GetProductCodeBySourceWorkOrderId(sourceWorkOrderId);
        }
        public bool CheckOrderFeesByOrderHierarchyId(int orderHId)
        {
            return new AccountingBillingDao().CheckOrderFeesByOrderHierarchyId(orderHId);
        }

        public bool CheckVendorWorkOrderFeesByOrderHierarchyId(int orderHId)
        {
            return new AccountingBillingDao().CheckVendorWorkOrderFeesByOrderHierarchyId(orderHId);
        }

        public bool CheckAPDetailByOrderHierarchyId(int orderHId, int? feeTypeId)
        {
            return new AccountingBillingDao().CheckAPDetailByOrderHierarchyId(orderHId, feeTypeId);
        }

        public bool CheckARDetailByOrderHierarchyId(int orderHId, int? feeTypeId)
        {
            return new AccountingBillingDao().CheckARDetailByOrderHierarchyId(orderHId, feeTypeId);
        }

        public List<PresBillingDetailView> GetPresBillingDetailsBySourceWorkOrderId(int sourceWorkOrderId)
        {
            return new AccountingBillingDao().GetPresBillingDetailsBySourceWorkOrderId(sourceWorkOrderId);
        }

        public void CalculateRealTimeVertexTax(List<int> adjustmentIds)
        {
            var accountingRepo = new AccountingRepository();
            var taxClasses = new Dictionary<int, int?>();
            var taxIds = new List<int>();

            foreach (var id in adjustmentIds)
            {
                var taxClass = accountingRepo.GetTaxServiceClass(id);
                if (taxClass.HasValue && taxClass.GetValueOrDefault() >= 0)
                    taxClasses.Add(id, taxClass);
                else
                    Logging.LogError(string.Format("Not able to create Accounts Tax Record because No Tax Service Class Found. Adjustment Id:{0}", id));
            }

            if (taxClasses.Any())
            {
                AccountsTaxBatch batch = new AccountsTaxBatch()
                {
                    TaxBatchDescription = "READY",
                    TransmissionStatus = "READY",
                    TransmissionStatusGroup = "TBSG",
                    ProductCategoryCodeGroup = "LOB",
                    ProductCategoryCode = "PRESERV",
                };

                foreach (var id in adjustmentIds)
                {
                    var taxClassVal = taxClasses.First(p => p.Key == id).Value;
                    if (taxClassVal.HasValue && taxClassVal.GetValueOrDefault() >= 0)
                    {

                        if (batch.AccountsTaxes == null || batch.AccountsTaxes.Count <= 0)
                            batch.AccountsTaxes = new List<AccountsTax>();

                        batch.AccountsTaxes.Add(
                            new AccountsTax()
                            {
                                AccountsReceivableAdjustmentId = id,
                                ApplicationId = 10016,
                                TransmissionStatusGroup = "TRSG",
                                TransmissionStatus = "NEW",
                                TaxServiceClass = taxClassVal.GetValueOrDefault(),
                                AccountsTaxBatchId = batch.AccountsTaxBatchId

                            });
                        taxIds.Add(id);
                    }
                }

                if (taxIds.Count > 0)
                {
                    batch = accountingRepo.SaveAccountsTaxWithBatch(batch);
                    if (batch.AccountsTaxBatchId > 0)
                        accountingRepo.UpdateArStatusPending(taxIds);
                    CalculateVertexTaxUsingTaxBatchId(batch.AccountsTaxBatchId, "57F9B2BD-21BA-4028-AAC8-A382FE62B95A");
                }

                //else
                //    throw new FSBusinessException("Problem in Creating Tax Batch");
            }

        }

        /// <summary>
        /// This method calls the Vertex a third party's service's method CalculateTax60 for tax calculations for all the records in the batch.
        /// Upon successful calculation of tax, the batch's status is marked as COMPLETE and in case of exception to atleast one record, tax cannot be computed
        /// for no record in the batch and the batch's status will be marked as FAILED.
        /// </summary>
        /// <param name="accountTaxBatchID">This will be part of the message that MQ receives.</param>
        /// <param name="tenantGuid">This will be passed by MQ which it would get from SSIS.</param>
        public void CalculateVertexTaxUsingTaxBatchId(int accountTaxBatchID, string tenantGuid)
        {
            var accountingRepo = new AccountingRepository();
            AccountsTaxBatch batch;
            string batchId = accountTaxBatchID.ToString();
            var loanOrderClientDetailsViews = new List<FSLoanOrderClientDetailsView>();
            var vertexTaxClient = new VS.CalculateTaxWS80Client();
            FetchDataMappingConfigurations(GetApplicationIdUsingTenantGuidId(tenantGuid), "VertexLoanType");
            Logging.LogInfo("Vertex Tax Calculation: BatchId is " + batchId + " tenantGuid is " + tenantGuid);
            // Get tax records using the BatchID
            Logging.LogInfo("Vertex Tax Calculation: Fetching records in the batch - " + batchId + " begins. " + DateTime.Now);
            batch = accountingRepo.GetAccountsTaxBatchById(accountTaxBatchID);
            Logging.LogInfo("Vertex Tax Calculation: Fetching records in the batch - " + batchId + " ends. " + DateTime.Now);

            if (batch.AccountsTaxes.Any())
            {
                Logging.LogInfo("Vertex Tax Calculation: There are " + batch.AccountsTaxes.Count.ToString() + " records in the batchId - " + batchId + ".");
                var workOrderIds = new Dictionary<int, int>();
                var orderIds = new Dictionary<int, int>();
                Logging.LogInfo("Vertex Tax Calculation: GetInputDataForTaxCalculation starts at - " + DateTime.Now + " for batch " + batchId);
                loanOrderClientDetailsViews = GetInputDataForTaxCalculation(batch, workOrderIds, orderIds);
                Logging.LogInfo("Vertex Tax Calculation: GetInputDataForTaxCalculation ends at - " + DateTime.Now + " for batch " + batchId);
                batch.AccountsTaxes = batch.AccountsTaxes.OrderBy(at => at.AccountsTaxId).ToList();
                Logging.LogInfo("Vertex Tax Calculation: Build Vertex Request Envelope starts at - " + DateTime.Now + " for batch " + batchId);
                var vEnvelope = BuildVertexRequestEnvelope(batch, loanOrderClientDetailsViews, workOrderIds, orderIds);
                Logging.LogInfo("Vertex Tax Calculation: Build Vertex Request Envelope ends at - " + DateTime.Now + " for batch " + batchId);
                if (vEnvelope != null)
                {
                    VS.InvoiceResponseType response = null;
                    try
                    {
                        var serializer = new System.Xml.Serialization.XmlSerializer(vEnvelope.GetType());
                        using (var stringWriter = new StringWriter())
                        {
                            Logging.LogInfo("Vertex Tax Calculation: Request Serialization starts at - " + DateTime.Now + " for batch " + batchId);
                            serializer.Serialize(stringWriter, vEnvelope);
                            Logging.LogInfo("Vertex Tax Calculation: Request Serialization ends at - " + DateTime.Now + " for batch " + batchId);
                            batch.OutboundXML = stringWriter.ToString();

                            Logging.LogInfo("Vertex Tax Calculation: Call to VertexTaxCalculation60 service begins at" + DateTime.Now + " for batch " + batchId);

                            ServicePointManager.Expect100Continue = true;
                            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;

                            vertexTaxClient.calculateTax80(ref vEnvelope);
                            Logging.LogInfo("Vertex Tax Calculation: Call to VertexTaxCalculation60 service ends ar" + DateTime.Now + " for batch " + batchId);
                            response = (VS.InvoiceResponseType)vEnvelope.Item;
                            Logging.LogInfo("Vertex Tax Calculation: Response Serialization ends at - " + DateTime.Now + " for batch " + batchId);
                            serializer.Serialize(stringWriter, vEnvelope);
                            Logging.LogInfo("Vertex Tax Calculation: Response Serialization ends at - " + DateTime.Now + " for batch " + batchId);
                            batch.InboundXML = stringWriter.ToString();
                        }

                    }
                    catch (Exception ex)
                    {
                        Logging.LogError("Vertex Tax Calculation: Exception occurred calling Vertex service, at - " + DateTime.Now + " for batch " + batchId);
                        Logging.LogError(ex);
                        batch.TransmissionStatus = "FAIL";
                        batch.ErrorMsg = ex.Message;
                        batch.ErrorDate = DateTime.Now;
                        accountingRepo.SaveAccountsTaxBatch(batch);
                        return;
                    }

                    try
                    {
                        ProcessVertexResponse(batch, workOrderIds, response);
                        batch.TransmissionStatus = "COMPLETE";
                    }
                    catch (Exception ex)
                    {
                        Logging.LogError("Vertex Tax Calculation: Exception occurred when processing Vertex response, at - " + DateTime.Now + " for batch " + batchId);
                        Logging.LogError(ex);
                        HandleVertexException(accountTaxBatchID, ex);
                    }
                }
                else
                {
                    batch.TransmissionStatus = "COMPLETE";
                }
            }
            else
            {
                batch.TransmissionStatus = "FAIL";
                batch.ErrorMsg = "There are no AccountsTax records in the BatchId " + batchId + ".";
                batch.ErrorDate = DateTime.Now;
            }
            try
            {
                Logging.LogInfo("Vertex Tax Calculation: Saving the calculated tax to the database, begins " + DateTime.Now + " for batch " + batchId);
                accountingRepo.SaveAccountsTaxBatch(batch);
            }
            catch (Exception ex)
            {
                Logging.LogError("Vertex Tax Calculation: Error in saving the calulcated tax for the batch - " + batchId, ex);
                Logging.LogError(ex);
                HandleVertexException(accountTaxBatchID, ex);
            }
            Logging.LogInfo("Vertex Tax Calculation: Saving the calculated tax to the database, ends. " + DateTime.Now + " for batch " + batchId);
        }

        private void HandleVertexException(int accountTaxBatchID, Exception e)
        {
            using (var txn = new System.Transactions.TransactionScope(System.Transactions.TransactionScopeOption.Suppress))
            {
                var accountingRepo = new AccountingRepository();
                var exBatch = accountingRepo.GetOnlyAccountsTaxBatchById(accountTaxBatchID);
                exBatch.TransmissionStatus = "FAIL";
                exBatch.ErrorMsg = e.Message + "\n" + e.StackTrace;
                exBatch.ErrorDate = DateTime.Now;

                accountingRepo.SaveOnlyAccountsTaxBatch(exBatch);
                txn.Complete();
            }
            throw (e);
        }

        private List<FSLoanOrderClientDetailsView> GetInputDataForTaxCalculation(AccountsTaxBatch batch, Dictionary<int, int> workOrderIds, Dictionary<int, int> orderIds)
        {
            var accountingRepo = new AccountingRepository();
            var loanOrderClientDetailsViews = new List<FSLoanOrderClientDetailsView>();
            var accountsTaxes = batch.AccountsTaxes.OrderBy(e => e.AccountsTaxId).ToList();
            if (batch.ProductCategoryCode == "INSPECT" || string.IsNullOrEmpty(batch.ProductCategoryCode))
            {
                accountsTaxes.ForEach(e =>
                {
                    var workOrderId = GetWorkOrderID(e);
                    if (workOrderId != 0)
                        workOrderIds.Add(e.AccountsTaxId, workOrderId);
                });

                // Making one call to the view to fetch all the records in one shot.
                loanOrderClientDetailsViews = accountingRepo.GetLoanOrderClientDetailsByWorkOrderIds(workOrderIds.Values.ToList<int>());
            }
            else
            {
                accountsTaxes.ForEach(e =>
                {
                    if (e.AccountsReceivableDetail != null)
                    {
                        if (e.AccountsReceivableDetail.OrderHierarchy != null)
                        {
                            orderIds.Add(e.AccountsTaxId, e.AccountsReceivableDetail.OrderHierarchy.OrderId);
                            if (e.AccountsReceivableDetail.OrderHierarchy.WorkOrderId.HasValue)
                                workOrderIds.Add(e.AccountsTaxId, e.AccountsReceivableDetail.OrderHierarchy.WorkOrderId.Value);
                            else
                                workOrderIds.Add(e.AccountsTaxId, 0);
                        }
                    }
                    else if (e.AccountsReceivableAdjustment != null)
                    {
                        if (e.AccountsReceivableAdjustment.AccountsReceivableDetail != null)
                            if (e.AccountsReceivableAdjustment.AccountsReceivableDetail.OrderHierarchy != null)
                                orderIds.Add(e.AccountsTaxId, e.AccountsReceivableAdjustment.AccountsReceivableDetail.OrderHierarchy.OrderId);
                    }
                });
                loanOrderClientDetailsViews = accountingRepo.GetLoanOrderClientDetailsByOrderIds(orderIds.Values.ToList<int>());
            }
            return loanOrderClientDetailsViews;
        }

        [HandleProcessCorruptedStateExceptions] 
        private VS.VertexEnvelope BuildVertexRequestEnvelope(AccountsTaxBatch batch, List<FSLoanOrderClientDetailsView> loanOrderClientDetailsViews, Dictionary<int, int> workOrderIds, Dictionary<int, int> orderIds)
        {

            var counter = 0;
            var documentDate = DateTime.Now.Date;
            var lineItems = new List<VS.LineItemISIType>();
            Logging.LogInfo("Vertex Tax Calculation: Iterating through each tax record for batch " + batch.AccountsTaxBatchId + " ends.");
            batch.AccountsTaxes.ToList().ForEach(e =>
            {
                var loanOrderClientDetail = new FSLoanOrderClientDetailsView();
                if (batch.ProductCategoryCode == "INSPECT" || string.IsNullOrEmpty(batch.ProductCategoryCode))
                    loanOrderClientDetail = loanOrderClientDetailsViews.First(f => f.WorkOrderId == workOrderIds[e.AccountsTaxId]);
                else
                    loanOrderClientDetail = loanOrderClientDetailsViews.First(f => f.OrderId == orderIds[e.AccountsTaxId]);

                decimal extendedPrice = 0;

                if (e.AccountsReceivableDetail != null)
                    extendedPrice = e.AccountsReceivableDetail.FinalTotalPrice;
                else if (e.AccountsReceivableAdjustment != null)
                {
                    if (e.AccountsReceivableAdjustment.AdjustmentType == "DEBIT")
                        extendedPrice = e.AccountsReceivableAdjustment.Amount;
                    else
                        extendedPrice = e.AccountsReceivableAdjustment.Amount * -1;
                }
                var loanType = loanOrderClientDetail.LoanType;
                if (_dataMappingConfigurations != null || _dataMappingConfigurations.Any())
                {
                    var dataMappingConfig = _dataMappingConfigurations.FirstOrDefault(f => f.Key3 == loanOrderClientDetail.LoanType && f.Key2 == loanOrderClientDetail.InvestorIdentifier);
                    loanType = dataMappingConfig != null ? dataMappingConfig.Value1 : "";
                }

                counter++;
                bool isLineItemAdded = true;
                if (e.AccountsReceivableAdjustmentId > 0)
                {
                    isLineItemAdded = new AccountingRepository().CheckAdjustedTaxRateAndTaxAmount(e.AccountsTaxId, out documentDate);
                }


                if (isLineItemAdded)
                {
                    var lineItem = new VS.LineItemISIType()
                    {
                        lineItemNumber = counter.ToString(),
                        lineItemId = e.AccountsTaxId.ToString(),
                        Customer = new VS.CustomerType(),
                        Product = new VS.Product
                        {
                            productClass = e.TaxServiceClass.ToString()
                        },

                        FlexibleFields = new VS.FlexibleFields
                        {
                            FlexibleCodeField = new VS.FlexibleFieldsFlexibleCodeField[]
                                {
                                    new VS.FlexibleFieldsFlexibleCodeField {fieldId="9", Value=loanOrderClientDetail.SourceWorkOrderId.ToString()},
                                    new VS.FlexibleFieldsFlexibleCodeField{fieldId="10", Value=loanType}
                                }
                        }
                    };
                    lineItem.ExtendedPrice = extendedPrice;// new VS.AmountType { Value = extendedPrice };
                    lineItem.ExtendedPriceSpecified = true;
                    if (loanOrderClientDetail.ClientLSCI != null)
                    {
                        lineItem.Customer.CustomerCode = new VS.CustomerCodeType
                        {
                            Value = loanOrderClientDetail.ClientLSCI
                        };
                    }
                    AssignDestination(lineItem, loanOrderClientDetail);

                    lineItems.Add(lineItem);
                }
                else
                {
                    UpdateTaxesOnAccountsReceivableAdjustmentRecords(batch.ProductCategoryCode, e, 0);
                }
            });
            Logging.LogInfo("Vertex Tax Calculation: Iterating through each tax record, for batch " + batch.AccountsTaxBatchId + " ends.");
            if (lineItems != null && lineItems.Count > 0)
            {
                var item = new VS.InvoiceRequestType
                {
                    documentNumber = batch.AccountsTaxBatchId.ToString(),
                    documentDate = documentDate,
                    returnAssistedParametersIndicator = true,
                    transactionType = VS.SaleTransactionType.SALE,
                    Seller = new VS.SellerType
                    {
                        Company = ConfigurationManager.AppSettings["VertexSellerCompanyCode"],
                        Division = ConfigurationManager.AppSettings["VertexSellerDivisionCode"]
                    },
                    LineItem = lineItems.ToArray(),
                };
                var vEnvelope = new VS.VertexEnvelope
                {
                    Login = new VS.LoginType
                    {
                        UserName = ConfigurationManager.AppSettings["VeretxLogin"],
                        Password = ConfigurationManager.AppSettings["VertexPassword"]
                    },
                    Item = item
                };
                return vEnvelope;
            }
            return null;
        }



        private void ProcessVertexResponse(AccountsTaxBatch batch, Dictionary<int, int> workOrderIds, VS.InvoiceResponseType response)
        {
            response.LineItem.ToList().ForEach(e =>
            {
                var accountsTaxRecord = batch.AccountsTaxes.First(lineItem => lineItem.AccountsTaxId == Int32.Parse(e.lineItemId));
                Logging.LogInfo("Vertex Tax Calculation: Processing the response for the AccountsTaxRecord - " + accountsTaxRecord.AccountsTaxId + " begin.");
                var totalTax = e.TotalTax;// e.TotalTax.Value;
                var taxRate = e.Taxes.Select(f => f.EffectiveRate).Sum() * 100;
                accountsTaxRecord.TaxAmount = Math.Abs((decimal)totalTax);
                accountsTaxRecord.TaxRate = (decimal)taxRate;
                accountsTaxRecord.TransmissionStatus = "COMPLETE";
                if (accountsTaxRecord.AccountsReceivableDetailId != null || accountsTaxRecord.AccountsReceivableDetailId == 0)
                {
                    Logging.LogInfo("Vertex Tax Calculation: Updating taxes on AccountsReceivableDetailRecordId - " + accountsTaxRecord.AccountsReceivableDetailId + " begins.");
                    UpdateTaxesOnAccountsReceivableDetailRecords(batch.ProductCategoryCode, workOrderIds, accountsTaxRecord, totalTax);
                    Logging.LogInfo("Vertex Tax Calculation: Updating taxes on AccountsReceivableDetailRecordId - " + accountsTaxRecord.AccountsTaxId + " end.");
                }
                else if (accountsTaxRecord.AccountsReceivableAdjustment != null)
                {
                    Logging.LogInfo("Vertex Tax Calculation: Updating taxes on AccountsReceivableAdjustmentRecordId - " + accountsTaxRecord.AccountsReceivableAdjustmentId + " begins.");
                    Logging.LogInfo("Vertex Tax Calculation: Before GetCreditAdjTaxAmount Vertex Response Tax Value- " + totalTax.ToString());
                    totalTax = new AccountingRepository().GetCreditAdjTaxAmount(accountsTaxRecord.AccountsTaxId, totalTax);
                    Logging.LogInfo("Vertex Tax Calculation: After GetCreditAdjTaxAmount- " + totalTax.ToString());
                    accountsTaxRecord.TaxAmount = Math.Abs(totalTax);
                    UpdateTaxesOnAccountsReceivableAdjustmentRecords(batch.ProductCategoryCode, accountsTaxRecord, totalTax);
                    Logging.LogInfo("Vertex Tax Calculation: Updating taxes on AccountsReceivableAdjustmentRecordId - " + accountsTaxRecord.AccountsReceivableAdjustmentId + " end.");
                }
                Logging.LogInfo("Vertex Tax Calculation: Processing the response for the AccountsTaxRecord - " + accountsTaxRecord.AccountsTaxId + " end.");
            });
        }

        private void UpdateTaxesOnAccountsReceivableAdjustmentRecords(string productCategoryCode, AccountsTax accountsTaxRecord, decimal totalTax)
        {
            accountsTaxRecord.AccountsReceivableAdjustment.ARAdjStatusType = "RDY2BILL";
            if (productCategoryCode != "INSPECT" && !string.IsNullOrEmpty(productCategoryCode))
            {
                if (accountsTaxRecord.AccountsReceivableAdjustment.DisputeReceivableAdjustmentHistoryId != null)
                {
                    var feeType = "";
                    if (accountsTaxRecord.AccountsReceivableAdjustment.AccountsReceivableDetail.FeeType != null)
                    {
                        feeType = accountsTaxRecord.AccountsReceivableAdjustment.AccountsReceivableDetail.FeeType.FeeTypeCode;
                    }
                    
                    var accountingRepo = new AccountingRepository();
                    var disputeReceivableAdjustmentHistoryId = accountsTaxRecord.AccountsReceivableAdjustment.DisputeReceivableAdjustmentHistoryId.Value;
                    Logging.LogInfo("Vertex Tax Calculation: GetDisputeReceivableAdjustmentHistory for the DisputeReceivableId - " + disputeReceivableAdjustmentHistoryId.ToString() + " when processing the AccountsTax record -" + accountsTaxRecord.ToString() + " begin.");
                    var disputeReceivableAdjustmentHistory = accountingRepo.GetDisputeReceivableAdjustmentHistory(disputeReceivableAdjustmentHistoryId);
                    Logging.LogInfo("Vertex Tax Calculation: GetDisputeReceivableAdjustmentHistory for the DisputeReceivableId - " + disputeReceivableAdjustmentHistoryId.ToString() + " when processing the AccountsTax record -" + accountsTaxRecord.ToString() + " end.");
                    if (disputeReceivableAdjustmentHistory != null)
                    {
                        AssignTaxAmountInDisputeReceivableAdjustmentHistory(totalTax, disputeReceivableAdjustmentHistory, feeType);
                        Logging.LogInfo("Vertex Tax Calculation: SaveDisputeReceivableAdjustmentHistory for the DispureReceivableId - " + disputeReceivableAdjustmentHistoryId.ToString() + " when processing the AccountsTax record -" + accountsTaxRecord.ToString() + " begin.");
                        accountingRepo.SaveDisputeReceivableAdjustmentHistory(disputeReceivableAdjustmentHistory);
                        Logging.LogInfo("Vertex Tax Calculation: SaveDisputeReceivableAdjustmentHistory for the DispureReceivableId - " + disputeReceivableAdjustmentHistoryId.ToString() + " when processing the AccountsTax record -" + accountsTaxRecord.ToString() + " begin.");
                        UpdateTaxOnFinalDisputeHistory(totalTax, accountingRepo, feeType, disputeReceivableAdjustmentHistory);
                        var orderHierarchyId = disputeReceivableAdjustmentHistory.OrderHierarchyId;
                        var orderHierarchy = accountingRepo.GetOrderHierarchyById(orderHierarchyId);
                        if (orderHierarchy.WorkOrderLineItemId != null)
                            UpdateTaxOnServiceLevelDisputeHistory(totalTax, accountingRepo, feeType, orderHierarchy);
                    }
                }
            }
        }

        private void UpdateTaxesOnAccountsReceivableDetailRecords(string productCategoryCode, Dictionary<int, int> workOrderIds, AccountsTax accountsTaxRecord, decimal totalTax)
        {
            accountsTaxRecord.AccountsReceivableDetail.ARStatusType = "RDY2BILL";
            if (productCategoryCode == "INSPECT" || string.IsNullOrEmpty(productCategoryCode))
            {
                accountsTaxRecord.AccountsReceivableDetail.AccountsReceivable.TaxesDue += accountsTaxRecord.TaxAmount;
                accountsTaxRecord.AccountsReceivableDetail.AccountsReceivable.TotalAmountDue =
                    Convert.ToDecimal(accountsTaxRecord.AccountsReceivableDetail.AccountsReceivable.TaxesDue) +
                    Convert.ToDecimal(accountsTaxRecord.AccountsReceivableDetail.AccountsReceivable.SubtotalDue);
            }
            else
            {
                if (accountsTaxRecord.AccountsReceivableDetail.OrderHierarchyId != null)
                {
                    var orderHierarchyId = accountsTaxRecord.AccountsReceivableDetail.OrderHierarchyId.Value;
                    var feeType = "";
                    if (accountsTaxRecord.AccountsReceivableDetail.FeeType != null)
                        feeType = accountsTaxRecord.AccountsReceivableDetail.FeeType.FeeTypeCode;
                    var accountingRepo = new AccountingRepository();
                    DisputeReceivableAdjustmentHistory dispReceivAdjHisRecord;
                    Logging.LogInfo("Vertex Tax Calculation: GetDisputeReceivAdjHisRecordByFeeTypePaymentRef for the OrderHierarchyId - " + accountsTaxRecord.AccountsReceivableDetail.OrderHierarchyId.Value + " when processing the AccountsTax record -" + accountsTaxRecord.ToString() + " begin.");
                    if (feeType == "CLTRF" || feeType == "CLTTF")
                        dispReceivAdjHisRecord = accountingRepo.GetDisputeReceivableHistoryByOrderHierarchyId(orderHierarchyId);
                    else
                        dispReceivAdjHisRecord = accountingRepo.GetDisputeReceivAdjHisRecordByFeeTypePaymentRef(orderHierarchyId, accountsTaxRecord.AccountsReceivableDetail.FeeTypeId, accountsTaxRecord.AccountsReceivableDetail.FeeTypePaymentRefId);
                    Logging.LogInfo("Vertex Tax Calculation: GetDisputeReceivAdjHisRecordByFeeTypePaymentRef for the OrderHierarchyId - " + accountsTaxRecord.AccountsReceivableDetail.OrderHierarchyId.Value + " when processing the AccountsTax record -" + accountsTaxRecord.ToString() + " begin.");
                    if (dispReceivAdjHisRecord != null)
                    {
                        AssignTaxAmountInDisputeReceivableAdjustmentHistory(totalTax, dispReceivAdjHisRecord, feeType);
                        Logging.LogInfo("Vertex Tax Calculation: SaveDisputeReceivableAdjustmentHistory record for the DispHistory record -" + dispReceivAdjHisRecord.DisputeReceivableAdjustmentHistoryId.ToString() + " when processing the AccountsTax record -" + accountsTaxRecord.AccountsTaxId + " begin.");
                        accountingRepo.SaveDisputeReceivableAdjustmentHistory(dispReceivAdjHisRecord);
                        Logging.LogInfo("Vertex Tax Calculation: SaveDisputeReceivableAdjustmentHistory record for the DispHistory record -" + dispReceivAdjHisRecord.DisputeReceivableAdjustmentHistoryId.ToString() + " when processing the AccountsTax record -" + accountsTaxRecord.AccountsTaxId + " end.");
                        var orderHierarchy = accountingRepo.GetOrderHierarchyById(orderHierarchyId);
                        // Check if the current transaction is a LineItem level transaction or not. If yes, then go to the service level transaction's dispute record and update the same tax there as well.
                        if (orderHierarchy.WorkOrderLineItemId != null)
                            UpdateTaxOnServiceLevelDisputeHistory(totalTax, accountingRepo, feeType, orderHierarchy);
                    }
                }
            }
            Logging.LogInfo("Vertex Tax Calculation: Updating Taxes on WorkOrders for the AccountsReceivableDetailId  - " + accountsTaxRecord.AccountsReceivableDetail.ToString() + " begins.");
            UpdateTaxesOnWorkOrders(productCategoryCode, workOrderIds, accountsTaxRecord);
            Logging.LogInfo("Vertex Tax Calculation: Updating Taxes on WorkOrders for the AccountsReceivableDetailId  - " + accountsTaxRecord.AccountsTaxId + " ends.");
        }

        private void AssignTaxAmountInDisputeReceivableAdjustmentHistory(decimal? totalTax, DisputeReceivableAdjustmentHistory disputeReceivableAdjHistory, string feeType)
        {
            switch (feeType)
            {
                case "CLTRF":
                    if (disputeReceivableAdjHistory.ClientRushFeeTax != null)
                        disputeReceivableAdjHistory.ClientRushFeeTax += totalTax;
                    else
                        disputeReceivableAdjHistory.ClientRushFeeTax = totalTax;
                    break;
                case "CLTTF":
                    if (disputeReceivableAdjHistory.ClientTripFeeTax != null)
                        disputeReceivableAdjHistory.ClientTripFeeTax += totalTax;
                    else
                        disputeReceivableAdjHistory.ClientTripFeeTax = totalTax;
                    break;
                default:
                    if (disputeReceivableAdjHistory.ClientPriceTax != null)
                        disputeReceivableAdjHistory.ClientPriceTax += totalTax;
                    else
                        disputeReceivableAdjHistory.ClientPriceTax = totalTax;
                    break;
            }
        }

        private void UpdateTaxOnFinalDisputeHistory(decimal totalTax, AccountingRepository accountingRepo, string feeType, DisputeReceivableAdjustmentHistory disputeReceivableAdjustmentHistory)
        {
            int? feeTypeRefId = disputeReceivableAdjustmentHistory.FeeTypePaymentRefId;


            var finalDisputeRecivableAdjustmentHistory = accountingRepo.GetDispReceivAdjHisRecordsByOrderHierarchyRcrdType(disputeReceivableAdjustmentHistory.OrderHierarchyId, "FINAL", feeTypeRefId);
            AssignTaxAmountInDisputeReceivableAdjustmentHistory(totalTax, finalDisputeRecivableAdjustmentHistory, feeType);
            Logging.LogInfo("Vertex Tax Calculation: SaveDisputeReceivableAdjustmentHistory for FINAL record with the DisputeReceivableHistory Id - " + finalDisputeRecivableAdjustmentHistory.DisputeReceivableAdjustmentHistoryId.ToString() + " begins.");
            accountingRepo.SaveDisputeReceivableAdjustmentHistory(finalDisputeRecivableAdjustmentHistory);
            Logging.LogInfo("Vertex Tax Calculation: SaveDisputeReceivableAdjustmentHistory for FINAL record with the DisputeReceivableHistory Id - " + finalDisputeRecivableAdjustmentHistory.DisputeReceivableAdjustmentHistoryId.ToString() + " ends.");
        }

        private void UpdateTaxOnServiceLevelDisputeHistory(decimal totalTax, AccountingRepository accountingRepo, string feeType, OrderHierarchy orderHierarchy)
        {
            Logging.LogInfo("Vertex Tax Calculation: GetServiceLevelOrderHierarchy for the OrderHierarchy Id - " + orderHierarchy.OrderHierarchyId.ToString() + " begins.");
            var serviceLevelOrderHierarchy = accountingRepo.GetServiceLevelOrderHierarchy(orderHierarchy.OrderId, orderHierarchy.WorkOrderItemId.Value);
            Logging.LogInfo("Vertex Tax Calculation: GetServiceLevelOrderHierarchy for the OrderHierarchy Id -  " + orderHierarchy.OrderHierarchyId.ToString() + " ends.");



            if (serviceLevelOrderHierarchy != null)
            {
                var serviceDisputeReceivableAdjustmentHistory = accountingRepo.GetDisputeReceivableHistoryByOrderHierarchyId(serviceLevelOrderHierarchy.OrderHierarchyId);
                if (serviceDisputeReceivableAdjustmentHistory != null)
                {
                    AssignTaxAmountInDisputeReceivableAdjustmentHistory(totalTax, serviceDisputeReceivableAdjustmentHistory, feeType);
                    Logging.LogInfo("Vertex Tax Calculation: SaveDisputeReceivableAdjustmentHistory at service level for the DisputeReceivableHistory Id - " + serviceDisputeReceivableAdjustmentHistory.DisputeReceivableAdjustmentHistoryId.ToString() + " begins.");
                    accountingRepo.SaveDisputeReceivableAdjustmentHistory(serviceDisputeReceivableAdjustmentHistory);
                    Logging.LogInfo("Vertex Tax Calculation: SaveDisputeReceivableAdjustmentHistory at service level for the DisputeReceivableHistory Id - " + serviceDisputeReceivableAdjustmentHistory.DisputeReceivableAdjustmentHistoryId.ToString() + " ends.");
                }
            }
        }

        private void UpdateTaxesOnWorkOrders(string productCategoryCode, Dictionary<int, int> workOrderIds, AccountsTax accountsTaxRecord)
        {
            var workOrderId = 0;
            if (accountsTaxRecord.AccountsReceivableAdjustment == null && accountsTaxRecord.AccountsReceivableDetail != null)
            {
                if (productCategoryCode == "INSPECT" || string.IsNullOrEmpty(productCategoryCode))
                    workOrderId = Convert.ToInt32(accountsTaxRecord.AccountsReceivableDetail.AccountsReceivable.WorkOrderId);
                else
                    if (workOrderIds.Count > 0)
                        workOrderId = workOrderIds[accountsTaxRecord.AccountsTaxId];

                var woRepo = new TxnDelegate.WorkOrderDelegate();
                if (workOrderId != 0)
                {
                    var workOrder = woRepo.GetWorkOrder(workOrderId);
                    if (workOrder != null)
                    {
                        if (productCategoryCode == "INSPECT" || string.IsNullOrEmpty(productCategoryCode))
                        {
                            workOrder.TotalAmountDue = accountsTaxRecord.AccountsReceivableDetail.AccountsReceivable.TotalAmountDue;
                            workOrder.TaxesDue = accountsTaxRecord.AccountsReceivableDetail.AccountsReceivable.TaxesDue;
                        }
                        else
                        {
                            workOrder.TotalAmountDue = workOrder.TotalAmountDue + accountsTaxRecord.TaxAmount;
                            if (workOrder.TaxesDue != null)
                                workOrder.TaxesDue = workOrder.TaxesDue + accountsTaxRecord.TaxAmount;
                            else
                                workOrder.TaxesDue = accountsTaxRecord.TaxAmount;
                        }
                        woRepo.SaveWorkOrderWithUpdateGraph(workOrder);
                    }
                }
            }
        }


        /// <summary>
        /// This method resolves the workOrderId for an AccountsTax record based on which table is populated, 
        /// i.e AccountsReceivableAdjustment or AccountsReceivableDetail.AccountsReceivable
        /// </summary>
        /// <param name="accountsTax"></param>
        /// <returns>int</returns>
        private int GetWorkOrderID(AccountsTax accountsTax)
        {
            var workOrderId = 0;
            var accountsReceivableDetail = accountsTax.AccountsReceivableDetail;
            var accountsReceivableAdjustment = accountsTax.AccountsReceivableAdjustment;
            if (accountsTax.AccountsReceivableDetailId != 0 && accountsReceivableDetail != null)
            {
                var accountsReceivable = accountsReceivableDetail.AccountsReceivable;
                if (accountsReceivable != null)
                {
                    workOrderId = Convert.ToInt32(accountsReceivable.WorkOrderId);
                }
            }
            else if (accountsTax.AccountsReceivableAdjustmentId != 0 && accountsReceivableAdjustment != null)
            {
                if (accountsReceivableAdjustment.WorkOrderId != 0)
                    workOrderId = Convert.ToInt32(accountsReceivableAdjustment.WorkOrderId);
            }

            return workOrderId;
        }

        /// <summary>
        /// This method returns the applicationID when tenantGuid is passed to the ReferenceService method GetTenantConfigurationDetail.
        /// The service method returns a GetTenantCOnfigurationResponse and 
        /// from that the application that has the highest hierachy order is used to arrive at the application ID.
        /// </summary>
        /// <param name="tenantGuid"></param>
        /// <returns>int</returns>
        private int GetApplicationIdUsingTenantGuidId(string tenantGuid)
        {
            var referenceServiceClient = new RFS.ReferenceServiceProxy();
            var tenantConfigurationResponse = referenceServiceClient.GetTenantConfigurationDetail(tenantGuid);
            var maxHierarchyOrder = tenantConfigurationResponse.TenantConfigurationDetail.TenantApplications.Max(e => e.HierarchyOrder);
            var tenantApplicationId = tenantConfigurationResponse.TenantConfigurationDetail.TenantApplications.
                First(e => e.HierarchyOrder == maxHierarchyOrder).ApplicationId;
            return tenantApplicationId;
        }

        /// <summary>
        /// This method populated the field _dataMappingConfigurations which contains all the 
        /// loantype,investoridentifier mappings for the application and lookup combination. The records are fetched once and stored in the collection and the 
        /// same data is used for all the records in the batch.
        /// </summary>
        /// <param name="applicationID"></param>
        /// <param name="lookUp"></param>
        private void FetchDataMappingConfigurations(int applicationID, string lookUp)
        {
            if (_dataMappingConfigurations == null || !_dataMappingConfigurations.Any())
            {
                var dataMappingRequest = new GetDataMappingConfigRequest { LookUp = lookUp, PageSize = 10000, SkipCount = 0, ApplicationId = 10016, PageNumber = 1 }; // Just to make sure all the records are returned set the PageSize to 10000
                var clientServiceProxy = new ClientServiceProxy();
                var dataMappingResponse = clientServiceProxy.GetDataMappingConfigs(dataMappingRequest);
                _dataMappingConfigurations = dataMappingResponse != null ? dataMappingResponse.DataMappingConfigs : null;
            }
        }

        private void AssignDestination(VS.LineItemISIType lineItem, FSLoanOrderClientDetailsView loanOrderClientDetail)
        {
            var destination = new VS.LocationType();
            if (loanOrderClientDetail.ValidAddress1 != null)
            {
                destination.StreetAddress1 = loanOrderClientDetail.ValidAddress1;
                destination.StreetAddress2 = loanOrderClientDetail.ValidAddress2;
                destination.City = loanOrderClientDetail.ValidCityName;
                destination.MainDivision = loanOrderClientDetail.ValidStateCode;
                if (loanOrderClientDetail.ValidZipPlusFour != null)
                {
                    if (loanOrderClientDetail.ValidZipPlusFour.Trim() != null && loanOrderClientDetail.ValidZipPlusFour.Trim() != "")
                    {
                        try
                        {
                            if (Convert.ToInt32(loanOrderClientDetail.ValidZipPlusFour.Trim()) != 0)
                                destination.PostalCode = loanOrderClientDetail.ValidZipCode + loanOrderClientDetail.ValidZipPlusFour.Trim().PadLeft(4, '0');
                        }
                        catch
                        {
                            destination.PostalCode = loanOrderClientDetail.ValidZipCode;
                        }
                    }
                    else
                        destination.PostalCode = loanOrderClientDetail.ValidZipCode;
                }
                else
                    destination.PostalCode = loanOrderClientDetail.ValidZipCode;
            }
            else
            {
                destination.StreetAddress1 = loanOrderClientDetail.PropertyAddress1;
                destination.StreetAddress2 = loanOrderClientDetail.PropertyAddress2;
                destination.City = loanOrderClientDetail.PropertyCityName;
                destination.MainDivision = loanOrderClientDetail.PropertyStateCode;
                if (loanOrderClientDetail.PropertyZipPlusFour != null)
                {
                    if (loanOrderClientDetail.PropertyZipPlusFour.Trim() != null && loanOrderClientDetail.PropertyZipPlusFour.Trim() != "")
                    {
                        try
                        {
                            if (Convert.ToInt32(loanOrderClientDetail.PropertyZipPlusFour.Trim()) != 0)
                                destination.PostalCode = loanOrderClientDetail.PropertyZipCode + loanOrderClientDetail.PropertyZipPlusFour.Trim().PadLeft(4, '0');
                        }
                        catch
                        {
                            destination.PostalCode = loanOrderClientDetail.PropertyZipCode;
                        }
                    }
                    else
                        destination.PostalCode = loanOrderClientDetail.PropertyZipCode;
                }
                else
                    destination.PostalCode = loanOrderClientDetail.PropertyZipCode;
            }
            lineItem.Customer.Destination = destination;
        }

    }


}
