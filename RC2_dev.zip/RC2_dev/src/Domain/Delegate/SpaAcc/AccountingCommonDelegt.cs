﻿namespace Delegate.SpaAcc
{

    using DataAccess.Accounting;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using DomainModel;
    using DomainModel.Accounting;

    public class AccountingCommonDelegt
    {
        public List<Remittance.SearchResult> GetRemittanceSearchResults(Remittance.SearchRequest searchRequestDao, int? skipCount, int? pageSize, int? PageNumber, out int? TotalRecordCount)
        {
            if (searchRequestDao == null)
                throw new ArgumentNullException("searchRequestDto");
            AccountingRepository obj = new AccountingRepository();
            int? take = (pageSize * 4); //Lets fetch 4 times more than requested, should not have any performance impact fetching whars requested OR fetching 4 times more. (this has been done to do the paging w/o fetching the full count)

            var result = obj.GetRemittanceSearchResults(searchRequestDao, skipCount.Value, take.Value); //TO-DO--> Can be moved to cache.

            TotalRecordCount = result.Count();

            if (TotalRecordCount == 0) return result;

            TotalRecordCount = CommonLib.Util.Utils.GetTotalRecordCount(TotalRecordCount, pageSize, PageNumber);

            return result.OrderBy(item => item.VendorNumber).Take(pageSize.Value).ToList();//return 50 only;        
            //Temp make Client side paging. as SP need modification for Server side paging

        }

        public RRRInvoiceJSONHeader GetRRRInvoiceJSONHeader(int headerId, List<int?> accountsReceivableDetailId)
        {
            return new AccountingRepository().GetRRRInvoiceJSONHeader(headerId, accountsReceivableDetailId);
        }

        //public bool SaveRRRInvoiceHeaderAndDetails(DomainModel.Accounting.RRRInvoiceJSONHeader request)
        //{
        //    return new AccountingRepository().SaveRRRInvoiceHeaderAndDetails(request);
        //}

        //public bool SaveRrrInvoiceDecision(int orderId, string recordStatus)
        //{
        //    return new AccountingRepository().SaveRrrInvoiceDecision(orderId, recordStatus);
        //}

        public List<RRRInvoiceData> GetRRRInvoiceData(int invoiceExportId)
        {
            return new AccountingRepository().GetRRRInvoiceData(invoiceExportId);
        }

        public bool ValidateInvoiceNumber(int orderId, string invoiceNumber)
        {
            return new AccountingRepository().ValidateInvoiceNumber(orderId, invoiceNumber);
        }

        //public bool UpdateRRRInvoiceHeader(int orderId, string recordStatus)
        //{
        //    return new AccountingRepository().UpdateRRRInvoiceHeader(orderId, recordStatus);
        //}

        //public bool UpdateRRRInvoiceDetail(int accReceivableDetailId, string recordStatus, string comments)
        //{
        //    return new AccountingRepository().UpdateRRRInvoiceDetail(accReceivableDetailId, recordStatus, comments);
        //}
        public bool SaveRrrInvoiceDecision(RrrInvoiceDecisionHeader header)
        {
            return new AccountingRepository().SaveRrrInvoiceDecision(header);
        }

        public RRRInvoiceJSONHeader GetRRRInvoiceJSONHeader(int orderId)
        {
            return new AccountingRepository().GetRRRInvoiceJSONHeader(orderId);
        }

        public List<RRRInvoiceJSONDetail> GetRRRInvoiceJSONDetails(List<int?> accRecIds)
        {
            return new AccountingRepository().GetRRRInvoiceJSONDetails(accRecIds);
        }
        public void SaveRRRInvoiceHeader(RRRInvoiceJSONHeader header)
        {
            new AccountingRepository().SaveRRRInvoiceHeader(header);
        }

        public void SaveRRRInvoiceDetailWithTrackingList(List<RRRInvoiceJSONDetail> details)
        {
            new AccountingRepository().SaveRRRInvoiceDetailWithTrackingList(details);
        }

        public void SaveRRRInvoiceDetail(List<RRRInvoiceJSONDetail> details)
        {
            new AccountingRepository().SaveRRRInvoiceDetail(details);
        }

        public List<RRRInvoiceJSONDetail> GetRRRInvoiceJSONDetailsForInsp(int orderId)
        {
          return  new AccountingRepository().GetRRRInvoiceJSONDetailsForInsp(orderId);
        }

        public List<InvoiceDecisionSearchResult> SearchInvoiceDecisions(InvoiceDecisionSearchInput input, int? skipCount, int? pageSize, int? PageNumber, out int? TotalRecordCount)
        {
            if (input == null)
                throw new ArgumentNullException("order");
            AccountingRepository accountingDao = new AccountingRepository();
            int? take = (pageSize.HasValue ? pageSize.Value * 5 : 1000 * 5); //Lets fetch 4 times more than requested, should not have any performance impact fetching whars requested OR fetching 4 times more. (this has been done to do the paging w/o fetching the full count)
            // input.ApplicationId =AppId.Value;

            var result = accountingDao.SearchInvoiceDecisions(input, skipCount.HasValue ? skipCount.Value : (int?)null, take.HasValue ? take.Value : (int?)null); //TO-DO--> Can be moved to cache.

            TotalRecordCount = result.Count();

            if (TotalRecordCount == 0) return result;

            TotalRecordCount = CommonLib.Util.Utils.GetTotalRecordCount(TotalRecordCount, pageSize, PageNumber);

            return result.Take(pageSize.Value).ToList();//return 50 only;
        }

        public bool UpdateRRRHeaderInternalStatus(int rrrHeaderJSOnId, string internalStatus)
        {
            var accountingDao = new AccountingRepository();
            return accountingDao.UpdateRRRHeaderInternalStatus(rrrHeaderJSOnId, internalStatus);
        }

        public RRRInvoiceDecisionDetail GetRRRInvoiceDecisionDetailData(int invoiceJSONHeaderId)
        {
            return new AccountingRepository().GetRRRInvoiceDecisionDetailData(invoiceJSONHeaderId);
        }

        public void SaveRRRInvoiceHeaderTracking(RRRInvoiceHeaderTracking domainModel)
        {
            var accountingDao = new AccountingRepository();
            accountingDao.SaveRRRInvoiceHeaderTracking(domainModel);
        }

        public void SaveInvoiceDecisionTrackingDetails(RRRDecisionInvoiceItemTracking domainModel)
        {            
            new AccountingRepository().SaveInvoiceDecisionTrackingDetails(domainModel);
        }

        public WorkOrderLineItem GetLineItemByAccReceivableDetailId(int accReceivableDetailId)
        {
            return new AccountingRepository().GetLineItemByAccReceivableDetailId(accReceivableDetailId);
        }

        public DateTime? GetPerformedDateByAccRecvDetailId(int accReceivableDetailId, string partnerSystemId)
        {
            return new AccountingRepository().GetPerformedDateByAccRecvDetailId(accReceivableDetailId, partnerSystemId);
        }
    }
}
