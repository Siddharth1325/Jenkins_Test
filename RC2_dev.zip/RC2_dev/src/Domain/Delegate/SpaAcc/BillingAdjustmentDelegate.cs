﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DomainModel;
using DomainModel.Accounting;
using DataAccess.Accounting;


namespace Delegate.SpaAcc
{
    public class BillingAdjustmentDelegate
    {
        #region Account Adjustment Methods


        public AdjustmentDetailResponseDAO GetAdjustmentMainData(int? orderId, string updateGridType)
        {
            if (orderId <= 0)
                return null;

            return new AccountingRepository().GetAdjustmentMainData(orderId, updateGridType);
        }

        public PenaltyMainData GetPenaltyAdjustmentMainData(int orderId)
        {
            if (orderId <= 0)
                return null;

            return new AccountingRepository().GetPenaltyAdjustmentMainData(orderId);
        }

        public List<PenaltyAdjustmentsScoreCard> GetPenaltyAdjustmentsDataForScoreCard(int vendorWorkOrderId)
        {
            if (vendorWorkOrderId <= 0)
                return null;

            return new AccountingRepository().GetPenaltyAdjustmentsDataForScoreCard(vendorWorkOrderId);
        }
        public List<ClientFeeAdjustmentDetail> GetClientFeeAdjustmentDetail(int arAdjustmentHistoryId, int orderHierarchyId)
        {
            if (arAdjustmentHistoryId <= 0) return null;
            return new AccountingRepository().GetClientFeeAdjustmentDetail(arAdjustmentHistoryId, orderHierarchyId);
        }
        public List<VendorFeeAdjustmentDetail> GetVendorFeeAdjustmentDetail(int arAdjustmentHistoryId, int orderHierarchyId)
        {
            if (arAdjustmentHistoryId <= 0) return null;
            return new AccountingRepository().GetVendorFeeAdjustmentDetail(arAdjustmentHistoryId, orderHierarchyId);
        }
        public List<FlatFeeAdjustmentDetail> GetFlatFeeAdjustmentDetail(int arAdjustmentHistoryId, int orderHierarchyId)
        {
            if (arAdjustmentHistoryId <= 0) return null;
            return new AccountingRepository().GetFlatFeeAdjustmentDetail(arAdjustmentHistoryId, orderHierarchyId);
        }
        public List<DiscountAdjustmentDetail> GetDiscountAdjustmentDetail(int arAdjustmentHistoryId, int orderHierarchyId)
        {
            if (arAdjustmentHistoryId <= 0) return null;
            return new AccountingRepository().GetDiscountAdjustmentDetail(arAdjustmentHistoryId, orderHierarchyId);
        }
        public List<LineItemAdjustmentDetail> GetLineItemAdjustmentDetail(int arAdjustmentHistoryId, int orderHierarchyId)
        {
            if (arAdjustmentHistoryId <= 0) return null;
            return new AccountingRepository().GetLineItemAdjustmentDetail(arAdjustmentHistoryId, orderHierarchyId);
        }

        public List<MiscAdjustmentDetail> GetMiscProductAdjustmentDetail(int historyId, int orderHierarchyId, string type, int? feeTypeId, int? feeTypeRefId)
        {
            if (historyId <= 0) return null;
            return new AccountingRepository().GetMiscProductAdjustmentDetail(historyId, orderHierarchyId, type, feeTypeId, feeTypeRefId);
        }

        public List<PenaltyAdjustmentDetail> GetPenaltyAdjustmentDetails(string achievementName, int orderHierarchyId)
        {
            return new AccountingRepository().GetPenaltyAdjustmentDetail(achievementName, orderHierarchyId);
        }

        public List<CronologicalAdjustmentListResponseDAO> GetCronologicalAdjustments(int? orderId)
        {
            if (orderId <= 0)
                return null;

            return new AccountingRepository().GetCronologicalAdjustments(orderId);
        }

        public DisputePayableAdjustmentHistory SaveDisputePayableAdjustmentHistory(DisputePayableAdjustmentHistory disputePayableAdjustmentHistory)
        {
            if (disputePayableAdjustmentHistory == null) return null;

            return new AccountingRepository().SaveDisputePayableAdjustmentHistory(disputePayableAdjustmentHistory);
        }

        public DisputeReceivableAdjustmentHistory SaveDisputeReceivableAdjustmentHistory(DisputeReceivableAdjustmentHistory disputeReceivableAdjustmentHistory)
        {
            if (disputeReceivableAdjustmentHistory == null) return null;

            return new AccountingRepository().SaveDisputeReceivableAdjustmentHistory(disputeReceivableAdjustmentHistory);
        }

        public DisputePenaltyAdjustmentHistory SaveDisputePenaltyAdjustmentHistory(DisputePenaltyAdjustmentHistory disputePenaltyAdjustmentHistory)
        {
            if (disputePenaltyAdjustmentHistory == null) return null;

            return new AccountingRepository().SaveDisputePenaltyAdjustmentHistory(disputePenaltyAdjustmentHistory);
        }

        public DisputePayableAdjustmentHistory GetDisputePayableAdjustmentHistory(int disputePayableAdjustmentHistoryId)
        {
            if (disputePayableAdjustmentHistoryId == 0) return null;

            return new AccountingRepository().GetDisputePayableAdjustmentHistory(disputePayableAdjustmentHistoryId);
        }

        public DisputeReceivableAdjustmentHistory GetDisputeReceivableAdjustmentHistory(int disputeReceivableAdjustmentHistoryId)
        {
            if (disputeReceivableAdjustmentHistoryId == 0) return null;

            return new AccountingRepository().GetDisputeReceivableAdjustmentHistory(disputeReceivableAdjustmentHistoryId);
        }

        public AccountsPayableAdjustment SaveAccountsPayableAdjustment(AccountsPayableAdjustment accountsPayableAdjustment)
        {
            if (accountsPayableAdjustment == null) return null;

            return new AccountingRepository().SaveAccountsPayableAdjustment(accountsPayableAdjustment);
        }

        public AccountsReceivableAdjustment SaveAccountsReceivableAdjustment(AccountsReceivableAdjustment accountsReceivableAdjustment)
        {
            if (accountsReceivableAdjustment == null) return null;

            return new AccountingRepository().SaveAccountsReceivableAdjustment(accountsReceivableAdjustment);
        }

        public PrdSrvMainResponseDAO GetPrdSrvMainData(int? orderhierachyID, string feeType)
        {
            if (orderhierachyID == 0) return null;

            return new AccountingRepository().GetPrdSrvMainData(orderhierachyID, feeType);
        }

        public DisputePayableAdjustmentHistory GetLatestDisputePayableAdjustmentHistory(int orderHierachyId)
        {
            if (orderHierachyId <= 0) return null;
            return new AccountingRepository().GetLatestDisputePayableAdjustmentHistory(orderHierachyId);
        }

        public DisputePayableAdjustmentHistory GetLatestDisputePayableAdjustmentHistory(int orderHierachyId, int? feeTypeId, int? feeTypeRefId)
        {
            if (orderHierachyId <= 0) return null;
            return new AccountingRepository().GetLatestDisputePayableAdjustmentHistory(orderHierachyId, feeTypeId, feeTypeRefId);
        }

        public DisputePayableAdjustmentHistory GetWorkItemPayableAdjustmentHistory(int lineitemOrderHierachyId)
        {
            if (lineitemOrderHierachyId <= 0) return null;
            return new AccountingRepository().GetWorkItemLatestPayableAdjustmentHistory(lineitemOrderHierachyId);
        }

        public DisputeReceivableAdjustmentHistory GetLatestDisputeReceivableAdjustmentHistory(int orderHierachyId)
        {
            if (orderHierachyId <= 0) return null;
            return new AccountingRepository().GetLatestDisputeReceivableAdjustmentHistory(orderHierachyId);
        }
        public DisputeReceivableAdjustmentHistory GetLatestDisputeReceivableAdjustmentHistory(int orderHierachyId, int? feeTypeId, int? feeTypeRefId)
        {
            if (orderHierachyId <= 0) return null;
            return new AccountingRepository().GetLatestDisputeReceivableAdjustmentHistory(orderHierachyId, feeTypeId, feeTypeRefId);
        }

        public DisputeReceivableAdjustmentHistory GetWorkItemLatestReceivableAdjustmentHistory(int lineitemOrderHierachyId)
        {
            if (lineitemOrderHierachyId <= 0) return null;
            return new AccountingRepository().GetWorkItemLatestReceivableAdjustmentHistory(lineitemOrderHierachyId);
        }

        public DisputePenaltyAdjustmentHistory GetDisputePenaltyAdjustmentHistory(int orderHierachyId, string achievementName)
        {
            if (orderHierachyId <= 0) return null;
            return new AccountingRepository().GetDisputePenaltyAdjustmentHistory(orderHierachyId, achievementName);
        }


        public int? GetAccountsReceivableId(string adjustmentType, int orderHierarchyId)
        {
            return new AccountingRepository().GetAccountsReceivableId(adjustmentType, orderHierarchyId);
        }

        public int? GetAccountsPayableId(string adjustmentType, int orderHierarchyId)
        {
            return new AccountingRepository().GetAccountsPayableId(adjustmentType, orderHierarchyId);
        }

        public int? GetAccountPayableInvoiceId(string invoiceNumber)
        {
            return new AccountingRepository().GetAccountPayableInvoiceId(invoiceNumber);
        }

        public int? GetAccountReceivableInvoiceId(string invoiceNumber)
        {
            return new AccountingRepository().GetAccountReceivableInvoiceId(invoiceNumber);
        }

        public int? GetAccountsReceivableByFeeTypeId(int? feeTypeId, int orderHierarchyId, int? feeTypeRefId)
        {
            return new AccountingRepository().GetAccountsReceivableByFeeTypeId(feeTypeId, orderHierarchyId, feeTypeRefId);
        }

        public int? GetAccountsPayableByFeeTypeId(int? feeTypeId, int orderHierarchyId)
        {
            return new AccountingRepository().GetAccountsPayableByFeeTypeId(feeTypeId, orderHierarchyId);
        }

        public List<AdjustmentLineItem> GetLineItemsForWoItem(int woiHierachyId)
        {
            return new AccountingRepository().GetLineItemsForWoItem(woiHierachyId);
        }

        public int GetLastRecordNumber(int orderHierarchyId)
        {
            return new AccountingRepository().GetLastRecordNumber(orderHierarchyId);
        }

        public int GetLastRecordNumber(int orderHierarchyId, int? feeTypeId, int? feeTypeRefId)
        {
            return new AccountingRepository().GetLastRecordNumber(orderHierarchyId, feeTypeId, feeTypeRefId);
        }

        public int GetReceivableLastRecordNumber(int orderHierarchyId)
        {
            return new AccountingRepository().GetReceivableLastRecordNumber(orderHierarchyId);
        }

        public int GetPenaltyLastRecordNumber(int orderHierarchyId, string achievementName)
        {
            return new AccountingRepository().GetPenaltyLastRecordNumber(orderHierarchyId, achievementName);
        }

        public int GetReceivableLastRecordNumber(int orderHierarchyId, int? feeTypeId, int? feeTypeRefId)
        {
            return new AccountingRepository().GetReceivableLastRecordNumber(orderHierarchyId, feeTypeId, feeTypeRefId);
        }

        public string GetProductCategory(int orderHierarchyId)
        {
            return new AccountingRepository().GetProductCategory(orderHierarchyId);
        }

        public bool IsAdjustmentExists(int sourceOrderId)
        {
            return new AccountingRepository().IsAdjustmentExists(sourceOrderId);
        }
        #endregion
    }
}
