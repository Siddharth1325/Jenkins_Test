﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DomainModel.Accounting;
using DataAccess.Accounting;
//using AutoMapper;

namespace Delegate.SpaAcc
{
    public class DynAdmDelegate
    {
       /* public IList<DomainModel.Insp.FormGroup> GetFormGroups(string clientId, string formId)
        {
            InspDao dao = new InspDao();
            return dao.GetFormGroups(clientId, formId);

        }

        public IList<DomainModel.Insp.FormGroup> GetFormGroups(int formId)
        {
            InspDao dao = new InspDao();
            return dao.GetFormGroups(formId);

        }
        public IList<ReferenceDataElement> GetQuestionTypes()
        {
            InspDao dao = new InspDao();
            return dao.GetQuestionTypes();

        }
        public IList<DomainModel.Insp.Form> GetForms(string clientId)
        {
            InspDao dao = new InspDao();
            return dao.GetForms(clientId);
        }
        public IList<ReferenceDataGroup> GetReferenceDataGroups(string groupId)
        {
            InspDao dao = new InspDao();
            return dao.GetReferenceDataGroups(groupId);
        }
        public string GetResponseGroup(string questionId)
        {
            InspDao dao = new InspDao();
            return dao.GetResponseGroup(questionId);
        }
        public bool UpdateQuestion(string questionId, string questionText, string questionType, bool isRequired, string responseMaxLen, string responseGroup)
        {
            InspDao dao = new InspDao();
            bool action = dao.UpdateQuestion(questionId, questionText, questionType, isRequired, responseMaxLen, responseGroup);
            return action;
        }
        public bool InsertQuestion(string clientId, string formId, string groupId, string userId, string questionId, string responseId, string questionText, string questionType, bool isRequired, string responseMaxLen)
        {
            InspDao dao = new InspDao();
            bool action = dao.InsertQuestion(clientId, formId, groupId, userId, questionId, responseId, questionText, questionType, isRequired, responseMaxLen);
            return action;
        }
        public bool DeleteQuestion(string questionId)
        {
            InspDao dao = new InspDao();
            bool action = dao.DeleteQuestion(questionId);
            return action;
        }
        public bool UpdateAnswer(string elementCode, string elementName)
        {
            InspDao dao = new InspDao();
            bool action = dao.UpdateAnswer(elementCode, elementName);
            return action;
        }
        public bool InsertAnswer(string clientId, string formId, string groupId, string userId, string questionId, string elementCode, string elementName)
        {
            InspDao dao = new InspDao();
            bool action = dao.InsertAnswer(clientId, formId, groupId, userId, questionId, elementCode, elementName);
            return action;
        }
        public bool DeleteAnswer(string elementCode)
        {
            InspDao dao = new InspDao();
            bool action = dao.DeleteAnswer(elementCode);
            return action;
        }
        */

    }
}
