﻿using CommonLib;
using CommonLib.Context;
using DataAccess.Accounting;
using DomainModel.Accounting;
using DomainModel.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Delegate
{
    public class DisputeDelegate
    {

        public List<DisputeSearchResult> SearchDispute(DisputeSearchInput input, int? skipCount, int? pageSize, int? PageNumber, out int? TotalRecordCount)
        {
            if (input == null)
                throw new ArgumentNullException("order");
            AccountingRepository accountingDao = new AccountingRepository();
            int? take = (pageSize.HasValue ? pageSize.Value * 5 : 1000 * 5); //Lets fetch 4 times more than requested, should not have any performance impact fetching whars requested OR fetching 4 times more. (this has been done to do the paging w/o fetching the full count)
            // input.ApplicationId =AppId.Value;

            var result = accountingDao.SearchDisputes(input, skipCount.HasValue ? skipCount.Value : (int?)null, take.HasValue ? take.Value : (int?)null); //TO-DO--> Can be moved to cache.

            TotalRecordCount = result.Count();

            if (TotalRecordCount == 0) return result;

            TotalRecordCount = CommonLib.Util.Utils.GetTotalRecordCount(TotalRecordCount, pageSize, PageNumber);

            return result.Take(pageSize.Value).ToList();//return 50 only;
        }

        public AccountingDispute GetAccountingDisputeById(int disputeId)
        {
            AccountingRepository repository = new AccountingRepository();
            return repository.GetAccountingDisputeById(disputeId);
        }

        public AccountingDispute SaveAccountingDispute(AccountingDispute accountingDispute)
        {
            AccountingRepository repository = new AccountingRepository();
            return repository.SaveAccountingDispute(accountingDispute);
        }

        public List<DisputeDocument> GetDisputeDocumentByDisputeId(int disputeId)
        {
            AccountingRepository repository = new AccountingRepository();
            return repository.GetDisputeDocumentByDisputeId(disputeId);
        }

        public DisputeDocument SaveDisputeDocument(DisputeDocument disputeDocument)
        {
            AccountingRepository repository = new AccountingRepository();
            return repository.SaveDisputeDocument(disputeDocument);
        }

        public List<DisputeFollowup> GetDisputeFollowUpByDisputeId(int disputeId)
        {
            AccountingRepository repository = new AccountingRepository();
            return repository.GetDisputeFollowUpByDisputeId(disputeId);
        }

        public DisputeFollowup SaveDisputeFollowup(DisputeFollowup disputeFollowUp)
        {
            AccountingRepository repository = new AccountingRepository();
            return repository.SaveFollowUpDispute(disputeFollowUp);
        }


        public VendorDisputeComment SaveVendorDisputeComments(VendorDisputeComment vendorDisputeComment)
        {
            AccountingRepository repository = new AccountingRepository();
            return repository.SaveVendorDisputeComments(vendorDisputeComment);
        }


        public List<VendorDisputeComment> GetVendorDisputeComment(int accountingDisputeId)
        {
            AccountingRepository repository = new AccountingRepository();
            return repository.GetVendorDisputeComment(accountingDisputeId);
        }

        public IList<int> DeleteVendorComments(IList<int> lstIds)
        {
            AccountingRepository repository = new AccountingRepository();
            return repository.DeleteVendorComments(lstIds);
        }

        public AutoCompleteEmailTemplate GetAutoCompEmailTemplate(string TemplateCode)
        {
            AccountingRepository repository = new AccountingRepository();
            return repository.GetAutoCompEmailTemplate(TemplateCode);
        }
        public List<SupplierDisputeSearchResult> SearchSupplierDisputes(SupplierDisputeSearchInput input, int? skipCount, int? pageSize, int? PageNumber, out int? TotalRecordCount)
        {
            if (input == null)
                throw new ArgumentNullException("order");
            AccountingRepository accountingDao = new AccountingRepository();
            int? take = (pageSize.HasValue ? pageSize.Value * 5 : 1000 * 5); //Lets fetch 4 times more than requested, should not have any performance impact fetching whars requested OR fetching 4 times more. (this has been done to do the paging w/o fetching the full count)
            // input.ApplicationId =AppId.Value;
            var result = accountingDao.SearchSupplierDisputes(input, skipCount.HasValue ? skipCount.Value : (int?)null, take.HasValue ? take.Value : (int?)null);

            TotalRecordCount = result.Count();

            if (TotalRecordCount == 0) return result;

            TotalRecordCount = CommonLib.Util.Utils.GetTotalRecordCount(TotalRecordCount, pageSize, PageNumber);

            return result.Take(pageSize.Value).ToList();//return 50 only;
        }
        public SupplierDispute GetSupplierDisputeById(int disputeId)
        {
            AccountingRepository repository = new AccountingRepository();
            return repository.GetSupplierDisputeById(disputeId);
        }

        public bool DeleteSupplierDisputeDocument(int supplierDisputeDocumentId)
        {

            AccountingRepository repository = new AccountingRepository();
            return repository.DeleteSupplierDisputeDocument(supplierDisputeDocumentId);
        }
        public bool SaveSupplierDispute(SupplierDispute supplierDispute)
        {
            AccountingRepository repository = new AccountingRepository();
            return repository.SaveSupplierDispute(supplierDispute);
        }

        public List<SupplierDisputeDocument> GetSupplierDisputeDocumentByDisputeId(int disputeId)
        {
            AccountingRepository repository = new AccountingRepository();
            return repository.GetSupplierDisputeDocumentByDisputeId(disputeId);
        }

        public bool SaveSupplierDisputeDocument(SupplierDisputeDocument disputeDocument)
        {
            AccountingRepository repository = new AccountingRepository();
            return repository.SaveSupplierDisputeDocument(disputeDocument);
        }

        public List<SupplierDisputeFollowup> GetSupplierDisputeFollowupByDisputeId(int disputeId)
        {
            AccountingRepository repository = new AccountingRepository();
            return repository.GetSupplierDisputeFollowupByDisputeId(disputeId);
        }

        public bool SaveSupplierDisputeFollowup(SupplierDisputeFollowup supplierDisputeFollowup)
        {
            AccountingRepository repository = new AccountingRepository();
            return repository.SaveSupplierDisputeFollowup(supplierDisputeFollowup);
        }
        public List<SupplierDisputeEscalation> GetSupplierDisputeEscalationByDisputeId(int supplierDisputeId)
        {
            AccountingRepository repository = new AccountingRepository();
            return repository.GetSupplierDisputeEscalationByDisputeId(supplierDisputeId);
        }
        public bool SaveSupplierDisputeEscalation(SupplierDisputeEscalation supplierDisputeEscalation)
        {
            AccountingRepository repository = new AccountingRepository();
            return repository.SaveSupplierDisputeEscalation(supplierDisputeEscalation);
        }

        public bool AssignUserToSupplierDisputes(List<int> DisputesIds, int assignUserId)
        {
            // return false;
            return new AccountingRepository().AssignUserToSupplierDisputes(DisputesIds, assignUserId);

        }

        public bool SaveVendorEscalation(SupplierDisputeEscalation model)
        {
            // return false;
            return new AccountingRepository().SaveVendorEscalation(model);

        }
        public List<SupplierDispute> GetRelatedSupplierDispute(int disputeId)
        {
            AccountingRepository repository = new AccountingRepository();
            return repository.GetRelatedSupplierDispute(disputeId);
        }
        public Document GetDocumentById(int documentId)
        {
            AccountingRepository repos = new AccountingRepository();
            return repos.GetDocumentById(documentId);
        }
        public List<DisputeWorkOrderDetail> GetDisputeWorkOrderDetails(int disputeId)
        {
            AccountingRepository repository = new AccountingRepository();
            return repository.GetDisputeWorkOrderDetails(disputeId);
        }

        public List<SupplierConfigurationBulkFile> GetSupplierConfigurationBulkFiles(int vendorId, DateTime? dateFrom, DateTime? dateTo)
        {
            AccountingRepository repository = new AccountingRepository();
            return repository.GetSupplierConfigurationBulkFiles(vendorId, dateFrom, dateTo);
        }

        public List<SupplierDisputeExportLog> GetSupplierDisputeExportLogResults(string bulkId)
        {
            AccountingRepository repository = new AccountingRepository();
            return repository.GetSupplierDisputeExportLogResults(bulkId);
        }



    }

}
