﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DomainModel.Accounting;
using DataAccess;
using CommonLib.Messaging;
using System.Xml;
using System.Xml.XPath;
using System.Xml.Serialization;
using System.IO;
using CommonLib;
namespace Delegate.Insp
{
    [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix")]
    public class BulkOrderIntgDelegate
    {
        //public BulkFile GetBulkOrderFile (String bulkOrderId)
        //{
        //    BulkOrderDao bodao = new BulkOrderDao();
        //    return bodao.GetBulkImportFile(bulkOrderId);
        //}

        /// <summary>
        /// returns the list of file records that match the passed in criterea
        /// </summary>
        /// <param name="clientId">subclient number</param>
        /// <param name="fileTypeEleCde">element type</param>
        /// <param name="startDate">start date</param>
        /// <param name="endDate">end date</param>
        /// <returns></returns>
        public IList<BulkFile> GetBulkOrderFiles(String clientId,string fileTypeEleCde,DateTime startDate,DateTime endDate)
        {
            BulkOrderDao bodao = new BulkOrderDao();
            return bodao.GetBulkImportFiles(clientId,fileTypeEleCde,startDate,endDate);
        }

        public ICollection<BulkOrder> GetBulkOrders(String bulkOrderId)
        {
            BulkOrderDao bodao = new BulkOrderDao();
            return bodao.GetBulkOrders(bulkOrderId);
        }

        public BulkFile SaveBulkOrderfile(BulkFile bulkImport)
        {
            BulkOrderDao bodao = new BulkOrderDao();
            return bodao.SaveBulkImport(bulkImport);
        }


        public BulkOrder SaveBulkOrderfile(BulkOrder bulkOrder)
        {
            BulkOrderDao bodao = new BulkOrderDao();
            return bodao.SaveBulkOrder(bulkOrder);
        }
        /// <summary>
        /// This method assume that we have a namevalue payload 
        /// it process the payload and return a nameValue; 
        /// TODO - Move to common
        /// </summary>
        /// <param name="xmlStringUtf"></param>
        /// <returns></returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1720:IdentifiersShouldNotContainTypeNames", MessageId = "string")]
        public IList<NameValue> GetMessageDataFromNameValuePayload(string xmlStringUtf)
        {
            byte[] encodedString = Encoding.UTF8.GetBytes(xmlStringUtf);

            //// Put the byte array into a stream and rewind it to the beginning
            //MemoryStream ms = new MemoryStream(encodedString);
            //ms.Flush();
            //ms.Position = 0;
            var xmlStr = Encoding.UTF8.GetString(encodedString);
            List<NameValue> returnData = new List<NameValue>();
            XmlDocument xml = new XmlDocument();
            xml.LoadXml(xmlStr);
            String xmlPayloadStr = xml.SelectNodes("/FsmqObject/Payload")[0].InnerText;
            //var serializer = new XmlSerializer(typeof(FsmqNameValuePayload));
           // var reader = new StringReader(xmlPayloadStr);
            //var instance = (FsmqNameValuePayload)serializer.Deserialize(reader);
            xml = new XmlDocument();
            xml.LoadXml(xmlPayloadStr);
            //Payload loaded and then get the namevalue pair.
            //Once we have the xml defined, we can have a xsd to serialize the object
            XmlNodeList xnList = xml.SelectNodes("/FsmqNameValuePayload/Variables/NameValue");
            foreach (XmlNode node in xnList)
            {
                //OrderId and value
                String name = node.SelectSingleNode("./Name").InnerText;
                String value = node.SelectSingleNode("./Value").InnerText;
                NameValue nameVal = new NameValue();
                nameVal.Name = name;
                nameVal.Value = value;
                returnData.Add(nameVal);
            }
            return returnData;
        }

        /// <summary>
        /// Retrieves teh bulk exceptions detail for passed in id
        /// </summary>
        /// <param name="bulkOrderId">bulk identifier</param>
        /// <returns>a list of bulk exceptions</returns>
        public IList<BulkException> GetBulkExceptions(String bulkOrderId)
        {
            Logging.LogDebug(String.Format("Bulk order id is {0}", bulkOrderId));
            BulkOrderDao bodao = new BulkOrderDao();
            return bodao.GetBulkExceptions(bulkOrderId);
        }
    }
}
