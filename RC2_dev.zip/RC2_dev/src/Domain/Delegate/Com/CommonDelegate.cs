﻿using IntCommonSvcLib.Constants;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Delegate.Com
{
    public class CommonDelegate
    {

        public TEntity GetEntityByKeys<TEntity>(TEntity Entity) where TEntity : class, new()
        {
            //new DataAccess.Common.GenericRepo<DataAccess.Accounting.AccountingData>().GetEntityByKeys<WorkOrder>(DomInstance as WorkOrder);

            return new CommonLib.Persistence.GenericRepo<DataAccess.Accounting.AccountingData>().GetEntityByKeys<TEntity>(Entity);
        }
        public object FetchEntityByKeys(object DomInstance)
        {
            //new DataAccess.Common.GenericRepo<DataAccess.Accounting.AccountingData>().GetEntityByKeys<WorkOrder>(DomInstance as WorkOrder);

           // return new DataAccess.Common.GenericRepo<DataAccess.Accounting.AccountingData>().GetEntityByKeys<TEntity>(Entity);

            Type genericType = typeof(CommonLib.Persistence.GenericRepo<DataAccess.Accounting.AccountingData>);

            MethodInfo mi = genericType.GetMethod("GetEntityByKeys");
            MethodInfo miConstructed = mi.MakeGenericMethod(DomInstance.GetType());
            object[] args = { DomInstance };

            return miConstructed.Invoke(new CommonLib.Persistence.GenericRepo<DataAccess.Accounting.AccountingData>(), args);
            
            

        }
        public void Save(object DomInstance)
        {
            Type genericType = typeof(CommonLib.Persistence.GenericRepo<DataAccess.Accounting.AccountingData>);

            MethodInfo mi = genericType.GetMethod(LiteralConstants.GenericInspRepoSaveEntity);
            MethodInfo miConstructed = mi.MakeGenericMethod(DomInstance.GetType());
            object[] args = { DomInstance };

            miConstructed.Invoke(new CommonLib.Persistence.GenericRepo<DataAccess.Accounting.AccountingData>(), args);
            return;
            
        }
    }
}
