﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DomainModel.Common;
using DataAccess.Common;

namespace Delegate.Common
{
    public class AssetDelegate
    {
        public Asset GetAssetDetails(int assetId)
        {
            AssetDao rdao = new AssetDao();
            Asset assetdetails = rdao.GetAsset(assetId, CommonEnums.AssetChild.All);
            return assetdetails;
        }

        public Asset GetAssetDetailsAlone(int assetId)
        {
            AssetDao rdao = new AssetDao();
            Asset assetdetails = rdao.GetAsset(assetId, CommonEnums.AssetChild.None);
            return assetdetails;
        }
        /// <summary>
        /// Saves the asset along with addresses
        /// </summary>
        /// <param name="asset">Asset object</param>
        /// <returns>Updated asset data</returns>
        public Asset SaveAsset(Asset asset)
        {
            if (asset == null) return null;
            AssetDao dao = new AssetDao();
            asset.DwellingTypeGroup = "DTSG";
            var result = dao.SaveAsset(asset, CommonEnums.AssetChild.AssetAddresses);
            return result;
        }

        public Asset GetHeaderDetails(int orderId, int workOrderId)
        {
            AssetDao dao = new AssetDao();
            var result = dao.GetAssetByWorkOrderId(orderId, workOrderId);
            return result;
        }

    }
}
