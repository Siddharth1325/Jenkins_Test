﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccess.Common;
using DomainModel.Common;

namespace Delegate.Common
{
    public class AddressCorrectionDelegate
    {

        public AddressCorrection GetAddressCorrection(int loanId)
        {
            AddressCorrectionDao rdao = new AddressCorrectionDao();
            AddressCorrection addressCorrection = rdao.GetAddressCorretion(loanId);
            return addressCorrection;
        }


        /// <summary>
        /// Saves the asset along with addresses
        /// </summary>
        /// <param name="asset">Asset object</param>
        /// <returns>Updated asset data</returns>
        public AddressCorrection SaveAddressCorrection(AddressCorrection addressCorrection)
        {
            if (addressCorrection == null)
                throw new ArgumentNullException("addressCorrection");

            int? orderId=addressCorrection.OrderId;

            AddressCorrectionDao dao = new AddressCorrectionDao();
            AddressCorrection result = dao.SaveAddressCorrection(addressCorrection);
            if(result !=null)
            { 
            LoanDao loanDao = new LoanDao();
           Loan loan= loanDao.GetLoanbyLoanId(addressCorrection.LoanId, CommonEnums.LoanChild.None);

           loan = loanDao.GetLoan(loan.LoanNumber, loan.SubClientProfileId, CommonEnums.LoanChild.AssetAndOrders);
           if (loan != null)
           {
               loan.ValidAddress1 = addressCorrection.AddressLine1;
               loan.ValidAddress2 = addressCorrection.AddressLine2;
               loan.ValidCityName = addressCorrection.CityName;
               loan.ValidCountyName = addressCorrection.CountyName;
               loan.ValidStateCode = addressCorrection.StateCode;
               loan.ValidZipCode = addressCorrection.ZipCode;

           }
                Order ord = loan.Orders.Where(o=>o.OrderId==orderId).FirstOrDefault();
                if(ord !=null)
                {
                    ord.AddressLine1 = addressCorrection.AddressLine1;
                    ord.AddressLine2 = addressCorrection.AddressLine2;
                    ord.CityName = addressCorrection.CityName;
                    //ord.county = addressCorrection.CountyName;
                    ord.StateCode = addressCorrection.StateCode;
                    ord.ZipCode = addressCorrection.ZipCode;
                    foreach (WorkOrder workOrd in ord.WorkOrders)
                    {
                        workOrd.AddressLine1 = addressCorrection.AddressLine1;
                        workOrd.AddressLine2 = addressCorrection.AddressLine2;
                        workOrd.CityName = addressCorrection.CityName;
                        //ord.county = addressCorrection.CountyName;
                        workOrd.StateCode = addressCorrection.StateCode;
                        workOrd.ZipCode = addressCorrection.ZipCode;
                    }
                }

                loan = loanDao.SaveLoan(loan, CommonEnums.LoanChild.AssetAndOrdersWKOrders);

           

            }

            return result;
        }
    }
}
