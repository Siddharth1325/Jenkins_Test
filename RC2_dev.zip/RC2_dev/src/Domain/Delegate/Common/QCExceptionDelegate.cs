﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccess.Common;
using DomainModel.Common;
using CommonLib;
using DomainModel.InspResult;


namespace Delegate.Common
{
    public class QCExceptionDelegate
    {
        /// <summary>
        /// GetAll QC Exceptions based on work order id
        /// </summary>
        /// <param name="workOrderId"></param>
        /// <returns></returns>
        public WorkOrder GetQCExceptions(int workOrderId)
        {
            QCExceptionDao dao = new QCExceptionDao();
            WorkOrder workOrderDomain = dao.GetQCExceptions(workOrderId);

            return workOrderDomain;
        }

        public IList<DatabaseChangeLog> GetDatabaseChangeLog(string entityId)
        {
            QCExceptionDao dao = new QCExceptionDao();
            return dao.GetDatabaseChangeLog(entityId);
        }

        public IList<Order> GetOrderSummary(int loan)
        {
            QCExceptionDao dao = new QCExceptionDao();
            return dao.GetOrderSummary(loan); 
        }
    }
}
