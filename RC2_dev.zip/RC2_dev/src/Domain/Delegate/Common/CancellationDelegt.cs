﻿using DomainModel.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CommonLib;
using DataAccess.Common;
//using Admin.ServiceProxy;
//using Admin.ServiceProxy.MqService;

namespace Delegate.Common
{
    public class CancellationDelegt
    {
        CancellationDao cancelDao = new CancellationDao();
        public List<Cancellation> SaveCancellationLoan(Loan cancelLoanData, Cancellation inputCancelData)
        {           
            List<Cancellation> data = new List<Cancellation>();
            List<Cancellation> myCancellations = new List<Cancellation>();
            List<Order> ordlist = new List<DomainModel.Common.Order>();
            if (cancelLoanData != null && inputCancelData != null)
            {
                if (cancelLoanData.Orders.Count > 0)
                {
                    ordlist = cancelLoanData.Orders.ToList<Order>();
                    foreach (Order item in ordlist)
                    {

                        Cancellation input = new Cancellation();
                        input.CancelledLoanId = item.LoanId;
                        input.CancelledOrderId = item.OrderId;
                        input.CancellationType = inputCancelData.CancellationType;
                        input.CancellationTypeGroup = inputCancelData.CancellationTypeGroup;
                        input.CancellationReasonType = inputCancelData.CancellationReasonType;
                        input.CancellationReasonGroup = inputCancelData.CancellationReasonGroup;
                        input.CancellationComments = inputCancelData.CancellationComments;

                        myCancellations.Add(input);

                    }
                    data = cancelDao.SaveCancellation(myCancellations);
                    //data = SaveCancellationOrder(myCancellations);
                }
                else
                {
                    Cancellation input = new Cancellation();

                    input.CancelledLoanId = cancelLoanData.LoanId;
                    input.CancellationType = inputCancelData.CancellationType;
                    input.CancellationTypeGroup = inputCancelData.CancellationTypeGroup;
                    input.CancellationReasonType = inputCancelData.CancellationTypeGroup;
                    input.CancellationReasonGroup = inputCancelData.CancellationReasonGroup;
                    input.CancellationComments = inputCancelData.CancellationComments;
                    myCancellations.Add(input);
                    cancelDao.SaveCancellation(myCancellations);
                }

            }

            return data;
        }

        //public List<Cancellation> SaveCancellationOrder(List<Cancellation> myCancellations)
        //{
        //    CancellationDao cancelD = new CancellationDao();

        //    //foreach (Order o in item)--List<Order> item,
        //        //{
        //        //    if (o.WorkOrders.Count > 0)
        //        //    {
        //        //        foreach (WorkOrder wOrders in o.WorkOrders)
        //        //        {
        //        //            //inputs to db save
        //        //            if (wOrders != null)
        //        //            {
        //        //                input.CancelledWorkOrderId = wOrders.WorkOrderId;
        //        //                input.CancelledLoanId = o.LoanId;
        //        //                input.CancelledOrderId = o.OrderId;
        //        //            }
        //        //        }
        //        //    }
        //        //}
        //    cancelD.SaveCancellation(myCancellations);
        //    return myCancellations;
        //}

        public List<Order> GetOderbyLoanId(int loanId)
        {
            CancellationDao dqo = new CancellationDao();
            List<Order> lst = new List<DomainModel.Common.Order>();
            lst = dqo.GetOrders(loanId);

            return lst;
        }

        public List<Order> SetOrderStatusType(int loanId)
        {
            CancellationDao dqo = new CancellationDao();
            List<Order> lst = new List<DomainModel.Common.Order>();
            lst = dqo.SetOrderStatusType(loanId);

            return lst;
        }

        public string MQServiceCall(Loan cancelLoanData, Cancellation inputCancelData)
        {
            return null;
            /*
            //MQ Call
            MqServiceProxy mqProxy = new MqServiceProxy();
            SendRequestToQDto requestDto = new SendRequestToQDto();
            List<NameValue> variables = new List<NameValue>();
            NameValue loan = new NameValue();
            if (cancelLoanData != null && inputCancelData != null)
            {
                loan.Name = "LoanId";
                loan.Value = cancelLoanData.LoanId;
                variables.Add(loan);
                NameValue ord = new NameValue();
                ord.Name = "OrderId";               
                string ordWord = string.Empty;
                foreach (Order val in cancelLoanData.Orders)
                {
                    if (val.WorkOrders.Count > 0)
                    {
                        foreach (WorkOrder wOrd in val.WorkOrders)
                        {
                            ordWord = ordWord + val.OrderId + "," + wOrd.WorkOrderId + "|";
                        }
                    }
                    else
                    {
                        ordWord = ordWord + val.OrderId + "," + "-1" + "|";
                    }                   
                }
                ord.Value = ordWord;
                variables.Add(ord);                
            }
            requestDto.parameters = variables;
            
            requestDto.messageType = MessageTypeEnum.CancelOrder;
            mqProxy.SendRequestToQ(requestDto);
            return "MessageSent";*/
        }
    }
}
