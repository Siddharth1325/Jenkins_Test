﻿using DomainModel.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CommonLib;
using DataAccess.Common;

namespace Delegate.Common
{
    public class LoanDelegate
    {
        /// <summary>
        /// Performs the search on the loan table based on the attributes that are passed
        /// and retuns the list of loans that matches the criterea.
        /// </summary>
        /// <param name="loan">loan object</param>
        /// <returns>returns the loan search results</returns>
        public List<LoanSearch> LoanSearch(LoanSearch loan)
        {
            LoanDao dao = new LoanDao();
            var result = dao.LoanSearch(loan);
            Logging.LogDebug(String.Format("Loan Search returns {0} rows", result == null ? 0 : result.Count));
            return result;
        }

        public List<Loan> LoanSearch(Loan loan)
        {
            LoanDao dao = new LoanDao();
            var result = dao.LoanSearch(loan);
            Logging.LogDebug(String.Format("Loan Search returns {0} rows", result == null ? 0 : result.Count));
            return result;
        }


        /// <summary>
        /// Saves the newly added loan note to database
        /// and retuns the updated row.
        /// </summary>
        /// <param name="loan">loan note object</param>
        /// <returns>returns the new loan note<returns>
        public LoanNote SaveLoanNotes(LoanNote loanNoteObj)
        {
            LoanDao dao = new LoanDao();
            var result = dao.SaveLoanNote(loanNoteObj);
            // Logging.LogDebug(String.Format("LoanNote Search returns {0} rows", result == null ? 0 : result.Count));
            return result;
        }

        /// <summary>
        /// Gets all loan Notes based on loan id passed
        /// </summary>
        /// <param name="loanId">loanid</param>
        /// <returns>returns the list of loan notes<returns>
        public List<LoanNote> GetLoanNotes(int? loanId)
        {
            List<LoanNote> lstLoanNoteList = null;
            LoanDao dao = new LoanDao();
            var result = dao.GetLoanNotes(loanId);
            // Logging.LogDebug(String.Format("LoanNote Search returns {0} rows", result == null ? 0 : result.Count));
            if (result != null && result.LoanNotes != null)
                lstLoanNoteList = result.LoanNotes.ToList<LoanNote>();
            return lstLoanNoteList;
        }

        /// <summary>
        /// Saves the Loan
        /// </summary>
        /// <param name="loan">loan object</param>
        /// <returns>updated loan object</returns>
        public Loan SaveLoan(Loan loan)
        {
            Loan result = null;
            LoanDao dao = new LoanDao();
            //Todo to generalize this
            if (loan != null)
            {
                Loan data = this.GetLoan(loan.LoanNumber, loan.SubClientProfileId);
                if (data != null)
                {
                    data.BorrowerFirstName = loan.BorrowerFirstName;
                    data.BorrowerLastName = loan.BorrowerLastName;
                    data.BorrowerMiddleInitial = loan.BorrowerMiddleInitial;
                    data.EligibleOccupancyGroup = loan.EligibleOccupancyGroup;
                    data.EligibleOccupancyType = loan.EligibleOccupancyType;
                    data.PropAddress1 = loan.PropAddress1;
                    data.PropAddress2 = loan.PropAddress2;
                    data.PropCityName = loan.PropCityName;
                    data.PropStateCode = loan.PropStateCode;
                    data.PropZipCode = loan.PropZipCode;
                    data.ValidAddress1 = loan.ValidAddress1;
                    data.ValidAddress2 = loan.ValidAddress2;
                    data.ValidCityName = loan.ValidCityName;
                    data.ValidStateCode = loan.ValidStateCode;
                    data.ValidZipCode = loan.ValidZipCode;

                    data.LoanStatus = loan.LoanStatus;
                    data.LoanStatusGroup = "LOSTA";
                    data.LoanTypeGroup = "LOAN";
                    data.LoanType = loan.LoanType;
                    data.NonStandardFreqReason = loan.NonStandardFreqReason;
                    data.IsCeaseAndDesist = loan.IsCeaseAndDesist;
                    data.IsNonStandardFrequent = loan.IsNonStandardFrequent;
                    data.CeaseAndDesistReason = loan.CeaseAndDesistReason;
                    result = dao.SaveLoan(data, CommonEnums.LoanChild.None);
                    if (loan.Asset != null)
                    {
                        AssetDao asstdao = new AssetDao();
                        Asset asset = asstdao.GetAsset((int)loan.AssetId, CommonEnums.AssetChild.AssetAddresses);
                        if (asset != null)
                        {
                            asset.DwellingType = loan.Asset.DwellingType;
                            asset.DwellingTypeGroup = loan.Asset.DwellingTypeGroup;
                            asset.DoorKeyCode = loan.Asset.DoorKeyCode;
                            asset.LockBoxCode = loan.Asset.LockBoxCode;
                            asset.Longitude = loan.Asset.Longitude;
                            asset.Latitude = loan.Asset.Latitude;
                            asset.LastGrassCutDate = loan.Asset.LastGrassCutDate;
                            asset.LastSecureDate = loan.Asset.LastSecureDate;
                            asset.LastOccupancyDate = loan.Asset.LastOccupancyDate;
                            asset.IsDoNotApproach = loan.Asset.IsDoNotApproach;
                            asset.DoNotApproachReason = loan.Asset.DoNotApproachReason;
                            asset.WinterizationDate = loan.Asset.WinterizationDate;
                            //TODO filter on correct address once the common service is fixed.
                            if (asset.AssetAddresses != null && asset.AssetAddresses.Count > 0 && loan.Asset.AssetAddresses != null && loan.Asset.AssetAddresses.Count > 0)
                            {
                                AssetAddress corrAdd = loan.Asset.AssetAddresses.Where(ad => ad.AddressType == "CORRECT").Where(ac => ac.IsValid == true).FirstOrDefault();
                                AssetAddress Addr = asset.AssetAddresses.Where(s => s.AssetAddressId == corrAdd.AssetAddressId).FirstOrDefault();
                                Addr.AddressLine1 = corrAdd.AddressLine1;
                                Addr.AddressLine2 = corrAdd.AddressLine2;
                                Addr.CityName = corrAdd.CityName;
                                Addr.StateCode = corrAdd.StateCode;
                                Addr.ZipCode = corrAdd.ZipCode;

                            }
                            asstdao.SaveAsset(asset, CommonEnums.AssetChild.AssetAddresses);
                        }

                    }

                }
                else
                    result = dao.SaveLoan(loan, CommonEnums.LoanChild.None);


            }
            return result;
        }
        /// <summary>
        /// Retrieves the loan information
        /// </summary>
        /// <param name="loanNumber">loan number </param>
        /// <returns>returns a loan object for given loan number</returns>
        public Loan GetLoan(string loanNumber, int? subclientId)
        {
            LoanDao dao = new LoanDao();
            Loan result = dao.GetLoan(loanNumber, (int)subclientId, CommonEnums.LoanChild.AssetAndOrders);
            if (result != null)
            {
                AddressCorrectionDao rdao = new AddressCorrectionDao();
                AddressCorrection addressCorrection = rdao.GetAddressCorretion(result.LoanId);
                if (addressCorrection != null)
                {
                    result.AddressCorrections = new List<AddressCorrection>();
                    result.AddressCorrections.Add(addressCorrection);
                }
            }
            //Logging.LogDebug(String.Format("Is loan data retrieved for loan number {0} and subclient {1} ? {2}", loanNumber, subclientId, result != null));
            return result;
        }

        public Loan GetLoanbyLoanId(int? loanid)
        {
            LoanDao dao = new LoanDao();
            var result = dao.GetLoanbyLoanId(loanid, CommonEnums.LoanChild.None);
            return result;
        }

        public Loan GetLoanbyLoanOrders(string loanno)
        {
            LoanDao dao = new LoanDao();
            Loan result = dao.GetLoan(loanno, 0, CommonEnums.LoanChild.AssetAndOrders);
            return result;
        }

        public Loan SaveLoanOrderChild(Loan req)
        {
            LoanDao loanData = new LoanDao();
            if (req != null)
            {
                loanData.SaveLoan(req, CommonEnums.LoanChild.AssetAndOrders);
            }
            return null;

        }

        /// <summary>
        /// Retrievies the loan data for the passed in ovl id
        /// </summary>
        /// <param name="ovlId">Occupancy Verification Letter Identifier</param>
        /// <returns>loan data</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1709:IdentifiersShouldBeCasedCorrectly", MessageId = "OVL"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA2204:Literals should be spelled correctly", MessageId = "GetLoanbyOVLId-OVL")]
        public Loan GetLoanbyOVLId(int ovlId)
        {
            Logging.LogDebug(string.Format("GetLoanbyOVLId-OVL id is {0}", ovlId));
            Loan loan = null;
            InspectionDao insp = new InspectionDao();
            InspectionOrderDetail inspdtl = insp.GetInspectionOrderbyOvlId(ovlId);
            if (inspdtl != null)
            {
                Order ordr = new OrderDao().GetOrder(inspdtl.OrderId, CommonEnums.OrderChild.None);
                if (ordr != null)
                {
                    loan = new LoanDao().GetLoanById((int)ordr.LoanId, CommonEnums.LoanChild.None);
                    loan.Orders = new List<Order>(); loan.Orders.Add(ordr);
                }
            }
            return loan;
        }
    }
}
