﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccess.Accounting;
using DomainModel.Accounting;
using CommonLib;
using System.Runtime.Serialization;
namespace Delegate.Common
{
    public class OrderDelegate
    {

        /// <summary>
        /// Performs the search on the loan table based on the attributes that are passed
        /// and retuns the list of loans that matches the criterea.
        /// </summary>
        /// <param name="loan">loan object</param>
        /// <returns>returns the loan search results</returns>
     /*   public List<OrderSearch> SearchOrders(OrderSearch order)
        {
            if (order == null)
                throw new ArgumentNullException("order");
            OrderDao dao = new OrderDao();
            var result = dao.SearchOrders(order);
            Logging.LogDebug(String.Format("Order Search returns {0} rows", result == null ? 0 : result.Count));
            return result;
        }

        //public Order SaveOrder(Order order, CommonEnums.OrderChild orderChildEnum)
        public Loan SaveLoanOrder(Loan loan)
        {
            if (loan == null)
                throw new ArgumentNullException("loan");

            Loan returnLoan = new Loan();
            Order savedOrder = null; ;
            OrderDao orderDao = new OrderDao();
            WorkOrderItem woItem = null;
            WorkOrder woRet = null;


            #region Default Values
            //loan.LoanTypeGroup = "LOAN";
            loan.LoanStatusGroup = "LOSTA";
            loan.LoanStatus = "ACTIVE";
            #endregion

            #region Loan Validation
            //For a give loan, get me the loanObject            
            LoanDao loanDao = new LoanDao();
            //Loan Exists?
            Loan tempLoan = loanDao.GetLoan(loan.LoanNumber, loan.SubClientProfileId, CommonEnums.LoanChild.None);

            if (tempLoan == null)
            {   //Loan doesn't exists
                //Save Loan
                returnLoan = loanDao.SaveLoan(loan, CommonEnums.LoanChild.None);
                loan.Orders.LastOrDefault().LoanId = returnLoan.LoanId;
            }
            else
            {
                //Loan Exists
                loan.Orders.LastOrDefault().LoanId = tempLoan.LoanId;
            }
            #endregion

            #region Loan Prop
            loan.Orders.LastOrDefault().Loan = returnLoan;

            loan.Orders.LastOrDefault().OrderTypeGroup = "LOAN";
            loan.Orders.LastOrDefault().OrderType = "UNINS";

            loan.Orders.LastOrDefault().OrderStatusGroup = "ORSTA";
            loan.Orders.LastOrDefault().OrderStatusType = "ACTIVE";
            loan.Orders.LastOrDefault().LOBTypeGroup = "PRDCT";

            loan.Orders.LastOrDefault().BorrowerFirstName = loan.BorrowerFirstName;
            loan.Orders.LastOrDefault().BorrowerLastName = loan.BorrowerLastName;
            loan.Orders.LastOrDefault().BorrowerMiddleInitial = loan.BorrowerMiddleInitial;

            loan.Orders.LastOrDefault().AddressLine1 = loan.PropAddress1;
            loan.Orders.LastOrDefault().AddressLine2 = loan.PropAddress2;

            loan.Orders.LastOrDefault().RequestedDate = DateTime.Now;

            loan.Orders.LastOrDefault().CityName = loan.PropCityName;
            loan.Orders.LastOrDefault().StateCode = loan.PropStateCode;
            loan.Orders.LastOrDefault().ZipCode = loan.PropZipCode;

            loan.Orders.LastOrDefault().OrderSourceGroup = "ORSRC";
            loan.Orders.LastOrDefault().OrderSourceType = "CLIENT";



            #endregion

            #region validation for service
            //TODO 
            //validate Order Details-------------------------------------------------------------
            //Call the service to get service Id------------------------
            //if (loan.Orders.LastOrDefault().OrderedProductId.HasValue)
            //{
            //    GetServicesByProductIdRequestDto requestbyID = new GetServicesByProductIdRequestDto();
            //    requestbyID.ProductId = loan.Orders.LastOrDefault().OrderedProductId.Value;
            //    GetServicesByProductIdResponseDto response = new GetServicesByProductIdResponseDto();                
            //    using (ProductServiceClient svc = new ProductServiceClient())
            //    {
            //        response = svc.GetServicesByProductId();
            //    }
            //}

            #endregion

            //Call Bejoy Service----------------------------------------
            if (loan.Orders.LastOrDefault().InspectionOrderDetail != null
                && loan.Orders.LastOrDefault().InspectionOrderDetail.SaleDate != null)
            {
                savedOrder = orderDao.SaveOrder(loan.Orders.LastOrDefault(), CommonEnums.OrderChild.All);
            }
            else if (loan.Orders.LastOrDefault().InspectionOrderDetail != null
                && loan.Orders.LastOrDefault().InspectionOrderDetail.OVLId != -1)
            {
                // InsuranceLossDamage toMap = new InsuranceLossDamage();
                // toMap = loan.Orders.LastOrDefault().InspectionOrderDetail.InsuranceLossDamages.LastOrDefault();
                //  toMap.InspectionOrderId = savedOrder.OrderId;
                loan.Orders.LastOrDefault().InspectionOrderDetail.InsuranceLossDamages.LastOrDefault().DamageTypeGroup = "DMTYP";
                // var temp = orderDao.SaveInsuranceDamageLoss(toMap);
                savedOrder = orderDao.SaveOrder(loan.Orders.LastOrDefault(), CommonEnums.OrderChild.InspectionOrderDetailAndInsuranceLossDamage);
            }
            else
            {
                savedOrder = orderDao.SaveOrder(loan.Orders.LastOrDefault(), CommonEnums.OrderChild.None);

            }
            //Need to pass the workorderid. 
            SendRequestToCreateOrderQ(savedOrder.OrderId, 0);
            returnLoan.Orders.Add(savedOrder);

            ProductServiceProxy prodsrv = new ProductServiceProxy();
            GetServicesByProductIdResponse serdto;

            serdto = prodsrv.GetServicesByProductId(savedOrder.OrderedProductId);





            ////try
            ////{

            ////    serdto = prodsrv.GetServicesByProductId(savedOrder.OrderedProductId);
            ////    toMap = loan.Orders.LastOrDefault().InspectionOrderDetail.InsuranceLossDamages.LastOrDefault();
            ////    toMap.InspectionOrderId = savedOrder.OrderId;
            ////    toMap.DamageTypeGroup = "LOAN";
            ////    if (toMap.DamageType == null || toMap.DamageType == string.Empty)
            ////        toMap.DamageType = "CONV";
            ////    var temp = orderDao.SaveInsuranceDamageLoss(toMap);
            ////}
            ////catch (Exception ex)
            ////{

            ////    throw;
            ////}

            foreach (var ps in serdto.ServiceList)
            {
                if (ps.ServiceId > 0)
                {
                    WorkOrderItem item = new WorkOrderItem();
                    item.ServiceId = ps.ServiceId;
                    item.OrderId = savedOrder.OrderId;
                    //item.WorkOrderItemStatusGroup = "WISTA";
                    // item.WorkOrderItemStatusGroup = "ACTIVE";
                    woItem = WorkOrderDao.SaveWorkOrderItem(item);

                    if (woItem != null && savedOrder != null)
                    {
                        #region Work Order Detail
                        WorkOrder wo = new WorkOrder();
                        wo.OrderId = woItem.OrderId;
                        wo.WorkOrderStatusGroup = "WOSTA";
                        wo.WorkOrderStatusType = "ACTIVE";
                        //wo.AssignedVendorId = 1;
                        wo.RequestedDate = DateTime.Now;
                        wo.DueToClientDate = wo.RequestedDate.AddDays(4);
                        wo.DueFromVendorDate = wo.RequestedDate.AddDays(2);
                        wo.BorrowerFirstName = savedOrder.BorrowerFirstName;
                        wo.BorrowerMiddleInitial = savedOrder.BorrowerMiddleInitial;
                        wo.BorrowerLastName = savedOrder.BorrowerLastName;
                        wo.AddressLine1 = savedOrder.AddressLine1;
                        wo.AddressLine2 = savedOrder.AddressLine2;
                        wo.CityName = savedOrder.CityName;
                        wo.StateCode = savedOrder.StateCode;
                        wo.ZipCode = savedOrder.ZipCode;
                        wo.ProductId = savedOrder.OrderedProductId;
                        WorkOrderDao woDao = new WorkOrderDao();
                        woRet = woDao.SaveWorkOrder(wo, CommonEnums.WorkOrderChild.None);
                        woItem.WorkOrderId = woRet.WorkOrderId;
                        woItem.ProductId = savedOrder.OrderedProductId;
                        WorkOrderDao.SaveWorkOrderItem(woItem);
                        #endregion
                    }
                }
            }

            return returnLoan;
        }

        public Order GetOrderDetails(int orderId)
        {
            OrderDao rdao = new OrderDao();
            Order orderdetil = new Order();
            orderdetil = rdao.GetOrder(orderId, CommonEnums.OrderChild.InspectionOrderDetail);
            return orderdetil;
        }

        public Order GetOrderDetails(int orderId, CommonEnums.OrderChild orderChild)
        {
            OrderDao rdao = new OrderDao();
            Order orderdetil = new Order();
            orderdetil = rdao.GetOrder(orderId, orderChild);
            return orderdetil;
        }

        public Loan GetLoanDetails(int loanId)
        {
            LoanDao rdao = new LoanDao();
            Loan loandetil = new Loan();
            loandetil = rdao.GetLoanById(loanId, CommonEnums.LoanChild.None);
            return loandetil;
        }
        public List<GenericOrderDetailGrid> GetOrderGridDetails(int orderId)
        {
            OrderDao rdao = new OrderDao();
            List<GenericOrderDetailGrid> Griddetil = new List<GenericOrderDetailGrid>();
            Griddetil = rdao.GetOrderDetails(orderId);
            return Griddetil;
        }

        //public List<ProductService> GetProductService(int ProdId)
        //{
        //    OrderDao rdao = new OrderDao();
        //    List<ProductService> Griddetil = new List<ProductService>();
        //    Griddetil = rdao.GetProductService(ProdId);
        //    return Griddetil;
        //}
        public Document SaveDocument(Document document)
        {
            OrderDao order = new OrderDao();

            return order.SaveDocument(document);
        }
        public Document DeleteDocument(Document document)
        {
            OrderDao order = new OrderDao();

            return order.DeleteDocument(document);
        }


        public void SendRequestToCreateOrderQ(int orderId, int workOrderId)
        {
            MqServiceProxy mqProxy = new MqServiceProxy();
            SendRequestToQDto requestDto = new SendRequestToQDto();
            List<NameValue> variables = new List<NameValue>();
            NameValue one = new NameValue();
            one.Name = "OrderId";
            one.Value = orderId;
            variables.Add(one);
            NameValue two = new NameValue();
            two.Name = "ProcessName";
            two.Value = "INSPECTIONS";
            variables.Add(two);
            NameValue three = new NameValue();
            three.Name = "WorkOrderId";
            three.Value = workOrderId;
            variables.Add(three);
            requestDto.parameters = variables;
            requestDto.messageType = MessageTypeEnum.CreateOrder;
            mqProxy.SendRequestToQ(requestDto);
        }

        public List<OrderNote> GetOrderNotes(int orderId)
        {
            OrderDao rdao = new OrderDao();
            Order orderObj = new Order();
            orderObj = rdao.GetOrder(orderId, CommonEnums.OrderChild.Notes);
            Logging.LogDebug(String.Format("Order Id : {0} has notes ? {1}", orderId, orderObj != null));
            return orderObj == null ? null : orderObj.OrderNotes.ToList<OrderNote>(); ;
        }

        public OrderNote SaveOrderNote(OrderNote orderNoteObj)
        {
            OrderDao dao = new OrderDao();
            var result = dao.SaveOrderNote(orderNoteObj);
            // Logging.LogDebug(String.Format("LoanNote Search returns {0} rows", result == null ? 0 : result.Count));
            return result;
        }
        public IList<OrderDocument> GetOrderDocument(OrderDocument orderDocument)
        {
            if (orderDocument == null) throw new ArgumentNullException("orderDocument");
            OrderDao dao = new OrderDao();

            var result = dao.GetOrderDocument(orderDocument);

            return result;
        }
        public IList<OrderDocument> SaveOrderDocument(OrderDocument orderDocument)
        {
            if (orderDocument == null) throw new ArgumentNullException("orderDocument");
            OrderDao dao = new OrderDao();
            orderDocument.Document.DocTypeGroup = "DOC";
            orderDocument = dao.SaveOrderDocument(orderDocument);

            return dao.GetOrderDocument(orderDocument);
        }
        public IList<OrderDocument> SaveOrderDocument(IList<OrderDocument> lstOrderDocument)
        {
            if (lstOrderDocument == null || lstOrderDocument.Count == 0) throw new ArgumentNullException("lstOrderDocument");
            OrderDocument result = new OrderDocument();
            OrderDao dao = new OrderDao();
            foreach (OrderDocument orderDocument in lstOrderDocument)
            {

                orderDocument.Document.DocTypeGroup = "DOC";
                result = dao.SaveOrderDocument(orderDocument);
            }

            return dao.GetOrderDocument(result);
        }

        public IList<OrderDocument> DeleteOrderDocument(IList<OrderDocument> listOrderDocument)
        {
            OrderDao dao = new OrderDao();

            OrderDocument orderDocument = dao.DeleteOrderDocument(listOrderDocument);

            return dao.GetOrderDocument(orderDocument);


        }


        /// <summary>
        /// Returns a list of loans and orders that are seemed to be duplicates.
        /// </summary>
        /// <param name="OrderId">Order Identifier</param>
        /// <returns>List of Loans and Orders</returns>
        public IList<Loan> GetDuplicateOrders(int order)
        {
            Logging.LogDebug(String.Format("Duplicate Order Id is {0}", order));

            OrderDao dao = new OrderDao();
            Order dtl = dao.GetOrder(order, CommonEnums.OrderChild.Loan);
            if (dtl == null) return null;

            if (dtl.Loan != null)
            {
                LoanDao loandao = new LoanDao();
                return loandao.GetLoansbyAssetId((int)dtl.Loan.AssetId, CommonEnums.LoanChild.Orders);
            }

            return new List<Loan>();
        }

        /// <summary>
        /// Updates duplicate orders and push to MQ
        /// </summary>
        /// <param name="orders">list of orders to be updated</param>
        public void UpdateDuplicateOrders(IList<Order> orders)
        {
            if (orders == null || orders.Count == 0) return;
            OrderDao dao = new OrderDao();
            Order dtl = null;
            foreach (Order ord in orders)
            {
                dtl = dao.GetOrder(ord.OrderId, CommonEnums.OrderChild.Loan);
                if (dtl != null)
                {
                    dtl.OrderStatusGroup = ord.OrderStatusGroup;
                    dtl.OrderStatusType = ord.OrderStatusType;
                    dtl.LastUpdatedById = ord.LastUpdatedById;
                    dtl.LastUpdatedDate = ord.LastUpdatedDate;
                    dao.SaveOrder(dtl, CommonEnums.OrderChild.None);
                }
            }

            //TODO MQ call
            //MqServiceProxy mqProxy = new MqServiceProxy();
            //SendRequestToQDto request = new SendRequestToQDto();
            //List<NameValue> data = new List<NameValue>();
            //request.messageType=
            //mqProxy.SendRequestToQ(request);
        }

        /// <summary>
        /// pdate the AppointmentDate for one InspectionOrderDetail
        /// </summary>
        /// <param name="inspectionOrderDetail">InspectionOrderDetail with new dates</param>
        /// <returns>InspectionOrderDetail updated</returns>
        public InspectionOrderDetail UpdateAppointmentDate(InspectionOrderDetail inspectionOrderDetail)
        {
            InspectionOrderDetail returnedValue = new InspectionOrderDetail();
            OrderDao orderDao = new OrderDao();
            returnedValue = orderDao.UpdateAppointmentDate(inspectionOrderDetail);
            return returnedValue;
        }

        /// <summary>
        /// update the due date of the order
        /// </summary>
        /// <param name="inspectionOrderDetail">order details with new date</param>
        /// <returns>order updated</returns>
        public Order SaveOrder(Order order)
        {
            Order returnedValue = new Order();
            OrderDao orderDao = new OrderDao();
            returnedValue = orderDao.SaveOrder(order, CommonEnums.OrderChild.None);
            return returnedValue;
        }
      * */
    }
}
