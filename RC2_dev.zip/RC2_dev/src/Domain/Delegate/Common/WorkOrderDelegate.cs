﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccess.Common;
using DomainModel.Common;
using CommonLib;
using DomainModel.InspResult;


namespace Delegate.Common
{
    public class WorkOrderDelegate
    {

        /// <summary>
        /// Retrieves the workorder based on workorder Id
        /// </summary>
        /// <param name="WorkOrderId">workorder Id</param>
        /// <returns>Workorder object</returns>
        public WorkOrder GetWorkOrder(int WorkOrderId)
        {
            WorkOrderDao dao = new WorkOrderDao();
            var result = dao.GetWorkOrder(WorkOrderId, CommonEnums.WorkOrderChild.None);
            return result;
        }

        /// <summary>
        /// Saves the workorder
        /// </summary>
        /// <param name="workorder">workorder object</param>
        /// <returns>returns the saved data</returns>
        public WorkOrder SaveWorkOrder(WorkOrder workorder)
        {
            WorkOrderDao dao = new WorkOrderDao();
            var result = dao.SaveWorkOrder(workorder, CommonEnums.WorkOrderChild.All);
            return result;
        }



        /// <summary>
        /// Saves the workorder note
        /// </summary>
        /// <param name="note">note object</param>
        /// <returns>updated note data</returns>
        public WorkOrderNote SaveWorkOrderNote(WorkOrderNote note)
        {
            WorkOrderDao dao = new WorkOrderDao();
            var result = dao.SaveWorkOrderNote(note);
            return result;
        }


        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public WorkOrderNote GetWorkOrderNote(int workordernoteId)
        {
            //WorkOrderDao dao = new WorkOrderDao();
            
            return null;
        }


        public List<WorkOrderNote> GetWorkOrderNotes(int workorderId)
        {
            WorkOrderDao dao = new WorkOrderDao();
            WorkOrder ordr = dao.GetWorkOrder(workorderId, CommonEnums.WorkOrderChild.Notes);
            if (ordr.WorkOrderNotes == null) return new List<WorkOrderNote>();
            return ordr.WorkOrderNotes.ToList<WorkOrderNote>();
        }

        public List<WorkOrder> GetWorkOrdersList(int assignedVendorId)
        {
            WorkOrderDao rdao = new WorkOrderDao();
            List<WorkOrder> wOrd = new List<WorkOrder>();
            List<WorkOrder> resWo = new List<WorkOrder>();
            wOrd = rdao.GetWordOrdersLst(assignedVendorId);
            foreach (WorkOrder orditem in wOrd)
            {
                if (orditem.Product.LineOfBusinessType == "INSPECT")
                {
                    resWo.Add(orditem);
                }
            }
            return resWo;
        }
    }
}
