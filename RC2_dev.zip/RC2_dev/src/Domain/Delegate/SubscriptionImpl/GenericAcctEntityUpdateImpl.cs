﻿using CommonLib;
using CommonLib.Messaging.Ict;
using CommonLib.Util;
using DomainModel.Accounting;
using IntCommonSvcLib.Constants;
using IntCommonSvcLib.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Platform.Acct.IntegrationBusinessSvcImpl
{

    // This is responsible to save all the Subscription Entities such as WorkOrder/Order/Aset/Loan.
    //We can write specific Impl also if we need to.
    public class GenericAcctEntityUpdateImpl : ActionBase
    {
        public GenericAcctEntityUpdateImpl()
        { }
        
        private string _DestType;
        public override void Init(IContext ActionCtx)
        {
            _DestType = ActionCtx.Context.ContextInfo[LiteralConstants.DestType].ToString();


        }
        public override void Execute(IContext MessageCtx)
        {
            while (true)
            {
                Type DestType = RelectionUtils.GetClassType(_DestType);

                var DomInstance = InstanceHelper.GetInstance<DomainModel.BaseDomainModel>(DestType);


                EntityUpdate EntityUpdateDto = null;

                if (MessageCtx.Context.ContextInfo.ContainsKey(typeof(EntityUpdate).Name))
                {
                    EntityUpdateDto = MessageCtx.Context.ContextInfo[typeof(EntityUpdate).Name] as EntityUpdate;
                }
                if (EntityUpdateDto == null)
                {
                    EntityUpdateDto = RelectionUtils.GetObjectFromXml<CommonLib.Messaging.Ict.EntityUpdate>(MessageCtx.Context.PayLoad);
                }

                //map
                base.Map<CommonLib.Messaging.Ict.EntityUpdate, DomainModel.BaseDomainModel>(EntityUpdateDto, DomInstance, MessageCtx);

                //Try to look up the Record by Id.
                int Pk = (int)DomInstance.GetType().GetProperty(DomInstance.GetType().Name + LiteralConstants.Id).GetValue(DomInstance);

                var ExistingEntity = new DataAccess.Common.GenericRepo<DataAccess.Accounting.AccountingData>().GetEntityByKeys<WorkOrder>(DomInstance as WorkOrder);

                if (ExistingEntity != null)
                {
                    if (base.IsLatestUpdated(ExistingEntity as DomainModel.BaseDomainModel, DomInstance as DomainModel.BaseDomainModel)) { return; } // If latest updates are already applied, exit.

                    byte[] version = (byte[])ExistingEntity.GetType().GetProperty(LiteralConstants.Version).GetValue(ExistingEntity);

                    DomInstance.GetType().GetProperty(LiteralConstants.Version).SetValue(DomInstance, version);

                    base.SimpleMap<DomainModel.BaseDomainModel, DomainModel.BaseDomainModel>(ExistingEntity as DomainModel.BaseDomainModel, DomInstance as DomainModel.BaseDomainModel, MessageCtx);

                }


                //Type genericType = typeof(DataAccess.Common.GenericRepo<DataAccess.AdmDao.SubscriptionContext>);

                //MethodInfo mi = genericType.GetMethod(LiteralConstants.GenericInspRepoSaveEntity);
                //MethodInfo miConstructed = mi.MakeGenericMethod(DestType);
                //object[] args = { DomInstance };
                //try
                //{
                //    miConstructed.Invoke(new DataAccess.Common.GenericRepo<DataAccess.AdmDao.SubscriptionContext>(), args);
                //    return;
                //}
                //catch (System.Data.Entity.Infrastructure.DbUpdateConcurrencyException e) { Logging.LogError("UpdateConcurrencyException Error in Execute method, moving on to save the data with retry ",e); }
               

               
            }
            
        }


    }
}
