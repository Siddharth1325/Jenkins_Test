﻿using System;

namespace ServiceLink.Billing.ART.RuleModel
{
    public class ARTRuleSummary
    {
        public decimal CostTracker { get; set; }
        public decimal FinalCost { get; set; }
        public decimal PriceTracker { get; set; }
        public decimal FinalPrice { get; set; }
        public bool IsEligibleForTran32 { get; set; }
        public decimal? BaseCost { get; set; }
        public string BaseCostSelectionReason { get; set; }
        public decimal? BasePrice { get; set; }
        public string BasePriceSelectionReason { get; set; }
        public string FailureReason { get; set; }
        public bool Successful { get; set; }
        public bool? Calculated { get; set; }
        public bool IsDirtyCost { get; set; }
        public bool IsDirtyPrice { get; set; }
        public bool IsDirty { get; set; }
        public Adjustments CostAdjustments { get; set; }
        public Adjustments PriceAdjustments { get; set; }
    }
}
