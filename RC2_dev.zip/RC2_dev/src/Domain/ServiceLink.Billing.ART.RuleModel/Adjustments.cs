﻿using System;

namespace ServiceLink.Billing.ART.RuleModel
{
    [Serializable]
    public class Adjustments
    {
        public string AdjustmentGroupCode { get; set; }
        public string AdjustmentTypeCode { get; set; }
        public decimal AdjustPercentage { get; set; }
    }
}
