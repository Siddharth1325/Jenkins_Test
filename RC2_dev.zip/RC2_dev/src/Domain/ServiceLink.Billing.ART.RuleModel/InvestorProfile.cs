﻿using System;

namespace ServiceLink.Billing.ART.RuleModel
{
    public class InvestorProfile
    {
        public int? InvestorProfileId { get; set; }
    }
}
