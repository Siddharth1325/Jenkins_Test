﻿using System;

namespace ServiceLink.Billing.ART.RuleModel
{
    [Serializable]
    public class DefaultCostCalculator
    {
        public decimal BaseCost { get; set; }
        public decimal CostTracker { get; set; }
        public string BaseCostSelectionReason { get; set; }
        public string FailureReason { get; set; }
        public bool Successful { get; set; }
        public bool IsDirty { get; set; }
        public VendorPricing VendorPricing { get; set; }
        public Loan Loan { get; set; }
        public Product Product { get; set; }
        public SubClientProfile SubClientProfile { get; set; }
        public Order Order { get; set; }
        public WorkOrder WorkOrder { get; set; }
    }
}
