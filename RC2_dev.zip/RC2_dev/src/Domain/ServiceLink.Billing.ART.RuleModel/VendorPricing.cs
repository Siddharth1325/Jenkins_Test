﻿using System;

namespace ServiceLink.Billing.ART.RuleModel
{
    public class VendorPricing
    {
        public decimal? RushRate { get; set; }
        public decimal? StandardRate { get; set; }
    }
}
