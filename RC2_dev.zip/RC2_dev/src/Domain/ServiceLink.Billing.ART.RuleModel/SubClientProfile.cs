﻿using System;

namespace ServiceLink.Billing.ART.RuleModel
{
    public class SubClientProfile
    {
        public int? SubClientProfileId { get; set; }
    }
}
