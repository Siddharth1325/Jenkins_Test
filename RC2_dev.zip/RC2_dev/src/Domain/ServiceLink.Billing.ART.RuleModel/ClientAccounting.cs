﻿using System;

namespace ServiceLink.Billing.ART.RuleModel
{
    [Serializable]
    public class ClientAccounting
    {
        public bool? IsBillCancellations { get; set; }
        public decimal? CancellationAmount { get; set; }
    }
}