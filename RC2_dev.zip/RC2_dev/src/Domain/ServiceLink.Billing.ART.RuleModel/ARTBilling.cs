﻿using System;
using System.Collections.Generic;

namespace ServiceLink.Billing.ART.RuleModel
{
    [Serializable]
    public class ARTBilling
    {
        public decimal CostTracker { get; set; }
        public decimal FinalCost { get; set; }
        public decimal PriceTracker { get; set; }
        public decimal FinalPrice { get; set; }
        public DateTime? OrderDate { get; set; }
        public bool? IsBillableIfLate { get; set; }
        public bool? IsPreviouslySignedFee { get; set; }
        public bool? WasCancelledWithin24Hrs { get; set; }
        public DateTime? DateTimeMinValue { get; set; }
        public bool IsDirty { get; set; }
        public bool IsDirtyCost { get; set; }
        public bool IsDirtyPrice { get; set; }
        public VPRSignageResult VPRSignageResult { get; set; }
        public Adjustments CostAdjustments { get; set; }
        public Adjustments PriceAdjustments { get; set; }
        public WorkOrder WorkOrder { get; set; }
        public ClientAccounting ClientAccounting { get; set; }
    }
}
