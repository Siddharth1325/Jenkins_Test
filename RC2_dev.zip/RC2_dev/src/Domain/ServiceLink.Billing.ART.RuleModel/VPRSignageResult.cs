﻿using System;

namespace ServiceLink.Billing.ART.RuleModel
{
    [Serializable]
    public class VPRSignageResult
    {
        public bool? WasWorkPerformed { get; set; }

        public DateTime? SubmissionDate { get; set; }
    }
}
