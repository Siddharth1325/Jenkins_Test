﻿using System;

namespace ServiceLink.Billing.ART.RuleModel
{
    public class Product
    {
        public int? ProductId { get; set; }

        public string ProductCode { get; set; }
    }
}
