﻿using CommonLib.Persistence;
using DomainModel.Accounting;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RefactorThis.GraphDiff;
using System.Data.Entity.Validation;
using System.Diagnostics;
using DomainModel.Common;

using CommonLib;
using DataAccess.Accounting;
using DomainModel;


namespace DataAccess
{
    public class RemittanceSearchDao : BaseDao
    {
        #region Constants
        private const string VENDORPROFILEID = "VendorProfileId";
        private const string VENDORNAME = "VendorName";
        private const string LOAN = "LoanNumber";
        private const string CHECK = "CheckNumber";
        private const string INSPWORKORDERID = "InspectionWO";
        private const string PRESWO = "PresWO";
        private const string LOB = "LOB";
        private const string CHKDATEFROM = "CheckDateFrom";
        private const string CHKDATETO = "CheckDateTo";
        private const string INVOICEDATEFROM = "InvoiceDateFrom";
        private const string INVOICEDATETO = "InvoiceDateTo";
        private const string SUBMISSIONFROMDATE = "SubmissionFromDate";
        private const string SUBMISSIONTODATE = "SubmissionToDate";
        private const string INVOICENUMBER = "ApInvoiceNUmber";
        private const string ORACLEID = "OracleId";
        //private const string APPLICATIONID = "AppId";

        private const string PROCREMITTANCESEARCH = "act.GetVendorPaymentRemittance  @VendorProfileId, @VendorName, @LoanNumber, @InspectionWO, @PresWO, @SubmissionFromDate, @SubmissionToDate" +
                                                    ",@LOB, @CheckNumber" +
                                                    ",@CheckDateFrom, @CheckDateTo, @InvoiceDateFrom, @InvoiceDateTo, @PageSize, @SkipCount,@viewType,@ApInvoiceNUmber,@OracleId";



        #endregion

        public List<Remittance.SearchResult> GetVendorRemittanceSearchResults(Remittance.SearchRequest searchRequestDao, int? skipCount, int? pageSize)
        {
            #region Params to Dbnull
            object vendorProfileId = DBNull.Value;
            object vendorName = DBNull.Value;
            object loan = DBNull.Value;
            object check = DBNull.Value;
            object inspWorkOrderId = DBNull.Value;
            object presWorkOrderId = DBNull.Value;
            object chkDateFrom = DBNull.Value;
            object chkDateTo = DBNull.Value;
            object invoiceDateFrom = DBNull.Value;
            object invoiceDateTo = DBNull.Value;
            object lob = DBNull.Value;
            object submissionFromDate = DBNull.Value;
            object submissionToDate = DBNull.Value;
            object viewType = DBNull.Value;
            object apInvoiceNumber = DBNull.Value;
            object oracleId = DBNull.Value;

            if ((searchRequestDao.VendorProfileId != null)) vendorProfileId = searchRequestDao.VendorProfileId;
            if (!string.IsNullOrEmpty(searchRequestDao.VendorName)) vendorName = searchRequestDao.VendorName;
            if ((searchRequestDao.Loan != null)) loan = searchRequestDao.Loan;
            if ((searchRequestDao.Check != null)) check = searchRequestDao.Check;
            if ((searchRequestDao.InspWorkOrderId != null)) inspWorkOrderId = searchRequestDao.InspWorkOrderId;
            if ((searchRequestDao.PresWorkOrderId != null)) presWorkOrderId = searchRequestDao.PresWorkOrderId;
            if ((searchRequestDao.ChkDateFrom != null)) chkDateFrom = searchRequestDao.ChkDateFrom;
            if ((searchRequestDao.ChkDateTo != null)) chkDateTo = searchRequestDao.ChkDateTo;
            if ((searchRequestDao.InvoiceDateFrom != null)) invoiceDateFrom = searchRequestDao.InvoiceDateFrom;
            if ((searchRequestDao.InvoiceDateTo != null)) invoiceDateTo = searchRequestDao.InvoiceDateTo;
            if ((searchRequestDao.LOBs != null)) lob = searchRequestDao.LOBs;
            if ((searchRequestDao.SubmissionDateFrom != null)) submissionFromDate = searchRequestDao.SubmissionDateFrom;
            if ((searchRequestDao.SubmissionDateTo != null)) submissionToDate = searchRequestDao.SubmissionDateTo;
            if ((searchRequestDao.ViewType != null)) viewType = searchRequestDao.ViewType;
            
            if ((searchRequestDao.ApInvoice != null)) apInvoiceNumber = searchRequestDao.ApInvoice;
            if ((searchRequestDao.OracleId != null)) oracleId = searchRequestDao.OracleId;

            var VendorProfileIdParam = new SqlParameter { ParameterName = VENDORPROFILEID, Value = vendorProfileId, DbType = System.Data.DbType.Int32 };
            var VendorNameParam = new SqlParameter { ParameterName = VENDORNAME, Value = vendorName, DbType = System.Data.DbType.String };
            var LoanParam = new SqlParameter { ParameterName = LOAN, Value = loan, DbType = System.Data.DbType.String };
            var CheckParam = new SqlParameter { ParameterName = CHECK, Value = check, DbType = System.Data.DbType.String };
            var InspWorkOrderIdParam = new SqlParameter { ParameterName = INSPWORKORDERID, Value = inspWorkOrderId, DbType = System.Data.DbType.String };
            var PresWorkOrderIdParam = new SqlParameter { ParameterName = PRESWO, Value = presWorkOrderId, DbType = System.Data.DbType.String };
            var ChkDateFromParam = new SqlParameter { ParameterName = CHKDATEFROM, Value = chkDateFrom, DbType = System.Data.DbType.DateTime2 };
            var ChkDateToParam = new SqlParameter { ParameterName = CHKDATETO, Value = chkDateTo, DbType = System.Data.DbType.DateTime2 };
            var InvoiceDateFromParam = new SqlParameter { ParameterName = INVOICEDATEFROM, Value = invoiceDateFrom, DbType = System.Data.DbType.DateTime2 };
            var InvoiceDateToParam = new SqlParameter { ParameterName = INVOICEDATETO, Value = invoiceDateTo, DbType = System.Data.DbType.DateTime2 };
            var lobParam = new SqlParameter { ParameterName = LOB, Value = lob, DbType = System.Data.DbType.String };
            var SubmissionDateFromParam = new SqlParameter { ParameterName = SUBMISSIONFROMDATE, Value = submissionFromDate, DbType = System.Data.DbType.DateTime2 };
            var SubmissionDateToParam = new SqlParameter { ParameterName = SUBMISSIONTODATE, Value = submissionToDate, DbType = System.Data.DbType.DateTime2 };
            var ParamSkipCount = new SqlParameter { ParameterName = "SkipCount", Value = skipCount };
            var ParamPageSize = new SqlParameter { ParameterName = "PageSize", Value = pageSize };
            var ParamViewType = new SqlParameter { ParameterName = "ViewType", Value = viewType, DbType = System.Data.DbType.String };
            
            var ParamInvoiceNumber = new SqlParameter { ParameterName = INVOICENUMBER, Value = apInvoiceNumber, DbType = System.Data.DbType.String };
            var ParamOracleId = new SqlParameter { ParameterName = ORACLEID, Value = oracleId, DbType = System.Data.DbType.String };
            List<Remittance.SearchResult> searchresults = null;
            using (AccountingData ctx = new AccountingData())
            {
                var results = ctx.Database.SqlQuery<Remittance.SearchResult>(PROCREMITTANCESEARCH, VendorProfileIdParam, VendorNameParam,
                                            LoanParam, InspWorkOrderIdParam, PresWorkOrderIdParam, SubmissionDateFromParam,
                                            SubmissionDateToParam, lobParam, CheckParam, ChkDateFromParam, ChkDateToParam,
                                            InvoiceDateFromParam, InvoiceDateToParam, ParamPageSize, ParamSkipCount, ParamViewType, ParamInvoiceNumber, ParamOracleId
                                            );
                searchresults = new List<Remittance.SearchResult>(results.ToList<Remittance.SearchResult>());
            }

            //If IsVendorNumber is False 
            if (searchresults.Count > 0 && searchRequestDao.IsVendorNumber == false)
            {
                foreach (var item in searchresults)
                {
                    using (AccountingDataFieldServices ctx = new AccountingDataFieldServices())
                    {
                        if (item.OrdinanceProfileId.HasValue)
                        {
                            var value = ctx.OrdinanceProfiles.Where(x => x.OrdinanceProfileId == item.OrdinanceProfileId.Value).FirstOrDefault();
                            item.VendorName = value.CommonName;
                            item.VendorNumber = value.OrdinanceProfileId;
                            item.IsVpr = true;
                        }
                    }
                }
            }


            #endregion
            return searchresults;
        }
    }
}
