﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Linq.Expressions;
using RefactorThis.GraphDiff;
using DataAccess.Persistence;
using System.Data.Entity.Validation;
using CommonLib;
using CommonLib.Util;
using System.Reflection;
using System.Data.Entity;
using DataAccess.Accounting;
using CommonLib.ModelAttrib;

namespace DataAccess.Common
{
    //to be moved into commonLib
    public partial class GenericRepoMoved<TCtx> where TCtx : CustomDbContext, new()
    {

        public TEntity SaveEntity<TEntity>(TEntity Entity) where TEntity : class,DomainModel.IBaseDomainModel, new()
        {
            using (CustomDbContext ctx = new TCtx())
            {

                Entity = ctx.UpdateGraph<TEntity>(Entity);
                ctx.SaveChanges();
            }

            return Entity;

        }
        public TEntity GetEntityByKeys<TEntity>(TEntity Entity) where TEntity : class, new()
        {
            using (CustomDbContext ctx = new TCtx())
            {
                IQueryable<TEntity> entityQuery = ctx.Set<TEntity>();
                ctx.Configuration.ProxyCreationEnabled = false;  

                PropertyInfo[] SecKeys = RelectionUtils.GetProperties(Entity.GetType()).Where(prop => prop.IsDefined(typeof(SecondaryKeyPropAttribute), false)).ToArray();

                Expression<Func<TEntity, bool>> where1 = null;
                Expression<Func<TEntity, bool>> where2 = null;
                if(SecKeys!=null && SecKeys.Length>0)
                {
                    where1 = GetExpression<TEntity>(RelectionUtils.GetValueImpl(Entity, SecKeys[0].Name), SecKeys[0].Name);
                }
                for (int i = 1; i < SecKeys.Length; i++)
                {
                    where2 = GetExpression<TEntity>(RelectionUtils.GetValueImpl(Entity, SecKeys[i].Name), SecKeys[i].Name);

                    where1 = where1.And(where2);

                }
                return entityQuery.FirstOrDefault(where1); 
                
            }

        }
        private static Expression<Func<T, bool>> GetExpression<T>(object id, string KeyPropertyName)
        {
            // Find primary key property based on primary key attribute.
            //var keyProperty = typeof(T).GetProperties().
            //    First(
            //        one =>
            //        one.GetCustomAttributes(typeof(EdmScalarPropertyAttribute), true)
            //        .Any(two => ((EdmScalarPropertyAttribute)two).EntityKeyProperty));

            // Create entity => portion of lambda expression
            ParameterExpression parameter = Expression.Parameter(typeof(T), "entity");

            // create entity.Id portion of lambda expression
            MemberExpression property = Expression.Property(parameter, KeyPropertyName);

            // create 'id' portion of lambda expression
            var equalsTo = Expression.Convert(Expression.Constant(id), typeof(T).GetProperty(KeyPropertyName).PropertyType); //Expression.Constant(id);

            // create entity.Id == 'id' portion of lambda expression
            var equality = Expression.Equal(property, equalsTo);

            // finally create entire expression - entity => entity.Id == 'id'
            Expression<Func<T, bool>> retVal =
                Expression.Lambda<Func<T, bool>>(equality, new[] { parameter });
            return retVal;
        }


        public object GetEntity(object o, int id)
        {
            using (CustomDbContext ctx = new TCtx())
            {
                if (o != null)
                {
                    object entity = ctx.Set(o.GetType()).Find(id);
                    return entity;
                }
                else return null;
            }
        }
        public Func<TSource, bool> SimpleComparison<TSource>
            (string property, object value)
        {
            var type = typeof(TSource);
            var pe = Expression.Parameter(type, "p");
            var propertyReference = Expression.Property(pe, property);
            var constantReference = Expression.Constant(value);
            return Expression.Lambda<Func<TSource, bool>>
                (Expression.Equal(propertyReference, constantReference),
                new[] { pe }).Compile();
        }
        public object GetEntityBySecondryKeys(object domainObject)
        {
            using (CustomDbContext ctx = new TCtx())
            {

                if (domainObject != null)
                {
                    ParameterExpression p1 = Expression.Parameter(domainObject.GetType());
                    Expression property1 = Expression.Property(p1, "SourceWorkOrderId");
                    Expression c1 = Expression.Constant(1200000001);
                    Expression body1 = Expression.Equal(property1, c1);
                    Expression exp1 = Expression.Lambda(body1, new ParameterExpression[] { p1 });

                    ParameterExpression p2 = Expression.Parameter(domainObject.GetType());
                    Expression property2 = Expression.Property(p2, "ApplicationId");
                    Expression c2 = Expression.Constant(1001);
                    Expression body2 = Expression.Equal(property2, c2);
                    Expression exp2 = Expression.Lambda(body2, new ParameterExpression[] { p2 });
                   


                    MethodInfo singleMethod = typeof(Queryable).GetMethods().Single(m => m.Name == "Single" && m.GetParameters().Count() == 2).MakeGenericMethod(domainObject.GetType());

                    DbSet dbSet = ctx.Set(domainObject.GetType());
                    object entity = singleMethod.Invoke(null, new object[] { dbSet, exp1,exp2 });
                    return entity;
                }
                
                else return null;
            }
        }

    }
}
