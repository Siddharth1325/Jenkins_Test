﻿using CommonLib;
using CommonLib.Persistence;
using DataAccess.Accounting;
using DomainModel.Accounting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RefactorThis.GraphDiff;
using DomainModel.FtvCheckLog;
using System.Data.SqlClient;

namespace DataAccess
{
    public class FtvCheckLogDao : BaseDao
    {

        public List<CheckLogSearchResult> CheckLogSearch(CheckLogSearchInput searchInput)
        {
            string CheckLogSearchProc = "act.FtvCheckLogSearch @InvoiceNumber, @CheckNumber,@WorkOrderNumber, @LoanNumber, @ClientNumber," +
              "@TrackingNumber,@IsPosted,  @IsDeliveryConfirmation,@PayeeName, @CompletedDateFrom,@CompletedDateTo,@CheckDateFrom,@CheckDateTo, @PageSize";

            object InvoiceNumber = DBNull.Value;
            object CheckNumber = DBNull.Value;
            object WorkOrderNumber = DBNull.Value;
            object LoanNumber = DBNull.Value;
            object ClientNumber = DBNull.Value;
            object TrackingNumber = DBNull.Value;
            object IsPosted = DBNull.Value;
            object IsDeliveryConfirmation = DBNull.Value;
            object PayeeName = DBNull.Value;
            object CompletedDateFrom = DBNull.Value;
            object CompletedDateTo = DBNull.Value;
            object CheckDateFrom = DBNull.Value;
            object CheckDateTo = DBNull.Value;
            object PageSize = DBNull.Value;
            // object SkipCount = DBNull.Value;


            if (!string.IsNullOrEmpty(searchInput.InvoiceNumber))
                InvoiceNumber = searchInput.InvoiceNumber;

            if (!string.IsNullOrEmpty(searchInput.CheckNumber))
                CheckNumber = searchInput.CheckNumber;

            if (searchInput.WorkOrderId.GetValueOrDefault() > 0)
                WorkOrderNumber = searchInput.WorkOrderId;

            if (!string.IsNullOrEmpty(searchInput.LoanNumber))
                LoanNumber = searchInput.LoanNumber;

            if (!string.IsNullOrEmpty(searchInput.ClientNumber))
                ClientNumber = searchInput.ClientNumber;

            if (!string.IsNullOrEmpty(searchInput.TrackingNumber))
                TrackingNumber = searchInput.TrackingNumber;

            if (searchInput.IsPosted.HasValue)
                IsPosted = searchInput.IsPosted;

            if (searchInput.IsDelieveryConfirmation.HasValue)
                IsDeliveryConfirmation = searchInput.IsDelieveryConfirmation;

            if (!string.IsNullOrEmpty(searchInput.PayableName))
                PayeeName = searchInput.PayableName;

            if (searchInput.CompletedDateFrom.HasValue)
                CompletedDateFrom = searchInput.CompletedDateFrom;

            if (searchInput.CompletedDateTo.HasValue)
                CompletedDateTo = searchInput.CompletedDateTo;

            if (searchInput.CheckedDateFrom.HasValue)
                CheckDateFrom = searchInput.CheckedDateFrom;

            if (searchInput.CheckedDateTo.HasValue)
                CheckDateTo = searchInput.CheckedDateTo;

            var ParamInvoiceNumber = new SqlParameter { ParameterName = "InvoiceNumber", Value = InvoiceNumber, DbType = System.Data.DbType.String };
            var ParamCheckNumber = new SqlParameter { ParameterName = "CheckNumber", Value = CheckNumber, DbType = System.Data.DbType.String };
            var ParamWorkOrderNumber = new SqlParameter { ParameterName = "WorkOrderNumber", Value = WorkOrderNumber, DbType = System.Data.DbType.Int32 };
            var ParamLoanNumber = new SqlParameter { ParameterName = "LoanNumber", Value = LoanNumber, DbType = System.Data.DbType.String };
            var ParamClientNumber = new SqlParameter { ParameterName = "ClientNumber", Value = ClientNumber, DbType = System.Data.DbType.String };
            var ParamTrackingNumber = new SqlParameter { ParameterName = "TrackingNumber", Value = TrackingNumber, DbType = System.Data.DbType.String };
            var ParamIsPosted = new SqlParameter { ParameterName = "IsPosted", Value = IsPosted, DbType = System.Data.DbType.Boolean };
            var ParamIsDeliveryConfirmation = new SqlParameter { ParameterName = "IsDeliveryConfirmation", Value = IsDeliveryConfirmation, DbType = System.Data.DbType.Boolean };
            var ParamPayeeName = new SqlParameter { ParameterName = "PayeeName", Value = PayeeName, DbType = System.Data.DbType.String };
            var ParamCompletedDateFrom = new SqlParameter { ParameterName = "CompletedDateFrom", Value = CompletedDateFrom, DbType = System.Data.DbType.Date };
            var ParamCompletedDateTo = new SqlParameter { ParameterName = "CompletedDateTo", Value = CompletedDateTo, DbType = System.Data.DbType.Date };
            var ParamCheckDateFrom = new SqlParameter { ParameterName = "CheckDateFrom", Value = CheckDateFrom, DbType = System.Data.DbType.Date };
            var ParamCheckDateTo = new SqlParameter { ParameterName = "CheckDateTo", Value = CheckDateTo, DbType = System.Data.DbType.Date };

            // var ParamSkipCount = new SqlParameter { ParameterName = "SkipCount", Value = searchInput.SkipCount, DbType = System.Data.DbType.Int32 };
            var ParamPageSize = new SqlParameter { ParameterName = "PageSize", Value = searchInput.PageSize, DbType = System.Data.DbType.Int32 };


            using (var ctx = new AccountingData())
            {
                var results = ctx.Database.SqlQuery<CheckLogSearchResult>(
                    CheckLogSearchProc, ParamInvoiceNumber, ParamCheckNumber, ParamWorkOrderNumber, ParamLoanNumber, ParamClientNumber, ParamTrackingNumber,
                    ParamIsPosted, ParamIsDeliveryConfirmation, ParamPayeeName, ParamCompletedDateFrom, ParamCompletedDateTo, ParamCheckDateFrom,
                    ParamCheckDateTo, ParamPageSize
                      ).ToList();

                return results;
            }
        }

        public List<CheckLogSearchResultExport> CheckLogSearchExport(CheckLogSearchInput searchInput)
        {
            string CheckLogSearchProc = "act.FtvCheckLogSearch @InvoiceNumber, @CheckNumber,@WorkOrderNumber, @LoanNumber, @ClientNumber," +
              "@TrackingNumber,@IsPosted,  @IsDeliveryConfirmation,@PayeeName, @CompletedDateFrom,@CompletedDateTo,@CheckDateFrom,@CheckDateTo, @PageSize";

            object InvoiceNumber = DBNull.Value;
            object CheckNumber = DBNull.Value;
            object WorkOrderNumber = DBNull.Value;
            object LoanNumber = DBNull.Value;
            object ClientNumber = DBNull.Value;
            object TrackingNumber = DBNull.Value;
            object IsPosted = DBNull.Value;
            object IsDeliveryConfirmation = DBNull.Value;
            object PayeeName = DBNull.Value;
            object CompletedDateFrom = DBNull.Value;
            object CompletedDateTo = DBNull.Value;
            object CheckDateFrom = DBNull.Value;
            object CheckDateTo = DBNull.Value;
            object PageSize = DBNull.Value;
            // object SkipCount = DBNull.Value;


            if (!string.IsNullOrEmpty(searchInput.InvoiceNumber))
                InvoiceNumber = searchInput.InvoiceNumber;

            if (!string.IsNullOrEmpty(searchInput.CheckNumber))
                CheckNumber = searchInput.CheckNumber;

            if (searchInput.WorkOrderId.GetValueOrDefault() > 0)
                WorkOrderNumber = searchInput.WorkOrderId;

            if (!string.IsNullOrEmpty(searchInput.LoanNumber))
                LoanNumber = searchInput.LoanNumber;

            if (!string.IsNullOrEmpty(searchInput.ClientNumber))
                ClientNumber = searchInput.ClientNumber;

            if (!string.IsNullOrEmpty(searchInput.TrackingNumber))
                TrackingNumber = searchInput.TrackingNumber;

            if (searchInput.IsPosted.HasValue)
                IsPosted = searchInput.IsPosted;

            if (searchInput.IsDelieveryConfirmation.HasValue)
                IsDeliveryConfirmation = searchInput.IsDelieveryConfirmation;

            if (!string.IsNullOrEmpty(searchInput.PayableName))
                PayeeName = searchInput.PayableName;

            if (searchInput.CompletedDateFrom.HasValue)
                CompletedDateFrom = searchInput.CompletedDateFrom;

            if (searchInput.CompletedDateTo.HasValue)
                CompletedDateTo = searchInput.CompletedDateTo;

            if (searchInput.CheckedDateFrom.HasValue)
                CheckDateFrom = searchInput.CheckedDateFrom;

            if (searchInput.CheckedDateTo.HasValue)
                CheckDateTo = searchInput.CheckedDateTo;

            var ParamInvoiceNumber = new SqlParameter { ParameterName = "InvoiceNumber", Value = InvoiceNumber, DbType = System.Data.DbType.String };
            var ParamCheckNumber = new SqlParameter { ParameterName = "CheckNumber", Value = CheckNumber, DbType = System.Data.DbType.String };
            var ParamWorkOrderNumber = new SqlParameter { ParameterName = "WorkOrderNumber", Value = WorkOrderNumber, DbType = System.Data.DbType.Int32 };
            var ParamLoanNumber = new SqlParameter { ParameterName = "LoanNumber", Value = LoanNumber, DbType = System.Data.DbType.String };
            var ParamClientNumber = new SqlParameter { ParameterName = "ClientNumber", Value = ClientNumber, DbType = System.Data.DbType.String };
            var ParamTrackingNumber = new SqlParameter { ParameterName = "TrackingNumber", Value = TrackingNumber, DbType = System.Data.DbType.String };
            var ParamIsPosted = new SqlParameter { ParameterName = "IsPosted", Value = IsPosted, DbType = System.Data.DbType.Binary };
            var ParamIsDeliveryConfirmation = new SqlParameter { ParameterName = "IsDeliveryConfirmation", Value = IsDeliveryConfirmation, DbType = System.Data.DbType.Binary };
            var ParamPayeeName = new SqlParameter { ParameterName = "PayeeName", Value = PayeeName, DbType = System.Data.DbType.String };
            var ParamCompletedDateFrom = new SqlParameter { ParameterName = "CompletedDateFrom", Value = CompletedDateFrom, DbType = System.Data.DbType.Date };
            var ParamCompletedDateTo = new SqlParameter { ParameterName = "CompletedDateTo", Value = CompletedDateTo, DbType = System.Data.DbType.Date };
            var ParamCheckDateFrom = new SqlParameter { ParameterName = "CheckDateFrom", Value = CheckDateFrom, DbType = System.Data.DbType.Date };
            var ParamCheckDateTo = new SqlParameter { ParameterName = "CheckDateTo", Value = CheckDateTo, DbType = System.Data.DbType.Date };

            // var ParamSkipCount = new SqlParameter { ParameterName = "SkipCount", Value = searchInput.SkipCount, DbType = System.Data.DbType.Int32 };
            var ParamPageSize = new SqlParameter { ParameterName = "PageSize", Value = searchInput.PageSize, DbType = System.Data.DbType.Int32 };


            using (var ctx = new AccountingData())
            {
                var results = ctx.Database.SqlQuery<CheckLogSearchResultExport>(
                    CheckLogSearchProc, ParamInvoiceNumber, ParamCheckNumber, ParamWorkOrderNumber, ParamLoanNumber, ParamClientNumber, ParamTrackingNumber,
                    ParamIsPosted, ParamIsDeliveryConfirmation, ParamPayeeName, ParamCompletedDateFrom, ParamCompletedDateTo, ParamCheckDateFrom,
                    ParamCheckDateTo, ParamPageSize
                      ).ToList();

                return results;
            }
        }

        public AccountsPayableTrackingLog GetAccountsPayableTrackingLogById(int accountsPayableTrackingLogId)
        {
            using (var ctx = new AccountingData())
            {
                var log = (from l in ctx.AccountsPayableTrackingLogs where l.AccountsPayableTrackingLogId == accountsPayableTrackingLogId select l).FirstOrDefault();
                return log;
            }
        }

        public AccountsPayableTrackingLog GetAccountsPayableTrackingLogByRemittanceId(int accountsPayableRemittanceId)
        {
            using (var ctx = new AccountingData())
            {
                var log = (from l in ctx.AccountsPayableTrackingLogs where l.AccountsPayableRemittanceId == accountsPayableRemittanceId select l).FirstOrDefault();
                return log;
            }
        }

        public AccountsPayableTrackingLog GetAccountsPayableTrackingLogByOrderHierarchyId(int orderHierarchyId, int? accountsPayableInvoiceId)
        {
            using (var ctx = new AccountingData())
            {
                var aptl = (from trackLog in ctx.AccountsPayableTrackingLogs
                            join oh in ctx.OrderHierarchys on trackLog.WorkOrderId equals oh.WorkOrderId
                            where oh.OrderHierarchyId == orderHierarchyId && trackLog.AccountsPayableInvoiceId == accountsPayableInvoiceId
                            select trackLog
                               ).FirstOrDefault();
                //if (aptl == null || aptl.AccountsPayableTrackingLogId <= 0)
                //{
                //    aptl = (from trackLog in ctx.AccountsPayableTrackingLogs
                //                join oh in ctx.OrderHierarchys on trackLog.WorkOrderId equals oh.WorkOrderId
                //                where oh.OrderHierarchyId == orderHierarchyId 
                //                select trackLog
                //                   ).FirstOrDefault();
                //}
                return aptl;
            }
        }

        public int? GetWorkOrderIdByOrderHierarchy(int orderHierarchyId)
        {
            using (var ctx = new AccountingData())
            {
                var woId = (from oh in ctx.OrderHierarchys where oh.OrderHierarchyId == orderHierarchyId select oh.WorkOrderId).FirstOrDefault();
                return woId;
            }
        }

        public int GetSourceWorkOrderIdByOrderHierarchy(int orderHierarchyId)
        {
            using (AccountingData ctx = new AccountingData())
            {
                int woId = (from wo in ctx.WorkOrders join oh in ctx.OrderHierarchys on wo.WorkOrderId equals oh.WorkOrderId where oh.OrderHierarchyId == orderHierarchyId select wo.SourceWorkOrderId).FirstOrDefault();
                return woId;
            }
        }

        public AccountsPayableTrackingLog GetAccountsPayableTrackingLogByWorkOrderId(int workOrderId)
        {
            using (var ctx = new AccountingData())
            {
                var log = (from l in ctx.AccountsPayableTrackingLogs where l.WorkOrderId == workOrderId select l).FirstOrDefault();
                return log;
            }
        }

        public AccountsPayableTrackingLog SaveAccountsPayableTrackingLog(AccountsPayableTrackingLog accountsPayableTrackingLog)
        {

            using (var ctx = new AccountingData())
            {
                ctx.UpdateGraph(accountsPayableTrackingLog, map => map);
                if (accountsPayableTrackingLog.AccountsPayableTrackingLogId > 0)
                    ctx.SaveChanges();
                else
                {
                    if (accountsPayableTrackingLog.RejectionReason != null)
                        accountsPayableTrackingLog.RejectedDate = DateTime.Today;
                    // ctx.AccountsPayableTrackingLogs.Add(accountsPayableTrackingLog);
                    ctx.SaveChanges();
                }
            }


            return accountsPayableTrackingLog;
        }

        public AccountsPayableDetail GetAccountsPayableDetailByHierarchyId(int orderHierarchyId)
        {
            using (var ctx = new AccountingData())
            {
                var apd = (from d in ctx.AccountsPayableDetails where d.OrderHierarchyId == orderHierarchyId select d).FirstOrDefault();
                return apd;
            }
        }

        public AccountsPayableDetail GetAccountsPayableDetailByKey(int payableDetailId)
        {
            using (var ctx = new AccountingData())
            {
                var apd = (from d in ctx.AccountsPayableDetails where d.AccountsPayableDetailId == payableDetailId select d).FirstOrDefault();
                return apd;
            }
        }

        public void SaveAccountsPayableDetail(AccountsPayableDetail payableDetail)
        {
            using (var ctx = new AccountingData())
            {
                payableDetail = ctx.UpdateGraph(payableDetail, map => map);
                payableDetail.FeeTypePaymentRefId = payableDetail.AccountsPayableDetailId;
                ctx.SaveChanges();

            }
        }

        public CheckLogAccountingData GetReceivableInvoice(int orderHierarchyId, int? feeTypeId, int? feeTypeRefId)
        {
            using (var ctx = new AccountingData())
            {
                //var data = new CheckLogAccountingData();
                var data = (from ard in ctx.AccountsReceivableDetails
                            where ard.OrderHierarchyId == orderHierarchyId && ard.FeeTypeId == feeTypeId
                                && ard.FeeTypePaymentRefId == feeTypeRefId
                            select new CheckLogAccountingData
                            {
                                AccountsReceivableDetailId = ard.AccountsReceivableDetailId,
                                FeeTypeId = ard.FeeTypeId,
                                FeeTypeRefId = ard.FeeTypePaymentRefId
                            }).FirstOrDefault();
                if (data == null || data.AccountsReceivableDetailId <= 0)
                {
                    data = (from ard in ctx.AccountsReceivableDetails
                            where ard.OrderHierarchyId == orderHierarchyId
                                && ard.FeeTypeId == feeTypeId
                            select new CheckLogAccountingData
                            {
                                AccountsReceivableDetailId = ard.AccountsReceivableDetailId,
                                FeeTypeId = ard.FeeTypeId,
                                FeeTypeRefId = ard.FeeTypePaymentRefId
                            }).FirstOrDefault();
                }
                if (data != null)
                {
                    if (data.AccountsReceivableDetailId > 0)
                        data.AccountsReceivableInvoiceId =
                                (from ari in ctx.AccountingARInvoiceReceivables
                                 where ari.AccountsReceivableDetailId == data.AccountsReceivableDetailId
                                 select ari.AccountsReceivableInvoiceId).FirstOrDefault();
                }
                return data;
            }
        }

        public AccountsReceivableDetail GetAccountsReceivableDetail(int orderHierarchyId, int feeTypeId, int? feeTypeRefId)
        {
            using (var ctx = new AccountingData())
            {
                var ard = (from ar in ctx.AccountsReceivableDetails
                           where ar.OrderHierarchyId == orderHierarchyId
                               && ar.FeeTypeId == feeTypeId
                               && ar.FeeTypePaymentRefId == feeTypeRefId
                           select ar).FirstOrDefault();
                return ard;
            }
        }

        public AccountingGLCode GetArGlCode(int orderHierarchyId, int? feeTypeId)
        {
            if (feeTypeId.HasValue && feeTypeId.GetValueOrDefault() > 0)
            {
                using (var ctx = new AccountingData())
                {
                    var feeType = (from ft in ctx.FeeTypes where ft.FeeTypeId == feeTypeId select ft.FeeTypeCode).FirstOrDefault();
                    return new AccountingGLCodeDao().GetPresAccountingGlCode(orderHierarchyId, feeType, "ARADJUST");
                }

            }
            return null;



            //using (var ctx = new AccountingData())
            //{
            //    var pCode = (from oh in ctx.OrderHierarchys
            //                 join wo in ctx.WorkOrders on oh.WorkOrderId equals wo.WorkOrderId
            //                 join p in ctx.Products on wo.ProductId equals p.ProductId```
            //                 where oh.OrderHierarchyId == orderHierarchyId
            //                 select new { p.ProductId, p.ProductCategory }
            //                    ).FirstOrDefault();
            //    if (pCode != null)
            //    {
            //        var glProdFeeType = (from glc in ctx.AccountingGLCodes where glc.ProductId == pCode.ProductId && glc.FeeTypeId == feeTypeId && glc.GLTransType == "ARADJUST" select glc).FirstOrDefault();
            //        if (glProdFeeType != null && glProdFeeType.AccountingGLCodeId >= 0)
            //            return glProdFeeType;

            //        glProdFeeType = (from glc in ctx.AccountingGLCodes where glc.ProductCategory == pCode.ProductCategory && glc.FeeTypeId == feeTypeId && glc.GLTransType == "ARADJUST" select glc).FirstOrDefault();
            //        if (glProdFeeType != null && glProdFeeType.AccountingGLCodeId >= 0)
            //            return glProdFeeType;

            //        glProdFeeType = (from glc in ctx.AccountingGLCodes where glc.ProductCategory == null && glc.FeeTypeId == feeTypeId && glc.GLTransType == "ARADJUST" select glc).FirstOrDefault();
            //        if (glProdFeeType != null && glProdFeeType.AccountingGLCodeId >= 0)
            //            return glProdFeeType;

            //        glProdFeeType = (from glc in ctx.AccountingGLCodes where glc.ProductCategory == pCode.ProductCategory && glc.FeeTypeId == null && glc.GLTransType == "ARADJUST" select glc).FirstOrDefault();
            //        if (glProdFeeType != null && glProdFeeType.AccountingGLCodeId >= 0)
            //            return glProdFeeType;

            //    }
            //    return null;
            //}
        }

        public AccountingGLCode GetApGlCode(int orderHierarchyId, int? feeTypeId)
        {
            if (feeTypeId.HasValue && feeTypeId.GetValueOrDefault() > 0)
            {
                using (var ctx = new AccountingData())
                {
                    var feeType = (from ft in ctx.FeeTypes where ft.FeeTypeId == feeTypeId select ft.FeeTypeCode).FirstOrDefault();
                    return new AccountingGLCodeDao().GetPresAccountingGlCode(orderHierarchyId, feeType, "APADJUST");
                }

            }
            return null;
            //using (var ctx = new AccountingData())
            //{
            //    var pCode = (from oh in ctx.OrderHierarchys
            //                 join wo in ctx.WorkOrders on oh.WorkOrderId equals wo.WorkOrderId
            //                 join p in ctx.Products on wo.ProductId equals p.ProductId
            //                 where oh.OrderHierarchyId == orderHierarchyId
            //                 select new { p.ProductId, p.ProductCategory }
            //                    ).FirstOrDefault();
            //    if (pCode != null)
            //    {
            //        var glProdFeeType = (from glc in ctx.AccountingGLCodes where glc.ProductId == pCode.ProductId && glc.FeeTypeId == feeTypeId && glc.GLTransType == "APADJUST" select glc).FirstOrDefault();
            //        if (glProdFeeType != null && glProdFeeType.AccountingGLCodeId >= 0)
            //            return glProdFeeType;

            //        glProdFeeType = (from glc in ctx.AccountingGLCodes where glc.ProductCategory == pCode.ProductCategory && glc.FeeTypeId == feeTypeId && glc.GLTransType == "APADJUST" select glc).FirstOrDefault();
            //        if (glProdFeeType != null && glProdFeeType.AccountingGLCodeId >= 0)
            //            return glProdFeeType;

            //        glProdFeeType = (from glc in ctx.AccountingGLCodes where glc.ProductCategory == null && glc.FeeTypeId == feeTypeId && glc.GLTransType == "APADJUST" select glc).FirstOrDefault();
            //        if (glProdFeeType != null && glProdFeeType.AccountingGLCodeId >= 0)
            //            return glProdFeeType;

            //        glProdFeeType = (from glc in ctx.AccountingGLCodes where glc.ProductCategory == pCode.ProductCategory && glc.FeeTypeId == null && glc.GLTransType == "APADJUST" select glc).FirstOrDefault();
            //        if (glProdFeeType != null && glProdFeeType.AccountingGLCodeId >= 0)
            //            return glProdFeeType;

            //    }
            //    return null;
            //}
        }

        public AccountsPayableDetail SaveAccountsPayableDetailWithTrace(AccountsPayableDetail payableDetail)
        {
            using (var ctx = new AccountingData())
            {
                payableDetail = ctx.UpdateGraph(payableDetail, map => map.OwnedCollection(p => p.AccountsPayableTraces));
                ctx.SaveChanges();
                return payableDetail;
            }
        }

        public List<PayeeList> GetPayeeList(int orderHierarchyId, int? payableInvoiceId)
        {

            using (var ctx = new AccountingData())
            {
                var payeeList = (from apd in ctx.AccountsPayableDetails
                                 join ft in ctx.FeeTypes on apd.FeeTypeId equals ft.FeeTypeId into lft
                                 from leftFt in lft.DefaultIfEmpty()

                                 join aapi in ctx.AccountingAPInvoicePayables on apd.AccountsPayableDetailId equals aapi.AccountsPayableDetailId into laapi
                                 from leftaapi in laapi.DefaultIfEmpty()

                                 where apd.OrderHierarchyId == orderHierarchyId
                                         && (payableInvoiceId == null || leftaapi.AccountsPayableInvoiceId == payableInvoiceId)
                                 select new PayeeList
                                 {
                                     Amount = apd.FinalTotalCost,
                                     FeeTypeId = apd.FeeTypeId,
                                     PayableDetailId = apd.AccountsPayableDetailId,
                                     PayeeName = apd.PayeeName,
                                     FeeType = leftFt.FeeTypeName
                                 }).ToList();
                return payeeList;
            }
        }

        public InvoiceInfo GetAccountsPayableInvoice(int payableInvoceId)
        {
            using (var ctx = new AccountingData())
            {
                var api = (from i in ctx.AccountsPayableInvoices

                           where i.AccountsPayableInvoiceId == payableInvoceId
                           select new InvoiceInfo
                           {
                               InvoiceAmount = i.InvoiceAmount,
                               InvoiceDate = i.InvoiceDate,
                               InvoiceNumber = i.InvoiceNumber,
                               AccountsPayableInvoiceId = i.AccountsPayableInvoiceId,
                               ApplicationId = i.ApplicationId,
                               PayeeName = ""
                           }).FirstOrDefault();
                return api;
            }
        }

        public AccountsPayableRemittance GetRemittanceByInvoiceId(int payableInvoiceId)
        {
            using (var ctx = new AccountingData())
            {
                var apr = (from r in ctx.AccountsPayableRemittances where r.AccountsPayableInvoiceId == payableInvoiceId select r).FirstOrDefault();
                return apr;
            }
        }

        public AccountsPayableRemittance SavePayableRemittance(AccountsPayableRemittance remittance)
        {
            using (var ctx = new AccountingData())
            {
                remittance = ctx.UpdateGraph(remittance, map => map);
                ctx.SaveChanges();
                return remittance;
            }
        }

        public void SaveNewAccountsReceivable(AccountsReceivableDetail det, DisputeReceivableAdjustmentHistory disp)
        {
            using (var ctx = new AccountingData())
            {
                det = ctx.UpdateGraph(det, map => map.OwnedCollection(p => p.AccountsReceivableTraces));
                ctx.SaveChanges();
                // disp.FeeTypePaymentRefId = det.AccountsReceivableDetailId;
                ctx.UpdateGraph(disp, map => map);
                ctx.SaveChanges();
            }
        }

        public string GetCheckNumberByInvoiceId(int invoiceId)
        {
            using (var ctx = new AccountingData())
            {
                var checkNo = (from ar in ctx.AccountsPayableRemittances where ar.AccountsPayableInvoiceId == invoiceId select ar.CheckNumber).FirstOrDefault();

                return checkNo;
            }
        }
    }
}
