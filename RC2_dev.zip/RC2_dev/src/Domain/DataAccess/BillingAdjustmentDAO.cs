﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccess.Accounting;
using DomainModel;
using DomainModel.Accounting;
using RefactorThis.GraphDiff;
using System.Data.SqlClient;
using System.Data.Entity.Infrastructure;
using System.Data.Entity.Core.Objects;

namespace DataAccess.Accounting
{
    public partial class AccountingRepository
    {

        public AdjustmentDetailResponseDAO GetAdjustmentMainData(int? orderId, string updateGridType)
        {
            if (orderId == null || orderId <= 0)
                return null;
            AdjustmentDetailResponseDAO result = new AdjustmentDetailResponseDAO();
            result.IsMiscProduct = IsMiscProduct(orderId.Value);


            if (result.IsMiscProduct)
            {

                var ParamOrderId = new SqlParameter { ParameterName = ORDERID, Value = orderId, DbType = System.Data.DbType.Int32 };

                using (AccountingData ctx = new AccountingData())
                {
                    using (var con = ctx.Database.Connection)
                    {
                        const string BILLING_ADJUSTMENT_MISC_LIST = "act.GetMiscProdMainData @OrderId";
                        var command = con.CreateCommand();
                        command.CommandText = BILLING_ADJUSTMENT_MISC_LIST;
                        command.Parameters.Add(ParamOrderId);
                        con.Open();
                        var reader = command.ExecuteReader();
                        var objectContext = ((IObjectContextAdapter)ctx).ObjectContext;
                        result.MiscAdjustmentDetailList = objectContext.Translate<MiscAdjustmentDetail>(reader).ToList();
                    }
                }
                //result.MiscAdjustmentDetailList = new List<MiscAdjustmentDetail>();
                //result.MiscAdjustmentDetailList.Add(new MiscAdjustmentDetail() { OrderId = 1, WorkOrderId = 11, Product = "Violation Review", Cost = 40, FeeType = "Penalty", Id = 1, IdType = "AP", RecType = "ORIG", InvoiceNumber = "112", InvoicedDate = DateTime.Now });
                //result.MiscAdjustmentDetailList.Add(new MiscAdjustmentDetail() { OrderId = 1, WorkOrderId = 12, Product = "Violation Review", Cost = 90, FeeType = string.Empty, Id = 1, IdType = "AR", RecType = "ORIG" });
                //result.MiscAdjustmentDetailList.Add(new MiscAdjustmentDetail() { OrderId = 1, WorkOrderId = 13, Product = "Violation Review", Cost = 130, FeeType = string.Empty, Id = 2, IdType = "AR", RecType = "ORIG" });
                //result.MiscAdjustmentDetailList.Add(new MiscAdjustmentDetail() { OrderId = 1, WorkOrderId = 14, Product = "Violation Review", Cost = 150, FeeType = "Penalty", Id = 2, IdType = "AP", RecType = "FINAL", InvoiceNumber = "252", InvoicedDate = DateTime.Now });
            }
            else
            {
                const string ORDERID = "OrderId";
                const string FEETYPE = "FeeType";
                const string BILLING_ADJUSTMENT_ALL_LIST = "act.GetAdjustmentMainData @OrderId, @FeeType";

                object OrderId = DBNull.Value;
                if (orderId != null) OrderId = orderId;

                object FeeType = DBNull.Value;
                if (FeeType != null) FeeType = updateGridType;


                var ParamOrderId = new SqlParameter { ParameterName = ORDERID, Value = orderId, DbType = System.Data.DbType.Int32 };
                var ParamFeeType = new SqlParameter { ParameterName = FEETYPE, Value = FeeType, DbType = System.Data.DbType.String };


                using (AccountingData ctx = new AccountingData())
                {
                    using (var con = ctx.Database.Connection)
                    {
                        var command = con.CreateCommand();
                        command.CommandText = BILLING_ADJUSTMENT_ALL_LIST;
                        command.Parameters.Add(ParamOrderId);
                        command.Parameters.Add(ParamFeeType);
                        try
                        {
                            con.Open();
                            var reader = command.ExecuteReader();
                            var objectContext = ((IObjectContextAdapter)ctx).ObjectContext;
                            //Need to create Enum which can access from UI and Here to match fee type of refresh.
                            switch (updateGridType)
                            {
                                case "ALL":
                                    result.clientAdjustMentResponseList = objectContext.Translate<ClientFeeAdjustmentDetail>(reader).ToList();
                                    reader.NextResult();
                                    result.vendorFeeAdjustmentResponseList = objectContext.Translate<VendorFeeAdjustmentDetail>(reader).ToList();
                                    reader.NextResult();
                                    result.productServiceAdjustmentResponseList = objectContext.Translate<ProductServiceAdjustmentResponse>(reader).ToList();
                                    break;
                                case "VENDOR":
                                    result.vendorFeeAdjustmentResponseList = objectContext.Translate<VendorFeeAdjustmentDetail>(reader).ToList();
                                    break;
                                case "CLIENT":
                                    result.clientAdjustMentResponseList = objectContext.Translate<ClientFeeAdjustmentDetail>(reader).ToList();
                                    break;
                                case "PRODUCTSERVICE":
                                    result.productServiceAdjustmentResponseList = objectContext.Translate<ProductServiceAdjustmentResponse>(reader).ToList();
                                    break;
                            }
                            reader.NextResult();
                            result.OrderTotals = objectContext.Translate<OrderTotal>(reader).FirstOrDefault();

                        }
                        finally
                        {
                            command = null;
                        }
                    }
                }
            }
            return result;

        }

        public PenaltyMainData GetPenaltyAdjustmentMainData(int orderId)
        {
            if (orderId <= 0)
                return null;
            PenaltyMainData penaltyData = new PenaltyMainData();
            using (AccountingData ctx = new AccountingData())
            {

                using (var con = ctx.Database.Connection)
                {
                    var command = con.CreateCommand();
                    command.CommandText = "act.GetPenaltyMainData @OrderId";
                    var ParamOrderId = new SqlParameter { ParameterName = "OrderId", Value = orderId, DbType = System.Data.DbType.Int32 };
                    command.Parameters.Add(ParamOrderId);
                    try
                    {
                        con.Open();
                        var reader = command.ExecuteReader();
                        var objectContext = ((IObjectContextAdapter)ctx).ObjectContext;

                        penaltyData.PenaltyAdjustmentDetailList = objectContext.Translate<PenaltyAdjustmentDetail>(reader).ToList();
                        reader.NextResult();
                        penaltyData.PenaltyVwoDetailsList = objectContext.Translate<PenaltyVendorWorkOrderDetail>(reader).ToList();
                    }
                    finally
                    {
                        command = null;
                    }

                }
                return penaltyData;
            }
        }

        public List<PenaltyAdjustmentsScoreCard> GetPenaltyAdjustmentsDataForScoreCard(int vendorWorkOrderId)
        {
            if (vendorWorkOrderId == null || vendorWorkOrderId <= 0)
                return null;

            using (AccountingData ctx = new AccountingData())
            {
                try
                {
                    var ParamVendorWorkOrderId = new SqlParameter { ParameterName = "VendorWorkOrderId", Value = vendorWorkOrderId, DbType = System.Data.DbType.Int32 };

                    var penaltyData = ctx.Database.SqlQuery<PenaltyAdjustmentsScoreCard>("[act].[GetCalculatedAdjustmentsForVendorWorkOrder] @VendorWorkOrderId", ParamVendorWorkOrderId).ToList<PenaltyAdjustmentsScoreCard>();
                    return penaltyData;
                }
                catch
                {
                    throw;
                }
            }
        }

        public bool IsMiscProduct(int orderId)
        {
            using (var ctx = new AccountingData())
            {
                List<string> miscProdCodes = new List<string>() { "INITIAL", "RENEWAL", "AMEND", "MUNLTR", "DEREG", "77", "78", "CNV", "VIO", "VAC", "REOMNTFE", "REGINSP", "VIOLNPAY" };
                var prodCode = (from o in ctx.Orders
                                join wo in ctx.WorkOrders on o.OrderId equals wo.OrderId
                                join p in ctx.Products on wo.ProductId equals p.ProductId
                                where o.SourceOrderId == orderId
                                select p.ProductCode
                                    ).FirstOrDefault();
                var isExist = miscProdCodes.Exists(p => p == prodCode);
                return isExist;
            }

        }

        public PrdSrvMainResponseDAO GetPrdSrvMainData(int? orderHirachyId, string updateGridType)
        {
            if (orderHirachyId == null || orderHirachyId <= 0)
                return null;

            const string ORDERHIERARCHYID = "OrderHierarchyId";
            const string FEETYPE = "FeeType";
            const string BILLING_PRD_SRV_ADJUSTMENT_ALL_LIST = "act.GetPrdSvcMainData  @OrderHierarchyId, @FeeType";



            object OrderHierarchyId = DBNull.Value;
            if (orderHirachyId != null) OrderHierarchyId = orderHirachyId;

            object FeeType = DBNull.Value;
            if (FeeType != null) FeeType = updateGridType;

            var ParamOrderHierarchyId = new SqlParameter { ParameterName = ORDERHIERARCHYID, Value = OrderHierarchyId, DbType = System.Data.DbType.Int32 };
            var ParamFeeType = new SqlParameter { ParameterName = FEETYPE, Value = FeeType, DbType = System.Data.DbType.String };

            PrdSrvMainResponseDAO result = new PrdSrvMainResponseDAO();
            using (AccountingData ctx = new AccountingData())
            {
                using (var con = ctx.Database.Connection)
                {
                    var command = con.CreateCommand();
                    command.CommandText = BILLING_PRD_SRV_ADJUSTMENT_ALL_LIST;

                    command.Parameters.Add(ParamOrderHierarchyId);
                    command.Parameters.Add(ParamFeeType);
                    try
                    {
                        con.Open();
                        var reader = command.ExecuteReader();
                        var objectContext = ((IObjectContextAdapter)ctx).ObjectContext;
                        //Need to create Enum which can access from UI and Here to match fee type of refresh
                        switch (updateGridType)
                        {

                            case "ALL":
                                result.flatFeeResponseList = objectContext.Translate<FlatFeeAdjustmentDetail>(reader).ToList();

                                reader.NextResult();
                                result.discountResponseList = objectContext.Translate<DiscountAdjustmentDetail>(reader).ToList();

                                reader.NextResult();
                                result.lineItemResponseList = objectContext.Translate<LineItemAdjustmentDetail>(reader).ToList();
                                break;
                            case "FLATFEE":
                                result.flatFeeResponseList = objectContext.Translate<FlatFeeAdjustmentDetail>(reader).ToList();
                                break;
                            case "DISCOUNT":
                                result.discountResponseList = objectContext.Translate<DiscountAdjustmentDetail>(reader).ToList();
                                break;
                            case "LINEITEM":
                                result.lineItemResponseList = objectContext.Translate<LineItemAdjustmentDetail>(reader).ToList();
                                break;
                        }
                        reader.NextResult();
                        result.OrderTotals = objectContext.Translate<OrderTotal>(reader).FirstOrDefault();
                    }
                    finally
                    {
                        command = null;
                    }
                }
            }

            return result;
        }

        public List<ClientFeeAdjustmentDetail> GetClientFeeAdjustmentDetail(int arAdjustmentHistoryId, int orderHierarchyId)
        {
            List<ClientFeeAdjustmentDetail> response = new List<ClientFeeAdjustmentDetail>();
            using (AccountingData acdCtx = new AccountingData())
            {
                response = (from darh in acdCtx.DisputeReceivableAdjustmentHistorys
                            where darh.OrderHierarchyId == orderHierarchyId && (darh.AdjustmentHistoryRecordType == "ADJED" || darh.AdjustmentHistoryRecordType == "ORIG")
                            select new ClientFeeAdjustmentDetail
                            {
                                AdjustmentDetailHistoryId = darh.DisputeReceivableAdjustmentHistoryId,
                                OrderId = null,
                                ARInvoiceNumber = darh.InvoiceNumber,
                                ClientTripFee = darh.ClientTripFee,
                                ClientTripFeeAdj = darh.ClientTripFeeAdjstdAmt,
                                RushFee = darh.ClientRushFee,
                                RushFeeAdj = darh.ClientRushFeeAdjstdAmt,
                                InvoicedDate = darh.InvoiceDate,
                                ClientTripFeeTaxAmount = darh.ClientTripFeeTax,
                                RushFeeTaxAmount = darh.ClientRushFeeTax,
                                AdjustmentDate = darh.AdjustmentHistoryRecordType == "ORIG" ? null : (DateTime?)darh.CreatedDate,
                                RecType = darh.AdjustmentHistoryRecordType,
                                Comments = darh.ClientAdjComments,
                                RecordNumber = darh.RecordNumber,
                                OrderHierarchyId = darh.OrderHierarchyId
                            }).OrderByDescending(t => t.AdjustmentDate).ToList();
            }
            if (response != null && response.Count > 1)
                return response;
            else
                return null;
        }

        public List<VendorFeeAdjustmentDetail> GetVendorFeeAdjustmentDetail(int arAdjustmentHistoryId, int orderHierarchyId)
        {
            List<VendorFeeAdjustmentDetail> response = new List<VendorFeeAdjustmentDetail>();
            using (AccountingData acdCtx = new AccountingData())
            {
                response = (from daph in acdCtx.DisputePayableAdjustmentHistorys
                            join oh in acdCtx.OrderHierarchys on daph.OrderHierarchyId equals oh.OrderHierarchyId
                            join vwo in acdCtx.VendorWorkOrders on oh.VendorWorkOrderId equals vwo.VendorWorkOrderId
                            where daph.OrderHierarchyId == orderHierarchyId && (daph.AdjustmentHistoryRecordType == "ADJED" || daph.AdjustmentHistoryRecordType == "ORIG")
                            select new VendorFeeAdjustmentDetail
                            {
                                AdjustmentDetailHistoryId = daph.DisputePayableAdjustmentHistoryId,
                                AdjustmentDate = daph.AdjustmentHistoryRecordType == "ORIG" ? null : (DateTime?)daph.CreatedDate,
                                Comments = daph.VendorAdjComments,
                                SupplierComment = daph.SupplierComment,
                                InvoicedDate = daph.InvoiceDate,
                                MinServiceFee = daph.VendorMinServiceFee,
                                MinServiceFeeAdjAmount = daph.VendorMinServiceFeeAdjstdAmt,
                                OneTimeFee = daph.VendorOneTimeFee,
                                OneTimeFeeAdjAmount = daph.VendorOneTimeFeeAdjstdAmt,
                                RecType = daph.AdjustmentHistoryRecordType,
                                TripFee = daph.VendorTripFee,
                                TripFeeAdjAmount = daph.VendorTripFeeAdjstdAmt,
                                VendorId = vwo.AssignedVendorId,
                                VendorWorkOrderId = vwo.VendorWorkOrderId,
                                RecordNumber = daph.RecordNumber,
                                OrderHierarchyId = daph.OrderHierarchyId,
                                InvoiceNumber = daph.InvoiceNumber
                            }).OrderByDescending(t => t.AdjustmentDate).ToList();
            }
            if (response != null && response.Count > 1)
                return response;
            else
                return null;
        }

        private bool IsLineItemExists(int orderHierarchyId)
        {
            using (AccountingData acdCtx = new AccountingData())
            {
                var workOrderItemId = (from oh in acdCtx.OrderHierarchys
                                       where oh.OrderHierarchyId == orderHierarchyId
                                       select oh.WorkOrderItemId).FirstOrDefault();
                if (workOrderItemId > 0)
                {
                    var dat1 = (from oh in acdCtx.OrderHierarchys
                                join dr in acdCtx.DisputeReceivableAdjustmentHistorys on oh.OrderHierarchyId equals dr.OrderHierarchyId
                                where oh.WorkOrderItemId == workOrderItemId && oh.WorkOrderLineItemId != null
                                select oh.OrderHierarchyId).Count();
                    return dat1 > 0;
                }
            }
            return false;
        }

        private int GetVendorId(int orderHierarchyId, AccountingData acdCtx)
        {
            var vendId = (from oh in acdCtx.OrderHierarchys
                          join vwo in acdCtx.VendorWorkOrders on oh.VendorWorkOrderId equals vwo.VendorWorkOrderId
                          where oh.OrderHierarchyId == orderHierarchyId
                          select vwo.AssignedVendorId
                                     ).FirstOrDefault();
            return vendId.GetValueOrDefault();
        }

        public List<FlatFeeAdjustmentDetail> GetFlatFeeAdjustmentDetail(int arAdjustmentHistoryId, int orderHierarchyId)
        {
            List<FlatFeeAdjustmentDetail> response = new List<FlatFeeAdjustmentDetail>();
            using (AccountingData acdCtx = new AccountingData())
            {
                var isLineItemExist = IsLineItemExists(orderHierarchyId);

                var vendId = GetVendorId(orderHierarchyId, acdCtx);

                if (isLineItemExist)
                {
                    response = (from daph in acdCtx.DisputePayableAdjustmentHistorys
                                join oh in acdCtx.OrderHierarchys on daph.OrderHierarchyId equals oh.OrderHierarchyId
                                where daph.OrderHierarchyId == orderHierarchyId &&
                                        ((daph.AdjustmentHistoryRecordType == "ADJED" && (daph.VendorFlatFee != null || daph.VendorFlatFeeAdjstdAmt != null)) || daph.AdjustmentHistoryRecordType == "ORIG")

                                select new FlatFeeAdjustmentDetail
                                {
                                    AdjustmentDetailHistoryId = daph.DisputePayableAdjustmentHistoryId,
                                    AdjustmentDate = daph.AdjustmentHistoryRecordType == "ORIG" ? null : (DateTime?)daph.HistoryDate,
                                    Comments = daph.VendorAdjComments,
                                    SupplierComment = daph.SupplierComment,
                                    OrderHierarchyId = daph.OrderHierarchyId,
                                    FlatFeeAmount = daph.VendorFlatFee,
                                    FlatFeeAdjAmount = daph.VendorFlatFeeAdjstdAmt,
                                    RecType = daph.AdjustmentHistoryRecordType,
                                    RecordNumber = daph.RecordNumber,
                                    ClientPrice = null,
                                    ArRecordNumber = null,
                                    ArInvoiceNumber = null,
                                    ArInvoiceDate = null,
                                    DisputeReceivableAdjustmentHistoryId = null,
                                    ClientPriceAdjstdAmt = null,
                                    InvoicedDate = daph.InvoiceDate,
                                    ApInvoiceNumber = daph.InvoiceNumber,
                                    VendorId = vendId


                                }).OrderByDescending(t => t.AdjustmentDate).ToList();
                }
                else
                {
                    response = (from daph in acdCtx.DisputePayableAdjustmentHistorys
                                join oh in acdCtx.OrderHierarchys on daph.OrderHierarchyId equals oh.OrderHierarchyId
                                join drah in acdCtx.DisputeReceivableAdjustmentHistorys on oh.OrderHierarchyId equals drah.OrderHierarchyId
                                where
                                (daph.OrderHierarchyId == orderHierarchyId && ((daph.AdjustmentHistoryRecordType == "ADJED" && daph.AdjustmentType == "FlatFee") || daph.AdjustmentHistoryRecordType == "ORIG")) &&
                                (drah.OrderHierarchyId == orderHierarchyId && ((drah.AdjustmentHistoryRecordType == "ADJED" && drah.AdjustmentType == "FlatFee") || drah.AdjustmentHistoryRecordType == "ORIG")) &&
                                    //(daph.OrderHierarchyId == orderHierarchyId && ((daph.AdjustmentHistoryRecordType == "ADJED" && (daph.VendorFlatFee != null || daph.VendorFlatFeeAdjstdAmt != null)) || daph.AdjustmentHistoryRecordType == "ORIG")) &&
                                    //(drah.OrderHierarchyId == orderHierarchyId && ((drah.AdjustmentHistoryRecordType == "ADJED" && (drah.ClientPrice != null || drah.ClientPriceAdjstdAmt != null)) || drah.AdjustmentHistoryRecordType == "ORIG")) &&
                                drah.RecordNumber == daph.RecordNumber

                                select new FlatFeeAdjustmentDetail
                                {
                                    AdjustmentDetailHistoryId = daph.DisputePayableAdjustmentHistoryId,
                                    AdjustmentDate = daph.AdjustmentHistoryRecordType == "ORIG" ? null : (DateTime?)daph.HistoryDate,
                                    Comments = daph.VendorAdjComments,
                                    SupplierComment = daph.SupplierComment,
                                    OrderHierarchyId = daph.OrderHierarchyId,
                                    FlatFeeAmount = daph.VendorFlatFee,
                                    FlatFeeAdjAmount = daph.VendorFlatFeeAdjstdAmt,
                                    RecType = daph.AdjustmentHistoryRecordType,
                                    RecordNumber = daph.RecordNumber,
                                    ClientPrice = drah.ClientPrice,
                                    ArRecordNumber = drah.RecordNumber,
                                    ArInvoiceNumber = drah.InvoiceNumber,
                                    ArInvoiceDate = drah.InvoiceDate,
                                    DisputeReceivableAdjustmentHistoryId = drah.DisputeReceivableAdjustmentHistoryId,
                                    ClientPriceAdjstdAmt = drah.ClientPriceAdjstdAmt,
                                    InvoicedDate = daph.InvoiceDate,
                                    ApInvoiceNumber = daph.InvoiceNumber,
                                    VendorId = vendId

                                }).OrderByDescending(t => t.AdjustmentDate).ToList();
                }
            }
            if (response != null && response.Count > 1)
                return response;
            else
                return null;
        }

        public List<DiscountAdjustmentDetail> GetDiscountAdjustmentDetail(int arAdjustmentHistoryId, int orderHierarchyId)
        {
            List<DiscountAdjustmentDetail> response = new List<DiscountAdjustmentDetail>();
            using (AccountingData acdCtx = new AccountingData())
            {
                var vendId = GetVendorId(orderHierarchyId, acdCtx);
                response = (from daph in acdCtx.DisputePayableAdjustmentHistorys
                            join oh in acdCtx.OrderHierarchys on daph.OrderHierarchyId equals oh.OrderHierarchyId
                            where daph.OrderHierarchyId == orderHierarchyId &&
                            ((daph.AdjustmentHistoryRecordType == "ADJED" && daph.AdjustmentType == "Discount" && (daph.VendorDiscountPercentage != null || daph.VendorDiscountAdjPercentage != null))
                                || daph.AdjustmentHistoryRecordType == "ORIG")

                            select new DiscountAdjustmentDetail
                            {
                                AdjustmentDetailHistoryId = daph.DisputePayableAdjustmentHistoryId,
                                AdjustmentDate = daph.AdjustmentHistoryRecordType == "ORIG" ? null : (DateTime?)daph.HistoryDate,
                                Comments = daph.VendorAdjComments,
                                SupplierComment = daph.SupplierComment,
                                OrderHierarchyId = daph.OrderHierarchyId,
                                DiscountPercent = daph.VendorDiscountPercentage,
                                DiscountPercentAdjsted = daph.VendorDiscountAdjPercentage,
                                RecType = daph.AdjustmentHistoryRecordType,
                                RecordNumber = daph.RecordNumber,
                                ApInvoiceNumber = daph.InvoiceNumber,
                                VendorId = vendId
                            }).OrderByDescending(t => t.AdjustmentDate).ToList();
            }
            if (response != null && response.Count > 1)
                return response;
            else
                return null;
        }

        public List<LineItemAdjustmentDetail> GetLineItemAdjustmentDetail(int arAdjustmentHistoryId, int orderHierarchyId)
        {
            List<LineItemAdjustmentDetail> response = new List<LineItemAdjustmentDetail>();
            using (AccountingData acdCtx = new AccountingData())
            {
                var vendId = GetVendorId(orderHierarchyId, acdCtx);

                response = (from daph in acdCtx.DisputePayableAdjustmentHistorys
                            join oh in acdCtx.OrderHierarchys on daph.OrderHierarchyId equals oh.OrderHierarchyId
                            join drah in acdCtx.DisputeReceivableAdjustmentHistorys on oh.OrderHierarchyId equals drah.OrderHierarchyId
                            //  join woli in acdCtx.WorkOrderLineItems on oh.WorkOrderLineItemId equals woli.WorkOrderLineItemId
                            where (daph.OrderHierarchyId == orderHierarchyId && (daph.AdjustmentHistoryRecordType == "ADJED" || daph.AdjustmentHistoryRecordType == "ORIG"))
                            && (drah.OrderHierarchyId == orderHierarchyId && (drah.AdjustmentHistoryRecordType == "ADJED" || drah.AdjustmentHistoryRecordType == "ORIG"))
                            && (daph.RecordNumber == drah.RecordNumber)
                            select new LineItemAdjustmentDetail
                            {
                                AdjustmentDetailHistoryId = daph.DisputePayableAdjustmentHistoryId,
                                OrderHierarchyId = daph.OrderHierarchyId,
                                ClientPrice = drah.ClientPrice,
                                ClientUnitPrice = drah.AgreedClientUnitPrice,
                                Comments = daph.VendorAdjComments,
                                SupplierComment = daph.SupplierComment,
                                InvoicedDate = drah.InvoiceDate,
                                LineItemDescription = drah.LineItemDescription,// woli.LineItemName,
                                Quantity = drah.Quantity, //- (drah.QuantityAdjusted==null?0:drah.QuantityAdjusted),

                                TaxAmount = drah.ClientPriceTax,
                                UnitOfMeasure = drah.UnitOfMeasure,
                                VendorFee = daph.VendorFee,
                                VendorFeeAfterDiscount = daph.VendorFinalFee,
                                VendorUnitCost = daph.AgreedUnitCost,
                                ApRecType = daph.AdjustmentHistoryRecordType,
                                APRecordNumber = daph.RecordNumber,
                                ARRecordNumber = drah.RecordNumber,
                                ClientPriceAdjAmt = drah.ClientPriceAdjstdAmt,
                                VendorFeeAdjAmt = daph.VendorFinalFeeAdjstdAmt,
                                AdjustmentDate = daph.AdjustmentHistoryRecordType == "ORIG" ? null : (DateTime?)daph.HistoryDate,
                                ArInvoiceNumber = drah.InvoiceNumber,
                                ApInvoiceNumber = daph.InvoiceNumber,
                                ApInvoicedDate = daph.InvoiceDate,
                                VendorId = vendId,
                                PerformedQuantity = drah.Quantity,

                            }).OrderByDescending(t => t.AdjustmentDetailHistoryId).ToList();
            }
            if (response != null && response.Count > 1)
                return response;
            else
                return null;

        }

        public List<MiscAdjustmentDetail> GetMiscProductAdjustmentDetail(int historyId, int orderHierarchyId, string type, int? feeTypeId, int? feeTypeRefId)
        {

            var response = new List<MiscAdjustmentDetail>();
            using (AccountingData ctx = new AccountingData())
            {
                if (type == "AP")
                {
                    response = (
                            from daph in ctx.DisputePayableAdjustmentHistorys
                            join oh in ctx.OrderHierarchys on daph.OrderHierarchyId equals oh.OrderHierarchyId
                            join o in ctx.Orders on oh.OrderId equals o.OrderId
                            join wo in ctx.WorkOrders on oh.WorkOrderId equals wo.WorkOrderId
                            join p in ctx.Products on wo.ProductId equals p.ProductId
                            join ft in ctx.FeeTypes on daph.FeeTypeId equals ft.FeeTypeId into leftFtype
                            from lft in leftFtype.DefaultIfEmpty()
                            where
                                    daph.OrderHierarchyId == orderHierarchyId &&
                                ((daph.AdjustmentHistoryRecordType == "ADJED" && (daph.VendorFee != null || daph.VendorFeeAdjstdAmt != null)) || daph.AdjustmentHistoryRecordType == "ORIG")
                                && ((feeTypeId == null && daph.FeeTypeId == null) || daph.FeeTypeId == feeTypeId.Value)
                                && ((feeTypeRefId == null && daph.FeeTypePaymentRefId == null) || daph.FeeTypePaymentRefId == feeTypeRefId.Value)
                            select new MiscAdjustmentDetail
                            {
                                AdjustmentDate = daph.AdjustmentHistoryRecordType == "ORIG" ? null : (DateTime?)daph.CreatedDate,
                                Comments = daph.VendorAdjComments,
                                SupplierComment = daph.SupplierComment,
                                Cost = daph.VendorFinalFee.HasValue ? daph.VendorFinalFee : daph.VendorFee,
                                CostAdjustment = daph.VendorFeeAdjstdAmt,
                                FeeTypeId = daph.FeeTypeId,
                                FeeType = lft.FeeTypeName,
                                Id = daph.DisputePayableAdjustmentHistoryId,
                                IdType = "AP",
                                InvoicedDate = daph.InvoiceDate,
                                InvoiceNumber = daph.InvoiceNumber,
                                OrderHierarchyId = daph.OrderHierarchyId,
                                OrderId = o.SourceOrderId,
                                Product = p.ProductName,
                                RecordNumber = daph.RecordNumber,
                                RecType = daph.AdjustmentHistoryRecordType,
                                Tax = null,
                                WorkOrderId = wo.SourceWorkOrderId,
                                FeeTypeRefId = daph.FeeTypePaymentRefId,
                                VendorId = wo.AssignedVendorId,
                                ProductCode = p.ProductCode
                            }
                        ).OrderByDescending(p => p.AdjustmentDate).ToList();
                }
                else
                {
                    response = (
                    from daph in ctx.DisputeReceivableAdjustmentHistorys
                    join oh in ctx.OrderHierarchys on daph.OrderHierarchyId equals oh.OrderHierarchyId
                    join o in ctx.Orders on oh.OrderId equals o.OrderId
                    join wo in ctx.WorkOrders on oh.WorkOrderId equals wo.WorkOrderId
                    join p in ctx.Products on wo.ProductId equals p.ProductId
                    join ft in ctx.FeeTypes on daph.FeeTypeId equals ft.FeeTypeId into leftFtype
                    from lft in leftFtype.DefaultIfEmpty()
                    where
                        daph.OrderHierarchyId == orderHierarchyId &&
                        ((daph.AdjustmentHistoryRecordType == "ADJED" && (daph.ClientPrice != null || daph.ClientPriceAdjstdAmt != null)) || daph.AdjustmentHistoryRecordType == "ORIG")
                       && ((feeTypeId == null && daph.FeeTypeId == null) || daph.FeeTypeId == feeTypeId.Value)
                       && ((feeTypeRefId == null && daph.FeeTypePaymentRefId == null) || daph.FeeTypePaymentRefId == feeTypeRefId.Value)
                    select new MiscAdjustmentDetail
                    {
                        AdjustmentDate = daph.AdjustmentHistoryRecordType == "ORIG" ? null : (DateTime?)daph.CreatedDate,
                        Comments = daph.ClientAdjComments,
                        Cost = daph.ClientPrice,
                        CostAdjustment = daph.ClientPriceAdjstdAmt,
                        FeeTypeId = daph.FeeTypeId,
                        FeeType = lft.FeeTypeName,
                        Id = daph.DisputeReceivableAdjustmentHistoryId,
                        IdType = "AR",
                        InvoicedDate = daph.InvoiceDate,
                        InvoiceNumber = daph.InvoiceNumber,
                        OrderHierarchyId = daph.OrderHierarchyId,
                        OrderId = o.SourceOrderId,
                        Product = p.ProductName,
                        RecordNumber = daph.RecordNumber,
                        RecType = daph.AdjustmentHistoryRecordType,
                        Tax = daph.ClientPriceTax,
                        WorkOrderId = wo.SourceWorkOrderId,
                        FeeTypeRefId = daph.FeeTypePaymentRefId,
                        VendorId = wo.AssignedVendorId,
                        ProductCode = p.ProductCode

                    }
                ).OrderByDescending(p => p.AdjustmentDate).ToList();
                }
            }

            return response;
        }

        public List<PenaltyAdjustmentDetail> GetPenaltyAdjustmentDetail(string achievementName, int orderHierarchyId)
        {
            var response = new List<PenaltyAdjustmentDetail>();
            using (AccountingData ctx = new AccountingData())
            {
                var vendId = GetVendorId(orderHierarchyId, ctx);
                response = (
                            from dpah in ctx.DisputePenaltyAdjustmentHistories
                            join oh in ctx.OrderHierarchys on dpah.OrderHierarchyId equals oh.OrderHierarchyId
                            join o in ctx.Orders on oh.OrderId equals o.OrderId
                            join wo in ctx.WorkOrders on oh.WorkOrderId equals wo.WorkOrderId into leftwo
                            from lftwo in leftwo.DefaultIfEmpty()
                            join woi in ctx.WorkOrderItems on oh.WorkOrderItemId equals woi.WorkOrderItemId into leftwoi
                            from lftwoi in leftwoi.DefaultIfEmpty()
                            join p in ctx.Products on lftwoi.ProductId equals p.ProductId into leftprd
                            from lftprd in leftprd.DefaultIfEmpty()
                            join s in ctx.Services on lftwoi.ServiceId equals s.ServiceId into leftsvc
                            from lftsvc in leftsvc.DefaultIfEmpty()

                            where oh.OrderHierarchyId == orderHierarchyId && dpah.AchievementName == achievementName &&
                            (dpah.RecordType == "ADJED" || dpah.RecordType == "ORIG")
                            select new PenaltyAdjustmentDetail
                            {
                                AchievementName = dpah.AchievementName,
                                AdjustmentDate = dpah.AdjustmentDate,
                                Comments = dpah.Comments,
                                GoalName = dpah.GoalName,
                                DisputePenaltyAdjustmentHistoryId = dpah.DisputePenaltyAdjustmentHistoryId,
                                InvoiceDate = dpah.InvoiceDate,
                                InvoiceNumber = dpah.InvoiceNumber,
                                OrderHierarchyId = dpah.OrderHierarchyId,
                                OrderId = oh.OrderId,
                                PenaltyAdjustmentAmount = dpah.AdjustmentAmount,
                                PenaltyAmount = dpah.PenaltyAmount,
                                RecordNumber = dpah.RecordNumber,
                                RecType = dpah.RecordType,
                                VendorWorkOrderId = oh.VendorWorkOrderId,
                                WorkOrderId = lftwo.SourceWorkOrderId,
                                Version = dpah.Version,
                                ProductName = lftprd.ProductName,
                                ServiceName = lftsvc.ServiceName,
                                AssignedVendorId = vendId,
                                ApplicationId = dpah.ApplicationId,
                                FeeTypeId = dpah.FeeTypeId
                            }).OrderByDescending(p => p.AdjustmentDate).ToList();
            }

            return response;
        }

        public List<CronologicalAdjustmentListResponseDAO> GetCronologicalAdjustments(int? orderId)
        {
            if (orderId == null || orderId <= 0)
                return null;

            const string ORDERID = "OrderId";
            const string BILLING_ADJ_CRONOLOGICAL = "act.GetCronologicalAdjustments @OrderId";

            object OrderId = DBNull.Value;
            if (orderId != null) OrderId = orderId;

            var ParamOrderId = new SqlParameter { ParameterName = ORDERID, Value = orderId, DbType = System.Data.DbType.Int32 };

            List<CronologicalAdjustmentListResponseDAO> results = null;
            using (AccountingData ctx = new AccountingData())
            {
                results = ctx.Database.SqlQuery<CronologicalAdjustmentListResponseDAO>(BILLING_ADJ_CRONOLOGICAL, ParamOrderId).ToList<CronologicalAdjustmentListResponseDAO>();
            }

            return results;
        }

        public DisputePayableAdjustmentHistory SaveDisputePayableAdjustmentHistory(DisputePayableAdjustmentHistory disputePayableAdjustmentHistory)
        {
            DisputePayableAdjustmentHistory result = null;
            if (disputePayableAdjustmentHistory != null)
            {
                using (AccountingData ctx = new AccountingData())
                {
                    result = ctx.UpdateGraph(disputePayableAdjustmentHistory);
                    ctx.SaveChanges();
                }
            }
            return result;
        }

        public DisputeReceivableAdjustmentHistory SaveDisputeReceivableAdjustmentHistory(DisputeReceivableAdjustmentHistory disputeReceivableAdjustmentHistory)
        {
            DisputeReceivableAdjustmentHistory result = null;
            if (disputeReceivableAdjustmentHistory != null)
            {
                using (AccountingData ctx = new AccountingData())
                {
                    result = ctx.UpdateGraph(disputeReceivableAdjustmentHistory);
                    ctx.SaveChanges();
                }
            }
            return result;
        }

        public DisputePenaltyAdjustmentHistory SaveDisputePenaltyAdjustmentHistory(DisputePenaltyAdjustmentHistory disputePenaltyAdjustmentHistory)
        {
            try
            {
                DisputePenaltyAdjustmentHistory result = null;
                if (disputePenaltyAdjustmentHistory != null)
                {
                    using (AccountingData ctx = new AccountingData())
                    {
                        result = ctx.UpdateGraph(disputePenaltyAdjustmentHistory);
                        ctx.SaveChanges();
                    }
                }
                return result;
            }
            catch
            {
                throw;
            }
        }

        public DisputePayableAdjustmentHistory GetDisputePayableAdjustmentHistory(int disputePayableAdjustmentHistoryId)
        {
            DisputePayableAdjustmentHistory result = null;
            if (disputePayableAdjustmentHistoryId > 0)
            {
                using (AccountingData ctx = new AccountingData())
                {
                    result = ctx.DisputePayableAdjustmentHistorys
                        .Include("OrderHierarchy.AccountsPayableDetails.FeeType")
                        .Include("AccountsPayableAdjustments")
                        .Where(id => id.DisputePayableAdjustmentHistoryId == disputePayableAdjustmentHistoryId).FirstOrDefault();
                }
            }
            return result;
        }

        public DisputeReceivableAdjustmentHistory GetDisputeReceivableAdjustmentHistory(int disputeReceivableAdjustmentHistoryId)
        {
            DisputeReceivableAdjustmentHistory result = null;
            if (disputeReceivableAdjustmentHistoryId > 0)
            {
                using (AccountingData ctx = new AccountingData())
                {
                    result = ctx.DisputeReceivableAdjustmentHistorys
                        .Include("OrderHierarchy.AccountsReceivableDetails.FeeType")
                        .Include("AccountsReceivableAdjustments")
                        .Where(disp => disp.DisputeReceivableAdjustmentHistoryId == disputeReceivableAdjustmentHistoryId).FirstOrDefault();
                }
            }
            return result;
        }

        public AccountsReceivableAdjustment SaveAccountsReceivableAdjustment(AccountsReceivableAdjustment accountsReceivableAdjustment)
        {
            if (accountsReceivableAdjustment != null)
            {
                using (AccountingData ctx = new AccountingData())
                {
                    accountsReceivableAdjustment = ctx.UpdateGraph(accountsReceivableAdjustment);
                    ctx.SaveChanges();
                }
            }
            return accountsReceivableAdjustment;
        }

        public bool UpdateArStatusPending(List<int> adjustmentIds)
        {
            using (var ctx = new AccountingData())
            {
                var adjs = (from a in ctx.AccountsReceivableAdjustments
                            where
                                adjustmentIds.Contains(a.AccountsReceivableAdjustmentId)
                            select a).ToList();
                if (adjs != null && adjs.Count > 0)
                {
                    foreach (var adj in adjs)
                        adj.ARAdjStatusType = "PENDING";

                    ctx.SaveChanges();
                }

                return true;
            }
        }

        public AccountsPayableAdjustment SaveAccountsPayableAdjustment(AccountsPayableAdjustment accountsPayableAdjustment)
        {
            AccountsPayableAdjustment result = null;
            if (accountsPayableAdjustment != null)
            {
                using (AccountingData ctx = new AccountingData())
                {
                    result = ctx.UpdateGraph(accountsPayableAdjustment);
                    ctx.SaveChanges();
                }
            }
            return result;
        }


        public DisputePayableAdjustmentHistory GetLatestDisputePayableAdjustmentHistory(int orderHierachyId)
        {
            if (orderHierachyId <= 0)
                return null;

            DisputePayableAdjustmentHistory result = null;
            using (AccountingData ctx = new AccountingData())
            {
                var response = from daph in ctx.DisputePayableAdjustmentHistorys
                               where daph.OrderHierarchyId == orderHierachyId && daph.AdjustmentHistoryRecordType == "FINAL"
                               select daph.DisputePayableAdjustmentHistoryId;

                if (response != null && response.FirstOrDefault<int>() > 0)
                    result = GetDisputePayableAdjustmentHistory(response.FirstOrDefault<int>());
                else
                {
                    response = from daph in ctx.DisputePayableAdjustmentHistorys
                               where daph.OrderHierarchyId == orderHierachyId && daph.AdjustmentHistoryRecordType == "ORIG"
                               select daph.DisputePayableAdjustmentHistoryId;

                    if (response != null && response.FirstOrDefault<int>() > 0)
                        result = GetDisputePayableAdjustmentHistory(response.FirstOrDefault<int>());
                }

            }

            return result;
        }

        public DisputePayableAdjustmentHistory GetLatestDisputePayableAdjustmentHistory(int orderHierachyId, int? feeTypeId, int? feeTypeRefId)
        {
            if (orderHierachyId <= 0)
                return null;

            DisputePayableAdjustmentHistory result = null;
            using (AccountingData ctx = new AccountingData())
            {
                var response = from daph in ctx.DisputePayableAdjustmentHistorys
                               where daph.OrderHierarchyId == orderHierachyId && daph.FeeTypeId == feeTypeId &&
                                     daph.FeeTypePaymentRefId == feeTypeRefId && daph.AdjustmentHistoryRecordType == "FINAL"
                               select daph.DisputePayableAdjustmentHistoryId;

                if (response != null && response.FirstOrDefault<int>() > 0)
                    result = GetDisputePayableAdjustmentHistory(response.FirstOrDefault<int>());
                else
                {
                    response = from daph in ctx.DisputePayableAdjustmentHistorys
                               where daph.OrderHierarchyId == orderHierachyId && daph.FeeTypeId == feeTypeId &&
                                     daph.FeeTypePaymentRefId == feeTypeRefId && daph.AdjustmentHistoryRecordType == "ORIG"
                               select daph.DisputePayableAdjustmentHistoryId;
                    if (response != null && response.FirstOrDefault<int>() > 0)
                        result = GetDisputePayableAdjustmentHistory(response.FirstOrDefault<int>());
                }
            }
            return result;
        }

        public DisputeReceivableAdjustmentHistory GetLatestDisputeReceivableAdjustmentHistory(int orderHierachyId)
        {
            if (orderHierachyId <= 0)
                return null;

            DisputeReceivableAdjustmentHistory result = null;
            using (AccountingData ctx = new AccountingData())
            {
                var response = from darh in ctx.DisputeReceivableAdjustmentHistorys
                               where darh.OrderHierarchyId == orderHierachyId && darh.AdjustmentHistoryRecordType == "FINAL"
                               select darh.DisputeReceivableAdjustmentHistoryId;

                if (response != null && response.FirstOrDefault<int>() > 0)
                    result = GetDisputeReceivableAdjustmentHistory(response.FirstOrDefault<int>());
                else
                {
                    response = from darh in ctx.DisputeReceivableAdjustmentHistorys
                               where darh.OrderHierarchyId == orderHierachyId && darh.AdjustmentHistoryRecordType == "ORIG"
                               select darh.DisputeReceivableAdjustmentHistoryId;

                    if (response != null && response.FirstOrDefault<int>() > 0)
                        result = GetDisputeReceivableAdjustmentHistory(response.FirstOrDefault<int>());
                }

            }

            return result;
        }

        public DisputeReceivableAdjustmentHistory GetLatestDisputeReceivableAdjustmentHistory(int orderHierachyId, int? feeTypeId, int? feeTypeRefId)
        {
            if (orderHierachyId <= 0)
                return null;

            DisputeReceivableAdjustmentHistory result = null;
            using (AccountingData ctx = new AccountingData())
            {
                var response = from darh in ctx.DisputeReceivableAdjustmentHistorys
                               where darh.OrderHierarchyId == orderHierachyId && darh.FeeTypeId == feeTypeId &&
                                     darh.FeeTypePaymentRefId == feeTypeRefId && darh.AdjustmentHistoryRecordType == "FINAL"
                               select darh.DisputeReceivableAdjustmentHistoryId;

                if (response != null && response.FirstOrDefault<int>() > 0)
                    result = GetDisputeReceivableAdjustmentHistory(response.FirstOrDefault<int>());
                else
                {
                    response = from darh in ctx.DisputeReceivableAdjustmentHistorys
                               where darh.OrderHierarchyId == orderHierachyId && darh.FeeTypeId == feeTypeId &&
                                     darh.FeeTypePaymentRefId == feeTypeRefId && darh.AdjustmentHistoryRecordType == "ORIG"
                               select darh.DisputeReceivableAdjustmentHistoryId;

                    if (response != null && response.FirstOrDefault<int>() > 0)
                        result = GetDisputeReceivableAdjustmentHistory(response.FirstOrDefault<int>());
                }
            }
            return result;
        }

        public DisputePenaltyAdjustmentHistory GetDisputePenaltyAdjustmentHistory(int orderHierachyId, string achievementName)
        {
            if (orderHierachyId <= 0)
                return null;

            using (AccountingData ctx = new AccountingData())
            {
                try
                {
                    var response = ctx.DisputePenaltyAdjustmentHistories.FirstOrDefault(x => x.OrderHierarchyId == orderHierachyId && x.RecordType == "FINAL" && x.AchievementName == achievementName);
                    if (response == null)
                    {
                        response = ctx.DisputePenaltyAdjustmentHistories.FirstOrDefault(x => x.OrderHierarchyId == orderHierachyId && x.RecordType == "ORIG" && x.AchievementName == achievementName);
                    }
                    return response;
                }
                catch
                {
                    throw;
                }
            }
        }

        public DisputePayableAdjustmentHistory GetWorkItemLatestPayableAdjustmentHistory(int lineItemrderHierachyId)
        {
            if (lineItemrderHierachyId <= 0)
                return null;

            DisputePayableAdjustmentHistory result = null;
            using (AccountingData ctx = new AccountingData())
            {
                var response = from oh in ctx.OrderHierarchys
                               where oh.WorkOrderItemId == (from ohli in ctx.OrderHierarchys
                                                            where ohli.OrderHierarchyId == lineItemrderHierachyId
                                                            select ohli.WorkOrderItemId).FirstOrDefault()
                                                            && oh.WorkOrderLineItemId == null
                               select oh.OrderHierarchyId;

                if (response != null && response.FirstOrDefault<int>() > 0)
                    result = GetLatestDisputePayableAdjustmentHistory(response.FirstOrDefault<int>());
            }

            return result;
        }

        public DisputeReceivableAdjustmentHistory GetWorkItemLatestReceivableAdjustmentHistory(int lineItemrderHierachyId)
        {
            if (lineItemrderHierachyId <= 0)
                return null;

            DisputeReceivableAdjustmentHistory result = null;
            using (AccountingData ctx = new AccountingData())
            {
                var response = from oh in ctx.OrderHierarchys
                               where oh.WorkOrderItemId == (from ohli in ctx.OrderHierarchys
                                                            where ohli.OrderHierarchyId == lineItemrderHierachyId
                                                            select ohli.WorkOrderItemId).FirstOrDefault()
                                                            && oh.WorkOrderLineItemId == null
                               select oh.OrderHierarchyId;

                if (response != null && response.FirstOrDefault<int>() > 0)
                    result = GetLatestDisputeReceivableAdjustmentHistory(response.FirstOrDefault<int>());
            }

            return result;
        }

        public List<AdjustmentLineItem> GetLineItemsForWoItem(int woiHierachyId)
        {
            if (woiHierachyId <= 0) return null;
            List<AdjustmentLineItem> lineItems = new List<AdjustmentLineItem>();

            using (AccountingData ctx = new AccountingData())
            {
                var response = (from oh in ctx.OrderHierarchys
                                where oh.WorkOrderItemId == (from ohli in ctx.OrderHierarchys
                                                             where ohli.OrderHierarchyId == woiHierachyId
                                                             select ohli.WorkOrderItemId).FirstOrDefault()
                                                             && oh.WorkOrderLineItemId != null
                                select oh.OrderHierarchyId).ToList();

                if (response != null)
                {
                    response.ForEach(p =>
                    {
                        lineItems.Add(new AdjustmentLineItem()
                        {
                            Payable = GetLatestDisputePayableAdjustmentHistory(p),
                            Receivable = GetLatestDisputeReceivableAdjustmentHistory(p)
                        });
                    });
                }
            }
            return lineItems;

        }

        public int? GetAccountsReceivableId(string adjustmentType, int orderHierarchyId)
        {
            using (AccountingData ctx = new AccountingData())
            {
                var det = (from d in ctx.AccountsReceivableDetails
                           join ft in ctx.FeeTypes on d.FeeTypeId equals ft.FeeTypeId into leftFtype
                           from lft in leftFtype.DefaultIfEmpty()
                           where d.OrderHierarchyId == orderHierarchyId
                                && (d.FeeTypeId == null || adjustmentType == lft.FeeTypeCode)
                           select d.AccountsReceivableDetailId

                           ).FirstOrDefault();

                if (det == 0)
                    return null;

                return det;
            }
        }

        public int? GetAccountsReceivableByFeeTypeId(int? feeTypeId, int orderHierarchyId, int? feeTypePaymentRefId)
        {
            using (AccountingData ctx = new AccountingData())
            {
                var det = (from d in ctx.AccountsReceivableDetails
                           //join ft in ctx.FeeTypes on d.FeeTypeId equals ft.FeeTypeId into leftFtype
                           //from lft in leftFtype.DefaultIfEmpty()
                           where d.OrderHierarchyId == orderHierarchyId
                                && ((feeTypeId == null && d.FeeTypeId == null) || feeTypeId == d.FeeTypeId)
                                && (feeTypePaymentRefId == null || d.FeeTypePaymentRefId == feeTypePaymentRefId)

                           select d.AccountsReceivableDetailId

                           ).FirstOrDefault();

                if (det == 0)
                    return null;

                return det;
            }
        }

        public int? GetAccountsPayableId(string adjustmentType, int orderHierarchyId)
        {
            using (AccountingData ctx = new AccountingData())
            {
                var det = (from d in ctx.AccountsPayableDetails
                           join ft in ctx.FeeTypes on d.FeeTypeId equals ft.FeeTypeId into leftFtype
                           from lft in leftFtype.DefaultIfEmpty()
                           where d.OrderHierarchyId == orderHierarchyId
                                && (d.FeeTypeId == null || adjustmentType == lft.FeeTypeCode)
                           select d.AccountsPayableDetailId
                               ).FirstOrDefault();
                if (det == 0)
                    return null;
                return det;
            }

        }

        public int? GetAccountsPayableByFeeTypeId(int? feeTypeId, int orderHierarchyId)
        {
            using (AccountingData ctx = new AccountingData())
            {
                var det = (from d in ctx.AccountsPayableDetails
                           //join ft in ctx.FeeTypes on d.FeeTypeId equals ft.FeeTypeId into leftFtype
                           //from lft in leftFtype.DefaultIfEmpty()
                           where d.OrderHierarchyId == orderHierarchyId
                                && ((feeTypeId == null && d.FeeTypeId == null) || feeTypeId == d.FeeTypeId)
                           select d.AccountsPayableDetailId
                               ).FirstOrDefault();
                if (det == 0)
                    return null;
                return det;
            }

        }

        public int? GetAccountPayableInvoiceId(string invoiceNumber)
        {
            using (var ctx = new AccountingData())
            {
                var inv = (from i in ctx.AccountsPayableInvoices where i.InvoiceNumber == invoiceNumber select i.AccountsPayableInvoiceId).FirstOrDefault();
                if (inv > 0)
                    return inv;
                else
                    return null;

            }
        }

        public int? GetAccountReceivableInvoiceId(string invoiceNumber)
        {
            using (var ctx = new AccountingData())
            {
                var inv = (from i in ctx.AccountsReceivableInvoices where i.InvoiceNumber == invoiceNumber select i.AccountsReceivableInvoiceId).FirstOrDefault();
                if (inv > 0)
                    return inv;
                else
                    return null;

            }
        }

        public int GetLastRecordNumber(int orderHierarchyId)
        {
            using (var ctx = new AccountingData())
            {
                var recNum = (from c in ctx.DisputePayableAdjustmentHistorys where c.OrderHierarchyId == orderHierarchyId select c.RecordNumber).Max();
                return recNum;
            }
        }

        public int GetLastRecordNumber(int orderHierarchyId, int? feeTypeId, int? feeTypeRefId)
        {
            using (var ctx = new AccountingData())
            {
                var recNum = (from c in ctx.DisputePayableAdjustmentHistorys
                              where c.OrderHierarchyId == orderHierarchyId && c.FeeTypePaymentRefId == feeTypeRefId && c.FeeTypeId == feeTypeId
                              select c.RecordNumber).Max();
                return recNum;
            }
        }

        public int GetReceivableLastRecordNumber(int orderHierarchyId)
        {
            using (var ctx = new AccountingData())
            {
                var recNum = (from c in ctx.DisputeReceivableAdjustmentHistorys where c.OrderHierarchyId == orderHierarchyId select c.RecordNumber).Max();
                return recNum;
            }
        }

        public int GetPenaltyLastRecordNumber(int orderHierarchyId, string achievementName)
        {
            using (var ctx = new AccountingData())
            {
                var recNum = (from c in ctx.DisputePenaltyAdjustmentHistories where c.OrderHierarchyId == orderHierarchyId && c.AchievementName == achievementName select c.RecordNumber).Max();
                return recNum;
            }
        }

        public int GetReceivableLastRecordNumber(int orderHierarchyId, int? feeTypeId, int? feeTypeRefId)
        {
            using (var ctx = new AccountingData())
            {
                var recNum = (from c in ctx.DisputeReceivableAdjustmentHistorys
                              where c.OrderHierarchyId == orderHierarchyId && c.FeeTypePaymentRefId == feeTypeRefId && c.FeeTypeId == feeTypeId
                              select c.RecordNumber).Max();
                return recNum;
            }
        }

        public string GetProductCategory(int orderHierarchyId)
        {

            using (var ctx = new AccountingData())
            {

                var orderId = (from c in ctx.OrderHierarchys where c.OrderHierarchyId == orderHierarchyId select c.OrderId).FirstOrDefault();
                if (orderId > 0)
                {
                    var productCat = (from o in ctx.Orders where o.OrderId == orderId select o.ProductCategory).First();
                    return productCat;
                }
                return null;
            }


        }

        public bool IsAdjustmentExists(int sourceOrderId)
        {
            using (var ctx = new AccountingData())
            {
                var orderHierarchyIds = (from to in ctx.Orders
                                         join oh in ctx.OrderHierarchys on to.OrderId equals oh.OrderId
                                         join da in ctx.DisputeReceivableAdjustmentHistorys on oh.OrderHierarchyId equals da.OrderHierarchyId
                                         where to.SourceOrderId == sourceOrderId
                                         && da.AdjustmentHistoryRecordType == "ADJED" &&
                                         (
                                            (da.ClientPriceAdjstdAmt != null && da.ClientPriceAdjstdAmt != 0) ||
                                             //(da.ClientRushFeeAdjstdAmt != null && da.ClientRushFeeAdjstdAmt != 0) ||
                                            (da.ClientTripFeeAdjstdAmt != null && da.ClientTripFeeAdjstdAmt != 0)
                                          )
                                         select oh.OrderHierarchyId
                                   ).Count();
                return orderHierarchyIds > 0;
            }
        }

        public int? GetTaxServiceClass(int adjustmentId)
        {
            using (var ctx = new AccountingData())
            {

                var tax = (from adj in ctx.AccountsReceivableAdjustments
                           join act in ctx.AccountsReceivableDetails on adj.AccountsReceivableDetailId equals act.AccountsReceivableDetailId
                           join at in ctx.AccountsTaxes on act.AccountsReceivableDetailId equals at.AccountsReceivableDetailId
                           where adj.AccountsReceivableAdjustmentId == adjustmentId
                           select at.TaxServiceClass).FirstOrDefault();
                return tax;
            }
        }
    }

    public class AdjustmentLineItem
    {
        public DisputePayableAdjustmentHistory Payable;

        public DisputeReceivableAdjustmentHistory Receivable;
    }
}

