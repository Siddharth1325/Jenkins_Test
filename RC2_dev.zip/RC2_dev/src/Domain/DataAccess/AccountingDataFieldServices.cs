﻿ namespace DataAccess.Accounting
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;
    using DomainModel.Accounting;
    using CommonLib.Persistence;
    using DataAccess.Persistence;
    using DomainModel.Common;
    public partial class AccountingDataFieldServices : CustomDbContext
    {
        public const int DbUpdateConcurrencyException_ReTryLimit = 3;

        public AccountingDataFieldServices()
            :base("name=FSEntityData")
        {
            Configuration.LazyLoadingEnabled = false;
        }

        public virtual DbSet<PaymentDetail> PaymentDetails { get; set; }
        public virtual DbSet<VPRGenInformation> VPRGenInformations { get; set; }
        public virtual DbSet<OrdinanceProfile> OrdinanceProfiles { get; set; }
        public virtual DbSet<AccountingDispute> AccountingDisputes { get; set; }
        public virtual DbSet<DisputeDocument> DisputeDocuments { get; set; }
        public virtual DbSet<DisputeFollowup> DisputeFollowups { get; set; }
        public virtual DbSet<VendorDisputeComment> VendorDisputeComments { get; set; }

        public virtual DbSet<AutoCompleteEmailTemplate> AutoCompleteEmailTemplates { get; set; }
        public virtual DbSet<SupplierDispute> SupplierDisputes { get; set; }
        public virtual DbSet<SupplierDisputeDocument> SupplierDisputeDocuments { get; set; }
        public virtual DbSet<SupplierDisputeEscalation> SupplierDisputeEscalations { get; set; }
        public virtual DbSet<SupplierDisputeFollowup> SupplierDisputeFollowups { get; set; }
        public virtual DbSet<SupplierConfigurationBulkFile> SupplierConfigurationBulkFiles { get; set; }
        public virtual DbSet<SupplierDisputeExportLog> SupplierDisputeExportLogs { get; set; }
        public virtual DbSet<Document> Documents { get; set; }
        public virtual DbSet<FieldscapeWorkOrderLoad> FieldscapeWorkOrderLoads { get; set; }



        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<PaymentDetail>()
                .Property(e => e.Payee)
                .IsUnicode(false);

            modelBuilder.Entity<PaymentDetail>()
                .Property(e => e.Amount)
                .HasPrecision(19, 4);

            modelBuilder.Entity<PaymentDetail>()
                .Property(e => e.PaymentType)
                .IsUnicode(false);

            modelBuilder.Entity<PaymentDetail>()
                .Property(e => e.Version)
                .IsFixedLength();

            modelBuilder.Entity<PaymentDetail>()
                .Property(e => e.FeeTypeName)
                .IsUnicode(false);

            modelBuilder.Entity<VPRGenInformation>()
                .Property(e => e.OccupancyStatusGroup)
                .IsUnicode(false);

            modelBuilder.Entity<VPRGenInformation>()
                .Property(e => e.OccupancyStatusType)
                .IsUnicode(false);

            modelBuilder.Entity<VPRGenInformation>()
                .Property(e => e.Version)
                .IsFixedLength();

            modelBuilder.Entity<VPRGenInformation>()
                .HasMany(e => e.PaymentDetails)
                .WithRequired(e => e.VPRGenInformation)
                .WillCascadeOnDelete(false);
            #region Accounting Disputes
            modelBuilder.Entity<AccountingDispute>()
                           .Property(e => e.DisputeStatusGroup)
                           .IsUnicode(false);

            modelBuilder.Entity<AccountingDispute>()
                .Property(e => e.DisputeStatusType)
                .IsUnicode(false);

            modelBuilder.Entity<AccountingDispute>()
                .Property(e => e.DisputeTypeGroup)
                .IsUnicode(false);

            modelBuilder.Entity<AccountingDispute>()
                .Property(e => e.DisputeType)
                .IsUnicode(false);

            modelBuilder.Entity<AccountingDispute>()
                .Property(e => e.DisComments)
                .IsUnicode(false);

            modelBuilder.Entity<AccountingDispute>()
                .Property(e => e.SLFSResponseToClient)
                .IsUnicode(false);

            modelBuilder.Entity<AccountingDispute>()
                .Property(e => e.DisInternalComments)
                .IsUnicode(false);

            modelBuilder.Entity<AccountingDispute>()
                .Property(e => e.DisResolutionGroup)
                .IsUnicode(false);

            modelBuilder.Entity<AccountingDispute>()
                .Property(e => e.DisResolutionType)
                .IsUnicode(false);

            modelBuilder.Entity<AccountingDispute>()
                .Property(e => e.DisResDepartGroup)
                .IsUnicode(false);

            modelBuilder.Entity<AccountingDispute>()
                .Property(e => e.DisResDepartType)
                .IsUnicode(false);

            modelBuilder.Entity<AccountingDispute>()
                .Property(e => e.DisErrorGroup)
                .IsUnicode(false);

            modelBuilder.Entity<AccountingDispute>()
                .Property(e => e.DisErrorType)
                .IsUnicode(false);

            modelBuilder.Entity<AccountingDispute>()
                .Property(e => e.CreditClientAmount)
                .HasPrecision(19, 4);

            modelBuilder.Entity<AccountingDispute>()
                .Property(e => e.DebitClientAmount)
                .HasPrecision(19, 4);

            modelBuilder.Entity<AccountingDispute>()
                .Property(e => e.RebillNumber)
                .IsUnicode(false);

            modelBuilder.Entity<AccountingDispute>()
                .Property(e => e.DisputeAmount)
                .HasPrecision(19, 4);

            modelBuilder.Entity<AccountingDispute>()
                .Property(e => e.LoanNumber)
                .IsUnicode(false);

            modelBuilder.Entity<AccountingDispute>()
                .Property(e => e.InvoiceNumber)
                .IsUnicode(false);

            modelBuilder.Entity<AccountingDispute>()
                .Property(e => e.InvoiceAmount)
                .HasPrecision(19, 4);

            modelBuilder.Entity<AccountingDispute>()
                .Property(e => e.Version)
                .IsFixedLength();

            modelBuilder.Entity<DisputeDocument>()
                .Property(e => e.AdditionalDocGroup)
                .IsUnicode(false);

            modelBuilder.Entity<DisputeDocument>()
                .Property(e => e.AdditionalDocType)
                .IsUnicode(false);

            modelBuilder.Entity<DisputeDocument>()
                .Property(e => e.Version)
                .IsFixedLength();

            modelBuilder.Entity<DisputeFollowup>()
                .Property(e => e.FollowUpResearchGroup)
                .IsUnicode(false);

            modelBuilder.Entity<DisputeFollowup>()
                .Property(e => e.FollowUpResearchType)
                .IsUnicode(false);

            modelBuilder.Entity<DisputeFollowup>()
                .Property(e => e.Version)
                .IsFixedLength();

            modelBuilder.Entity<VendorDisputeComment>()
                .Property(e => e.VendorCreditAmount)
                .HasPrecision(19, 4);

            modelBuilder.Entity<VendorDisputeComment>()
                .Property(e => e.VendorDebitAmount)
                .HasPrecision(19, 4);

            modelBuilder.Entity<VendorDisputeComment>()
                .Property(e => e.SLFSResponseTVendor)
                .IsUnicode(false);

            modelBuilder.Entity<VendorDisputeComment>()
                .Property(e => e.Version)
                .IsFixedLength();
            #endregion

        }
    }
}
