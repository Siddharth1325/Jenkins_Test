namespace DataAccess.Accounting
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;
    using DomainModel.Accounting;
    using CommonLib.Persistence;
    using DataAccess.Persistence;

    public partial class AccountingData : CustomDbContext
    {
        public const int DbUpdateConcurrencyException_ReTryLimit = 3;

        public AccountingData()
            : base("name=AccountingData")
        {
            Configuration.LazyLoadingEnabled = false;
        }

        #region Data Members
        public virtual DbSet<AccountingAdjustmentCode> AccountingAdjustmentCodes { get; set; }
        public virtual DbSet<AccountingAPInvoicePayable> AccountingAPInvoicePayables { get; set; }
        public virtual DbSet<AccountingARInvoiceReceivable> AccountingARInvoiceReceivables { get; set; }
        public virtual DbSet<AccountingGLCode> AccountingGLCodes { get; set; }
        public virtual DbSet<AccountingWorkOrderAPInvoice> AccountingWorkOrderAPInvoices { get; set; }
        public virtual DbSet<AccountingWorkOrderARInvoice> AccountingWorkOrderARInvoices { get; set; }
        public virtual DbSet<AccountsPayable> AccountsPayables { get; set; }
        public virtual DbSet<AccountsPayableAdjustment> AccountsPayableAdjustments { get; set; }
        public virtual DbSet<AccountsPayableDetail> AccountsPayableDetails { get; set; }
        public virtual DbSet<AccountsPayableInvoice> AccountsPayableInvoices { get; set; }
        public virtual DbSet<AccountsPayableRemittance> AccountsPayableRemittances { get; set; }
        public virtual DbSet<AccountsPayableTrace> AccountsPayableTraces { get; set; }
        public virtual DbSet<AccountsReceivable> AccountsReceivables { get; set; }
        public virtual DbSet<AccountsReceivableAdjustment> AccountsReceivableAdjustments { get; set; }
        public virtual DbSet<AccountsReceivableDetail> AccountsReceivableDetails { get; set; }
        public virtual DbSet<AccountsReceivableInvoice> AccountsReceivableInvoices { get; set; }
        public virtual DbSet<DisputePayableAdjustmentHistory> DisputePayableAdjustmentHistorys { get; set; }
        public virtual DbSet<DisputeReceivableAdjustmentHistory> DisputeReceivableAdjustmentHistorys { get; set; }

        public virtual DbSet<DisputePenaltyAdjustmentHistory> DisputePenaltyAdjustmentHistories { get; set; }

        public virtual DbSet<AccountsReceivableTrace> AccountsReceivableTraces { get; set; }
        public virtual DbSet<IClearLSCIMapping> IClearLSCIMappings { get; set; }
        public virtual DbSet<IClearMBAMapping> IClearMBAMappings { get; set; }
        public virtual DbSet<IClearProductMapping> IClearProductMappings { get; set; }
        public virtual DbSet<IMChaseMapping> IMChaseMappings { get; set; }
        public virtual DbSet<IMStandardMapping> IMStandardMappings { get; set; }
        public virtual DbSet<IClearMappingSummaryView> IClearMappingSummaryViews { get; set; }
        public virtual DbSet<IMChaseMappingView> IMChaseMappingViews { get; set; }
        public virtual DbSet<IMStandardMappingView> IMStandardMappingViews { get; set; }
        public virtual DbSet<ARInvoiceDetailView> ARInvoiceDetailViews { get; set; }
        public virtual DbSet<APInvoiceDetailView> APInvoiceDetailViews { get; set; }
        public virtual DbSet<PresBillingDetailView> PresBillingDetailViews { get; set; }
        public virtual DbSet<Asset> Assets { get; set; }
        public virtual DbSet<Loan> Loans { get; set; }
        public virtual DbSet<Order> Orders { get; set; }
        public virtual DbSet<WorkOrder> WorkOrders { get; set; }
        public virtual DbSet<WorkOrderItem> WorkOrderItems { get; set; }
        public virtual DbSet<WorkOrderLineItem> WorkOrderLineItems { get; set; }
        public virtual DbSet<BulkException> BulkExceptions { get; set; }
        public virtual DbSet<Application> Applications { get; set; }
        public virtual DbSet<Product> Products { get; set; }
        public virtual DbSet<Cancellation> Cancellations { get; set; }
        public virtual DbSet<VendorWorkOrder> VendorWorkOrders { get; set; }
        public virtual DbSet<OrderHierarchy> OrderHierarchys { get; set; }

        public virtual DbSet<FeeType> FeeTypes { get; set; }

        public virtual DbSet<ProductFeeType> ProductFeeTypes { get; set; }

        public virtual DbSet<Service> Services { get; set; }
        public virtual DbSet<LineItem> LineItems { get; set; }
        public virtual DbSet<APDetailView> APDetailViews { get; set; }
        public virtual DbSet<ARDetailView> ARDetailViews { get; set; }
        public virtual DbSet<ProductService> ProductServices { get; set; }
        public virtual DbSet<APInvoiceDetailSummaryView> APInvoiceDetailSummaryViews { get; set; }
        public virtual DbSet<VendorProfile> VendorProfiles { get; set; }
        // public virtual DbSet<AccountsTax> AccountsTaxes { get; set; }
        public virtual DbSet<CostingInfoView> CostingInfoViews { get; set; }
        public virtual DbSet<StateTaxConfiguration> StateTaxConfigurations { get; set; }

        //public virtual DbSet<State> States { get; set; }
        // public virtual DbSet<State> States { get; set; }
        public virtual DbSet<AccountsTax> AccountsTaxes { get; set; }
        public virtual DbSet<AccountsTaxBatch> AccountsTaxBatches { get; set; }
        public virtual DbSet<FSWorkOrderLoanClientDetailsView> FSWorkOrderLoanClientDetailsViews { get; set; }
        public virtual DbSet<FSLoanOrderClientDetailsView> FSLoanOrderClientDetailsViews { get; set; }
        public virtual DbSet<APAdjustmentDetailView> APAdjustmentDetails { get; set; }
        public virtual DbSet<ARAdjustmentDetailView> ARAdjustmentDetails { get; set; }

        public virtual DbSet<AccountsPayableTrackingLog> AccountsPayableTrackingLogs { get; set; }
       // public virtual DbSet<SupplierConfigurationBulkFile> SupplierConfigurationBulkFiles { get; set; }
        public virtual DbSet<Document> Documents { get; set; }
        public virtual DbSet<RRRInvoiceJSONHeader> RRRInvoiceJSONHeaders { get; set; }
        public virtual DbSet<RRRInvoiceJSONDetail> RRRInvoiceJSONDetails { get; set; }
        public virtual DbSet<RRRDecisionInvoiceItemTracking> RRRDecisionInvoiceItemTrackings { get; set; }
        public virtual DbSet<RRRInvoiceHeaderTracking> RRRInvoiceHeaderTrackings { get; set; }
        #endregion

        #region Methods
        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<AccountingAdjustmentCode>()
                .Property(e => e.AdjustmentCategoryGroup)
                .IsUnicode(false);

            modelBuilder.Entity<AccountingAdjustmentCode>()
                .Property(e => e.AdjustmentCategoryType)
                .IsUnicode(false);

            modelBuilder.Entity<AccountingAdjustmentCode>()
                .Property(e => e.AdjustmentTypeGroup)
                .IsUnicode(false);

            modelBuilder.Entity<AccountingAdjustmentCode>()
                .Property(e => e.AdjustmentType)
                .IsUnicode(false);

            modelBuilder.Entity<AccountingAdjustmentCode>()
                .Property(e => e.AdjustmentCode)
                .IsUnicode(false);

            modelBuilder.Entity<AccountingAdjustmentCode>()
                .Property(e => e.Description)
                .IsUnicode(false);

            modelBuilder.Entity<AccountingAdjustmentCode>()
                .Property(e => e.Version)
                .IsFixedLength();

            modelBuilder.Entity<AccountingAPInvoicePayable>()
                .Property(e => e.Version)
                .IsFixedLength();

            modelBuilder.Entity<AccountingARInvoiceReceivable>()
                .HasRequired(x => x.AccountsReceivableDetail)
                .WithMany(x => x.AccountingARInvoiceReceivables)
                .HasForeignKey(x => x.AccountsReceivableDetailId);

            modelBuilder.Entity<AccountingAPInvoicePayable>()
                .HasRequired(x => x.AccountsPayableDetail)
                .WithMany(x => x.AccountingAPInvoicePayables)
                .HasForeignKey(x => x.AccountsPayableDetailId);

            modelBuilder.Entity<AccountingARInvoiceReceivable>()
                .Property(e => e.Version)
                .IsFixedLength();

            modelBuilder.Entity<AccountingGLCode>()
                .Property(e => e.ProductCategoryGroup)
                .IsUnicode(false);

            modelBuilder.Entity<AccountingGLCode>()
                .Property(e => e.ProductCategory)
                .IsUnicode(false);

            modelBuilder.Entity<AccountingGLCode>()
                .Property(e => e.GLTransTypeGroup)
                .IsUnicode(false);

            modelBuilder.Entity<AccountingGLCode>()
                .Property(e => e.GLTransType)
                .IsUnicode(false);

            modelBuilder.Entity<AccountingGLCode>()
                .Property(e => e.ReserveTypeGroup)
                .IsUnicode(false);

            modelBuilder.Entity<AccountingGLCode>()
                .Property(e => e.ReserveType)
                .IsUnicode(false);

            modelBuilder.Entity<AccountingGLCode>()
                .Property(e => e.GLCompany)
                .IsUnicode(false);

            modelBuilder.Entity<AccountingGLCode>()
                .Property(e => e.Operation)
                .IsUnicode(false);

            modelBuilder.Entity<AccountingGLCode>()
                .Property(e => e.Function)
                .IsUnicode(false);

            modelBuilder.Entity<AccountingGLCode>()
                .Property(e => e.NaturalAccount)
                .IsUnicode(false);

            modelBuilder.Entity<AccountingGLCode>()
                .Property(e => e.Intercompany)
                .IsUnicode(false);

            modelBuilder.Entity<AccountingGLCode>()
                .Property(e => e.FRU1)
                .IsUnicode(false);

            modelBuilder.Entity<AccountingGLCode>()
                .Property(e => e.FRU2)
                .IsUnicode(false);

            modelBuilder.Entity<AccountingGLCode>()
                .Property(e => e.Version)
                .IsFixedLength();

            modelBuilder.Entity<AccountingWorkOrderAPInvoice>()
                .Property(e => e.Version)
                .IsFixedLength();

            modelBuilder.Entity<AccountingWorkOrderARInvoice>()
                .Property(e => e.Version)
                .IsFixedLength();

            modelBuilder.Entity<AccountsPayable>()
                .Property(e => e.GLTransTypeGroup)
                .IsUnicode(false);

            modelBuilder.Entity<AccountsPayable>()
                .Property(e => e.GLTransType)
                .IsUnicode(false);

            modelBuilder.Entity<AccountsPayable>()
                .Property(e => e.SubtotalDue)
                .HasPrecision(19, 4);

            modelBuilder.Entity<AccountsPayable>()
                .Property(e => e.TaxesDue)
                .HasPrecision(19, 4);

            modelBuilder.Entity<AccountsPayable>()
                .Property(e => e.TotalAmountDue)
                .HasPrecision(19, 4);

            modelBuilder.Entity<AccountsPayable>()
                .Property(e => e.Version)
                .IsFixedLength();

            modelBuilder.Entity<AccountsPayableAdjustment>()
                .Property(e => e.AdjustmentType)
                .IsUnicode(false);

            modelBuilder.Entity<AccountsPayableAdjustment>()
                .Property(e => e.AdjustmentCode)
                .IsUnicode(false);

            modelBuilder.Entity<AccountsPayableAdjustment>()
                .Property(e => e.Amount)
                .HasPrecision(19, 4);

            modelBuilder.Entity<AccountsPayableAdjustment>()
                .Property(e => e.GLTransTypeGroup)
                .IsUnicode(false);

            modelBuilder.Entity<AccountsPayableAdjustment>()
                .Property(e => e.GLTransType)
                .IsUnicode(false);

            modelBuilder.Entity<AccountsPayableAdjustment>()
                .Property(e => e.Operation)
                .IsUnicode(false);

            modelBuilder.Entity<AccountsPayableAdjustment>()
                .Property(e => e.Function)
                .IsUnicode(false);

            modelBuilder.Entity<AccountsPayableAdjustment>()
                .Property(e => e.NaturalAccount)
                .IsUnicode(false);

            modelBuilder.Entity<AccountsPayableAdjustment>()
                .Property(e => e.Comments)
                .IsUnicode(false);

            modelBuilder.Entity<AccountsPayableAdjustment>()
                .Property(e => e.Version)
                .IsFixedLength();

            modelBuilder.Entity<AccountsPayableDetail>()
                .Property(e => e.UnitsGroup)
                .IsUnicode(false);

            modelBuilder.Entity<AccountsPayableDetail>()
                .Property(e => e.UnitsType)
                .IsUnicode(false);

            modelBuilder.Entity<AccountsPayableDetail>()
                .Property(e => e.BaseCostPerUnit)
                .HasPrecision(19, 4);

            modelBuilder.Entity<AccountsPayableDetail>()
                .Property(e => e.BaseTotalCost)
                .HasPrecision(19, 4);

            modelBuilder.Entity<AccountsPayableDetail>()
                .Property(e => e.FinalTotalCost)
                .HasPrecision(19, 4);

            modelBuilder.Entity<AccountsPayableDetail>()
                .Property(e => e.Version)
                .IsFixedLength();

            modelBuilder.Entity<AccountsPayableInvoice>()
                .Property(e => e.InvoiceNumber)
                .IsUnicode(false);

            modelBuilder.Entity<AccountsPayableInvoice>()
                .Property(e => e.InvoiceAmount)
                .HasPrecision(19, 4);

            modelBuilder.Entity<AccountsPayableInvoice>()
                .Property(e => e.Version)
                .IsFixedLength();

            modelBuilder.Entity<AccountsPayableRemittance>()
                .Property(e => e.InvoiceNumber)
                .IsUnicode(false);

            modelBuilder.Entity<AccountsPayableRemittance>()
                .Property(e => e.InvoiceTypeGroup)
                .IsUnicode(false);

            modelBuilder.Entity<AccountsPayableRemittance>()
                .Property(e => e.InvoiceType)
                .IsUnicode(false);

            modelBuilder.Entity<AccountsPayableRemittance>()
                .Property(e => e.InvoiceAmount)
                .HasPrecision(19, 4);

            modelBuilder.Entity<AccountsPayableRemittance>()
                .Property(e => e.CheckNumber)
                .IsUnicode(false);

            modelBuilder.Entity<AccountsPayableRemittance>()
                .Property(e => e.CheckTypeGroup)
                .IsUnicode(false);

            modelBuilder.Entity<AccountsPayableRemittance>()
                .Property(e => e.CheckType)
                .IsUnicode(false);

            modelBuilder.Entity<AccountsPayableRemittance>()
                .Property(e => e.PaidAmount)
                .HasPrecision(19, 4);

            modelBuilder.Entity<AccountsPayableRemittance>()
                .Property(e => e.PayeeCode)
                .IsUnicode(false);

            modelBuilder.Entity<AccountsPayableRemittance>()
                .Property(e => e.Comments)
                .IsUnicode(false);

            modelBuilder.Entity<AccountsPayableRemittance>()
                .Property(e => e.Version)
                .IsFixedLength();

            modelBuilder.Entity<AccountsPayableTrace>()
                .Property(e => e.StartingCost)
                .HasPrecision(19, 4);

            modelBuilder.Entity<AccountsPayableTrace>()
                .Property(e => e.CostSelectionReason)
                .IsUnicode(false);

            modelBuilder.Entity<AccountsPayableTrace>()
                .Property(e => e.CostAdjustment)
                .HasPrecision(19, 4);

            modelBuilder.Entity<AccountsPayableTrace>()
                .Property(e => e.CostAdjustmentTypeGroup)
                .IsUnicode(false);

            modelBuilder.Entity<AccountsPayableTrace>()
                .Property(e => e.CostAdjustmentType)
                .IsUnicode(false);

            modelBuilder.Entity<AccountsPayableTrace>()
                .Property(e => e.Version)
                .IsFixedLength();

            modelBuilder.Entity<AccountsReceivable>()
                .Property(e => e.GLTransTypeGroup)
                .IsUnicode(false);

            modelBuilder.Entity<AccountsReceivable>()
                .Property(e => e.GLTransType)
                .IsUnicode(false);

            modelBuilder.Entity<AccountsReceivable>()
                .Property(e => e.SubtotalDue)
                .HasPrecision(19, 4);

            modelBuilder.Entity<AccountsReceivable>()
                .Property(e => e.TaxesDue)
                .HasPrecision(19, 4);

            modelBuilder.Entity<AccountsReceivable>()
                .Property(e => e.TotalAmountDue)
                .HasPrecision(19, 4);

            modelBuilder.Entity<AccountsReceivable>()
                .Property(e => e.Version)
                .IsFixedLength();

            modelBuilder.Entity<AccountsReceivableAdjustment>()
                .Property(e => e.AdjustmentType)
                .IsUnicode(false);

            modelBuilder.Entity<AccountsReceivableAdjustment>()
                .Property(e => e.AdjustmentCode)
                .IsUnicode(false);

            modelBuilder.Entity<AccountsReceivableAdjustment>()
                .Property(e => e.Amount)
                .HasPrecision(19, 4);

            modelBuilder.Entity<AccountsReceivableAdjustment>()
                .Property(e => e.GLTransTypeGroup)
                .IsUnicode(false);

            modelBuilder.Entity<AccountsReceivableAdjustment>()
                .Property(e => e.GLTransType)
                .IsUnicode(false);

            modelBuilder.Entity<AccountsReceivableAdjustment>()
                .Property(e => e.ReserveType)
                .IsUnicode(false);

            modelBuilder.Entity<AccountsReceivableAdjustment>()
                .Property(e => e.Operation)
                .IsUnicode(false);

            modelBuilder.Entity<AccountsReceivableAdjustment>()
                .Property(e => e.Function)
                .IsUnicode(false);

            modelBuilder.Entity<AccountsReceivableAdjustment>()
                .Property(e => e.NaturalAccount)
                .IsUnicode(false);

            modelBuilder.Entity<AccountsReceivableAdjustment>()
                .Property(e => e.Comments)
                .IsUnicode(false);

            modelBuilder.Entity<AccountsReceivableAdjustment>()
                .Property(e => e.Version)
                .IsFixedLength();

            modelBuilder.Entity<AccountsReceivableDetail>()
                .Property(e => e.UnitsGroup)
                .IsUnicode(false);

            modelBuilder.Entity<AccountsReceivableDetail>()
                .Property(e => e.UnitsType)
                .IsUnicode(false);

            modelBuilder.Entity<AccountsTax>()
                .Property(e => e.TransmissionStatus)
                .IsUnicode(false);

            modelBuilder.Entity<AccountsTax>()
                .Property(e => e.TransmissionStatusGroup)
                .IsUnicode(false);

            modelBuilder.Entity<AccountsTax>()
                .Property(e => e.ErrorMsg)
                .IsUnicode(false);

            modelBuilder.Entity<AccountsReceivableDetail>()
                .Property(e => e.BasePricePerUnit)
                .HasPrecision(19, 4);

            modelBuilder.Entity<AccountsReceivableDetail>()
                .Property(e => e.BaseTotalPrice)
                .HasPrecision(19, 4);

            modelBuilder.Entity<AccountsReceivableDetail>()
                .Property(e => e.FinalTotalPrice)
                .HasPrecision(19, 4);

            modelBuilder.Entity<AccountsTax>()
               .Property(e => e.TaxAmount)
               .HasPrecision(19, 4);

            modelBuilder.Entity<AccountsTax>()
                .Property(e => e.TaxRate)
                .HasPrecision(19, 4);

            modelBuilder.Entity<AccountsReceivableDetail>()
                .Property(e => e.Version)
                .IsFixedLength();

            modelBuilder.Entity<AccountsReceivableInvoice>()
                .Property(e => e.ProductCategoryGroup)
                .IsUnicode(false);

            modelBuilder.Entity<AccountsReceivableInvoice>()
                .Property(e => e.ProductCategory)
                .IsUnicode(false);

            modelBuilder.Entity<AccountsReceivableInvoice>()
                .Property(e => e.InvoiceTypeGroup)
                .IsUnicode(false);

            modelBuilder.Entity<AccountsReceivableInvoice>()
                .Property(e => e.InvoiceType)
                .IsUnicode(false);

            modelBuilder.Entity<AccountsReceivableInvoice>()
                .Property(e => e.BillFreqGroup)
                .IsUnicode(false);

            modelBuilder.Entity<AccountsReceivableInvoice>()
                .Property(e => e.BillFreqType)
                .IsUnicode(false);

            modelBuilder.Entity<AccountsReceivableInvoice>()
                .Property(e => e.DepartmentCode)
                .IsUnicode(false);

            modelBuilder.Entity<AccountsReceivableInvoice>()
                .Property(e => e.InvoiceNumber)
                .IsUnicode(false);

            modelBuilder.Entity<AccountsReceivableInvoice>()
                .Property(e => e.InvoiceAmount)
                .HasPrecision(19, 4);

            modelBuilder.Entity<AccountsReceivableInvoice>()
                .Property(e => e.Version)
                .IsFixedLength();

            modelBuilder.Entity<AccountsReceivableTrace>()
                .Property(e => e.StartingPrice)
                .HasPrecision(19, 4);

            modelBuilder.Entity<AccountsReceivableTrace>()
                .Property(e => e.PriceSelectionReason)
                .IsUnicode(false);

            modelBuilder.Entity<AccountsReceivableTrace>()
                .Property(e => e.PriceAdjustment)
                .HasPrecision(19, 4);

            modelBuilder.Entity<AccountsReceivableTrace>()
                .Property(e => e.PriceAdjustmentTypeGroup)
                .IsUnicode(false);

            modelBuilder.Entity<AccountsReceivableTrace>()
                .Property(e => e.PriceAdjustmentType)
                .IsUnicode(false);

            modelBuilder.Entity<AccountsReceivableTrace>()
                .Property(e => e.Version)
                .IsFixedLength();

            modelBuilder.Entity<IClearLSCIMapping>()
                .Property(e => e.IClearClientCode)
                .IsUnicode(false);

            modelBuilder.Entity<IClearLSCIMapping>()
                .Property(e => e.Version)
                .IsFixedLength();

            modelBuilder.Entity<AccountsTax>()
                .Property(e => e.Version)
                .IsFixedLength();

            modelBuilder.Entity<IClearMBAMapping>()
                .Property(e => e.MBACodeGroup)
                .IsUnicode(false);

            modelBuilder.Entity<IClearMBAMapping>()
                .Property(e => e.MBACodeType)
                .IsUnicode(false);

            modelBuilder.Entity<IClearMBAMapping>()
                .Property(e => e.IClearLineItem)
                .IsUnicode(false);

            modelBuilder.Entity<IClearMBAMapping>()
                .Property(e => e.Version)
                .IsFixedLength();

            modelBuilder.Entity<IClearProductMapping>()
                .Property(e => e.InspectionResultGroup)
                .IsUnicode(false);

            modelBuilder.Entity<IClearProductMapping>()
                .Property(e => e.InspectionResultType)
                .IsUnicode(false);

            modelBuilder.Entity<IClearProductMapping>()
                .Property(e => e.IClearLineItem)
                .IsUnicode(false);

            modelBuilder.Entity<IClearProductMapping>()
                .Property(e => e.Version)
                .IsFixedLength();

            modelBuilder.Entity<IMChaseMapping>()
                .Property(e => e.RequestorCode)
                .IsUnicode(false);

            modelBuilder.Entity<IMChaseMapping>()
                .Property(e => e.MBACodeGroup)
                .IsUnicode(false);

            modelBuilder.Entity<IMChaseMapping>()
                .Property(e => e.MBACodeType)
                .IsUnicode(false);

            modelBuilder.Entity<IMChaseMapping>()
                .Property(e => e.IMInvoiceType)
                .IsUnicode(false);

            modelBuilder.Entity<IMChaseMapping>()
                .Property(e => e.IMOrderTypeGroup)
                .IsUnicode(false);

            modelBuilder.Entity<IMChaseMapping>()
                .Property(e => e.IMOrderType)
                .IsUnicode(false);

            modelBuilder.Entity<IMChaseMapping>()
                .Property(e => e.IMLineItem)
                .IsUnicode(false);

            modelBuilder.Entity<IMChaseMapping>()
                .Property(e => e.Version)
                .IsFixedLength();

            modelBuilder.Entity<IMStandardMapping>()
                .Property(e => e.DepartmentCode)
                .IsUnicode(false);

            modelBuilder.Entity<IMStandardMapping>()
                .Property(e => e.LoanTypeGroup)
                .IsUnicode(false);

            modelBuilder.Entity<IMStandardMapping>()
                .Property(e => e.LoanType)
                .IsUnicode(false);

            modelBuilder.Entity<IMStandardMapping>()
                .Property(e => e.InspectionResultGroup)
                .IsUnicode(false);

            modelBuilder.Entity<IMStandardMapping>()
                .Property(e => e.InspectionResultType)
                .IsUnicode(false);

            modelBuilder.Entity<IMStandardMapping>()
                .Property(e => e.IMInvoiceType)
                .IsUnicode(false);

            modelBuilder.Entity<IMStandardMapping>()
                .Property(e => e.IMOrderTypeGroup)
                .IsUnicode(false);

            modelBuilder.Entity<IMStandardMapping>()
                .Property(e => e.IMOrderType)
                .IsUnicode(false);

            modelBuilder.Entity<IMStandardMapping>()
                .Property(e => e.IMLineItem)
                .IsUnicode(false);

            modelBuilder.Entity<IMStandardMapping>()
                .Property(e => e.Version)
                .IsFixedLength();

            modelBuilder.Entity<IClearMappingSummaryView>()
               .Property(e => e.MappingType)
               .IsUnicode(false);

            modelBuilder.Entity<IClearMappingSummaryView>()
                .Property(e => e.ClientLSCI)
                .IsUnicode(false);

            modelBuilder.Entity<IClearMappingSummaryView>()
                .Property(e => e.IClearClientCode)
                .IsUnicode(false);

            modelBuilder.Entity<IClearMappingSummaryView>()
                .Property(e => e.InspectionType)
                .IsUnicode(false);

            modelBuilder.Entity<IClearMappingSummaryView>()
                .Property(e => e.InspectionResultType)
                .IsUnicode(false);

            modelBuilder.Entity<IClearMappingSummaryView>()
                .Property(e => e.MBACodeType)
                .IsUnicode(false);

            modelBuilder.Entity<IClearMappingSummaryView>()
                .Property(e => e.IClearLineItem)
                .IsUnicode(false);

            modelBuilder.Entity<IClearMappingSummaryView>()
                .Property(e => e.MappingTypeDescription)
                .IsUnicode(false);

            modelBuilder.Entity<IMChaseMappingView>()
                .Property(e => e.ClientLSCI)
                .IsUnicode(false);

            modelBuilder.Entity<IMChaseMappingView>()
                .Property(e => e.RequestorCode)
                .IsUnicode(false);

            modelBuilder.Entity<IMChaseMappingView>()
                .Property(e => e.MBACodeType)
                .IsUnicode(false);

            modelBuilder.Entity<IMChaseMappingView>()
                .Property(e => e.IMInvoiceType)
                .IsUnicode(false);

            modelBuilder.Entity<IMChaseMappingView>()
                .Property(e => e.IMOrderType)
                .IsUnicode(false);

            modelBuilder.Entity<IMChaseMappingView>()
                .Property(e => e.IMLineItem)
                .IsUnicode(false);

            modelBuilder.Entity<IMStandardMappingView>()
                .Property(e => e.DepartmentCode)
                .IsUnicode(false);

            modelBuilder.Entity<IMStandardMappingView>()
                .Property(e => e.ProductId)
                .IsUnicode(false);

            modelBuilder.Entity<IMStandardMappingView>()
                .Property(e => e.InspectionType)
                .IsUnicode(false);

            modelBuilder.Entity<IMStandardMappingView>()
                .Property(e => e.LoanType)
                .IsUnicode(false);

            modelBuilder.Entity<IMStandardMappingView>()
                .Property(e => e.IsRush)
                .IsUnicode(false);

            modelBuilder.Entity<IMStandardMappingView>()
                .Property(e => e.InspectionResultType)
                .IsUnicode(false);

            modelBuilder.Entity<IMStandardMappingView>()
                .Property(e => e.IMInvoiceType)
                .IsUnicode(false);

            modelBuilder.Entity<IMStandardMappingView>()
                .Property(e => e.IMOrderType)
                .IsUnicode(false);

            modelBuilder.Entity<IMStandardMappingView>()
                .Property(e => e.IMLineItem)
                .IsUnicode(false);

            modelBuilder.Entity<IMStandardMappingView>()
                .Property(e => e.LOBType)
                .IsUnicode(false);

            modelBuilder.Entity<IMStandardMappingView>()
                .Property(e => e.ServiceName)
                .IsUnicode(false);

            modelBuilder.Entity<IMStandardMappingView>()
                .Property(e => e.ServiceItem)
                .IsUnicode(false);

            modelBuilder.Entity<IMStandardMappingView>()
                .Property(e => e.FeeTypeName)
                .IsUnicode(false);

            modelBuilder.Entity<ARInvoiceDetailView>()
              .Property(e => e.InvoiceNumber)
              .IsUnicode(false);

            modelBuilder.Entity<ARInvoiceDetailView>()
                .Property(e => e.LoanNumber)
                .IsUnicode(false);

            modelBuilder.Entity<ARInvoiceDetailView>()
                .Property(e => e.InvoiceAmount)
                .HasPrecision(19, 4);
            modelBuilder.Entity<ARInvoiceDetailView>()
               .Property(e => e.TaxAmount)
               .HasPrecision(19, 4);
            modelBuilder.Entity<ARInvoiceDetailView>()
               .Property(e => e.ClientPrice)
               .HasPrecision(19, 4);

            modelBuilder.Entity<ARInvoiceDetailView>()
                .Property(e => e.ProductCode)
                .IsUnicode(false);

            modelBuilder.Entity<ARInvoiceDetailView>()
                .Property(e => e.LoanType)
                .IsUnicode(false);

            modelBuilder.Entity<ARInvoiceDetailView>()
                .Property(e => e.Occupancy)
                .IsUnicode(false);

            modelBuilder.Entity<ARInvoiceDetailView>()
                .Property(e => e.MBACode)
                .IsUnicode(false);

            modelBuilder.Entity<ARInvoiceDetailView>()
                .Property(e => e.MortgagorName)
                .IsUnicode(false);

            modelBuilder.Entity<ARInvoiceDetailView>()
               .Property(e => e.ProductCategory)
               .IsUnicode(false);

            modelBuilder.Entity<APInvoiceDetailView>()
              .Property(e => e.InvoiceNumber)
              .IsUnicode(false);

            modelBuilder.Entity<APInvoiceDetailView>()
                .Property(e => e.InspectorUniqueId)
                .IsUnicode(false);

            modelBuilder.Entity<APInvoiceDetailView>()
                .Property(e => e.FinalTotalCost)
                .HasPrecision(19, 4);

            modelBuilder.Entity<APInvoiceDetailView>()
                .Property(e => e.ProductCategory)
                .IsUnicode(false);

            modelBuilder.Entity<APInvoiceDetailView>()
                .Property(e => e.EligibleOccupancyType)
                .IsUnicode(false);

            modelBuilder.Entity<APInvoiceDetailView>()
                .Property(e => e.PropertyAddress)
                .IsUnicode(false);


            //modelBuilder.Entity<FeeType>()
            //   .Property(e => e.FeeTypeCode)
            //   .IsUnicode(false);

            modelBuilder.Entity<FeeType>()
                .Property(e => e.FeeTypeName)
                .IsUnicode(false);

            modelBuilder.Entity<FeeType>()
                .Property(e => e.Version)
                .IsFixedLength();

            modelBuilder.Entity<FeeType>()
                .HasMany(e => e.ProductFeeTypes)
                .WithRequired(e => e.FeeType)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<ProductFeeType>()
                .Property(e => e.Version)
                .IsFixedLength();

            modelBuilder.Entity<Service>()
                    .Property(e => e.ServiceCode)
                    .IsUnicode(false);

            modelBuilder.Entity<Service>()
                .Property(e => e.ServiceName)
                .IsUnicode(false);

            modelBuilder.Entity<Service>()
                .Property(e => e.ServiceDesc)
                .IsUnicode(false);

            modelBuilder.Entity<Service>()
                .Property(e => e.Instructions)
                .IsUnicode(false);

            modelBuilder.Entity<Service>()
                .Property(e => e.ProductCategoryGroup)
                .IsUnicode(false);

            modelBuilder.Entity<Service>()
                .Property(e => e.ProductCategory)
                .IsUnicode(false);

            modelBuilder.Entity<Service>()
                .Property(e => e.ServiceCategoryGroup)
                .IsUnicode(false);

            modelBuilder.Entity<Service>()
                .Property(e => e.ServiceCategoryType)
                .IsUnicode(false);

            modelBuilder.Entity<Service>()
                .Property(e => e.DefaultPrice)
                .HasPrecision(19, 4);

            modelBuilder.Entity<Service>()
                .Property(e => e.Version)
                .IsFixedLength();

            modelBuilder.Entity<ProductService>()
                .Property(e => e.Version)
                .IsFixedLength();

            modelBuilder.Entity<APInvoiceDetailSummaryView>()
             .Property(e => e.VendorName)
             .IsUnicode(false);

            modelBuilder.Entity<APInvoiceDetailSummaryView>()
                .Property(e => e.InvoiceNumber)
                .IsUnicode(false);

            modelBuilder.Entity<APInvoiceDetailSummaryView>()
                .Property(e => e.InvoiceAmount)
                .HasPrecision(19, 4);

            modelBuilder.Entity<APInvoiceDetailSummaryView>()
                .Property(e => e.CheckNumber)
                .IsUnicode(false);

            modelBuilder.Entity<APInvoiceDetailSummaryView>()
                .Property(e => e.PaidAmount)
                .HasPrecision(19, 4);


            modelBuilder.Entity<VendorProfile>()
                .Property(e => e.VendorName)
                .IsUnicode(false);

            modelBuilder.Entity<VendorProfile>()
                .Property(e => e.AddressLine1)
                .IsUnicode(false);

            modelBuilder.Entity<VendorProfile>()
                .Property(e => e.AddressLine2)
                .IsUnicode(false);

            modelBuilder.Entity<VendorProfile>()
                .Property(e => e.CityName)
                .IsUnicode(false);

            modelBuilder.Entity<VendorProfile>()
                .Property(e => e.StateCode)
                .IsFixedLength()
                .IsUnicode(false);

            modelBuilder.Entity<VendorProfile>()
                .Property(e => e.ZipCode)
                .IsFixedLength()
                .IsUnicode(false);

            modelBuilder.Entity<VendorProfile>()
                .Property(e => e.CountyName)
                .IsUnicode(false);

            modelBuilder.Entity<VendorProfile>()
                .Property(e => e.Phone)
                .IsFixedLength()
                .IsUnicode(false);

            modelBuilder.Entity<VendorProfile>()
                .Property(e => e.PhoneExtension)
                .IsUnicode(false);

            modelBuilder.Entity<VendorProfile>()
                .Property(e => e.Fax)
                .IsFixedLength()
                .IsUnicode(false);

            modelBuilder.Entity<VendorProfile>()
                .Property(e => e.Website)
                .IsUnicode(false);

            modelBuilder.Entity<VendorProfile>()
                .Property(e => e.BusinessHours)
                .IsUnicode(false);

            modelBuilder.Entity<VendorProfile>()
                .Property(e => e.VendorTypeGroup)
                .IsUnicode(false);

            modelBuilder.Entity<VendorProfile>()
                .Property(e => e.VendorType)
                .IsUnicode(false);

            modelBuilder.Entity<VendorProfile>()
                .Property(e => e.VendorStatusGroup)
                .IsUnicode(false);

            modelBuilder.Entity<VendorProfile>()
                .Property(e => e.VendorStatusType)
                .IsUnicode(false);

            modelBuilder.Entity<VendorProfile>()
                .Property(e => e.OnHoldReasonGroup)
                .IsUnicode(false);

            modelBuilder.Entity<VendorProfile>()
                .Property(e => e.OnHoldReasonType)
                .IsUnicode(false);

            modelBuilder.Entity<VendorProfile>()
                .Property(e => e.TerminationReason)
                .IsUnicode(false);

            modelBuilder.Entity<VendorProfile>()
                .Property(e => e.CredentialingId)
                .IsUnicode(false);

            modelBuilder.Entity<VendorProfile>()
                .Property(e => e.CredentialingStatusGroup)
                .IsUnicode(false);

            modelBuilder.Entity<VendorProfile>()
                .Property(e => e.CredentialingStatusType)
                .IsUnicode(false);

            modelBuilder.Entity<VendorProfile>()
                .Property(e => e.ComplianceGroup)
                .IsUnicode(false);

            modelBuilder.Entity<VendorProfile>()
                .Property(e => e.ComplianceType)
                .IsUnicode(false);

            modelBuilder.Entity<VendorProfile>()
                .Property(e => e.PrimaryContactFirst)
                .IsUnicode(false);

            modelBuilder.Entity<VendorProfile>()
                .Property(e => e.PrimaryContactLast)
                .IsUnicode(false);

            modelBuilder.Entity<VendorProfile>()
                .Property(e => e.PrimaryContactEmail)
                .IsUnicode(false);

            modelBuilder.Entity<VendorProfile>()
                .Property(e => e.ContactTypeGroup)
                .IsUnicode(false);

            modelBuilder.Entity<VendorProfile>()
                .Property(e => e.ContactType)
                .IsUnicode(false);

            modelBuilder.Entity<VendorProfile>()
                .Property(e => e.CloudServiceProvider)
                .IsUnicode(false);

            modelBuilder.Entity<VendorProfile>()
                .Property(e => e.AlsoKnownAs)
                .IsUnicode(false);

            modelBuilder.Entity<VendorProfile>()
                .Property(e => e.OnLeaveReasonGroup)
                .IsUnicode(false);

            modelBuilder.Entity<VendorProfile>()
                .Property(e => e.OnLeaveReason)
                .IsUnicode(false);

            modelBuilder.Entity<VendorProfile>()
                .Property(e => e.OverallScore)
                .HasPrecision(5, 2);

            modelBuilder.Entity<VendorProfile>()
                .Property(e => e.Version)
                .IsFixedLength();
            modelBuilder.Entity<VendorProfile>()
               .HasMany(e => e.WorkOrders)
               .WithOptional(e => e.VendorProfile)
               .HasForeignKey(e => e.AssignedVendorId);

            modelBuilder.Entity<AccountsTax>()
              .Property(e => e.TaxAmount)
              .HasPrecision(19, 4);

            modelBuilder.Entity<AccountsTax>()
                .Property(e => e.TaxRate)
                .HasPrecision(19, 4);

            modelBuilder.Entity<AccountsTax>()
                .Property(e => e.TransmissionStatus)
                .IsUnicode(false);

            modelBuilder.Entity<AccountsTax>()
                .Property(e => e.TransmissionStatusGroup)
                .IsUnicode(false);

            modelBuilder.Entity<AccountsTax>()
                .Property(e => e.ErrorMsg)
                .IsUnicode(false);

            modelBuilder.Entity<AccountsTax>()
                .Property(e => e.Version)
                .IsFixedLength();
            modelBuilder.Entity<CostingInfoView>()
               .Property(e => e.Amount)
               .HasPrecision(19, 4);

            modelBuilder.Entity<CostingInfoView>()
                .Property(e => e.AdjustmentType)
                .IsUnicode(false);

            modelBuilder.Entity<CostingInfoView>()
                .Property(e => e.TotalAmountDue)
                .HasPrecision(19, 4);

            modelBuilder.Entity<CostingInfoView>()
                .Property(e => e.InvoiceNumber)
                .IsUnicode(false);

            modelBuilder.Entity<CostingInfoView>()
                .Property(e => e.VendorName)
                .IsUnicode(false);

            modelBuilder.Entity<StateTaxConfiguration>()
               .Property(e => e.ProductCategoryGroup)
               .IsUnicode(false);

            modelBuilder.Entity<StateTaxConfiguration>()
                .Property(e => e.ProductCategory)
                .IsUnicode(false);

            modelBuilder.Entity<StateTaxConfiguration>()
                .Property(e => e.StateCode)
                .IsFixedLength()
                .IsUnicode(false);

            modelBuilder.Entity<StateTaxConfiguration>()
                .Property(e => e.Version)
                .IsFixedLength();


            //modelBuilder.Entity<State>()
            //    .Property(e => e.StateCode)
            //    .IsFixedLength()
            //    .IsUnicode(false);

            //modelBuilder.Entity<State>()
            //    .Property(e => e.StateName)
            //    .IsUnicode(false);

            //modelBuilder.Entity<State>()
            //    .Property(e => e.Version)
            //    .IsFixedLength();

            #region TxnEntities
            modelBuilder.Entity<Product>()
                .Property(e => e.ProductCode)
                .IsUnicode(false);

            modelBuilder.Entity<Product>()
                .Property(e => e.ProductName)
                .IsUnicode(false);

            modelBuilder.Entity<Product>()
                .Property(e => e.ProductDesc)
                .IsUnicode(false);

            modelBuilder.Entity<Product>()
                .Property(e => e.Instructions)
                .IsUnicode(false);

            modelBuilder.Entity<Product>()
                .Property(e => e.ProductCategoryGroup)
                .IsUnicode(false);

            modelBuilder.Entity<Product>()
                .Property(e => e.ProductCategory)
                .IsUnicode(false);

            modelBuilder.Entity<Product>()
                .Property(e => e.Version)
                .IsFixedLength();

            modelBuilder.Entity<Product>()
                .HasMany(e => e.ConvertedProductOrders)
                .WithOptional(e => e.ConvertedProduct)
                .HasForeignKey(e => e.ConvertedProductId);

            modelBuilder.Entity<Product>()
                .HasMany(e => e.OrderedProductOrders)
                .WithRequired(e => e.OrderedProduct)
                .HasForeignKey(e => e.OrderedProductId)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Product>()
                .HasMany(e => e.WorkOrders)
                .WithRequired(e => e.Product)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Asset>()
                .Property(e => e.DwellingTypeGroup)
                .IsUnicode(false);

            modelBuilder.Entity<Asset>()
                .Property(e => e.DwellingType)
                .IsUnicode(false);

            modelBuilder.Entity<Asset>()
                .Property(e => e.MobileVinNumber)
                .IsUnicode(false);

            modelBuilder.Entity<Asset>()
                .Property(e => e.MobileHudNumber)
                .IsUnicode(false);

            modelBuilder.Entity<Asset>()
                .Property(e => e.Latitude)
                .IsUnicode(false);

            modelBuilder.Entity<Asset>()
                .Property(e => e.Longitude)
                .IsUnicode(false);

            modelBuilder.Entity<Asset>()
                .Property(e => e.DoNotApproachReason)
                .IsUnicode(false);

            modelBuilder.Entity<Asset>()
                .Property(e => e.GateCode)
                .IsUnicode(false);

            modelBuilder.Entity<Asset>()
                .Property(e => e.HOAName)
                .IsUnicode(false);

            modelBuilder.Entity<Asset>()
                .Property(e => e.HOAPhone)
                .IsUnicode(false);

            modelBuilder.Entity<Asset>()
                .Property(e => e.CommunityName)
                .IsUnicode(false);

            modelBuilder.Entity<Asset>()
                .Property(e => e.CommunityNumber)
                .IsUnicode(false);

            modelBuilder.Entity<Asset>()
                .Property(e => e.CommunityAddress1)
                .IsUnicode(false);

            modelBuilder.Entity<Asset>()
                .Property(e => e.CommunityAddress2)
                .IsUnicode(false);

            modelBuilder.Entity<Asset>()
                .Property(e => e.CommunityCityName)
                .IsUnicode(false);

            modelBuilder.Entity<Asset>()
                .Property(e => e.VendorNotes)
                .IsUnicode(false);

            modelBuilder.Entity<Asset>()
                .Property(e => e.Version)
                .IsFixedLength();

            modelBuilder.Entity<Cancellation>()
                .Property(e => e.CancellationReasonGroup)
                .IsUnicode(false);

            modelBuilder.Entity<Cancellation>()
                .Property(e => e.CancellationReasonType)
                .IsUnicode(false);

            modelBuilder.Entity<Cancellation>()
                .Property(e => e.CancellationComments)
                .IsUnicode(false);

            modelBuilder.Entity<Cancellation>()
                .Property(e => e.Version)
                .IsFixedLength();

            modelBuilder.Entity<Loan>()
                .Property(e => e.LoanNumber)
                .IsUnicode(false);

            modelBuilder.Entity<Loan>()
                .Property(e => e.LoanTypeGroup)
                .IsUnicode(false);

            modelBuilder.Entity<Loan>()
                .Property(e => e.LoanType)
                .IsUnicode(false);

            modelBuilder.Entity<Loan>()
                .Property(e => e.LoanStatusGroup)
                .IsUnicode(false);

            modelBuilder.Entity<Loan>()
                .Property(e => e.LoanStatus)
                .IsUnicode(false);

            modelBuilder.Entity<Loan>()
                .Property(e => e.InvestorIdentifier)
                .IsUnicode(false);

            modelBuilder.Entity<Loan>()
                .Property(e => e.InvestorName)
                .IsUnicode(false);

            modelBuilder.Entity<Loan>()
                .Property(e => e.InvestorCode)
                .IsUnicode(false);

            modelBuilder.Entity<Loan>()
                .Property(e => e.BorrowerFirstName)
                .IsUnicode(false);

            modelBuilder.Entity<Loan>()
                .Property(e => e.BorrowerMiddleInitial)
                .IsFixedLength()
                .IsUnicode(false);

            modelBuilder.Entity<Loan>()
                .Property(e => e.BorrowerLastName)
                .IsUnicode(false);

            modelBuilder.Entity<Loan>()
                .Property(e => e.PropAddress1)
                .IsUnicode(false);

            modelBuilder.Entity<Loan>()
                .Property(e => e.PropAddress2)
                .IsUnicode(false);

            modelBuilder.Entity<Loan>()
                .Property(e => e.PropCityName)
                .IsUnicode(false);

            modelBuilder.Entity<Loan>()
                .Property(e => e.PropStateCode)
                .IsFixedLength()
                .IsUnicode(false);

            modelBuilder.Entity<Loan>()
                .Property(e => e.PropZipCode)
                .IsFixedLength()
                .IsUnicode(false);

            modelBuilder.Entity<Loan>()
                .Property(e => e.PropZipPlusFour)
                .IsFixedLength()
                .IsUnicode(false);

            modelBuilder.Entity<Loan>()
                .Property(e => e.PropCountyName)
                .IsUnicode(false);

            modelBuilder.Entity<Loan>()
                .Property(e => e.MailAddress1)
                .IsUnicode(false);

            modelBuilder.Entity<Loan>()
                .Property(e => e.MailAddress2)
                .IsUnicode(false);

            modelBuilder.Entity<Loan>()
                .Property(e => e.MailCityName)
                .IsUnicode(false);

            modelBuilder.Entity<Loan>()
                .Property(e => e.MailStateCode)
                .IsFixedLength()
                .IsUnicode(false);

            modelBuilder.Entity<Loan>()
                .Property(e => e.MailZipCode)
                .IsFixedLength()
                .IsUnicode(false);

            modelBuilder.Entity<Loan>()
                .Property(e => e.MailZipPlusFour)
                .IsFixedLength()
                .IsUnicode(false);

            modelBuilder.Entity<Loan>()
                .Property(e => e.ValidAddress1)
                .IsUnicode(false);

            modelBuilder.Entity<Loan>()
                .Property(e => e.ValidAddress2)
                .IsUnicode(false);

            modelBuilder.Entity<Loan>()
                .Property(e => e.ValidCityName)
                .IsUnicode(false);

            modelBuilder.Entity<Loan>()
                .Property(e => e.ValidStateCode)
                .IsFixedLength()
                .IsUnicode(false);

            modelBuilder.Entity<Loan>()
                .Property(e => e.ValidZipCode)
                .IsFixedLength()
                .IsUnicode(false);

            modelBuilder.Entity<Loan>()
                .Property(e => e.ValidZipPlusFour)
                .IsFixedLength()
                .IsUnicode(false);

            modelBuilder.Entity<Loan>()
                .Property(e => e.ValidCountyName)
                .IsUnicode(false);

            modelBuilder.Entity<Loan>()
                .Property(e => e.ValidLatitude)
                .IsUnicode(false);

            modelBuilder.Entity<Loan>()
                .Property(e => e.ValidLongitude)
                .IsUnicode(false);

            modelBuilder.Entity<Loan>()
                .Property(e => e.PrimaryPhone)
                .IsUnicode(false);

            modelBuilder.Entity<Loan>()
                .Property(e => e.PrimaryPhoneTypeGroup)
                .IsUnicode(false);

            modelBuilder.Entity<Loan>()
                .Property(e => e.PrimaryPhoneType)
                .IsUnicode(false);

            modelBuilder.Entity<Loan>()
                .Property(e => e.AlternatePhone)
                .IsUnicode(false);

            modelBuilder.Entity<Loan>()
                .Property(e => e.AlternatePhoneTypeGroup)
                .IsUnicode(false);

            modelBuilder.Entity<Loan>()
                .Property(e => e.AlternatePhoneType)
                .IsUnicode(false);

            modelBuilder.Entity<Loan>()
                .Property(e => e.OccupancyStatusGroup)
                .IsUnicode(false);

            modelBuilder.Entity<Loan>()
                .Property(e => e.OccupancyStatusType)
                .IsUnicode(false);

            modelBuilder.Entity<Loan>()
                .Property(e => e.CeaseAndDesistReason)
                .IsUnicode(false);

            modelBuilder.Entity<Loan>()
                .Property(e => e.InspFreqTypeGroup)
                .IsUnicode(false);

            modelBuilder.Entity<Loan>()
                .Property(e => e.InspectionFreqType)
                .IsUnicode(false);

            modelBuilder.Entity<Loan>()
                .Property(e => e.EligibleOccupancyGroup)
                .IsUnicode(false);

            modelBuilder.Entity<Loan>()
                .Property(e => e.EligibleOccupancyType)
                .IsUnicode(false);

            modelBuilder.Entity<Loan>()
                .Property(e => e.NonStandardFreqReason)
                .IsUnicode(false);

            modelBuilder.Entity<Loan>()
                .Property(e => e.DoorKeyCode)
                .IsUnicode(false);

            modelBuilder.Entity<Loan>()
                .Property(e => e.LockBoxCode)
                .IsUnicode(false);

            modelBuilder.Entity<Loan>()
                .Property(e => e.OutstandingBalance)
                .HasPrecision(19, 4);

            modelBuilder.Entity<Loan>()
                .Property(e => e.GuarantorCaseNumber)
                .IsUnicode(false);

            modelBuilder.Entity<Loan>()
                .Property(e => e.BillMortgagor)
                .IsUnicode(false);

            modelBuilder.Entity<Loan>()
                .Property(e => e.LowType)
                .IsUnicode(false);

            modelBuilder.Entity<Loan>()
                .Property(e => e.DepartmentTypeGroup)
                .IsUnicode(false);

            modelBuilder.Entity<Loan>()
                .Property(e => e.DepartmentType)
                .IsUnicode(false);

            modelBuilder.Entity<Loan>()
                .Property(e => e.Version)
                .IsFixedLength();

            modelBuilder.Entity<Loan>()
                .HasMany(e => e.Cancellations)
                .WithOptional(e => e.CancelledLoan)
                .HasForeignKey(e => e.CancelledLoanId);

            modelBuilder.Entity<Loan>()
                .HasMany(e => e.Orders)
                .WithRequired(e => e.Loan)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Order>()
                .Property(e => e.OrderTypeGroup)
                .IsUnicode(false);

            modelBuilder.Entity<Order>()
                .Property(e => e.OrderType)
                .IsUnicode(false);

            modelBuilder.Entity<Order>()
                .Property(e => e.OrderStatusGroup)
                .IsUnicode(false);

            modelBuilder.Entity<Order>()
                .Property(e => e.OrderStatusType)
                .IsUnicode(false);

            modelBuilder.Entity<Order>()
                .Property(e => e.CancellationReasonGroup)
                .IsUnicode(false);

            modelBuilder.Entity<Order>()
                .Property(e => e.CancellationReasonType)
                .IsUnicode(false);

            modelBuilder.Entity<Order>()
                .Property(e => e.BorrowerFirstName)
                .IsUnicode(false);

            modelBuilder.Entity<Order>()
                .Property(e => e.BorrowerMiddleInitial)
                .IsFixedLength()
                .IsUnicode(false);

            modelBuilder.Entity<Order>()
                .Property(e => e.BorrowerLastName)
                .IsUnicode(false);

            modelBuilder.Entity<Order>()
                .Property(e => e.AddressLine1)
                .IsUnicode(false);

            modelBuilder.Entity<Order>()
                .Property(e => e.AddressLine2)
                .IsUnicode(false);

            modelBuilder.Entity<Order>()
                .Property(e => e.CityName)
                .IsUnicode(false);

            modelBuilder.Entity<Order>()
                .Property(e => e.StateCode)
                .IsFixedLength()
                .IsUnicode(false);

            modelBuilder.Entity<Order>()
                .Property(e => e.ZipCode)
                .IsFixedLength()
                .IsUnicode(false);

            modelBuilder.Entity<Order>()
                .Property(e => e.ZipPlusFour)
                .IsFixedLength()
                .IsUnicode(false);

            modelBuilder.Entity<Order>()
                .Property(e => e.CountyName)
                .IsUnicode(false);

            modelBuilder.Entity<Order>()
                .Property(e => e.SpecialInstructions)
                .IsUnicode(false);

            modelBuilder.Entity<Order>()
                .Property(e => e.ProductCategoryGroup)
                .IsUnicode(false);

            modelBuilder.Entity<Order>()
                .Property(e => e.ProductCategory)
                .IsUnicode(false);

            modelBuilder.Entity<Order>()
                .Property(e => e.MBACodeGroup)
                .IsUnicode(false);

            modelBuilder.Entity<Order>()
                .Property(e => e.MBACodeType)
                .IsUnicode(false);

            modelBuilder.Entity<Order>()
                .Property(e => e.DepartmentCode)
                .IsUnicode(false);

            modelBuilder.Entity<Order>()
                .Property(e => e.DepartmentTypeGroup)
                .IsUnicode(false);

            modelBuilder.Entity<Order>()
                .Property(e => e.DepartmentType)
                .IsUnicode(false);

            modelBuilder.Entity<Order>()
                .Property(e => e.OrderSourceGroup)
                .IsUnicode(false);

            modelBuilder.Entity<Order>()
                .Property(e => e.OrderSourceType)
                .IsUnicode(false);

            modelBuilder.Entity<Order>()
                .Property(e => e.FileTypeGroup)
                .IsUnicode(false);

            modelBuilder.Entity<Order>()
                .Property(e => e.FileType)
                .IsUnicode(false);

            modelBuilder.Entity<Order>()
                .Property(e => e.Version)
                .IsFixedLength();

            modelBuilder.Entity<Order>()
                .HasMany(e => e.Cancellations)
                .WithOptional(e => e.CancelledOrder)
                .HasForeignKey(e => e.CancelledOrderId);

            modelBuilder.Entity<Order>()
               .Property(e => e.RequestorCode)
               .IsUnicode(false);

            modelBuilder.Entity<WorkOrder>()
                .Property(e => e.WorkOrderStatusGroup)
                .IsUnicode(false);

            modelBuilder.Entity<WorkOrder>()
                .Property(e => e.WorkOrderStatusType)
                .IsUnicode(false);

            modelBuilder.Entity<WorkOrder>()
                .Property(e => e.CancellationReasonGroup)
                .IsUnicode(false);

            modelBuilder.Entity<WorkOrder>()
                .Property(e => e.CancellationReasonType)
                .IsUnicode(false);

            modelBuilder.Entity<WorkOrder>()
                .Property(e => e.BorrowerFirstName)
                .IsUnicode(false);

            modelBuilder.Entity<WorkOrder>()
                .Property(e => e.BorrowerMiddleInitial)
                .IsFixedLength()
                .IsUnicode(false);

            modelBuilder.Entity<WorkOrder>()
                .Property(e => e.BorrowerLastName)
                .IsUnicode(false);

            modelBuilder.Entity<WorkOrder>()
                .Property(e => e.AddressLine1)
                .IsUnicode(false);

            modelBuilder.Entity<WorkOrder>()
                .Property(e => e.AddressLine2)
                .IsUnicode(false);

            modelBuilder.Entity<WorkOrder>()
                .Property(e => e.CityName)
                .IsUnicode(false);

            modelBuilder.Entity<WorkOrder>()
                .Property(e => e.StateCode)
                .IsFixedLength()
                .IsUnicode(false);

            modelBuilder.Entity<WorkOrder>()
                .Property(e => e.ZipCode)
                .IsFixedLength()
                .IsUnicode(false);

            modelBuilder.Entity<WorkOrder>()
                .Property(e => e.ZipPlusFour)
                .IsFixedLength()
                .IsUnicode(false);

            modelBuilder.Entity<WorkOrder>()
                .Property(e => e.CountyName)
                .IsUnicode(false);

            modelBuilder.Entity<WorkOrder>()
                .Property(e => e.SpecialInstructions)
                .IsUnicode(false);

            modelBuilder.Entity<WorkOrder>()
                .Property(e => e.PayVendorGroup)
                .IsUnicode(false);

            modelBuilder.Entity<WorkOrder>()
                .Property(e => e.PayVendorType)
                .IsUnicode(false);

            modelBuilder.Entity<WorkOrder>()
                .Property(e => e.DoorCardTypeGroup)
                .IsUnicode(false);

            modelBuilder.Entity<WorkOrder>()
                .Property(e => e.DoorCardType)
                .IsUnicode(false);

            modelBuilder.Entity<WorkOrder>()
                .Property(e => e.DoorCardMessageText)
                .IsUnicode(false);

            modelBuilder.Entity<WorkOrder>()
                .Property(e => e.InspectorUniqueId)
                .IsUnicode(false);

            modelBuilder.Entity<WorkOrder>()
                .Property(e => e.TotalAmountDue)
                .HasPrecision(19, 4);

            modelBuilder.Entity<WorkOrder>()
                .Property(e => e.SubTotalDue)
                .HasPrecision(19, 4);

            modelBuilder.Entity<WorkOrder>()
                .Property(e => e.Version)
                .IsFixedLength();

            modelBuilder.Entity<WorkOrder>()
                .HasMany(e => e.Cancellations)
                .WithOptional(e => e.CancelledWorkOrder)
                .HasForeignKey(e => e.CancelledWorkOrderId);


            modelBuilder.Entity<WorkOrderItem>()
                .Property(e => e.WorkOrderItemStatusGroup)
                .IsUnicode(false);

            modelBuilder.Entity<WorkOrderItem>()
                .Property(e => e.WorkOrderItemStatusType)
                .IsUnicode(false);

            modelBuilder.Entity<WorkOrderItem>()
                .Property(e => e.Version)
                .IsFixedLength();

            modelBuilder.Entity<APDetailView>()
                .Property(e => e.VendorName)
                .IsUnicode(false);

            modelBuilder.Entity<APDetailView>()
                .Property(e => e.ProductName)
                .IsUnicode(false);

            modelBuilder.Entity<APDetailView>()
                .Property(e => e.BaseAmount)
                .HasPrecision(19, 4);

            modelBuilder.Entity<APDetailView>()
                .Property(e => e.EligibleAmount)
                .HasPrecision(19, 4);

            modelBuilder.Entity<APDetailView>()
                .Property(e => e.InvoiceNumber)
                .IsUnicode(false);

            modelBuilder.Entity<APDetailView>()
                .Property(e => e.CheckNumber)
                .IsUnicode(false);

            modelBuilder.Entity<APDetailView>()
                .Property(e => e.PaidAmount)
                .HasPrecision(19, 4);

            modelBuilder.Entity<APDetailView>()
               .Property(e => e.Status)
               .IsUnicode(false);



            modelBuilder.Entity<ARDetailView>()
                .Property(e => e.ClientName)
                .IsUnicode(false);

            modelBuilder.Entity<ARDetailView>()
                .Property(e => e.ProductName)
                .IsUnicode(false);

            modelBuilder.Entity<ARDetailView>()
                .Property(e => e.BaseAmount)
                .HasPrecision(19, 4);

            modelBuilder.Entity<ARDetailView>()
                .Property(e => e.EligibleAmount)
                .HasPrecision(19, 4);

            modelBuilder.Entity<ARDetailView>()
                .Property(e => e.TaxRate)
                .HasPrecision(19, 4);

            modelBuilder.Entity<ARDetailView>()
                .Property(e => e.TaxAmount)
                .HasPrecision(19, 4);

            modelBuilder.Entity<ARDetailView>()
                .Property(e => e.TotalAmount)
                .HasPrecision(19, 4);

            modelBuilder.Entity<ARDetailView>()
                .Property(e => e.InvoiceNumber)
                .IsUnicode(false);

            modelBuilder.Entity<ARDetailView>()
                .Property(e => e.Status)
                .IsUnicode(false);

            modelBuilder.Entity<APAdjustmentDetailView>()
               .Property(e => e.InvoiceNumber)
               .IsUnicode(false);

            modelBuilder.Entity<APAdjustmentDetailView>()
                .Property(e => e.InvoiceAmount)
                .HasPrecision(19, 4);

            modelBuilder.Entity<APAdjustmentDetailView>()
                .Property(e => e.InspectorUniqueId)
                .IsUnicode(false);

            modelBuilder.Entity<APAdjustmentDetailView>()
                .Property(e => e.AdjustmentType)
                .IsUnicode(false);

            modelBuilder.Entity<APAdjustmentDetailView>()
                .Property(e => e.AdjustmentCode)
                .IsUnicode(false);

            modelBuilder.Entity<APAdjustmentDetailView>()
                .Property(e => e.Amount)
                .HasPrecision(19, 4);

            modelBuilder.Entity<APAdjustmentDetailView>()
                .Property(e => e.Operation)
                .IsUnicode(false);

            modelBuilder.Entity<APAdjustmentDetailView>()
                .Property(e => e.FunctionValue)
                .IsUnicode(false);

            modelBuilder.Entity<APAdjustmentDetailView>()
                .Property(e => e.NaturalAccount)
                .IsUnicode(false);

            modelBuilder.Entity<APAdjustmentDetailView>()
                .Property(e => e.Comments)
                .IsUnicode(false);

            modelBuilder.Entity<ARAdjustmentDetailView>()
                .Property(e => e.InvoiceNumber)
                .IsUnicode(false);

            modelBuilder.Entity<ARAdjustmentDetailView>()
                .Property(e => e.AdjustmentType)
                .IsUnicode(false);

            modelBuilder.Entity<ARAdjustmentDetailView>()
                .Property(e => e.Amount)
                .HasPrecision(19, 4);

            modelBuilder.Entity<ARAdjustmentDetailView>()
                .Property(e => e.TaxRate)
                .HasPrecision(19, 4);

            modelBuilder.Entity<ARAdjustmentDetailView>()
                .Property(e => e.TaxAmount)
                .HasPrecision(19, 4);

            modelBuilder.Entity<ARAdjustmentDetailView>()
                .Property(e => e.Operation)
                .IsUnicode(false);

            modelBuilder.Entity<ARAdjustmentDetailView>()
                .Property(e => e.FunctionValue)
                .IsUnicode(false);

            modelBuilder.Entity<ARAdjustmentDetailView>()
                .Property(e => e.NaturalAccount)
                .IsUnicode(false);

            modelBuilder.Entity<ARAdjustmentDetailView>()
                .Property(e => e.Comments)
                .IsUnicode(false);

            modelBuilder.Entity<ARAdjustmentDetailView>()
                .Property(e => e.AdjustmentCode)
                .IsUnicode(false);

            modelBuilder.Entity<Document>()
              .Property(e => e.DocumentName)
              .IsUnicode(false);

            modelBuilder.Entity<Document>()
                .Property(e => e.DocumentDesc)
                .IsUnicode(false);

            modelBuilder.Entity<Document>()
                .Property(e => e.DocTypeGroup)
                .IsUnicode(false);

            modelBuilder.Entity<Document>()
                .Property(e => e.DocumentType)
                .IsUnicode(false);

            modelBuilder.Entity<Document>()
                .Property(e => e.MimeType)
                .IsUnicode(false);

            modelBuilder.Entity<Document>()
                .Property(e => e.DocumentPath)
                .IsUnicode(false);

            modelBuilder.Entity<Document>()
                .Property(e => e.Version)
                .IsFixedLength();

            #endregion

            modelBuilder.Entity<RRRInvoiceJSONHeader>()
                .Property(e => e.Version)
                .IsFixedLength();

            modelBuilder.Entity<RRRInvoiceJSONDetail>()
                .Property(e => e.Version)
                .IsFixedLength();

            modelBuilder.Entity<RRRInvoiceHeaderTracking>()
             .Property(e => e.Version)
             .IsFixedLength();

            modelBuilder.Entity<RRRDecisionInvoiceItemTracking>()
            .Property(e => e.Version)
            .IsFixedLength();
        }

        #endregion
    }
}
