﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using DomainModel.Accounting;
using InspProxy = Inspections.ServiceProxy.InspectionSvc;
using PresProxy = Pres.ServiceProxy.PresSvc;
using RefactorThis.GraphDiff;

using System.Data.Entity.Validation;
using CommonLib;
using System.Data.SqlClient;

namespace DataAccess.Accounting
{
    using BillProxy = Billing.ServiceProxy.BillingSyncSvc;
    public class AccountingBillingDao
    {
        public AccountsReceivable SaveAccountsReceivableOnly(AccountsReceivable accountsReceivable, int workOrderId)
        {
            if (accountsReceivable == null || workOrderId <= 0)
                throw new ArgumentNullException("accountsReceivable, workOrderId");

            using (AccountingData ctx = new AccountingData())
            {
                bool saveFailed = false;
                int tryCount = 0;
                do
                {
                    try
                    {
                        var wo = ctx.WorkOrders.Where(p => p.WorkOrderId == workOrderId).SingleOrDefault();
                        if (wo == null) throw new ArgumentOutOfRangeException("workOrderId");
                        wo.AcctProcessedDate = DateTime.UtcNow;
                        wo.WorkOrderStatusType = string.Compare(wo.WorkOrderStatusType, "CANCEL", true) == 0 ? wo.WorkOrderStatusType : "BILLED";
                        wo.TotalAmountDue = accountsReceivable.TotalAmountDue;
                        wo.SubTotalDue = accountsReceivable.TotalAmountDue;
                        ctx.AccountsReceivables.Add(accountsReceivable);
                        ctx.SaveChanges();
                        saveFailed = false;
                    }
                    catch (DbUpdateConcurrencyException ex)
                    {
                        saveFailed = true;
                        tryCount++;
                        if (tryCount <= AccountingData.DbUpdateConcurrencyException_ReTryLimit)
                        {
                            // Update original values from the database 
                            foreach (var entry in ex.Entries)
                            {
                                var dbValue = entry.GetDatabaseValues();
                                if (dbValue != null)
                                    entry.OriginalValues.SetValues(dbValue);
                                else
                                {
                                    saveFailed = false; //give up since the original db record is deleted and there is no reason to retry
                                    break;
                                }
                            }
                        }
                        else
                        {
                            CommonLib.Logging.LogError(ex);
                            throw;
                        }
                    }
                } while (saveFailed && tryCount <= AccountingData.DbUpdateConcurrencyException_ReTryLimit);
            }
            return accountsReceivable;
        }

        public AccountsPayable SaveAccountsPayableOnly(AccountsPayable accountsPayable, int workOrderId)
        {
            if (accountsPayable == null || workOrderId <= 0)
                throw new ArgumentNullException("accountsPayable,, workOrderId");

            using (AccountingData ctx = new AccountingData())
            {
                bool saveFailed = false;
                int tryCount = 0;
                do
                {
                    try
                    {
                        var wo = ctx.WorkOrders.Where(p => p.WorkOrderId == workOrderId).SingleOrDefault();
                        if (wo == null) throw new ArgumentOutOfRangeException("workOrderId");
                        wo.AcctProcessedDate = DateTime.UtcNow;
                        wo.WorkOrderStatusType = string.Compare(wo.WorkOrderStatusType, "CANCEL", true) == 0 ? wo.WorkOrderStatusType : "BILLED";
                        ctx.AccountsPayables.Add(accountsPayable);
                        ctx.SaveChanges();
                        saveFailed = false;
                    }
                    catch (DbUpdateConcurrencyException ex)
                    {
                        saveFailed = true;
                        tryCount++;
                        if (tryCount <= AccountingData.DbUpdateConcurrencyException_ReTryLimit)
                        {
                            // Update original values from the database 
                            foreach (var entry in ex.Entries)
                            {
                                var dbValue = entry.GetDatabaseValues();
                                if (dbValue != null)
                                    entry.OriginalValues.SetValues(dbValue);
                                else
                                {
                                    saveFailed = false; //give up since the original db record is deleted and there is no reason to retry
                                    break;
                                }
                            }
                        }
                        else
                        {
                            CommonLib.Logging.LogError(ex);
                            throw;
                        }
                    }
                } while (saveFailed && tryCount <= AccountingData.DbUpdateConcurrencyException_ReTryLimit);
            }
            return accountsPayable;
        }

        public void SaveAccountsBilling(AccountsReceivable receivable, AccountsPayable payable, int workOrderId)
        {
            if (receivable == null || payable == null || workOrderId <= 0)
                throw new ArgumentNullException("receivable, payable, workOrderId");

            using (AccountingData ctx = new AccountingData())
            {
                bool saveFailed = false;
                int tryCount = 0;
                do
                {
                    try
                    {
                        var wo = ctx.WorkOrders.Where(p => p.WorkOrderId == workOrderId).SingleOrDefault();
                        if (wo == null) throw new ArgumentOutOfRangeException("workOrderId");

                        wo.AcctProcessedDate = DateTime.UtcNow;
                        wo.WorkOrderStatusType = string.Compare(wo.WorkOrderStatusType, "CANCEL", true) == 0 ? wo.WorkOrderStatusType : "BILLED";
                        wo.TotalAmountDue = receivable.TotalAmountDue;
                        wo.SubTotalDue = receivable.TotalAmountDue;
                        ctx.AccountsPayables.Add(payable);
                        ctx.AccountsReceivables.Add(receivable);
                        ctx.SaveChanges();
                        saveFailed = false;
                    }
                    catch (DbUpdateConcurrencyException ex)
                    {
                        saveFailed = true;
                        tryCount++;
                        if (tryCount <= AccountingData.DbUpdateConcurrencyException_ReTryLimit)
                        {
                            // Update original values from the database 
                            foreach (var entry in ex.Entries)
                            {
                                var dbValue = entry.GetDatabaseValues();
                                if (dbValue != null)
                                    entry.OriginalValues.SetValues(dbValue);
                                else
                                {
                                    saveFailed = false; //give up since the original db record is deleted and there is no reason to retry
                                    break;
                                }
                            }
                        }
                        else
                        {
                            CommonLib.Logging.LogError(ex);
                            throw;
                        }
                    }
                } while (saveFailed && tryCount <= AccountingData.DbUpdateConcurrencyException_ReTryLimit);
            }
        }

        public List<OrderHierarchy> SaveAccountsReceivableOnly(List<OrderHierarchy> accountsReceivable)
        {
            if (accountsReceivable == null)
                throw new ArgumentNullException("accountsReceivable");

            using (AccountingData ctx = new AccountingData())
            {
                List<int?> woLst = accountsReceivable.Select(x => x.WorkOrderId).Distinct().ToList();
                foreach (int? workOrderId in woLst)
                {
                    if (workOrderId.HasValue)
                    {
                        var wo = ctx.WorkOrders.Where(p => p.WorkOrderId == workOrderId).SingleOrDefault();
                        if (wo == null) throw new ArgumentOutOfRangeException("workOrderId");
                        wo.AcctProcessedDate = DateTime.UtcNow;
                        wo.WorkOrderStatusType = string.Compare(wo.WorkOrderStatusType, "CANCEL", true) == 0 ? wo.WorkOrderStatusType : "BILLED";
                        wo.TotalAmountDue = accountsReceivable.Where(p => p.WorkOrderId == workOrderId).SelectMany(ar => ar.AccountsReceivableDetails).Select(ard => ard.FinalTotalPrice).Sum();
                        wo.SubTotalDue = wo.TotalAmountDue;
                    }
                }
                var list = new List<AccountsReceivableDetail>();
                foreach (var rec in accountsReceivable)
                {
                    list.AddRange(rec.AccountsReceivableDetails.ToList());
                }
                ctx.AccountsReceivableDetails.AddRange(list);

                var recAdjHLst = new List<DisputeReceivableAdjustmentHistory>();
                foreach (var rec in accountsReceivable)
                {
                    recAdjHLst.AddRange(rec.DisputeReceivableAdjustmentHistorys.ToList());
                }
                ctx.DisputeReceivableAdjustmentHistorys.AddRange(recAdjHLst);

                ctx.SaveChanges();
            }
            return accountsReceivable;
        }

        public List<OrderHierarchy> SaveAccountsPayableOnly(List<OrderHierarchy> accountsPayable)
        {
            if (accountsPayable == null)
                throw new ArgumentNullException("accountsPayable");

            using (AccountingData ctx = new AccountingData())
            {
                List<int?> woLst = accountsPayable.Select(x => x.WorkOrderId).Distinct().ToList();
                foreach (int? workOrderId in woLst)
                {
                    if (workOrderId.HasValue)
                    {
                        var wo = ctx.WorkOrders.Where(p => p.WorkOrderId == workOrderId).SingleOrDefault();
                        if (wo == null) throw new ArgumentOutOfRangeException("workOrderId");
                        wo.AcctProcessedDate = DateTime.UtcNow;
                        wo.WorkOrderStatusType = string.Compare(wo.WorkOrderStatusType, "CANCEL", true) == 0 ? wo.WorkOrderStatusType : "BILLED";
                    }
                }

                var list = new List<AccountsPayableDetail>();
                foreach (var pay in accountsPayable)
                {
                    list.AddRange(pay.AccountsPayableDetails.ToList());
                }
                ctx.AccountsPayableDetails.AddRange(list);

                var payAdjHLst = new List<DisputePayableAdjustmentHistory>();
                foreach (var pay in accountsPayable)
                {
                    payAdjHLst.AddRange(pay.DisputePayableAdjustmentHistorys.ToList());
                }
                ctx.DisputePayableAdjustmentHistorys.AddRange(payAdjHLst);

                ctx.SaveChanges();
            }
            return accountsPayable;
        }

        public void SaveAccountsBilling(List<OrderHierarchy> receivable, List<OrderHierarchy> payable)
        {
            if (receivable == null || payable == null)
                throw new ArgumentNullException("receivable, payable");

            using (AccountingData ctx = new AccountingData())
            {
                List<int?> woLst = receivable.Select(x => x.WorkOrderId).Distinct().ToList();
                foreach (int? workOrderId in woLst)
                {
                    if (workOrderId.HasValue)
                    {
                        var wo = ctx.WorkOrders.Where(p => p.WorkOrderId == workOrderId).SingleOrDefault();
                        if (wo == null) throw new ArgumentOutOfRangeException("workOrderId");
                        wo.AcctProcessedDate = DateTime.UtcNow;
                        wo.WorkOrderStatusType = string.Compare(wo.WorkOrderStatusType, "CANCEL", true) == 0 ? wo.WorkOrderStatusType : "BILLED";
                        wo.TotalAmountDue = receivable.Where(p => p.WorkOrderId == workOrderId).SelectMany(ar => ar.AccountsReceivableDetails).Select(ard => ard.FinalTotalPrice).Sum();
                        wo.SubTotalDue = wo.TotalAmountDue;
                    }
                }
                var recLst = new List<AccountsReceivableDetail>();
                foreach (var rec in receivable)
                {
                    recLst.AddRange(rec.AccountsReceivableDetails.ToList());
                }
                ctx.AccountsReceivableDetails.AddRange(recLst);

                var payLst = new List<AccountsPayableDetail>();
                foreach (var pay in payable)
                {
                    payLst.AddRange(pay.AccountsPayableDetails.ToList());
                }
                ctx.AccountsPayableDetails.AddRange(payLst);

                var payAdjHLst = new List<DisputePayableAdjustmentHistory>();
                foreach (var pay in payable)
                {
                    payAdjHLst.AddRange(pay.DisputePayableAdjustmentHistorys.ToList());
                }
                ctx.DisputePayableAdjustmentHistorys.AddRange(payAdjHLst);

                var recAdjHLst = new List<DisputeReceivableAdjustmentHistory>();
                foreach (var rec in receivable)
                {
                    recAdjHLst.AddRange(rec.DisputeReceivableAdjustmentHistorys.ToList());
                }
                ctx.DisputeReceivableAdjustmentHistorys.AddRange(recAdjHLst);

                ctx.SaveChanges();
            }
        }

        public OrderHierarchy GetSetOrderHierarchyByFK(int orderId, int? vendorWorkOrderId, int? workOrderId, int? workOrderItemId, int? workOrderLineItemId)
        {
            using (AccountingData ctx = new AccountingData())
            {
                var ordHry = ctx.OrderHierarchys.Where(p => p.OrderId == orderId && p.VendorWorkOrderId == vendorWorkOrderId && p.WorkOrderId == workOrderId
                    && p.WorkOrderItemId == workOrderItemId && p.WorkOrderLineItemId == workOrderLineItemId).FirstOrDefault();
                if (ordHry == null)
                {
                    OrderHierarchy ordH = new OrderHierarchy();
                    ordH.OrderId = orderId;

                    if (vendorWorkOrderId.HasValue)
                        ordH.VendorWorkOrderId = vendorWorkOrderId;

                    if (workOrderId.HasValue)
                        ordH.WorkOrderId = workOrderId;

                    if (workOrderItemId.HasValue)
                        ordH.WorkOrderItemId = workOrderItemId;

                    if (workOrderLineItemId.HasValue)
                        ordH.WorkOrderLineItemId = workOrderLineItemId;

                    ctx.OrderHierarchys.Add(ordH);
                    ctx.SaveChanges();

                    return ordH;
                }
                else
                {
                    return ordHry;
                }
            }
        }

        public FeeType GetFeeType(string feeTypeName)
        {
            using (AccountingData ctx = new AccountingData())
            {
                var ft = ctx.FeeTypes.Where(p => p.FeeTypeName == feeTypeName).SingleOrDefault();
                if (ft == null) throw new ArgumentOutOfRangeException("feeTypeName");
                return ft;
            }
        }

        public FeeType GetFeeTypeById(int feeTypeId)
        {
            using (AccountingData ctx = new AccountingData())
            {
                var ft = ctx.FeeTypes.Where(p => p.FeeTypeId == feeTypeId).SingleOrDefault();
                if (ft == null) throw new ArgumentOutOfRangeException("feeTypeName");
                return ft;
            }
        }

        public DateTime? GetWorkOrderCancellationDate(int workOrderId)
        {
            using (AccountingData ctx = new AccountingData())
            {
                var wo = ctx.WorkOrders.Where(p => p.WorkOrderId == workOrderId).SingleOrDefault();
                if (wo == null) throw new ArgumentOutOfRangeException("workOrderId");
                return wo.CancellationDate;
            }
        }

        public bool CheckOrderFeesByOrderHierarchyId(int orderHId)
        {
            bool isExists = false;
            using (AccountingData ctx = new AccountingData())
            {
                var ordHry = ctx.DisputeReceivableAdjustmentHistorys.Where(p => p.OrderHierarchyId == orderHId).FirstOrDefault();
                if (ordHry != null)
                {
                    isExists = true;
                }
            }
            return isExists;
        }

        public bool CheckVendorWorkOrderFeesByOrderHierarchyId(int orderHId)
        {
            bool isExists = false;
            using (AccountingData ctx = new AccountingData())
            {
                var ordHry = ctx.DisputePayableAdjustmentHistorys.Where(p => p.OrderHierarchyId == orderHId).FirstOrDefault();
                if (ordHry != null)
                {
                    isExists = true;
                }
            }
            return isExists;
        }

        public bool CheckAPDetailByOrderHierarchyId(int orderHId, int? feeTypeId)
        {
            bool isExists = false;
            using (AccountingData ctx = new AccountingData())
            {
                var ordHry = ctx.AccountsPayableDetails.Where(p => p.OrderHierarchyId == orderHId && p.FeeTypeId == feeTypeId).FirstOrDefault();
                if (ordHry != null)
                {
                    isExists = true;
                }
            }
            return isExists;
        }

        public bool CheckARDetailByOrderHierarchyId(int orderHId, int? feeTypeId)
        {
            bool isExists = false;
            using (AccountingData ctx = new AccountingData())
            {
                var ordHry = ctx.AccountsReceivableDetails.Where(p => p.OrderHierarchyId == orderHId && p.FeeTypeId == feeTypeId).FirstOrDefault();
                if (ordHry != null)
                {
                    isExists = true;
                }
            }
            return isExists;
        }

        public string GetProductCodeBySourceWorkOrderId(int sourceWorkOrderId)
        {
            if (sourceWorkOrderId <= 0)
                throw new ArgumentOutOfRangeException("sourceWorkOrderId");
            using (AccountingData ctx = new AccountingData())
            {
                var productCode = (from workOrder in ctx.WorkOrders
                                   join product in ctx.Products on workOrder.ProductId equals product.ProductId
                                   where workOrder.SourceWorkOrderId == sourceWorkOrderId
                                   select product.ProductCode).SingleOrDefault();
                return productCode;
            }
        }

        public List<PresBillingDetailView> GetPresBillingDetailsBySourceWorkOrderId(int sourceWorkOrderId)
        {
            if (sourceWorkOrderId <= 0)
                throw new ArgumentOutOfRangeException("sourceWorkOrderId");
            using (AccountingData ctx = new AccountingData())
            {
                var vw = ctx.PresBillingDetailViews.Where(f => f.SourceWorkOrderId == sourceWorkOrderId).Distinct();
                if (vw != null)
                {
                    return vw.OrderBy(x => x.WorkOrderId).ThenBy(x => x.WorkOrderItemId).ToList();
                }
                else
                    return new List<PresBillingDetailView>();
            }
        }

        public void SyncTxnEntitiesByInspWorkOrder(InspProxy.WorkOrder inspWorkOrder)
        {
            if (inspWorkOrder == null) throw new ArgumentNullException("inspWorkOrder");
            if (inspWorkOrder.Order == null) throw new ArgumentNullException("inspWorkOrder", "Missing Order for the inspection work order");
            if (inspWorkOrder.Order.Loan == null) throw new ArgumentNullException("inspWorkOrder", "Missing Loan for the inspection work order");
            if (inspWorkOrder.Order.Loan.Asset == null) throw new ArgumentNullException("inspWorkOrder", "Missing Asset for the inspection work order");
            if (inspWorkOrder.WorkOrderItems == null || inspWorkOrder.WorkOrderItems.Count == 0) throw new ArgumentNullException("inspWorkOrder", "Missing Work Order Items for the inspection work order");

            using (AccountingData ctx = new AccountingData())
            {
                try
                {
                    //Sync Order
                    Order platformOrder = ctx.Orders.Where(od => od.SourceOrderId == inspWorkOrder.Order.OrderId && TenantHierarchyHelper.TenantApplicationIds.Contains(od.ApplicationId)).SingleOrDefault();
                    TxnEntitySynchronizer<InspProxy.Order> orderSynchronizer = new TxnEntitySynchronizer<InspProxy.Order>();
                    platformOrder = (Order)orderSynchronizer.Synchronize(inspWorkOrder.Order, platformOrder);
                    if (platformOrder.OrderId == 0)
                    {
                        ctx.Orders.Add(platformOrder);
                    }

                    //Sync Loan
                    Loan platformLoan = ctx.Loans.Where(ln => ln.SourceLoanId == inspWorkOrder.Order.Loan.LoanId && TenantHierarchyHelper.TenantApplicationIds.Contains(ln.ApplicationId)).SingleOrDefault();
                    TxnEntitySynchronizer<InspProxy.Loan> loanSynchronizer = new TxnEntitySynchronizer<InspProxy.Loan>();
                    platformLoan = (Loan)loanSynchronizer.Synchronize(inspWorkOrder.Order.Loan, platformLoan);
                    if (platformLoan.LoanId == 0)
                    {
                        ctx.Loans.Add(platformLoan);
                        platformLoan.Orders.Add(platformOrder);
                    }
                    else platformOrder.LoanId = platformLoan.LoanId;

                    //Sync Asset
                    Asset platformAsset = ctx.Assets.Where(at => at.SourceAssetId == inspWorkOrder.Order.Loan.Asset.AssetId && TenantHierarchyHelper.TenantApplicationIds.Contains(at.ApplicationId)).SingleOrDefault();
                    TxnEntitySynchronizer<InspProxy.Asset> assetSynchronizer = new TxnEntitySynchronizer<InspProxy.Asset>();
                    platformAsset = (Asset)assetSynchronizer.Synchronize(inspWorkOrder.Order.Loan.Asset, platformAsset);
                    if (platformAsset.AssetId == 0)
                    {
                        ctx.Assets.Add(platformAsset);
                        platformAsset.Loans.Add(platformLoan);
                    }
                    else platformLoan.AssetId = platformAsset.AssetId;

                    ctx.SaveChanges();
                }
                catch (DbUpdateException dbUpdateEx)
                {
                    if (dbUpdateEx != null && dbUpdateEx.InnerException != null && dbUpdateEx.InnerException.InnerException != null)
                    {
                        SqlException sqlException = dbUpdateEx.InnerException.InnerException as SqlException;
                        if (sqlException != null)
                        {
                            switch (sqlException.Number)
                            {
                                case 2627:  // Unique key constraint
                                    Logging.LogError(string.Format("Unique key constraint error as part of Accounting Sync for the Inspection work order {0}, exception {1}", inspWorkOrder.WorkOrderId, dbUpdateEx));
                                    break;
                                case 2601: // Duplicate key
                                    Logging.LogError(string.Format("Duplicate key error as part of Accounting Sync for the Inspection work order {0}, exception {1}", inspWorkOrder.WorkOrderId, dbUpdateEx));
                                    break;
                                default:
                                    CommonLib.Logging.LogError(dbUpdateEx);
                                    throw;
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    CommonLib.Logging.LogError(ex);
                    throw;
                }
            }

            using (AccountingData ctx = new AccountingData())
            {
                Order platformOrder = ctx.Orders.Where(od => od.SourceOrderId == inspWorkOrder.Order.OrderId && TenantHierarchyHelper.TenantApplicationIds.Contains(od.ApplicationId)).SingleOrDefault();

                //Sync Work Order
                WorkOrder platformWorkOrder = ctx.WorkOrders.Where(wo => wo.SourceWorkOrderId == inspWorkOrder.WorkOrderId && TenantHierarchyHelper.TenantApplicationIds.Contains(wo.ApplicationId)).SingleOrDefault();
                TxnEntitySynchronizer<InspProxy.WorkOrder> workOrderSynchronizer = new TxnEntitySynchronizer<InspProxy.WorkOrder>();
                platformWorkOrder = (WorkOrder)workOrderSynchronizer.Synchronize(inspWorkOrder, platformWorkOrder);
                if (platformWorkOrder.WorkOrderId == 0)
                {
                    platformWorkOrder.OrderId = platformOrder.OrderId;
                    ctx.WorkOrders.Add(platformWorkOrder);
                }

                ctx.SaveChanges();
            }

            using (AccountingData ctx = new AccountingData())
            {
                WorkOrder platformWorkOrder = ctx.WorkOrders.Where(wo => wo.SourceWorkOrderId == inspWorkOrder.WorkOrderId && TenantHierarchyHelper.TenantApplicationIds.Contains(wo.ApplicationId)).SingleOrDefault();
                Order platformOrder = ctx.Orders.Where(od => od.SourceOrderId == inspWorkOrder.Order.OrderId && TenantHierarchyHelper.TenantApplicationIds.Contains(od.ApplicationId)).SingleOrDefault();
                Loan platformLoan = ctx.Loans.Where(ln => ln.SourceLoanId == inspWorkOrder.Order.Loan.LoanId && TenantHierarchyHelper.TenantApplicationIds.Contains(ln.ApplicationId)).SingleOrDefault();

                if (platformWorkOrder != null && platformOrder != null && platformLoan != null)
                {
                    try
                    {
                        //Special handling on CreatedDate for Loan, Order and Work Order
                        platformLoan.CreatedDate = ConvertToUtc(inspWorkOrder.Order.Loan.CreatedDate);
                        platformOrder.CreatedDate = ConvertToUtc(inspWorkOrder.Order.CreatedDate);
                        platformWorkOrder.CreatedDate = ConvertToUtc(inspWorkOrder.CreatedDate);

                        //Sync Work Order Items
                        TxnEntitySynchronizer<InspProxy.WorkOrderItem> workOrderItemSynchronizer = new TxnEntitySynchronizer<InspProxy.WorkOrderItem>();
                        if (inspWorkOrder.WorkOrderItems != null && inspWorkOrder.WorkOrderItems.Count > 0)
                        {
                            inspWorkOrder.WorkOrderItems.ForEach(inspWorkOrderItem =>
                            {
                                WorkOrderItem platformWorkOrderItem = ctx.WorkOrderItems.Where(woi => woi.SourceWorkOrderItemId == inspWorkOrderItem.WorkOrderItemId && TenantHierarchyHelper.TenantApplicationIds.Contains(woi.ApplicationId)).SingleOrDefault();
                                platformWorkOrderItem = (WorkOrderItem)workOrderItemSynchronizer.Synchronize(inspWorkOrderItem, platformWorkOrderItem);
                                platformWorkOrderItem.WorkOrderId = platformWorkOrder.WorkOrderId;
                                platformWorkOrderItem.OrderId = platformOrder.OrderId;
                                if (platformWorkOrderItem.WorkOrderItemId == 0) ctx.WorkOrderItems.Add(platformWorkOrderItem);
                            });
                        }

                        //Sync Cancellation
                        TxnEntitySynchronizer<InspProxy.Cancellation> cancellationSynchronizer = new TxnEntitySynchronizer<InspProxy.Cancellation>();
                        if (inspWorkOrder.Order.Cancellations != null && inspWorkOrder.Order.Cancellations.Count > 0)
                        {
                            foreach (InspProxy.Cancellation inspCancellation in inspWorkOrder.Order.Cancellations.Where(c =>
                                (c.CancelledWorkOrderId == null || c.CancelledWorkOrderId.HasValue && c.CancelledWorkOrderId.Value == inspWorkOrder.WorkOrderId)).OrderBy(c => c.CancellationId).ToList())
                            {
                                int? cLoanId = new Nullable<int>();
                                int? cOrderId = new Nullable<int>();
                                int? cWOId = new Nullable<int>();

                                if (inspCancellation.CancelledWorkOrderId.HasValue)
                                {
                                    cWOId = platformWorkOrder.WorkOrderId;
                                }
                                if (inspCancellation.CancelledOrderId.HasValue)
                                {
                                    cOrderId = platformOrder.OrderId;
                                }
                                if (inspCancellation.CancelledLoanId.HasValue)
                                {
                                    cLoanId = platformLoan.LoanId;
                                }

                                Cancellation platformCancellation = ctx.Cancellations.Where(c => c.SourceCancellationId == inspCancellation.CancellationId
                                    && TenantHierarchyHelper.TenantApplicationIds.Contains(c.ApplicationId)).SingleOrDefault();
                                platformCancellation = (Cancellation)cancellationSynchronizer.Synchronize(inspCancellation, platformCancellation);

                                if (platformCancellation.CancellationId == 0)
                                {
                                    platformCancellation.CancelledLoanId = cLoanId;
                                    platformCancellation.CancelledOrderId = cOrderId;
                                    platformCancellation.CancelledWorkOrderId = cWOId;
                                    ctx.Cancellations.Add(platformCancellation);
                                }
                                else
                                {
                                    platformCancellation.CancelledLoanId = cLoanId;
                                    platformCancellation.CancelledOrderId = cOrderId;
                                    platformCancellation.CancelledWorkOrderId = cWOId;
                                }
                            }
                        }
                        ctx.SaveChanges();
                    }
                    catch (DbUpdateException dbUpdateEx)
                    {
                        if (dbUpdateEx != null && dbUpdateEx.InnerException != null && dbUpdateEx.InnerException.InnerException != null)
                        {
                            SqlException sqlException = dbUpdateEx.InnerException.InnerException as SqlException;
                            if (sqlException != null)
                            {
                                switch (sqlException.Number)
                                {
                                    case 2627:  // Unique key constraint
                                        Logging.LogError(string.Format("Unique key constraint error as part of Accounting Sync for the Inspection work order {0}, exception {1}", inspWorkOrder.WorkOrderId, dbUpdateEx));
                                        break;
                                    case 2601: // Duplicate key
                                        Logging.LogError(string.Format("Duplicate key error as part of Accounting Sync for the Inspection work order {0}, exception {1}", inspWorkOrder.WorkOrderId, dbUpdateEx));
                                        break;
                                    default:
                                        CommonLib.Logging.LogError(dbUpdateEx);
                                        throw;
                                }
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        CommonLib.Logging.LogError(ex);
                        throw;
                    }
                }
            }
        }

        private DateTime ConvertToUtc(DateTime dt)
        {
            if (dt.Kind == DateTimeKind.Utc)
                return dt;
            else if (dt.Kind == DateTimeKind.Local)
                return TimeZoneInfo.ConvertTimeToUtc(dt);
            else
                return TimeZoneInfo.ConvertTimeToUtc(dt, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time"));
        }

        private sealed class TxnEntitySynchronizer<T> where T : class
        {
            private static HashSet<KeyValuePair<Type, Type>> _SyncMap = new HashSet<KeyValuePair<Type, Type>>
            {
                new KeyValuePair<Type, Type>(typeof(InspProxy.Asset), typeof(Asset)), 
                new KeyValuePair<Type, Type>(typeof(InspProxy.Loan), typeof(Loan)),
                new KeyValuePair<Type, Type>(typeof(InspProxy.Order), typeof(Order)), 
                new KeyValuePair<Type, Type>(typeof(InspProxy.WorkOrder), typeof(WorkOrder)),
                new KeyValuePair<Type, Type>(typeof(InspProxy.WorkOrderItem), typeof(WorkOrderItem)),
                new KeyValuePair<Type, Type>(typeof(InspProxy.Cancellation), typeof(Cancellation))
            };

            private static List<string> _IgnoredPropList = new List<string>
            {
                "CreatedById",
                //"CreatedDate",
                "LastUpdatedById",
                "LastUpdatedDate",
                "DBCreatedBy",
                "DBCreatedDate",
                "DBLastUpdatedBy",
                "DBLastUpdatedDate",
                "Version",
                "AssetId",
                "LoanId",
                "OrderId",
                "WorkOrderId",
                "WorkOrderItemId",
                "CancellationId",
                "CancelledWorkOrderId",
                "CancelledOrderId",
                "CancelledLoanId"
            };

            private static ConcurrentDictionary<Type, List<PropertyInfo>> _SyncFields = new ConcurrentDictionary<Type, List<PropertyInfo>>();

            private static PropertyInfo _ApplicationIdProp(Type targetType)
            {
                return targetType == null ? null : targetType.GetProperty("ApplicationId", BindingFlags.Instance | BindingFlags.Public | BindingFlags.IgnoreCase);
            }

            internal TxnEntitySynchronizer()
            {
                if (_SyncMap.SingleOrDefault(map => map.Key.Equals(typeof(T))).Key == null || _SyncMap.SingleOrDefault(map => map.Key.Equals(typeof(T))).Value == null)
                    throw new NotSupportedException("TxnEntitySynchronizer doesn't support synchronization of intended type: " + typeof(T).FullName);
            }

            internal object Synchronize(T inspDtoObj, object platformTxnObj)
            {
                if (inspDtoObj == null) throw new ArgumentNullException("inspDtoObj");
                Type targetType = _SyncMap.Single(map => map.Key.Equals(typeof(T))).Value;
                if (platformTxnObj != null && !(platformTxnObj.GetType() == targetType || platformTxnObj.GetType().IsSubclassOf(targetType)))
                    throw new ArgumentException(string.Format("{0} is not supported as synchronization target for {1}", platformTxnObj.GetType().FullName, typeof(T).FullName), "platformTxnObj");

                object targetObj = platformTxnObj != null ? platformTxnObj : Activator.CreateInstance(targetType);
                PropertyInfo applicationIdProp = _ApplicationIdProp(targetType);
                if (applicationIdProp != null && (int)applicationIdProp.GetValue(targetObj) == 0) applicationIdProp.SetValue(targetObj, TenantHierarchyHelper.LowestTenantApplicationId);

                List<PropertyInfo> tgtPropList = _SyncFields.GetOrAdd(targetType, targetType.GetProperties(BindingFlags.Instance | BindingFlags.Public | BindingFlags.IgnoreCase)
                    .Where(pi => pi.PropertyType.IsPrimitive || pi.PropertyType.IsValueType || pi.PropertyType == typeof(string))
                    .Where(pi => !_IgnoredPropList.Contains(pi.Name)).ToList());
                List<PropertyInfo> srcPropList = _SyncFields.GetOrAdd(typeof(T), typeof(T).GetProperties(BindingFlags.Instance | BindingFlags.Public | BindingFlags.IgnoreCase)
                    .Where(pi => pi.PropertyType.IsPrimitive || pi.PropertyType.IsValueType || pi.PropertyType == typeof(string))
                    .Where(pi => !_IgnoredPropList.Contains(pi.Name)).ToList());
                if (tgtPropList != null && tgtPropList.Count > 0)
                    tgtPropList.ForEach(prop =>
                    {
                        PropertyInfo srcProp = srcPropList.SingleOrDefault(pi => string.Compare(pi.Name, prop.Name, false) == 0);
                        if (srcProp == null)
                        {
                            CommonLib.ModelAttrib.MapPropAttribute mapAttr = prop.GetCustomAttributes(typeof(CommonLib.ModelAttrib.MapPropAttribute), false)
                                                                             .Cast<CommonLib.ModelAttrib.MapPropAttribute>().SingleOrDefault();
                            if (mapAttr != null)
                                srcProp = srcPropList.SingleOrDefault(pi => string.Compare(pi.Name, mapAttr.MapFrom, false) == 0);
                        }
                        if (srcProp != null)
                        {
                            if (srcProp.PropertyType != typeof(DateTime) && srcProp.PropertyType != typeof(Nullable<DateTime>))
                                prop.SetValue(targetObj, srcProp.GetValue(inspDtoObj));
                            else
                            {
                                DateTime dt = srcProp.GetValue(inspDtoObj) != null ? (DateTime)srcProp.GetValue(inspDtoObj) : DateTime.MinValue;
                                if (dt != DateTime.MinValue)
                                {
                                    if (dt.Kind == DateTimeKind.Utc)
                                        prop.SetValue(targetObj, dt);
                                    else if (dt.Kind == DateTimeKind.Local)
                                        prop.SetValue(targetObj, TimeZoneInfo.ConvertTimeToUtc(dt));
                                    else
                                        prop.SetValue(targetObj, TimeZoneInfo.ConvertTimeToUtc(dt, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time")));
                                }
                                else
                                    prop.SetValue(targetObj, null);
                            }
                        }
                    }
                );

                if (typeof(T) == typeof(InspProxy.Asset)) ((Asset)targetObj).SourceAssetId = (inspDtoObj as InspProxy.Asset).AssetId;
                else if (typeof(T) == typeof(InspProxy.Loan)) ((Loan)targetObj).SourceLoanId = (inspDtoObj as InspProxy.Loan).LoanId;
                else if (typeof(T) == typeof(InspProxy.Order)) ((Order)targetObj).SourceOrderId = (inspDtoObj as InspProxy.Order).OrderId;
                else if (typeof(T) == typeof(InspProxy.WorkOrder)) ((WorkOrder)targetObj).SourceWorkOrderId = (inspDtoObj as InspProxy.WorkOrder).WorkOrderId;
                else if (typeof(T) == typeof(InspProxy.WorkOrderItem)) ((WorkOrderItem)targetObj).SourceWorkOrderItemId = (inspDtoObj as InspProxy.WorkOrderItem).WorkOrderItemId;
                else if (typeof(T) == typeof(InspProxy.Cancellation)) ((Cancellation)targetObj).SourceCancellationId = (inspDtoObj as InspProxy.Cancellation).CancellationId;

                return targetObj;
            }
        }

        public void SyncTxnEntitiesByPresWorkOrder(PresProxy.WorkOrder presWorkOrder)
        {
            if (presWorkOrder == null) throw new ArgumentNullException("presWorkOrder");
            if (presWorkOrder.Order == null) throw new ArgumentNullException("presWorkOrder", string.Format("Missing Order for the preservation work order {0}", presWorkOrder.WorkOrderId.ToString()));
            if (presWorkOrder.Order.Loan == null) throw new ArgumentNullException("presWorkOrder", string.Format("Missing Loan for the preservation work order {0}", presWorkOrder.WorkOrderId.ToString()));
            if (presWorkOrder.Order.Loan.Asset == null) throw new ArgumentNullException("presWorkOrder", string.Format("Missing Asset for the preservation work order {0}", presWorkOrder.WorkOrderId.ToString()));
            if (presWorkOrder.WorkOrderItems == null || presWorkOrder.WorkOrderItems.Count == 0) throw new ArgumentNullException("presWorkOrder", string.Format("Missing Work Order Items for the preservation work order {0}", presWorkOrder.WorkOrderId.ToString()));
            //if (presWorkOrder.WorkOrderItems == null || presWorkOrder.WorkOrderItems.Sum(l => l.WorkOrderLineItems.Count()) == 0) throw new ArgumentNullException("presWorkOrder", string.Format("Missing Work Order Line Items for the preservation work order {0}", presWorkOrder.WorkOrderId.ToString()));
            if (presWorkOrder.VendorWorkOrder == null) throw new ArgumentNullException("presWorkOrder", "Missing Vendor Work Order for the preservation work order");

            using (AccountingData ctx = new AccountingData())
            {
                try
                {
                    //Sync Order
                    Order platformOrder = ctx.Orders.Where(od => od.SourceOrderId == presWorkOrder.Order.OrderId && TenantHierarchyHelper.TenantApplicationIds.Contains(od.ApplicationId)).SingleOrDefault();
                    TxnEntitySynchronizerPres<PresProxy.Order> orderSynchronizer = new TxnEntitySynchronizerPres<PresProxy.Order>();
                    platformOrder = (Order)orderSynchronizer.Synchronize(presWorkOrder.Order, platformOrder);
                    if (platformOrder.OrderId == 0)
                    {
                        ctx.Orders.Add(platformOrder);
                    }

                    //Sync Loan
                    Loan platformLoan = ctx.Loans.Where(ln => ln.SourceLoanId == presWorkOrder.Order.Loan.LoanId && TenantHierarchyHelper.TenantApplicationIds.Contains(ln.ApplicationId)).SingleOrDefault();
                    TxnEntitySynchronizerPres<PresProxy.Loan> loanSynchronizer = new TxnEntitySynchronizerPres<PresProxy.Loan>();
                    platformLoan = (Loan)loanSynchronizer.Synchronize(presWorkOrder.Order.Loan, platformLoan);
                    if (platformLoan.LoanId == 0)
                    {
                        ctx.Loans.Add(platformLoan);
                        platformLoan.Orders.Add(platformOrder);
                    }
                    else platformOrder.LoanId = platformLoan.LoanId;

                    //Sync Asset
                    Asset platformAsset = ctx.Assets.Where(at => at.SourceAssetId == presWorkOrder.Order.Loan.Asset.AssetId && TenantHierarchyHelper.TenantApplicationIds.Contains(at.ApplicationId)).SingleOrDefault();
                    TxnEntitySynchronizerPres<PresProxy.Asset> assetSynchronizer = new TxnEntitySynchronizerPres<PresProxy.Asset>();
                    platformAsset = (Asset)assetSynchronizer.Synchronize(presWorkOrder.Order.Loan.Asset, platformAsset);
                    if (platformAsset.AssetId == 0)
                    {
                        ctx.Assets.Add(platformAsset);
                        platformAsset.Loans.Add(platformLoan);
                    }
                    else platformLoan.AssetId = platformAsset.AssetId;

                    ctx.SaveChanges();
                }
                catch (DbUpdateException dbUpdateEx)
                {
                    if (dbUpdateEx != null && dbUpdateEx.InnerException != null && dbUpdateEx.InnerException.InnerException != null)
                    {
                        SqlException sqlException = dbUpdateEx.InnerException.InnerException as SqlException;
                        if (sqlException != null)
                        {
                            switch (sqlException.Number)
                            {
                                case 2627:  // Unique key constraint
                                    Logging.LogError(string.Format("Unique key constraint error as part of Accounting Sync for the Preservation work order {0}, exception {1}", presWorkOrder.WorkOrderId, dbUpdateEx));
                                    break;
                                case 2601: // Duplicate key
                                    Logging.LogError(string.Format("Duplicate key error as part of Accounting Sync for the Preservation work order {0}, exception {1}", presWorkOrder.WorkOrderId, dbUpdateEx));
                                    break;
                                default:
                                    CommonLib.Logging.LogError(dbUpdateEx);
                                    throw;
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    CommonLib.Logging.LogError(ex);
                    throw;
                }
            }

            using (AccountingData ctx = new AccountingData())
            {
                try
                {
                    Order platformOrder = ctx.Orders.Where(od => od.SourceOrderId == presWorkOrder.Order.OrderId && TenantHierarchyHelper.TenantApplicationIds.Contains(od.ApplicationId)).SingleOrDefault();

                    //Sync Work Order
                    WorkOrder platformWorkOrder = ctx.WorkOrders.Where(wo => wo.SourceWorkOrderId == presWorkOrder.WorkOrderId && TenantHierarchyHelper.TenantApplicationIds.Contains(wo.ApplicationId)).SingleOrDefault();
                    TxnEntitySynchronizerPres<PresProxy.WorkOrder> workOrderSynchronizer = new TxnEntitySynchronizerPres<PresProxy.WorkOrder>();
                    platformWorkOrder = (WorkOrder)workOrderSynchronizer.Synchronize(presWorkOrder, platformWorkOrder);
                    if (platformWorkOrder.WorkOrderId == 0)
                    {
                        platformWorkOrder.OrderId = platformOrder.OrderId;
                        ctx.WorkOrders.Add(platformWorkOrder);
                    }

                    //Sync Vendor Work Order
                    if (presWorkOrder.VendorWorkOrder != null)
                    {
                        VendorWorkOrder platformVendorWorkOrder = ctx.VendorWorkOrders.Where(vwo => vwo.SourceVendorWorkOrderId == presWorkOrder.VendorWorkOrder.VendorWorkOrderId && TenantHierarchyHelper.TenantApplicationIds.Contains(vwo.ApplicationId)).SingleOrDefault();
                        TxnEntitySynchronizerPres<PresProxy.VendorWorkOrder> vendorWorkOrderSynchronizer = new TxnEntitySynchronizerPres<PresProxy.VendorWorkOrder>();
                        platformVendorWorkOrder = (VendorWorkOrder)vendorWorkOrderSynchronizer.Synchronize(presWorkOrder.VendorWorkOrder, platformVendorWorkOrder);

                        if (platformVendorWorkOrder.VendorWorkOrderId == 0)
                        {
                            platformVendorWorkOrder.OrderId = platformOrder.OrderId;
                            ctx.VendorWorkOrders.Add(platformVendorWorkOrder);
                            platformOrder.VendorWorkOrders.Add(platformVendorWorkOrder);
                            platformWorkOrder.VendorWorkOrderId = platformVendorWorkOrder.VendorWorkOrderId;
                        }
                        else
                        {
                            platformWorkOrder.VendorWorkOrderId = platformVendorWorkOrder.VendorWorkOrderId;
                            platformVendorWorkOrder.VendorWorkOrderId = platformVendorWorkOrder.VendorWorkOrderId;
                        }
                    }
                    ctx.SaveChanges();
                }
                catch (DbUpdateException dbUpdateEx)
                {
                    if (dbUpdateEx != null && dbUpdateEx.InnerException != null && dbUpdateEx.InnerException.InnerException != null)
                    {
                        SqlException sqlException = dbUpdateEx.InnerException.InnerException as SqlException;
                        if (sqlException != null)
                        {
                            switch (sqlException.Number)
                            {
                                case 2627:  // Unique key constraint
                                    Logging.LogError(string.Format("1. Unique key constraint error as part of Accounting Sync for the Preservation work order {0}, exception {1}", presWorkOrder.WorkOrderId, dbUpdateEx));
                                    break;
                                case 2601: // Duplicate key
                                    Logging.LogError(string.Format("1. Duplicate key error as part of Accounting Sync for the Preservation work order {0}, exception {1}", presWorkOrder.WorkOrderId, dbUpdateEx));
                                    break;
                                default:
                                    CommonLib.Logging.LogError(dbUpdateEx);
                                    throw;
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    CommonLib.Logging.LogError(ex);
                    throw;
                }
            }

            using (AccountingData ctx = new AccountingData())
            {
                WorkOrder platformWorkOrder = ctx.WorkOrders.Where(wo => wo.SourceWorkOrderId == presWorkOrder.WorkOrderId && TenantHierarchyHelper.TenantApplicationIds.Contains(wo.ApplicationId)).SingleOrDefault();
                Order platformOrder = ctx.Orders.Where(od => od.SourceOrderId == presWorkOrder.Order.OrderId && TenantHierarchyHelper.TenantApplicationIds.Contains(od.ApplicationId)).SingleOrDefault();
                Loan platformLoan = ctx.Loans.Where(ln => ln.SourceLoanId == presWorkOrder.Order.Loan.LoanId && TenantHierarchyHelper.TenantApplicationIds.Contains(ln.ApplicationId)).SingleOrDefault();

                if (platformWorkOrder != null && platformOrder != null && platformLoan != null)
                {
                    try
                    {
                        //Special handling on CreatedDate for Loan, Order and Work Order
                        platformLoan.CreatedDate = ConvertToUtc(presWorkOrder.Order.Loan.CreatedDate);
                        platformOrder.CreatedDate = ConvertToUtc(presWorkOrder.Order.CreatedDate);
                        platformWorkOrder.CreatedDate = ConvertToUtc(presWorkOrder.CreatedDate);

                        //Sync Work Order Items
                        TxnEntitySynchronizerPres<PresProxy.WorkOrderItem> workOrderItemSynchronizer = new TxnEntitySynchronizerPres<PresProxy.WorkOrderItem>();

                        if (presWorkOrder.WorkOrderItems != null && presWorkOrder.WorkOrderItems.Count > 0)
                        {
                            presWorkOrder.WorkOrderItems.ForEach(presWorkOrderItem =>
                            {
                                WorkOrderItem platformWorkOrderItem = ctx.WorkOrderItems.Where(woi => woi.SourceWorkOrderItemId == presWorkOrderItem.WorkOrderItemId && TenantHierarchyHelper.TenantApplicationIds.Contains(woi.ApplicationId)).SingleOrDefault();
                                platformWorkOrderItem = (WorkOrderItem)workOrderItemSynchronizer.Synchronize(presWorkOrderItem, platformWorkOrderItem);
                                if (platformWorkOrderItem.WorkOrderItemId == 0)
                                {
                                    platformWorkOrderItem.WorkOrderId = platformWorkOrder.WorkOrderId;
                                    platformWorkOrderItem.OrderId = platformOrder.OrderId;
                                    ctx.WorkOrderItems.Add(platformWorkOrderItem);
                                    platformWorkOrder.WorkOrderItems.Add(platformWorkOrderItem);
                                }
                                else platformWorkOrderItem.WorkOrderItemId = platformWorkOrderItem.WorkOrderItemId;

                                //Sync Work Order Line Items
                                TxnEntitySynchronizerPres<PresProxy.WorkOrderLineItem> workOrderLineItemSynchronizer = new TxnEntitySynchronizerPres<PresProxy.WorkOrderLineItem>();
                                if (presWorkOrderItem.WorkOrderLineItems != null && presWorkOrderItem.WorkOrderLineItems.Count > 0)
                                {
                                    presWorkOrderItem.WorkOrderLineItems.ForEach(presWorkOrderLineItem =>
                                    {
                                        WorkOrderLineItem platformWorkOrderLineItem = ctx.WorkOrderLineItems.Where(woli => woli.SourceWorkOrderLineItemId == presWorkOrderLineItem.WorkOrderLineItemId && TenantHierarchyHelper.TenantApplicationIds.Contains(woli.ApplicationId)).SingleOrDefault();
                                        platformWorkOrderLineItem = (WorkOrderLineItem)workOrderLineItemSynchronizer.Synchronize(presWorkOrderLineItem, platformWorkOrderLineItem);
                                        if (platformWorkOrderLineItem.WorkOrderLineItemId == 0)
                                        {
                                            platformWorkOrderLineItem.WorkOrderItemId = platformWorkOrderItem.WorkOrderItemId;
                                            ctx.WorkOrderLineItems.Add(platformWorkOrderLineItem);
                                            platformWorkOrderItem.WorkOrderLineItems.Add(platformWorkOrderLineItem);
                                        }
                                    });
                                }
                            });
                        }

                        //Sync Cancellation
                        TxnEntitySynchronizerPres<PresProxy.Cancellation> cancellationSynchronizer = new TxnEntitySynchronizerPres<PresProxy.Cancellation>();
                        if (presWorkOrder.Order.Cancellations != null && presWorkOrder.Order.Cancellations.Count > 0)
                        {
                            foreach (PresProxy.Cancellation presCancellation in presWorkOrder.Order.Cancellations.Where(c =>
                                (c.CancelledWorkOrderId == null || c.CancelledWorkOrderId.HasValue && c.CancelledWorkOrderId.Value == presWorkOrder.WorkOrderId)).OrderBy(c => c.CancellationId).ToList())
                            {
                                int? cLoanId = new Nullable<int>();
                                int? cOrderId = new Nullable<int>();
                                int? cWOId = new Nullable<int>();

                                if (presCancellation.CancelledWorkOrderId.HasValue)
                                {
                                    cWOId = platformWorkOrder.WorkOrderId;
                                }
                                if (presCancellation.CancelledOrderId.HasValue)
                                {
                                    cOrderId = platformOrder.OrderId;
                                }
                                if (presCancellation.CancelledLoanId.HasValue)
                                {
                                    cLoanId = platformLoan.LoanId;
                                }

                                Cancellation platformCancellation = ctx.Cancellations.Where(c => c.SourceCancellationId == presCancellation.CancellationId
                                    && TenantHierarchyHelper.TenantApplicationIds.Contains(c.ApplicationId)).SingleOrDefault();
                                platformCancellation = (Cancellation)cancellationSynchronizer.Synchronize(presCancellation, platformCancellation);

                                if (platformCancellation.CancellationId == 0)
                                {
                                    platformCancellation.CancelledLoanId = cLoanId;
                                    platformCancellation.CancelledOrderId = cOrderId;
                                    platformCancellation.CancelledWorkOrderId = cWOId;
                                    ctx.Cancellations.Add(platformCancellation);
                                }
                                else
                                {
                                    platformCancellation.CancelledLoanId = cLoanId;
                                    platformCancellation.CancelledOrderId = cOrderId;
                                    platformCancellation.CancelledWorkOrderId = cWOId;
                                }
                            }
                        }

                        ctx.SaveChanges();
                    }
                    catch (DbUpdateException dbUpdateEx)
                    {
                        if (dbUpdateEx != null && dbUpdateEx.InnerException != null && dbUpdateEx.InnerException.InnerException != null)
                        {
                            SqlException sqlException = dbUpdateEx.InnerException.InnerException as SqlException;
                            if (sqlException != null)
                            {
                                switch (sqlException.Number)
                                {
                                    case 2627:  // Unique key constraint
                                        Logging.LogError(string.Format("Unique key constraint error as part of Accounting Sync for the Preservation work order {0}, exception {1}", presWorkOrder.WorkOrderId, dbUpdateEx));
                                        break;
                                    case 2601: // Duplicate key
                                        Logging.LogError(string.Format("Duplicate key error as part of Accounting Sync for the Preservation work order {0}, exception {1}", presWorkOrder.WorkOrderId, dbUpdateEx));
                                        break;
                                    default:
                                        CommonLib.Logging.LogError(dbUpdateEx);
                                        throw;
                                }
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        CommonLib.Logging.LogError(ex);
                        throw;
                    }
                }
            }
        }

        private sealed class TxnEntitySynchronizerPres<T> where T : class
        {
            private static HashSet<KeyValuePair<Type, Type>> _SyncMap = new HashSet<KeyValuePair<Type, Type>>
            {
                new KeyValuePair<Type, Type>(typeof(PresProxy.Asset), typeof(Asset)), 
                new KeyValuePair<Type, Type>(typeof(PresProxy.Loan), typeof(Loan)),
                new KeyValuePair<Type, Type>(typeof(PresProxy.Order), typeof(Order)), 
                new KeyValuePair<Type, Type>(typeof(PresProxy.WorkOrder), typeof(WorkOrder)),
                new KeyValuePair<Type, Type>(typeof(PresProxy.WorkOrderItem), typeof(WorkOrderItem)),
                new KeyValuePair<Type, Type>(typeof(PresProxy.WorkOrderLineItem), typeof(WorkOrderLineItem)),
                new KeyValuePair<Type, Type>(typeof(PresProxy.VendorWorkOrder), typeof(VendorWorkOrder)),
                new KeyValuePair<Type, Type>(typeof(PresProxy.Cancellation), typeof(Cancellation))
            };

            private static List<string> _IgnoredPropList = new List<string>
            {
                "CreatedById",
                //"CreatedDate",
                "LastUpdatedById",
                "LastUpdatedDate",
                "DBCreatedBy",
                "DBCreatedDate",
                "DBLastUpdatedBy",
                "DBLastUpdatedDate",
                "Version",
                "AssetId",
                "LoanId",
                "OrderId",
                "WorkOrderId",
                "WorkOrderItemId",
                "WorkOrderLineItemId",
                "VendorWorkOrderId",
                "CancellationId",
                "CancelledWorkOrderId",
                "CancelledOrderId",
                "CancelledLoanId"
            };

            private static ConcurrentDictionary<Type, List<PropertyInfo>> _SyncFields = new ConcurrentDictionary<Type, List<PropertyInfo>>();

            private static PropertyInfo _ApplicationIdProp(Type targetType)
            {
                return targetType == null ? null : targetType.GetProperty("ApplicationId", BindingFlags.Instance | BindingFlags.Public | BindingFlags.IgnoreCase);
            }

            internal TxnEntitySynchronizerPres()
            {
                if (_SyncMap.SingleOrDefault(map => map.Key.Equals(typeof(T))).Key == null || _SyncMap.SingleOrDefault(map => map.Key.Equals(typeof(T))).Value == null)
                    throw new NotSupportedException("TxnEntitySynchronizerPres doesn't support synchronization of intended type: " + typeof(T).FullName);
            }

            internal object Synchronize(T presDtoObj, object platformTxnObj)
            {
                if (presDtoObj == null) throw new ArgumentNullException("presDtoObj");
                Type targetType = _SyncMap.Single(map => map.Key.Equals(typeof(T))).Value;
                if (platformTxnObj != null && !(platformTxnObj.GetType() == targetType || platformTxnObj.GetType().IsSubclassOf(targetType)))
                    throw new ArgumentException(string.Format("{0} is not supported as synchronization target for {1}", platformTxnObj.GetType().FullName, typeof(T).FullName), "platformTxnObj");

                object targetObj = platformTxnObj != null ? platformTxnObj : Activator.CreateInstance(targetType);
                PropertyInfo applicationIdProp = _ApplicationIdProp(targetType);
                if (applicationIdProp != null && (int)applicationIdProp.GetValue(targetObj) == 0) applicationIdProp.SetValue(targetObj, TenantHierarchyHelper.LowestTenantApplicationId);

                List<PropertyInfo> tgtPropList = _SyncFields.GetOrAdd(targetType, targetType.GetProperties(BindingFlags.Instance | BindingFlags.Public | BindingFlags.IgnoreCase)
                    .Where(pi => pi.PropertyType.IsPrimitive || pi.PropertyType.IsValueType || pi.PropertyType == typeof(string))
                    .Where(pi => !_IgnoredPropList.Contains(pi.Name)).ToList());
                List<PropertyInfo> srcPropList = _SyncFields.GetOrAdd(typeof(T), typeof(T).GetProperties(BindingFlags.Instance | BindingFlags.Public | BindingFlags.IgnoreCase)
                    .Where(pi => pi.PropertyType.IsPrimitive || pi.PropertyType.IsValueType || pi.PropertyType == typeof(string))
                    .Where(pi => !_IgnoredPropList.Contains(pi.Name)).ToList());
                if (tgtPropList != null && tgtPropList.Count > 0)
                    tgtPropList.ForEach(prop =>
                    {
                        PropertyInfo srcProp = srcPropList.SingleOrDefault(pi => string.Compare(pi.Name, prop.Name, false) == 0);
                        if (srcProp == null)
                        {
                            CommonLib.ModelAttrib.MapPropAttribute mapAttr = prop.GetCustomAttributes(typeof(CommonLib.ModelAttrib.MapPropAttribute), false)
                                                                             .Cast<CommonLib.ModelAttrib.MapPropAttribute>().SingleOrDefault();
                            if (mapAttr != null)
                                srcProp = srcPropList.SingleOrDefault(pi => string.Compare(pi.Name, mapAttr.MapFrom, false) == 0);
                        }
                        if (srcProp != null)
                        {
                            if (srcProp.PropertyType != typeof(DateTime) && srcProp.PropertyType != typeof(Nullable<DateTime>))
                                prop.SetValue(targetObj, srcProp.GetValue(presDtoObj));
                            else
                            {
                                DateTime dt = srcProp.GetValue(presDtoObj) != null ? (DateTime)srcProp.GetValue(presDtoObj) : DateTime.MinValue;
                                if (dt != DateTime.MinValue)
                                {
                                    if (dt.Kind == DateTimeKind.Utc)
                                        prop.SetValue(targetObj, dt);
                                    else if (dt.Kind == DateTimeKind.Local)
                                        prop.SetValue(targetObj, TimeZoneInfo.ConvertTimeToUtc(dt));
                                    else
                                        prop.SetValue(targetObj, TimeZoneInfo.ConvertTimeToUtc(dt, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time")));
                                }
                                else
                                    prop.SetValue(targetObj, null);
                            }
                        }
                    }
                );

                if (typeof(T) == typeof(PresProxy.Asset)) ((Asset)targetObj).SourceAssetId = (presDtoObj as PresProxy.Asset).AssetId;
                else if (typeof(T) == typeof(PresProxy.Loan)) ((Loan)targetObj).SourceLoanId = (presDtoObj as PresProxy.Loan).LoanId;
                else if (typeof(T) == typeof(PresProxy.Order)) ((Order)targetObj).SourceOrderId = (presDtoObj as PresProxy.Order).OrderId;
                else if (typeof(T) == typeof(PresProxy.WorkOrder)) ((WorkOrder)targetObj).SourceWorkOrderId = (presDtoObj as PresProxy.WorkOrder).WorkOrderId;
                else if (typeof(T) == typeof(PresProxy.WorkOrderItem)) ((WorkOrderItem)targetObj).SourceWorkOrderItemId = (presDtoObj as PresProxy.WorkOrderItem).WorkOrderItemId;
                else if (typeof(T) == typeof(PresProxy.WorkOrderLineItem)) ((WorkOrderLineItem)targetObj).SourceWorkOrderLineItemId = (presDtoObj as PresProxy.WorkOrderLineItem).WorkOrderLineItemId;
                else if (typeof(T) == typeof(PresProxy.Cancellation)) ((Cancellation)targetObj).SourceCancellationId = (presDtoObj as PresProxy.Cancellation).CancellationId;
                else if (typeof(T) == typeof(PresProxy.VendorWorkOrder)) ((VendorWorkOrder)targetObj).SourceVendorWorkOrderId = (presDtoObj as PresProxy.VendorWorkOrder).VendorWorkOrderId;

                return targetObj;
            }
        }

        public AccountsPayableTrackingLog GetTrackingLogByWoId(int workOrderId)
        {
            using (var ctx = new AccountingData())
            {
                var aptl = (from l in ctx.AccountsPayableTrackingLogs where l.WorkOrderId == workOrderId select l).FirstOrDefault();
                return aptl;
            }
        }

        public void SaveTrackingLog(AccountsPayableTrackingLog log)
        {
            using (var ctx = new AccountingData())
            {
                ctx.UpdateGraph(log, map => map);
                ctx.SaveChanges();
            }
        }

        public void SyncTxnEntitiesByWorkOrder(BillProxy.WorkOrder fsWorkOrder)
        {
            if (fsWorkOrder == null) throw new ArgumentNullException("fsWorkOrder");
            if (fsWorkOrder.Order == null) throw new ArgumentNullException("fsWorkOrder", string.Format("Missing Order for the work order {0}", fsWorkOrder.WorkOrderId.ToString()));
            if (fsWorkOrder.Order.Loan == null) throw new ArgumentNullException("fsWorkOrder", string.Format("Missing Loan for the work order {0}", fsWorkOrder.WorkOrderId.ToString()));
            //if (fsWorkOrder.Order.Loan.Asset == null) throw new ArgumentNullException("fsWorkOrder", string.Format("Missing Asset for the work order {0}", fsWorkOrder.WorkOrderId.ToString()));
            if (fsWorkOrder.WorkOrderItems == null || fsWorkOrder.WorkOrderItems.Count == 0) throw new ArgumentNullException("fsWorkOrder", string.Format("Missing Work Order Items for the work order {0}", fsWorkOrder.WorkOrderId.ToString()));

            using (AccountingData ctx = new AccountingData())
            {
                try
                {
                    //Sync Order
                    Order platformOrder = ctx.Orders.Where(od => od.SourceOrderId == fsWorkOrder.Order.OrderId && TenantHierarchyHelper.TenantApplicationIds.Contains(od.ApplicationId)).SingleOrDefault();
                    TxnEntitySynchronize<BillProxy.Order> orderSynchronizer = new TxnEntitySynchronize<BillProxy.Order>();
                    platformOrder = (Order)orderSynchronizer.Synchronize(fsWorkOrder.Order, platformOrder);

                    if (platformOrder.OrderId == 0)
                    {
                        ctx.Orders.Add(platformOrder);
                    }

                    //Sync Loan
                    Loan platformLoan = ctx.Loans.Where(ln => ln.SourceLoanId == fsWorkOrder.Order.Loan.LoanId && TenantHierarchyHelper.TenantApplicationIds.Contains(ln.ApplicationId)).SingleOrDefault();
                    TxnEntitySynchronize<BillProxy.Loan> loanSynchronizer = new TxnEntitySynchronize<BillProxy.Loan>();
                    platformLoan = (Loan)loanSynchronizer.Synchronize(fsWorkOrder.Order.Loan, platformLoan);
                    if (platformLoan.LoanId == 0)
                    {
                        ctx.Loans.Add(platformLoan);
                        platformLoan.Orders.Add(platformOrder);
                    }
                    else platformOrder.LoanId = platformLoan.LoanId;

                    if (fsWorkOrder.Order.Loan.Asset != null)
                    {
                        //Sync Asset
                        Asset platformAsset = ctx.Assets.Where(at => at.SourceAssetId == fsWorkOrder.Order.Loan.Asset.AssetId && TenantHierarchyHelper.TenantApplicationIds.Contains(at.ApplicationId)).SingleOrDefault();
                        TxnEntitySynchronize<BillProxy.Asset> assetSynchronizer = new TxnEntitySynchronize<BillProxy.Asset>();
                        platformAsset = (Asset)assetSynchronizer.Synchronize(fsWorkOrder.Order.Loan.Asset, platformAsset);
                        if (platformAsset.AssetId == 0)
                        {
                            ctx.Assets.Add(platformAsset);
                            platformAsset.Loans.Add(platformLoan);
                        }
                        else platformLoan.AssetId = platformAsset.AssetId;
                    }

                    ctx.SaveChanges();
                }
                catch (DbUpdateException dbUpdateEx)
                {
                    if (dbUpdateEx != null && dbUpdateEx.InnerException != null && dbUpdateEx.InnerException.InnerException != null)
                    {
                        SqlException sqlException = dbUpdateEx.InnerException.InnerException as SqlException;
                        if (sqlException != null)
                        {
                            switch (sqlException.Number)
                            {
                                case 2627:  // Unique key constraint
                                    Logging.LogError(string.Format("1. Unique key constraint error as part of Accounting Sync for the work order {0}, exception {1}", fsWorkOrder.WorkOrderId, dbUpdateEx));
                                    break;
                                case 2601: // Duplicate key
                                    Logging.LogError(string.Format("1. Duplicate key error as part of Accounting Sync for the work order {0}, exception {1}", fsWorkOrder.WorkOrderId, dbUpdateEx));
                                    break;
                                default:
                                    CommonLib.Logging.LogError(dbUpdateEx);
                                    throw;
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    CommonLib.Logging.LogError(ex);
                    throw;
                }
            }

            using (AccountingData ctx = new AccountingData())
            {
                try
                {
                    //Sync Work Order
                    WorkOrder platformWorkOrder = ctx.WorkOrders.Where(wo => wo.SourceWorkOrderId == fsWorkOrder.WorkOrderId
                        && TenantHierarchyHelper.TenantApplicationIds.Contains(wo.ApplicationId)).SingleOrDefault();

                    if (platformWorkOrder == null || (platformWorkOrder != null && platformWorkOrder.InvoiceDate == null))
                    {
                        Order platformOrder = ctx.Orders.Where(od => od.SourceOrderId == fsWorkOrder.Order.OrderId && TenantHierarchyHelper.TenantApplicationIds.Contains(od.ApplicationId)).SingleOrDefault();

                        TxnEntitySynchronize<BillProxy.WorkOrder> workOrderSynchronizer = new TxnEntitySynchronize<BillProxy.WorkOrder>();
                        platformWorkOrder = (WorkOrder)workOrderSynchronizer.Synchronize(fsWorkOrder, platformWorkOrder);

                        //Sync Vendor Work Order
                        if (fsWorkOrder.VendorWorkOrder != null && platformWorkOrder != null)
                        {
                            VendorWorkOrder platformVendorWorkOrder = ctx.VendorWorkOrders.Where(vwo => vwo.SourceVendorWorkOrderId == fsWorkOrder.VendorWorkOrder.VendorWorkOrderId && TenantHierarchyHelper.TenantApplicationIds.Contains(vwo.ApplicationId)).SingleOrDefault();
                            if (platformVendorWorkOrder == null)
                            {
                                TxnEntitySynchronize<BillProxy.VendorWorkOrder> vendorWorkOrderSynchronizer = new TxnEntitySynchronize<BillProxy.VendorWorkOrder>();
                                platformVendorWorkOrder = (VendorWorkOrder)vendorWorkOrderSynchronizer.Synchronize(fsWorkOrder.VendorWorkOrder, platformVendorWorkOrder);

                                if (platformVendorWorkOrder.VendorWorkOrderId == 0)
                                {
                                    platformVendorWorkOrder.OrderId = platformOrder.OrderId;
                                    ctx.VendorWorkOrders.Add(platformVendorWorkOrder);
                                    platformOrder.VendorWorkOrders.Add(platformVendorWorkOrder);
                                    platformWorkOrder.VendorWorkOrderId = platformVendorWorkOrder.VendorWorkOrderId;
                                }
                                else
                                {
                                    platformWorkOrder.VendorWorkOrderId = platformVendorWorkOrder.VendorWorkOrderId;
                                    platformVendorWorkOrder.VendorWorkOrderId = platformVendorWorkOrder.VendorWorkOrderId;
                                }
                            }
                            else
                            {
                                platformWorkOrder.VendorWorkOrderId = platformVendorWorkOrder.VendorWorkOrderId;
                            }
                        }

                        if (platformWorkOrder.WorkOrderId == 0)
                        {
                            platformWorkOrder.OrderId = platformOrder.OrderId;
                            ctx.WorkOrders.Add(platformWorkOrder);
                        }

                        ctx.SaveChanges();
                    }
                }
                catch (DbUpdateException dbUpdateEx)
                {
                    if (dbUpdateEx != null && dbUpdateEx.InnerException != null && dbUpdateEx.InnerException.InnerException != null)
                    {
                        SqlException sqlException = dbUpdateEx.InnerException.InnerException as SqlException;
                        if (sqlException != null)
                        {
                            switch (sqlException.Number)
                            {
                                case 2627:  // Unique key constraint
                                    Logging.LogError(string.Format("1. Unique key constraint error as part of Accounting Sync for the work order {0}, exception {1}", fsWorkOrder.WorkOrderId, dbUpdateEx));
                                    break;
                                case 2601: // Duplicate key
                                    Logging.LogError(string.Format("1. Duplicate key error as part of Accounting Sync for the work order {0}, exception {1}", fsWorkOrder.WorkOrderId, dbUpdateEx));
                                    break;
                                default:
                                    CommonLib.Logging.LogError(dbUpdateEx);
                                    throw;
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    CommonLib.Logging.LogError(ex);
                    throw;
                }
            }

            using (AccountingData ctx = new AccountingData())
            {
                try
                {
                    WorkOrder platformWorkOrder = ctx.WorkOrders.Where(wo => wo.SourceWorkOrderId == fsWorkOrder.WorkOrderId
                        && TenantHierarchyHelper.TenantApplicationIds.Contains(wo.ApplicationId)).SingleOrDefault();

                    if (platformWorkOrder != null && platformWorkOrder.InvoiceDate == null)
                    {
                        Order platformOrder = ctx.Orders.Where(od => od.SourceOrderId == fsWorkOrder.Order.OrderId && TenantHierarchyHelper.TenantApplicationIds.Contains(od.ApplicationId)).SingleOrDefault();
                        Loan platformLoan = ctx.Loans.Where(ln => ln.SourceLoanId == fsWorkOrder.Order.Loan.LoanId && TenantHierarchyHelper.TenantApplicationIds.Contains(ln.ApplicationId)).SingleOrDefault();

                        //Special handling on CreatedDate for Loan, Order and Work Order
                        platformLoan.CreatedDate = ConvertToUtc(fsWorkOrder.Order.Loan.CreatedDate);
                        platformOrder.CreatedDate = ConvertToUtc(fsWorkOrder.Order.CreatedDate);
                        platformWorkOrder.CreatedDate = ConvertToUtc(fsWorkOrder.CreatedDate);

                        //Sync Work Order Items
                        if (fsWorkOrder.WorkOrderItems != null && fsWorkOrder.WorkOrderItems.Count > 0)
                        {
                            TxnEntitySynchronize<BillProxy.WorkOrderItem> workOrderItemSynchronizer = new TxnEntitySynchronize<BillProxy.WorkOrderItem>();
                            fsWorkOrder.WorkOrderItems.ForEach(fsWorkOrderItem =>
                            {
                                WorkOrderItem platformWorkOrderItem = ctx.WorkOrderItems.Where(woi => woi.SourceWorkOrderItemId == fsWorkOrderItem.WorkOrderItemId && TenantHierarchyHelper.TenantApplicationIds.Contains(woi.ApplicationId)).SingleOrDefault();
                                platformWorkOrderItem = (WorkOrderItem)workOrderItemSynchronizer.Synchronize(fsWorkOrderItem, platformWorkOrderItem);
                                if (platformWorkOrderItem.WorkOrderItemId == 0)
                                {
                                    platformWorkOrderItem.WorkOrderId = platformWorkOrder.WorkOrderId;
                                    platformWorkOrderItem.OrderId = platformOrder.OrderId;
                                    ctx.WorkOrderItems.Add(platformWorkOrderItem);
                                    platformWorkOrder.WorkOrderItems.Add(platformWorkOrderItem);
                                }
                                else platformWorkOrderItem.WorkOrderItemId = platformWorkOrderItem.WorkOrderItemId;

                                //Sync Work Order Line Items
                                if (fsWorkOrderItem.WorkOrderLineItems != null && fsWorkOrderItem.WorkOrderLineItems.Count > 0)
                                {
                                    TxnEntitySynchronize<BillProxy.WorkOrderLineItem> workOrderLineItemSynchronizer = new TxnEntitySynchronize<BillProxy.WorkOrderLineItem>();
                                    fsWorkOrderItem.WorkOrderLineItems.ForEach(fsWorkOrderLineItem =>
                                    {
                                        WorkOrderLineItem platformWorkOrderLineItem = ctx.WorkOrderLineItems.Where(woli => woli.SourceWorkOrderLineItemId == fsWorkOrderLineItem.WorkOrderLineItemId && TenantHierarchyHelper.TenantApplicationIds.Contains(woli.ApplicationId)).SingleOrDefault();
                                        platformWorkOrderLineItem = (WorkOrderLineItem)workOrderLineItemSynchronizer.Synchronize(fsWorkOrderLineItem, platformWorkOrderLineItem);
                                        if (platformWorkOrderLineItem.WorkOrderLineItemId == 0)
                                        {
                                            platformWorkOrderLineItem.WorkOrderItemId = platformWorkOrderItem.WorkOrderItemId;
                                            ctx.WorkOrderLineItems.Add(platformWorkOrderLineItem);
                                            platformWorkOrderItem.WorkOrderLineItems.Add(platformWorkOrderLineItem);
                                        }
                                        else platformWorkOrderLineItem.WorkOrderLineItemId = platformWorkOrderLineItem.WorkOrderLineItemId;
                                    });
                                }
                            });
                        }
                        ctx.SaveChanges();
                    }
                }
                catch (DbUpdateException dbUpdateEx)
                {
                    if (dbUpdateEx != null && dbUpdateEx.InnerException != null && dbUpdateEx.InnerException.InnerException != null)
                    {
                        SqlException sqlException = dbUpdateEx.InnerException.InnerException as SqlException;
                        if (sqlException != null)
                        {
                            switch (sqlException.Number)
                            {
                                case 2627:  // Unique key constraint
                                    Logging.LogError(string.Format("2. Unique key constraint error as part of Accounting Sync for the work order {0}, exception {1}", fsWorkOrder.WorkOrderId, dbUpdateEx));
                                    break;
                                case 2601: // Duplicate key
                                    Logging.LogError(string.Format("2. Duplicate key error as part of Accounting Sync for the work order {0}, exception {1}", fsWorkOrder.WorkOrderId, dbUpdateEx));
                                    break;
                                default:
                                    CommonLib.Logging.LogError(dbUpdateEx);
                                    throw;
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    CommonLib.Logging.LogError(ex);
                    throw;
                }
            }

            using (AccountingData ctx = new AccountingData())
            {
                WorkOrder platformWorkOrder = ctx.WorkOrders.Include(wo => wo.WorkOrderItems).Where(wo => wo.SourceWorkOrderId == fsWorkOrder.WorkOrderId
                        && TenantHierarchyHelper.TenantApplicationIds.Contains(wo.ApplicationId)).SingleOrDefault();

                if (platformWorkOrder != null && platformWorkOrder.InvoiceDate == null)
                {
                    Order platformOrder = ctx.Orders.Where(od => od.SourceOrderId == fsWorkOrder.Order.OrderId && TenantHierarchyHelper.TenantApplicationIds.Contains(od.ApplicationId)).SingleOrDefault();
                    Loan platformLoan = ctx.Loans.Where(ln => ln.SourceLoanId == fsWorkOrder.Order.Loan.LoanId && TenantHierarchyHelper.TenantApplicationIds.Contains(ln.ApplicationId)).SingleOrDefault();
                    try
                    {
                        //Sync Accounts Payable
                        if (fsWorkOrder.AccountsPayable != null && fsWorkOrder.AccountsPayable.Count > 0)
                        {
                            TxnEntitySynchronize<BillProxy.AccountsPayable> apSynchronizer = new TxnEntitySynchronize<BillProxy.AccountsPayable>();
                            fsWorkOrder.AccountsPayable.ForEach(fsAccountsPayable =>
                            {
                                AccountsPayable platformAP = ctx.AccountsPayables.Where(at => at.SourceAccountsPayableId == fsAccountsPayable.AccountsPayableId && TenantHierarchyHelper.TenantApplicationIds.Contains(at.ApplicationId)).SingleOrDefault();
                                if (platformAP == null)
                                {
                                    platformAP = (AccountsPayable)apSynchronizer.Synchronize(fsAccountsPayable, platformAP);
                                    if (platformAP.AccountsPayableId == 0)
                                    {
                                        platformAP.WorkOrderId = platformWorkOrder.WorkOrderId;
                                        ctx.AccountsPayables.Add(platformAP);
                                    }
                                    else platformAP.AccountsPayableId = platformAP.AccountsPayableId;

                                    //Sync Accounts Payable Details
                                    if (fsAccountsPayable.AccountsPayableDetails != null && fsAccountsPayable.AccountsPayableDetails.Count > 0)
                                    {
                                        TxnEntitySynchronize<BillProxy.AccountsPayableDetail> apDetailSynchronizer = new TxnEntitySynchronize<BillProxy.AccountsPayableDetail>();
                                        fsAccountsPayable.AccountsPayableDetails.ForEach(fsAPDetail =>
                                        {
                                            AccountsPayableDetail platformAPDetail = ctx.AccountsPayableDetails.Where(p => p.SourceAccountsPayableDetailId == fsAPDetail.AccountsPayableDetailId && TenantHierarchyHelper.TenantApplicationIds.Contains(p.ApplicationId)).SingleOrDefault();
                                            if (platformAPDetail == null)
                                            {
                                                platformAPDetail = (AccountsPayableDetail)apDetailSynchronizer.Synchronize(fsAPDetail, platformAPDetail);
                                                if (platformAPDetail.AccountsPayableDetailId == 0)
                                                {
                                                    platformAPDetail.AccountsPayableId = platformAP.AccountsPayableId;
                                                    platformAPDetail.WorkOrderItemId = platformWorkOrder.WorkOrderItems.First().WorkOrderItemId;
                                                    ctx.AccountsPayableDetails.Add(platformAPDetail);
                                                    platformAP.AccountsPayableDetails.Add(platformAPDetail);
                                                }
                                                else platformAPDetail.AccountsPayableDetailId = platformAPDetail.AccountsPayableDetailId;

                                                //Sync Accounts Payable Trace
                                                if (fsAPDetail.AccountsPayableTraces != null && fsAPDetail.AccountsPayableTraces.Count > 0)
                                                {
                                                    TxnEntitySynchronize<BillProxy.AccountsPayableTrace> apTraceSynchronizer = new TxnEntitySynchronize<BillProxy.AccountsPayableTrace>();
                                                    fsAPDetail.AccountsPayableTraces.ForEach(fsAPTrace =>
                                                    {
                                                        AccountsPayableTrace platformAPTrace = ctx.AccountsPayableTraces.Where(p => p.SourceAccountsPayableTraceId == fsAPTrace.AccountsPayableTraceId && TenantHierarchyHelper.TenantApplicationIds.Contains(p.ApplicationId)).SingleOrDefault();
                                                        platformAPTrace = (AccountsPayableTrace)apTraceSynchronizer.Synchronize(fsAPTrace, platformAPTrace);
                                                        if (platformAPTrace.AccountsPayableTraceId == 0)
                                                        {
                                                            platformAPTrace.AccountsPayableDetailId = platformAPDetail.AccountsPayableDetailId;
                                                            ctx.AccountsPayableTraces.Add(platformAPTrace);
                                                            platformAPDetail.AccountsPayableTraces.Add(platformAPTrace);
                                                        }
                                                    });
                                                }
                                            }
                                        });
                                    }
                                }
                            });
                        }

                        //Sync Accounts Receivable
                        if (fsWorkOrder.AccountsReceivable != null && fsWorkOrder.AccountsReceivable.Count > 0)
                        {
                            TxnEntitySynchronize<BillProxy.AccountsReceivable> arSynchronizer = new TxnEntitySynchronize<BillProxy.AccountsReceivable>();
                            fsWorkOrder.AccountsReceivable.ForEach(fsAccountsReceivable =>
                            {
                                AccountsReceivable platformAR = ctx.AccountsReceivables.Where(at => at.SourceAccountsReceivableId == fsAccountsReceivable.AccountsReceivableId && TenantHierarchyHelper.TenantApplicationIds.Contains(at.ApplicationId)).SingleOrDefault();
                                if (platformAR == null)
                                {
                                    platformAR = (AccountsReceivable)arSynchronizer.Synchronize(fsAccountsReceivable, platformAR);
                                    if (platformAR.AccountsReceivableId == 0)
                                    {
                                        platformAR.WorkOrderId = platformWorkOrder.WorkOrderId;
                                        ctx.AccountsReceivables.Add(platformAR);
                                    }
                                    else platformAR.AccountsReceivableId = platformAR.AccountsReceivableId;

                                    //Sync Accounts Receivable Details
                                    if (fsAccountsReceivable.AccountsReceivableDetails != null && fsAccountsReceivable.AccountsReceivableDetails.Count > 0)
                                    {
                                        TxnEntitySynchronize<BillProxy.AccountsReceivableDetail> arDetailSynchronizer = new TxnEntitySynchronize<BillProxy.AccountsReceivableDetail>();
                                        fsAccountsReceivable.AccountsReceivableDetails.ForEach(fsARDetail =>
                                        {
                                            AccountsReceivableDetail platformARDetail = ctx.AccountsReceivableDetails.Where(p => p.SourceAccountsReceivableDetailId == fsARDetail.AccountsReceivableDetailId && TenantHierarchyHelper.TenantApplicationIds.Contains(p.ApplicationId)).SingleOrDefault();
                                            if (platformARDetail == null)
                                            {
                                                platformARDetail = (AccountsReceivableDetail)arDetailSynchronizer.Synchronize(fsARDetail, platformARDetail);
                                                if (platformARDetail.AccountsReceivableDetailId == 0)
                                                {
                                                    platformARDetail.AccountsReceivableId = platformAR.AccountsReceivableId;
                                                    platformARDetail.WorkOrderItemId = platformWorkOrder.WorkOrderItems.First().WorkOrderItemId;
                                                    ctx.AccountsReceivableDetails.Add(platformARDetail);
                                                    platformAR.AccountsReceivableDetails.Add(platformARDetail);
                                                }
                                                else platformARDetail.AccountsReceivableDetailId = platformARDetail.AccountsReceivableDetailId;

                                                //Sync Accounts Receivable Trace
                                                if (fsARDetail.AccountsReceivableTraces != null && fsARDetail.AccountsReceivableTraces.Count > 0)
                                                {
                                                    TxnEntitySynchronize<BillProxy.AccountsReceivableTrace> arTraceSynchronizer = new TxnEntitySynchronize<BillProxy.AccountsReceivableTrace>();
                                                    fsARDetail.AccountsReceivableTraces.ForEach(fsARTrace =>
                                                    {
                                                        AccountsReceivableTrace platformARTrace = ctx.AccountsReceivableTraces.Where(p => p.SourceAccountsReceivableTraceId == fsARTrace.AccountsReceivableTraceId && TenantHierarchyHelper.TenantApplicationIds.Contains(p.ApplicationId)).SingleOrDefault();
                                                        platformARTrace = (AccountsReceivableTrace)arTraceSynchronizer.Synchronize(fsARTrace, platformARTrace);
                                                        if (platformARTrace.AccountsReceivableTraceId == 0)
                                                        {
                                                            platformARTrace.AccountsReceivableDetailId = platformARDetail.AccountsReceivableDetailId;
                                                            ctx.AccountsReceivableTraces.Add(platformARTrace);
                                                            platformARDetail.AccountsReceivableTraces.Add(platformARTrace);
                                                        }
                                                    });
                                                }
                                            }
                                        });
                                    }
                                }
                            });
                        }
                        ctx.SaveChanges();

                        // Sync Order Hierarchy
                        if (fsWorkOrder.OrderHierarchy != null && fsWorkOrder.OrderHierarchy.Count > 0)
                        {
                            TxnEntitySynchronize<BillProxy.OrderHierarchy> orderHierarchyItemSynchronizer = new TxnEntitySynchronize<BillProxy.OrderHierarchy>();
                            fsWorkOrder.OrderHierarchy.ForEach(fsOrderHierarchy =>
                            {
                                int? oOrderId = new Nullable<int>();
                                int? oVWOOrderId = new Nullable<int>();
                                int? oWorkOrderId = new Nullable<int>();
                                int? oWorkOrderItemId = new Nullable<int>();
                                int? oWorkOrderLineItemId = new Nullable<int>();

                                if (fsOrderHierarchy.OrderId > 0)
                                {
                                    Order pltOrder = ctx.Orders.Where(od => od.SourceOrderId == fsOrderHierarchy.OrderId
                                        && TenantHierarchyHelper.TenantApplicationIds.Contains(od.ApplicationId)).SingleOrDefault();
                                    if (pltOrder != null)
                                        oOrderId = pltOrder.OrderId;
                                }
                                if (fsOrderHierarchy.VendorWorkOrderId.HasValue)
                                {
                                    VendorWorkOrder pltVWO = ctx.VendorWorkOrders.Where(ln => ln.SourceVendorWorkOrderId == fsOrderHierarchy.VendorWorkOrderId.Value
                                        && TenantHierarchyHelper.TenantApplicationIds.Contains(ln.ApplicationId)).SingleOrDefault();
                                    if (pltVWO != null)
                                        oVWOOrderId = pltVWO.VendorWorkOrderId;
                                }
                                if (fsOrderHierarchy.WorkOrderId.HasValue)
                                {
                                    WorkOrder pltWorkOrder = ctx.WorkOrders.Where(wo => wo.SourceWorkOrderId == fsOrderHierarchy.WorkOrderId.Value
                                        && TenantHierarchyHelper.TenantApplicationIds.Contains(wo.ApplicationId)).SingleOrDefault();
                                    if (pltWorkOrder != null)
                                        oWorkOrderId = pltWorkOrder.WorkOrderId;
                                }
                                if (fsOrderHierarchy.WorkOrderItemId.HasValue)
                                {
                                    WorkOrderItem pltWorkOrderItem = ctx.WorkOrderItems.Where(wo => wo.SourceWorkOrderItemId == fsOrderHierarchy.WorkOrderItemId.Value
                                        && TenantHierarchyHelper.TenantApplicationIds.Contains(wo.ApplicationId)).SingleOrDefault();
                                    if (pltWorkOrderItem != null)
                                        oWorkOrderItemId = pltWorkOrderItem.WorkOrderItemId;
                                }
                                if (fsOrderHierarchy.WorkOrderLineItemId.HasValue)
                                {
                                    WorkOrderLineItem pltWorkOrderLineItem = ctx.WorkOrderLineItems.Where(wo => wo.SourceWorkOrderLineItemId == fsOrderHierarchy.WorkOrderLineItemId.Value
                                        && TenantHierarchyHelper.TenantApplicationIds.Contains(wo.ApplicationId)).SingleOrDefault();
                                    if (pltWorkOrderLineItem != null)
                                        oWorkOrderLineItemId = pltWorkOrderLineItem.WorkOrderLineItemId;
                                }

                                OrderHierarchy platformOrderHierarchy = ctx.OrderHierarchys.Where(p => p.OrderId == oOrderId && p.VendorWorkOrderId == oVWOOrderId
                                    && p.WorkOrderId == oWorkOrderId && p.WorkOrderItemId == oWorkOrderItemId
                                    && p.WorkOrderLineItemId == oWorkOrderLineItemId).FirstOrDefault();

                                platformOrderHierarchy = (OrderHierarchy)orderHierarchyItemSynchronizer.Synchronize(fsOrderHierarchy, platformOrderHierarchy);

                                if (platformOrderHierarchy.OrderHierarchyId == 0)
                                {
                                    if (oOrderId.HasValue)
                                        platformOrderHierarchy.OrderId = oOrderId.Value;

                                    if (oVWOOrderId.HasValue)
                                        platformOrderHierarchy.VendorWorkOrderId = oVWOOrderId.Value;

                                    if (oWorkOrderId.HasValue)
                                        platformOrderHierarchy.WorkOrderId = oWorkOrderId.Value;

                                    if (oWorkOrderItemId.HasValue)
                                        platformOrderHierarchy.WorkOrderItemId = oWorkOrderItemId.Value;

                                    if (oWorkOrderLineItemId.HasValue)
                                        platformOrderHierarchy.WorkOrderLineItemId = oWorkOrderLineItemId.Value;

                                    ctx.OrderHierarchys.Add(platformOrderHierarchy);
                                }
                                else platformOrderHierarchy.OrderHierarchyId = platformOrderHierarchy.OrderHierarchyId;

                                //Sync Accounts Payable Details
                                if (fsOrderHierarchy.AccountsPayableDetails != null && fsOrderHierarchy.AccountsPayableDetails.Count > 0)
                                {
                                    TxnEntitySynchronize<BillProxy.AccountsPayableDetail> apDetailSynchronizer = new TxnEntitySynchronize<BillProxy.AccountsPayableDetail>();
                                    fsOrderHierarchy.AccountsPayableDetails.ForEach(fsAPDetail =>
                                    {
                                        AccountsPayableDetail platformAPDetail = ctx.AccountsPayableDetails.Where(p => p.SourceAccountsPayableDetailId == fsAPDetail.AccountsPayableDetailId && TenantHierarchyHelper.TenantApplicationIds.Contains(p.ApplicationId)).SingleOrDefault();
                                        if (platformAPDetail == null)
                                        {
                                            platformAPDetail = (AccountsPayableDetail)apDetailSynchronizer.Synchronize(fsAPDetail, platformAPDetail);
                                            if (platformAPDetail.AccountsPayableDetailId == 0)
                                            {
                                                platformAPDetail.OrderHierarchyId = platformOrderHierarchy.OrderHierarchyId;
                                                ctx.AccountsPayableDetails.Add(platformAPDetail);
                                                platformOrderHierarchy.AccountsPayableDetails.Add(platformAPDetail);
                                            }
                                            else platformAPDetail.AccountsPayableDetailId = platformAPDetail.AccountsPayableDetailId;

                                            //Sync Accounts Payable Trace
                                            if (fsAPDetail.AccountsPayableTraces != null && fsAPDetail.AccountsPayableTraces.Count > 0)
                                            {
                                                TxnEntitySynchronize<BillProxy.AccountsPayableTrace> apTraceSynchronizer = new TxnEntitySynchronize<BillProxy.AccountsPayableTrace>();
                                                fsAPDetail.AccountsPayableTraces.ForEach(fsAPTrace =>
                                                {
                                                    AccountsPayableTrace platformAPTrace = ctx.AccountsPayableTraces.Where(p => p.SourceAccountsPayableTraceId == fsAPTrace.AccountsPayableTraceId && TenantHierarchyHelper.TenantApplicationIds.Contains(p.ApplicationId)).SingleOrDefault();
                                                    platformAPTrace = (AccountsPayableTrace)apTraceSynchronizer.Synchronize(fsAPTrace, platformAPTrace);
                                                    if (platformAPTrace.AccountsPayableTraceId == 0)
                                                    {
                                                        platformAPTrace.AccountsPayableDetailId = platformAPDetail.AccountsPayableDetailId;
                                                        ctx.AccountsPayableTraces.Add(platformAPTrace);
                                                        platformAPDetail.AccountsPayableTraces.Add(platformAPTrace);
                                                    }
                                                });
                                            }
                                        }
                                    });
                                }
                                else
                                {
                                    // ONLY VPR PRODS WHERE NO FEE TRANS Bug#: 78175
                                    if (fsWorkOrder != null && fsOrderHierarchy.WorkOrderId.HasValue && fsOrderHierarchy.WorkOrderId>0)
                                    {
                                        string prodCode = string.Empty;
                                        if (fsWorkOrder.Product == null || fsWorkOrder.Product.ProductId <= 0)
                                            prodCode = (from p in ctx.Products where p.ProductId == fsWorkOrder.ProductId select p.ProductCode).FirstOrDefault();
                                        else
                                            prodCode = fsWorkOrder.Product.ProductCode;

                                        string[] vpr = new string[] { "INITIAL", "RENEWAL", "DEREG", "AMEND", "MUNLTR", "REGINSP", "VIOLNPAY" };

                                        if (!string.IsNullOrEmpty(vpr.FirstOrDefault(p => p == prodCode)))
                                        {
                                            var aptl = GetTrackingLogByWoId(platformWorkOrder.WorkOrderId);
                                            if (aptl == null || aptl.AccountsPayableTrackingLogId <= 0)
                                            {
                                                aptl = new AccountsPayableTrackingLog();
                                                aptl.WorkOrderId = platformWorkOrder.WorkOrderId;
                                                SaveTrackingLog(aptl);
                                            }
                                        }
                                    }
                                }

                                //Sync Accounts Receivable Details
                                if (fsOrderHierarchy.AccountsReceivableDetails != null && fsOrderHierarchy.AccountsReceivableDetails.Count > 0)
                                {
                                    TxnEntitySynchronize<BillProxy.AccountsReceivableDetail> arDetailSynchronizer = new TxnEntitySynchronize<BillProxy.AccountsReceivableDetail>();
                                    fsOrderHierarchy.AccountsReceivableDetails.ForEach(fsARDetail =>
                                    {
                                        AccountsReceivableDetail platformARDetail = ctx.AccountsReceivableDetails.Where(p => p.SourceAccountsReceivableDetailId == fsARDetail.AccountsReceivableDetailId && TenantHierarchyHelper.TenantApplicationIds.Contains(p.ApplicationId)).SingleOrDefault();
                                        if (platformARDetail == null)
                                        {
                                            platformARDetail = (AccountsReceivableDetail)arDetailSynchronizer.Synchronize(fsARDetail, platformARDetail);

                                            if (platformARDetail.AccountsReceivableDetailId == 0)
                                            {
                                                platformARDetail.OrderHierarchyId = platformOrderHierarchy.OrderHierarchyId;
                                                ctx.AccountsReceivableDetails.Add(platformARDetail);
                                                platformOrderHierarchy.AccountsReceivableDetails.Add(platformARDetail);
                                            }
                                            else platformARDetail.AccountsReceivableDetailId = platformARDetail.AccountsReceivableDetailId;

                                            //Sync Accounts Receivable Trace
                                            if (fsARDetail.AccountsReceivableTraces != null && fsARDetail.AccountsReceivableTraces.Count > 0)
                                            {
                                                TxnEntitySynchronize<BillProxy.AccountsReceivableTrace> arTraceSynchronizer = new TxnEntitySynchronize<BillProxy.AccountsReceivableTrace>();
                                                fsARDetail.AccountsReceivableTraces.ForEach(fsARTrace =>
                                                {
                                                    AccountsReceivableTrace platformARTrace = ctx.AccountsReceivableTraces.Where(p => p.SourceAccountsReceivableTraceId == fsARTrace.AccountsReceivableTraceId && TenantHierarchyHelper.TenantApplicationIds.Contains(p.ApplicationId)).SingleOrDefault();
                                                    platformARTrace = (AccountsReceivableTrace)arTraceSynchronizer.Synchronize(fsARTrace, platformARTrace);
                                                    if (platformARTrace.AccountsReceivableTraceId == 0)
                                                    {
                                                        platformARTrace.AccountsReceivableDetailId = platformARDetail.AccountsReceivableDetailId;
                                                        ctx.AccountsReceivableTraces.Add(platformARTrace);
                                                        platformARDetail.AccountsReceivableTraces.Add(platformARTrace);
                                                    }
                                                });
                                            }
                                        }
                                    });
                                }

                                //Sync Dispute Payable AdjustmentHistory
                                if (fsOrderHierarchy.DisputePayableAdjustmentHistorys != null && fsOrderHierarchy.DisputePayableAdjustmentHistorys.Count > 0)
                                {
                                    TxnEntitySynchronize<BillProxy.DisputePayableAdjustmentHistory> payDisDetailSynchronizer = new TxnEntitySynchronize<BillProxy.DisputePayableAdjustmentHistory>();
                                    fsOrderHierarchy.DisputePayableAdjustmentHistorys.ForEach(fsARDis =>
                                    {
                                        DisputePayableAdjustmentHistory platformAPDis = ctx.DisputePayableAdjustmentHistorys.Where(p => p.SourceDisputePayableAdjustmentHistoryId == fsARDis.DisputePayableAdjustmentHistoryId && TenantHierarchyHelper.TenantApplicationIds.Contains(p.ApplicationId)).SingleOrDefault();
                                        if (platformAPDis == null)
                                        {
                                            platformAPDis = (DisputePayableAdjustmentHistory)payDisDetailSynchronizer.Synchronize(fsARDis, platformAPDis);
                                            if (platformAPDis.DisputePayableAdjustmentHistoryId == 0)
                                            {
                                                platformAPDis.OrderHierarchyId = platformOrderHierarchy.OrderHierarchyId;
                                                ctx.DisputePayableAdjustmentHistorys.Add(platformAPDis);
                                                platformOrderHierarchy.DisputePayableAdjustmentHistorys.Add(platformAPDis);
                                            }
                                        }
                                    });
                                }

                                //Sync Dispute Receivable AdjustmentHistory
                                TxnEntitySynchronize<BillProxy.DisputeReceivableAdjustmentHistory> recDisDetailSynchronizer = new TxnEntitySynchronize<BillProxy.DisputeReceivableAdjustmentHistory>();
                                if (fsOrderHierarchy.DisputeReceivableAdjustmentHistorys != null && fsOrderHierarchy.DisputeReceivableAdjustmentHistorys.Count > 0)
                                {
                                    fsOrderHierarchy.DisputeReceivableAdjustmentHistorys.ForEach(fsARDis =>
                                    {
                                        DisputeReceivableAdjustmentHistory platformARDis = ctx.DisputeReceivableAdjustmentHistorys.Where(p => p.SourceDisputeReceivableAdjustmentHistoryId == fsARDis.DisputeReceivableAdjustmentHistoryId && TenantHierarchyHelper.TenantApplicationIds.Contains(p.ApplicationId)).SingleOrDefault();
                                        if (platformARDis == null)
                                        {
                                            platformARDis = (DisputeReceivableAdjustmentHistory)recDisDetailSynchronizer.Synchronize(fsARDis, platformARDis);
                                            if (platformARDis.DisputeReceivableAdjustmentHistoryId == 0)
                                            {
                                                platformARDis.OrderHierarchyId = platformOrderHierarchy.OrderHierarchyId;
                                                ctx.DisputeReceivableAdjustmentHistorys.Add(platformARDis);
                                                platformOrderHierarchy.DisputeReceivableAdjustmentHistorys.Add(platformARDis);
                                            }
                                        }
                                    });
                                }

                                //Sync Dispute Payable AdjustmentHistory
                                if (fsOrderHierarchy.DisputePenaltyAdjustmentHistories != null && fsOrderHierarchy.DisputePenaltyAdjustmentHistories.Count > 0)
                                {
                                    TxnEntitySynchronize<BillProxy.DisputePenaltyAdjustmentHistory> payDisDetailSynchronizer = new TxnEntitySynchronize<BillProxy.DisputePenaltyAdjustmentHistory>();
                                    fsOrderHierarchy.DisputePenaltyAdjustmentHistories.ForEach(fsARDis =>
                                    {
                                        DisputePenaltyAdjustmentHistory platformAPDis = ctx.DisputePenaltyAdjustmentHistories.Where(p => p.SourceDisputePenaltyAdjustmentHistoryId == fsARDis.DisputePenaltyAdjustmentHistoryId ).SingleOrDefault();
                                        if (platformAPDis == null)
                                        {
                                            platformAPDis = (DisputePenaltyAdjustmentHistory)payDisDetailSynchronizer.Synchronize(fsARDis, platformAPDis);
                                            if (platformAPDis.DisputePenaltyAdjustmentHistoryId == 0)
                                            {
                                                platformAPDis.OrderHierarchyId = platformOrderHierarchy.OrderHierarchyId;
                                                ctx.DisputePenaltyAdjustmentHistories.Add(platformAPDis);
                                                platformOrderHierarchy.DisputePenaltyAdjustmentHistories.Add(platformAPDis);
                                            }
                                        }
                                    });
                                }
                            });
                        }

                        //Sync Cancellation
                        if (fsWorkOrder.Order.Cancellations != null && fsWorkOrder.Order.Cancellations.Count > 0)
                        {
                            TxnEntitySynchronize<BillProxy.Cancellation> cancellationSynchronizer = new TxnEntitySynchronize<BillProxy.Cancellation>();
                            foreach (BillProxy.Cancellation presCancellation in fsWorkOrder.Order.Cancellations.Where(c =>
                                (c.CancelledOrderId == null || c.CancelledOrderId.HasValue && c.CancelledOrderId.Value == fsWorkOrder.Order.OrderId) &&
                                (c.CancelledWorkOrderId == null || c.CancelledWorkOrderId.HasValue && c.CancelledWorkOrderId.Value == fsWorkOrder.WorkOrderId)).OrderBy(c => c.CancellationId).ToList())
                            {
                                int? cLoanId = new Nullable<int>();
                                int? cOrderId = new Nullable<int>();
                                int? cWOId = new Nullable<int>();

                                if (presCancellation.CancelledWorkOrderId.HasValue)
                                {
                                    cWOId = platformWorkOrder.WorkOrderId;
                                }
                                if (presCancellation.CancelledOrderId.HasValue)
                                {
                                    cOrderId = platformOrder.OrderId;
                                }
                                if (presCancellation.CancelledLoanId.HasValue)
                                {
                                    cLoanId = platformLoan.LoanId;
                                }

                                Cancellation platformCancellation = ctx.Cancellations.Where(c => c.SourceCancellationId == presCancellation.CancellationId
                                    && TenantHierarchyHelper.TenantApplicationIds.Contains(c.ApplicationId)).SingleOrDefault();
                                platformCancellation = (Cancellation)cancellationSynchronizer.Synchronize(presCancellation, platformCancellation);

                                if (platformCancellation.CancellationId == 0)
                                {
                                    platformCancellation.CancelledLoanId = cLoanId;
                                    platformCancellation.CancelledOrderId = cOrderId;
                                    platformCancellation.CancelledWorkOrderId = cWOId;
                                    ctx.Cancellations.Add(platformCancellation);
                                }
                                else
                                {
                                    platformCancellation.CancelledLoanId = cLoanId;
                                    platformCancellation.CancelledOrderId = cOrderId;
                                    platformCancellation.CancelledWorkOrderId = cWOId;
                                }
                            }
                        }

                        ctx.SaveChanges();
                    }
                    catch (DbUpdateException dbUpdateEx)
                    {
                        if (dbUpdateEx != null && dbUpdateEx.InnerException != null && dbUpdateEx.InnerException.InnerException != null)
                        {
                            SqlException sqlException = dbUpdateEx.InnerException.InnerException as SqlException;
                            if (sqlException != null)
                            {
                                switch (sqlException.Number)
                                {
                                    case 2627:  // Unique key constraint
                                        Logging.LogError(string.Format("3. Unique key constraint error as part of Accounting Sync for the work order {0}, exception {1}", fsWorkOrder.WorkOrderId, dbUpdateEx));
                                        break;
                                    case 2601: // Duplicate key
                                        Logging.LogError(string.Format("3. Duplicate key error as part of Accounting Sync for the work order {0}, exception {1}", fsWorkOrder.WorkOrderId, dbUpdateEx));
                                        break;
                                    default:
                                        CommonLib.Logging.LogError(dbUpdateEx);
                                        throw;
                                }
                            }
                        }
                    }


                    catch (Exception ex)
                    {
                        CommonLib.Logging.LogError(ex);
                        throw;
                    }

                }

            }


        }

        private sealed class TxnEntitySynchronize<T> where T : class
        {
            private static HashSet<KeyValuePair<Type, Type>> _SyncMap = new HashSet<KeyValuePair<Type, Type>>
            {
                new KeyValuePair<Type, Type>(typeof(BillProxy.Asset), typeof(Asset)), 
                new KeyValuePair<Type, Type>(typeof(BillProxy.Loan), typeof(Loan)),
                new KeyValuePair<Type, Type>(typeof(BillProxy.Order), typeof(Order)), 
                new KeyValuePair<Type, Type>(typeof(BillProxy.WorkOrder), typeof(WorkOrder)),
                new KeyValuePair<Type, Type>(typeof(BillProxy.WorkOrderItem), typeof(WorkOrderItem)),
                new KeyValuePair<Type, Type>(typeof(BillProxy.WorkOrderLineItem), typeof(WorkOrderLineItem)),
                new KeyValuePair<Type, Type>(typeof(BillProxy.VendorWorkOrder), typeof(VendorWorkOrder)),
                new KeyValuePair<Type, Type>(typeof(BillProxy.Cancellation), typeof(Cancellation)),
                new KeyValuePair<Type, Type>(typeof(BillProxy.AccountsPayable), typeof(AccountsPayable)),
                new KeyValuePair<Type, Type>(typeof(BillProxy.AccountsPayableDetail), typeof(AccountsPayableDetail)),
                new KeyValuePair<Type, Type>(typeof(BillProxy.AccountsPayableTrace), typeof(AccountsPayableTrace)),
                new KeyValuePair<Type, Type>(typeof(BillProxy.AccountsReceivable), typeof(AccountsReceivable)),
                new KeyValuePair<Type, Type>(typeof(BillProxy.AccountsReceivableDetail), typeof(AccountsReceivableDetail)),
                new KeyValuePair<Type, Type>(typeof(BillProxy.AccountsReceivableTrace), typeof(AccountsReceivableTrace)),
                new KeyValuePair<Type, Type>(typeof(BillProxy.DisputePayableAdjustmentHistory), typeof(DisputePayableAdjustmentHistory)),
                new KeyValuePair<Type, Type>(typeof(BillProxy.DisputeReceivableAdjustmentHistory), typeof(DisputeReceivableAdjustmentHistory)),
                new KeyValuePair<Type, Type>(typeof(BillProxy.DisputePenaltyAdjustmentHistory), typeof(DisputePenaltyAdjustmentHistory)),
                new KeyValuePair<Type, Type>(typeof(BillProxy.OrderHierarchy), typeof(OrderHierarchy))
            };

            private static List<string> _IgnoredPropList = new List<string>
            {
                "CreatedById",
                //"CreatedDate",
                "LastUpdatedById",
                "LastUpdatedDate",
                "DBCreatedBy",
                "DBCreatedDate",
                "DBLastUpdatedBy",
                "DBLastUpdatedDate",
                "Version",
                "AssetId",
                "LoanId",
                "OrderId",
                "WorkOrderId",
                "WorkOrderItemId",
                "WorkOrderLineItemId",
                "VendorWorkOrderId",
                "CancellationId",
                "CancelledWorkOrderId",
                "CancelledOrderId",
                "CancelledLoanId",
                "AccountsPayableId",
                "AccountsPayableDetailId",
                "AccountsPayableTraceId",
                "AccountsReceivableId",
                "AccountsReceivableDetailId",
                "AccountsReceivableTraceId",
                "DisputePayableAdjustmentHistoryId",
                "DisputeReceivableAdjustmentHistoryId",
                "DisputePenaltyAdjustmentHistoryId",
                "OrderHierarchyId"
            };

            private static ConcurrentDictionary<Type, List<PropertyInfo>> _SyncFields = new ConcurrentDictionary<Type, List<PropertyInfo>>();

            private static PropertyInfo _ApplicationIdProp(Type targetType)
            {
                return targetType == null ? null : targetType.GetProperty("ApplicationId", BindingFlags.Instance | BindingFlags.Public | BindingFlags.IgnoreCase);
            }

            internal TxnEntitySynchronize()
            {
                if (_SyncMap.SingleOrDefault(map => map.Key.Equals(typeof(T))).Key == null || _SyncMap.SingleOrDefault(map => map.Key.Equals(typeof(T))).Value == null)
                    throw new NotSupportedException("TxnEntitySynchronize doesn't support synchronization of intended type: " + typeof(T).FullName);
            }

            internal object Synchronize(T DtoObj, object platformTxnObj)
            {
                if (DtoObj == null) throw new ArgumentNullException("DtoObj");
                Type targetType = _SyncMap.Single(map => map.Key.Equals(typeof(T))).Value;
                if (platformTxnObj != null && !(platformTxnObj.GetType() == targetType || platformTxnObj.GetType().IsSubclassOf(targetType)))
                    throw new ArgumentException(string.Format("{0} is not supported as synchronization target for {1}", platformTxnObj.GetType().FullName, typeof(T).FullName), "platformTxnObj");

                object targetObj = platformTxnObj != null ? platformTxnObj : Activator.CreateInstance(targetType);
                PropertyInfo applicationIdProp = _ApplicationIdProp(targetType);
                if (applicationIdProp != null && (int)applicationIdProp.GetValue(targetObj) == 0) applicationIdProp.SetValue(targetObj, TenantHierarchyHelper.LowestTenantApplicationId);

                List<PropertyInfo> tgtPropList = _SyncFields.GetOrAdd(targetType, targetType.GetProperties(BindingFlags.Instance | BindingFlags.Public | BindingFlags.IgnoreCase)
                    .Where(pi => pi.PropertyType.IsPrimitive || pi.PropertyType.IsValueType || pi.PropertyType == typeof(string))
                    .Where(pi => !_IgnoredPropList.Contains(pi.Name)).ToList());
                List<PropertyInfo> srcPropList = _SyncFields.GetOrAdd(typeof(T), typeof(T).GetProperties(BindingFlags.Instance | BindingFlags.Public | BindingFlags.IgnoreCase)
                    .Where(pi => pi.PropertyType.IsPrimitive || pi.PropertyType.IsValueType || pi.PropertyType == typeof(string))
                    .Where(pi => !_IgnoredPropList.Contains(pi.Name)).ToList());
                if (tgtPropList != null && tgtPropList.Count > 0)
                    tgtPropList.ForEach(prop =>
                    {
                        PropertyInfo srcProp = srcPropList.SingleOrDefault(pi => string.Compare(pi.Name, prop.Name, false) == 0);
                        if (srcProp == null)
                        {
                            CommonLib.ModelAttrib.MapPropAttribute mapAttr = prop.GetCustomAttributes(typeof(CommonLib.ModelAttrib.MapPropAttribute), false)
                                                                             .Cast<CommonLib.ModelAttrib.MapPropAttribute>().SingleOrDefault();
                            if (mapAttr != null)
                                srcProp = srcPropList.SingleOrDefault(pi => string.Compare(pi.Name, mapAttr.MapFrom, false) == 0);
                        }
                        if (srcProp != null)
                        {
                            if (srcProp.PropertyType != typeof(DateTime) && srcProp.PropertyType != typeof(Nullable<DateTime>))
                                prop.SetValue(targetObj, srcProp.GetValue(DtoObj));
                            else
                            {
                                DateTime dt = srcProp.GetValue(DtoObj) != null ? (DateTime)srcProp.GetValue(DtoObj) : DateTime.MinValue;
                                if (dt != DateTime.MinValue)
                                {
                                    prop.SetValue(targetObj, dt);
                                    /*
                                    if (dt.Kind == DateTimeKind.Utc)
                                        prop.SetValue(targetObj, dt);
                                    else if (dt.Kind == DateTimeKind.Local)
                                        prop.SetValue(targetObj, TimeZoneInfo.ConvertTimeToUtc(dt));
                                    else
                                        prop.SetValue(targetObj, TimeZoneInfo.ConvertTimeToUtc(dt, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time")));

                                    if (srcProp.Name == "AcctProcessedDate")
                                    {
                                        prop.SetValue(targetObj, dt);
                                    }
                                    */
                                }
                                else
                                    prop.SetValue(targetObj, null);
                            }
                        }
                    }
                );

                if (typeof(T) == typeof(BillProxy.Asset)) ((Asset)targetObj).SourceAssetId = (DtoObj as BillProxy.Asset).AssetId;
                else if (typeof(T) == typeof(BillProxy.Loan)) ((Loan)targetObj).SourceLoanId = (DtoObj as BillProxy.Loan).LoanId;
                else if (typeof(T) == typeof(BillProxy.Order)) ((Order)targetObj).SourceOrderId = (DtoObj as BillProxy.Order).OrderId;
                else if (typeof(T) == typeof(BillProxy.WorkOrder)) ((WorkOrder)targetObj).SourceWorkOrderId = (DtoObj as BillProxy.WorkOrder).WorkOrderId;
                else if (typeof(T) == typeof(BillProxy.WorkOrderItem)) ((WorkOrderItem)targetObj).SourceWorkOrderItemId = (DtoObj as BillProxy.WorkOrderItem).WorkOrderItemId;
                else if (typeof(T) == typeof(BillProxy.WorkOrderLineItem)) ((WorkOrderLineItem)targetObj).SourceWorkOrderLineItemId = (DtoObj as BillProxy.WorkOrderLineItem).WorkOrderLineItemId;
                else if (typeof(T) == typeof(BillProxy.Cancellation)) ((Cancellation)targetObj).SourceCancellationId = (DtoObj as BillProxy.Cancellation).CancellationId;
                else if (typeof(T) == typeof(BillProxy.VendorWorkOrder)) ((VendorWorkOrder)targetObj).SourceVendorWorkOrderId = (DtoObj as BillProxy.VendorWorkOrder).VendorWorkOrderId;
                else if (typeof(T) == typeof(BillProxy.AccountsPayable)) ((AccountsPayable)targetObj).SourceAccountsPayableId = (DtoObj as BillProxy.AccountsPayable).AccountsPayableId;
                else if (typeof(T) == typeof(BillProxy.AccountsPayableDetail)) ((AccountsPayableDetail)targetObj).SourceAccountsPayableDetailId = (DtoObj as BillProxy.AccountsPayableDetail).AccountsPayableDetailId;
                else if (typeof(T) == typeof(BillProxy.AccountsPayableTrace)) ((AccountsPayableTrace)targetObj).SourceAccountsPayableTraceId = (DtoObj as BillProxy.AccountsPayableTrace).AccountsPayableTraceId;
                else if (typeof(T) == typeof(BillProxy.AccountsReceivable)) ((AccountsReceivable)targetObj).SourceAccountsReceivableId = (DtoObj as BillProxy.AccountsReceivable).AccountsReceivableId;
                else if (typeof(T) == typeof(BillProxy.AccountsReceivableDetail)) ((AccountsReceivableDetail)targetObj).SourceAccountsReceivableDetailId = (DtoObj as BillProxy.AccountsReceivableDetail).AccountsReceivableDetailId;
                else if (typeof(T) == typeof(BillProxy.AccountsReceivableTrace)) ((AccountsReceivableTrace)targetObj).SourceAccountsReceivableTraceId = (DtoObj as BillProxy.AccountsReceivableTrace).AccountsReceivableTraceId;
                else if (typeof(T) == typeof(BillProxy.DisputePayableAdjustmentHistory)) ((DisputePayableAdjustmentHistory)targetObj).SourceDisputePayableAdjustmentHistoryId = (DtoObj as BillProxy.DisputePayableAdjustmentHistory).DisputePayableAdjustmentHistoryId;
                else if (typeof(T) == typeof(BillProxy.DisputeReceivableAdjustmentHistory)) ((DisputeReceivableAdjustmentHistory)targetObj).SourceDisputeReceivableAdjustmentHistoryId = (DtoObj as BillProxy.DisputeReceivableAdjustmentHistory).DisputeReceivableAdjustmentHistoryId;
                else if (typeof(T) == typeof(BillProxy.DisputePenaltyAdjustmentHistory)) ((DisputePenaltyAdjustmentHistory)targetObj).SourceDisputePenaltyAdjustmentHistoryId = (DtoObj as BillProxy.DisputePenaltyAdjustmentHistory).DisputePenaltyAdjustmentHistoryId;
                else if (typeof(T) == typeof(BillProxy.OrderHierarchy)) ((OrderHierarchy)targetObj).SourceOrderHierarchyId = (DtoObj as BillProxy.OrderHierarchy).OrderHierarchyId;

                return targetObj;
            }
        }
    }
}
