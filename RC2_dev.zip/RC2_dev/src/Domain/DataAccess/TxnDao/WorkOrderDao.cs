﻿using System;
using System.Collections.Generic;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RefactorThis.GraphDiff;
using DomainModel.Accounting;

namespace DataAccess.Accounting.Subscriber
{
    public enum WorkOrderStatusEnum
    {
        CANCEL,
        COMP,
        ASGNED,
        EXTEND,
        PENDASSG,
        REASSGN,
        SUBMIT,
        INPROC,
        LOC,
        PENDCANC,
        QCINPROC,
        BILL,
        REJVEND,
        VENDACPT,
        BILLED,
        QC1REJCT
    }
    public class WorkOrderDao
    {
        public WorkOrder SaveWorkOrderWithUpdateGraph(WorkOrder workOrder)
        {
            WorkOrder wo = null;
            using (var ctx = new AccountingData())
            {
                wo = ctx.UpdateGraph(workOrder, map => map);
                ctx.SaveChanges();
            }
            return wo;
        }
        public WorkOrder SaveWorkOrder(WorkOrder workOrder)
        {
            if (workOrder == null) throw new ArgumentNullException("workOrder");
            using (var ctx = new AccountingData())
            {
                bool saveFailed = false;
                int tryCount = 0;
                do
                {
                    try
                    {
                        ctx.Entry<WorkOrder>(workOrder).State = System.Data.Entity.EntityState.Modified;
                        ctx.SaveChanges();
                        saveFailed = false;
                    }
                    catch (DbUpdateConcurrencyException ex)
                    {
                        saveFailed = true;
                        tryCount++;
                        if (tryCount <= AccountingData.DbUpdateConcurrencyException_ReTryLimit)
                        {
                            // Update original values from the database 
                            foreach (var entry in ex.Entries)
                            {
                                var dbValue = entry.GetDatabaseValues();
                                if (dbValue != null)
                                    entry.OriginalValues.SetValues(dbValue);
                                else
                                {
                                    saveFailed = false; //give up since the original db record is deleted and there is no reason to retry
                                    break;
                                }
                            }
                        }
                        else
                        {
                            CommonLib.Logging.LogError(ex);
                            throw;
                        }
                    }
                } while (saveFailed && tryCount <= AccountingData.DbUpdateConcurrencyException_ReTryLimit);                
            }
            return workOrder;
        }

        public WorkOrder GetWorkOrder(int workOrderId)
        {
            using (var ctx = new AccountingData())
            {
                return ctx.WorkOrders.Where(a => a.WorkOrderId == workOrderId && TenantHierarchyHelper.TenantApplicationIds.Contains(a.ApplicationId)).FirstOrDefault();
            }
        }
        public WorkOrder GetWorkOrder(int AppId, int SourceWorkOrderId)
        {
            using (var ctx = new AccountingData())
            {
                return ctx.WorkOrders.Where(a => a.ApplicationId == AppId && a.SourceWorkOrderId == SourceWorkOrderId).FirstOrDefault();
            }
        }

        public List<WorkOrder> GetWorkOrdersByOrderId(int orderId)
        {
            using (var ctx = new AccountingData())
            {
                return ctx.WorkOrders.Where(a => a.OrderId == orderId && TenantHierarchyHelper.TenantApplicationIds.Contains(a.ApplicationId)).ToList();
            }
        }
    }
}
