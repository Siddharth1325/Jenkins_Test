﻿using System;
using System.Collections.Generic;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RefactorThis.GraphDiff;
using DomainModel.Accounting;

namespace DataAccess.Accounting.Subscriber
{
    public class AssetDao
    {
        public Asset SaveAsset(Asset asset)
        {
            if (asset == null) throw new ArgumentNullException("asset");
            using (var ctx = new AccountingData())
            {
                bool saveFailed = false;
                int tryCount = 0;
                do
                {
                    try
                    {
                        ctx.Entry<Asset>(asset).State = System.Data.Entity.EntityState.Modified;
                        ctx.SaveChanges();
                        saveFailed = false;
                    }
                    catch (DbUpdateConcurrencyException ex)
                    {
                        saveFailed = true;
                        tryCount++;
                        if (tryCount <= AccountingData.DbUpdateConcurrencyException_ReTryLimit)
                        {
                            // Update original values from the database 
                            foreach (var entry in ex.Entries)
                            {
                                var dbValue = entry.GetDatabaseValues();
                                if (dbValue != null)
                                    entry.OriginalValues.SetValues(dbValue);
                                else
                                {
                                    saveFailed = false; //give up since the original db record is deleted and there is no reason to retry
                                    break;
                                }
                            }
                        }
                        else
                        {
                            CommonLib.Logging.LogError(ex);
                            throw;
                        }
                    }
                } while (saveFailed && tryCount <= AccountingData.DbUpdateConcurrencyException_ReTryLimit);  
            }
            return asset;
        }

        public Asset GetAsset(int assetId)
        {
            using (var ctx = new AccountingData())
            {
                return ctx.Assets.Where(a => a.AssetId == assetId && TenantHierarchyHelper.TenantApplicationIds.Contains(a.ApplicationId)).FirstOrDefault();
            }
        }

        public Asset GetAsset(int AppId, int SourceAssetId)
        {
            using (var ctx = new AccountingData())
            {
                return ctx.Assets.Where(a => a.ApplicationId == AppId && a.SourceAssetId == SourceAssetId).FirstOrDefault();
            }
        }
    }
}
