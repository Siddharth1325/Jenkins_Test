﻿using System;
using System.Collections.Generic;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DomainModel.Accounting;
using RefactorThis.GraphDiff;

namespace DataAccess.Accounting.Subscriber
{
    public class CancellationDao
    {
        public Cancellation SaveCancellation(Cancellation cancellation)
        {
            if (cancellation == null) throw new ArgumentNullException("cancellation");
            using (var ctx = new AccountingData())
            {
                bool saveFailed = false;
                int tryCount = 0;
                do
                {
                    try
                    {
                        ctx.Entry<Cancellation>(cancellation).State = System.Data.Entity.EntityState.Modified;
                        ctx.SaveChanges();
                        saveFailed = false;
                    }
                    catch (DbUpdateConcurrencyException ex)
                    {
                        saveFailed = true;
                        tryCount++;
                        if (tryCount <= AccountingData.DbUpdateConcurrencyException_ReTryLimit)
                        {
                            // Update original values from the database 
                            foreach (var entry in ex.Entries)
                            {
                                var dbValue = entry.GetDatabaseValues();
                                if (dbValue != null)
                                    entry.OriginalValues.SetValues(dbValue);
                                else
                                {
                                    saveFailed = false; //give up since the original db record is deleted and there is no reason to retry
                                    break;
                                }
                            }
                        }
                        else
                        {
                            CommonLib.Logging.LogError(ex);
                            throw;
                        }
                    }
                } while (saveFailed && tryCount <= AccountingData.DbUpdateConcurrencyException_ReTryLimit);  
            }
            return cancellation;
        }

        public Cancellation GetCancellation(int cancellationId)
        {
            using (var ctx = new AccountingData())
            {
                return ctx.Cancellations.Where(a => a.CancellationId == cancellationId && TenantHierarchyHelper.TenantApplicationIds.Contains(a.ApplicationId)).FirstOrDefault();
            }
        }

        public List<Cancellation> GetCancellationListByOrderId(int orderId)
        {
            using (var ctx = new AccountingData())
            {
                return ctx.Cancellations.Where(a => a.CancelledOrderId == orderId && TenantHierarchyHelper.TenantApplicationIds.Contains(a.ApplicationId)).ToList();
            }
        }
    }
}
