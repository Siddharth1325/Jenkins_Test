﻿using System;
using System.Collections.Generic;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RefactorThis.GraphDiff;
using DomainModel.Accounting;
using DomainModel.Common;

namespace DataAccess.Accounting.Subscriber
{
    public class OrderDao
    {
        public Order SaveOrder(Order order)
        {
            if (order == null) throw new ArgumentNullException("order");
            using (var ctx = new AccountingData())
            {
                bool saveFailed = false;
                int tryCount = 0;
                do
                {
                    try
                    {
                        ctx.Entry<Order>(order).State = System.Data.Entity.EntityState.Modified;   
                        ctx.SaveChanges();
                        saveFailed = false;
                    }
                    catch (DbUpdateConcurrencyException ex)
                    {
                        saveFailed = true;
                        tryCount++;
                        if (tryCount <= AccountingData.DbUpdateConcurrencyException_ReTryLimit)
                        {
                            // Update original values from the database 
                            foreach (var entry in ex.Entries)
                            {
                                var dbValue = entry.GetDatabaseValues();
                                if (dbValue != null)
                                    entry.OriginalValues.SetValues(dbValue);
                                else
                                {
                                    saveFailed = false; //give up since the original db record is deleted and there is no reason to retry
                                    break;
                                }
                            }
                        }
                        else
                        {
                            CommonLib.Logging.LogError(ex);
                            throw;
                        }
                    }
                } while (saveFailed && tryCount <= AccountingData.DbUpdateConcurrencyException_ReTryLimit);  
            }
            return order;
        }

        public Order GetOrder(int OrderId, CommonEnums.OrderChild orderChild)
        {
            using (var ctx = new AccountingData())
            {
                switch(orderChild)
                {
                    case CommonEnums.OrderChild.None:
                        return ctx.Orders
                            .Where(a => a.OrderId == OrderId && TenantHierarchyHelper.TenantApplicationIds.Contains(a.ApplicationId)).FirstOrDefault();

                    case CommonEnums.OrderChild.Loan:
                        return ctx.Orders.Include("Loan")
                            .Where(a => a.OrderId == OrderId && TenantHierarchyHelper.TenantApplicationIds.Contains(a.ApplicationId)).FirstOrDefault();

                    case CommonEnums.OrderChild.WorkOrder:
                        return ctx.Orders.Include("WorkOrders")
                            .Where(a => a.OrderId == OrderId && TenantHierarchyHelper.TenantApplicationIds.Contains(a.ApplicationId)).FirstOrDefault();

                    case CommonEnums.OrderChild.WorkOrderItem:
                        return ctx.Orders.Include("WorkOrders.WorkOrderItems")
                            .Where(a => a.OrderId == OrderId && TenantHierarchyHelper.TenantApplicationIds.Contains(a.ApplicationId)).FirstOrDefault();

                    case CommonEnums.OrderChild.Cancellation:
                        return ctx.Orders.Include("Cancellations")
                            .Where(a => a.OrderId == OrderId && TenantHierarchyHelper.TenantApplicationIds.Contains(a.ApplicationId)).FirstOrDefault();

                    case CommonEnums.OrderChild.All:
                        return ctx.Orders.Include("Loan").Include("WorkOrders").Include("WorkOrders.WorkOrderItems").Include("Cancellations")
                            .Where(a => a.OrderId == OrderId && TenantHierarchyHelper.TenantApplicationIds.Contains(a.ApplicationId)).FirstOrDefault();
                }

                return null;
            }
        }
        public Order GetOrder(int AppId, int SourceOrderId)
        {
            using (var ctx = new AccountingData())
            {
                return ctx.Orders.Where(a => a.ApplicationId == AppId && a.SourceOrderId == SourceOrderId).FirstOrDefault();
            }
        }
    }
}
